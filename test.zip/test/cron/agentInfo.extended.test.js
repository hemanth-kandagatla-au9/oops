const agentModel = require('../../server/models/agentModel');
const sapMasterdataModule = require('../../server/models/sapMasterdataModel');

jest.mock('../../server/models/agentModel', () => ({
  findOne: jest.fn(),
  bulkWrite: jest.fn(),
  updateMany: jest.fn(),
  find: jest.fn(),
  updateOne: jest.fn(),
}));

jest.mock('../../server/models/sapMasterdataModel', () =>
  jest.fn(() =>
    Promise.resolve({ findOne: jest.fn() })
  )
);

jest.mock('../../server/utils/envUtils', () => ({
  getOpenSearchPassword: jest.fn().mockResolvedValue('mockedPassword'),
  getMongoConnectionURL: jest.fn(() => 'mocked-url'),
}));

jest.mock('node-fetch', () => jest.fn());

const { getOpenSearchPassword } = require('../../server/utils/envUtils');
const fetch = require('node-fetch');

const {
  insertintoDB,
  updateFailedAgent,
  syncAgentStatus,
  syncDiscoveryData,
  fetchDataByTimeInterval,
} = require('../../server/cron/agentInfo');

describe('agentInfo extended tests', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'error').mockImplementation(() => {});
    process.env.OPENSEARCH_USER = 'user';
    process.env.OPENSEARCH_NON_PROD_PASSWORD = 'pass';
    process.env.OPENSEARCH_URL = 'http://opensearch.test';
    process.env.OPENSEARCH_HEALTH_DISCOVERY_INDEX = 'health-index';
  });

  afterEach(() => {
    console.log.mockRestore();
    console.error.mockRestore();
  });

  // ── fetchDataByTimeInterval ────────────────────────────────────────────────

  describe('fetchDataByTimeInterval', () => {
    it('returns hits when response is ok', async () => {
      const hits = [{ _source: { hostname: 'H1' } }];
      fetch.mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue({ hits: { hits } }),
      });

      const result = await fetchDataByTimeInterval(10);

      expect(result).toEqual(hits);
    });

    it('returns empty array when response is not ok', async () => {
      fetch.mockResolvedValue({ ok: false });

      const result = await fetchDataByTimeInterval(10);

      expect(result).toEqual([]);
    });

    it('uses getOpenSearchPassword when OPENSEARCH_NON_PROD_PASSWORD is not set', async () => {
      delete process.env.OPENSEARCH_NON_PROD_PASSWORD;
      fetch.mockResolvedValue({ ok: false });

      await fetchDataByTimeInterval(10);

      expect(getOpenSearchPassword).toHaveBeenCalled();
    });

    it('handles fetch errors and logs them', async () => {
      fetch.mockRejectedValue(new Error('network failure'));

      const result = await fetchDataByTimeInterval(10);

      expect(result).toBeUndefined();
      expect(console.error).toHaveBeenCalledWith(expect.stringContaining('Error occurred'));
    });
  });

  // ── insertDataintoAgentInfoCollection (via syncAgentStatus) ────────────────

  describe('syncAgentStatus (insertDataintoAgentInfoCollection)', () => {
    it('calls insertintoDB with hits when fetch succeeds', async () => {
      const hits = [
        {
          _source: {
            hostname: 'SYNC-HOST',
            agent_details: { os_type: 'linux', version: '1.0', pid: '9', server_port: '8080' },
            agent_config: { agent_id: 'aid' },
          },
        },
      ];
      fetch.mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue({ hits: { hits } }),
      });
      agentModel.findOne.mockResolvedValue(null);
      agentModel.bulkWrite.mockResolvedValue({ insertedCount: 1 });
      agentModel.updateMany.mockResolvedValue({ modifiedCount: 0 });

      await syncAgentStatus();

      expect(agentModel.updateMany).toHaveBeenCalled();
      expect(agentModel.bulkWrite).toHaveBeenCalled();
    });

    it('handles non-ok response without error', async () => {
      fetch.mockResolvedValue({ ok: false });

      await expect(syncAgentStatus()).resolves.not.toThrow();
    });

    it('handles fetch error in insertDataintoAgentInfoCollection', async () => {
      fetch.mockRejectedValue(new Error('connection refused'));

      await expect(syncAgentStatus()).resolves.not.toThrow();
      expect(console.error).toHaveBeenCalled();
    });

    it('uses getOpenSearchPassword when env var not set', async () => {
      delete process.env.OPENSEARCH_NON_PROD_PASSWORD;
      fetch.mockResolvedValue({ ok: false });

      await syncAgentStatus();

      expect(getOpenSearchPassword).toHaveBeenCalled();
    });
  });

  // ── insertintoDB ───────────────────────────────────────────────────────────

  describe('insertintoDB', () => {
    it('inserts new agents when no existing record found', async () => {
      const data = [
        {
          _source: {
            hostname: 'HOST-NEW',
            agent_details: { os_type: 'linux', version: '1.0', pid: '123', server_port: '8080' },
            agent_config: { agent_id: 'abc' },
          },
        },
      ];

      agentModel.findOne.mockResolvedValue(null);
      agentModel.bulkWrite.mockResolvedValue({ modifiedCount: 0, matchedCount: 0, insertedCount: 1 });
      agentModel.updateMany.mockResolvedValue({ modifiedCount: 0 });

      await insertintoDB(data);

      expect(agentModel.updateMany).toHaveBeenCalled();
      expect(agentModel.bulkWrite).toHaveBeenCalledWith(
        expect.arrayContaining([expect.objectContaining({ insertOne: expect.anything() })])
      );
    });

    it('updates existing agents when record exists', async () => {
      const data = [
        {
          _source: {
            hostname: 'HOST-EXIST',
            agent_details: { os_type: 'windows', version: '2.0', pid: '456', server_port: '9090' },
            agent_config: { agent_id: 'xyz' },
          },
        },
      ];

      agentModel.findOne.mockResolvedValue({ hostname: 'HOST-EXIST', status: 'Active' });
      agentModel.bulkWrite.mockResolvedValue({ modifiedCount: 1, matchedCount: 1 });
      agentModel.updateMany.mockResolvedValue({ modifiedCount: 0 });

      await insertintoDB(data);

      expect(agentModel.bulkWrite).toHaveBeenCalledWith(
        expect.arrayContaining([expect.objectContaining({ updateOne: expect.anything() })])
      );
    });

    it('handles multiple hosts including duplicates (deduplication by hostname)', async () => {
      const data = [
        { _source: { hostname: 'DUPE', agent_details: {}, agent_config: {} } },
        { _source: { hostname: 'DUPE', agent_details: {}, agent_config: {} } },
      ];
      agentModel.findOne.mockResolvedValue(null);
      agentModel.bulkWrite.mockResolvedValue({ insertedCount: 1 });
      agentModel.updateMany.mockResolvedValue({ modifiedCount: 0 });

      await insertintoDB(data);

      // Only one findOne call because duplicates are removed
      expect(agentModel.findOne).toHaveBeenCalledTimes(1);
    });

    it('skips entries without hostname', async () => {
      const data = [{ _source: { hostname: null } }];
      agentModel.updateMany.mockResolvedValue({ modifiedCount: 0 });

      await insertintoDB(data);

      expect(agentModel.findOne).not.toHaveBeenCalled();
    });

    it('handles errors gracefully', async () => {
      agentModel.updateMany.mockRejectedValue(new Error('DB failure'));

      await insertintoDB([{ _source: { hostname: 'H1', agent_details: {}, agent_config: {} } }]);

      expect(console.error).toHaveBeenCalled();
    });
  });

  // ── updateFailedAgent ──────────────────────────────────────────────────────

  describe('updateFailedAgent', () => {
    it('marks agents as Failed when not seen in last 24h', async () => {
      fetch.mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue({
          hits: { hits: [{ _source: { hostname: 'SEEN-HOST' } }] },
        }),
      });

      agentModel.find.mockResolvedValue([{ hostname: 'SEEN-HOST' }, { hostname: 'MISSING-HOST' }]);
      agentModel.bulkWrite.mockResolvedValue({ modifiedCount: 1 });

      await updateFailedAgent();

      expect(agentModel.bulkWrite).toHaveBeenCalledWith(
        expect.arrayContaining([
          expect.objectContaining({
            updateOne: expect.objectContaining({
              filter: { hostname: 'MISSING-HOST' },
              update: { $set: { status: 'Failed' } },
            }),
          }),
        ])
      );
    });

    it('skips bulkWrite when all agents are already seen', async () => {
      fetch.mockResolvedValue({
        ok: true,
        json: jest.fn().mockResolvedValue({
          hits: { hits: [{ _source: { hostname: 'SAME-HOST' } }] },
        }),
      });
      agentModel.find.mockResolvedValue([{ hostname: 'SAME-HOST' }]);

      await updateFailedAgent();

      expect(agentModel.bulkWrite).not.toHaveBeenCalled();
    });

    it('handles fetch errors gracefully', async () => {
      fetch.mockRejectedValue(new Error('network error'));
      agentModel.find.mockResolvedValue([{ hostname: 'HOST' }]);

      await updateFailedAgent();

      expect(console.error).toHaveBeenCalled();
    });
  });

  // ── syncDiscoveryData (updateCMDBData) ─────────────────────────────────────

  describe('syncDiscoveryData', () => {
    it('iterates agents and skips when no SAP data found', async () => {
      const SapMock = { findOne: jest.fn().mockResolvedValue(null) };
      sapMasterdataModule.mockResolvedValue(SapMock);
      agentModel.find.mockResolvedValue([
        { hostname: 'HOST-1', status: 'Active' },
        { hostname: 'HOST-2', status: 'Active' },
      ]);

      await syncDiscoveryData();

      expect(agentModel.find).toHaveBeenCalled();
      expect(agentModel.updateOne).not.toHaveBeenCalled();
    });

    it('updates agent cmdb when SAP master data found', async () => {
      const sapRecord = {
        ciOsType: 'Linux',
        slRegion: 'US-EAST',
        slName: 'Service1',
        slPlatform: 'VMware',
        ciSapUsedFor: 'Prod',
        ciSapNameSid: 'SID1',
      };
      const SapMock = { findOne: jest.fn().mockResolvedValue(sapRecord) };
      sapMasterdataModule.mockResolvedValue(SapMock);

      agentModel.find.mockResolvedValue([{ hostname: 'HOST-CMDB', status: 'Active' }]);
      agentModel.updateOne.mockResolvedValue({ modifiedCount: 1 });

      await syncDiscoveryData();

      expect(agentModel.updateOne).toHaveBeenCalledWith(
        { hostname: 'HOST-CMDB' },
        expect.objectContaining({
          $set: expect.objectContaining({ cmdb: expect.any(Object) }),
        })
      );
    });

    it('handles empty agent list', async () => {
      agentModel.find.mockResolvedValue([]);

      await syncDiscoveryData();

      expect(agentModel.updateOne).not.toHaveBeenCalled();
    });
  });
});
