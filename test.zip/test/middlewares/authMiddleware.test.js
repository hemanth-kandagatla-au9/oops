const responseCodes = require('../../server/utils/responseCodes');

describe('authMiddleware (unit)', () => {

  const loadWithMocks = async (verifyImpl, extraMocks = {}) => {

    jest.resetModules();

    delete process.env.JWT_SECRET_KEY;

    jest.doMock('jsonwebtoken', () => ({
      verify: jest.fn(verifyImpl),
      decode: jest.fn(() => ({ iss: 'wrong-issuer' })),
    }));

    const mockJwksClient = {
      getSigningKey: jest.fn((_kid, cb) =>
        cb(null, { getPublicKey: () => 'PUBLIC_KEY' })
      ),
      getKeys: jest.fn((cb) => cb(null, [])),
      ...extraMocks,
    };

    jest.doMock('jwks-rsa', () => jest.fn(() => mockJwksClient));

    jest.doMock('../../server/utils/mslConfig', () => ({
      loadConfig: jest.fn().mockResolvedValue({
        msalConfig: {
          auth: {
            authority: 'https://login.microsoftonline.com/test-tenant'
          }
        },
        tokenValidationConfig: {
          issuer: 'issuer',
          audience: 'audience'
        },
      }),
    }));

    const middleware = require('../../server/middlewares/authMiddleware');

    await new Promise((resolve) => setImmediate(resolve));

    return { middleware, mockJwksClient };
  };

  const makeRes = () => ({
    status: jest.fn().mockReturnThis(),
    json: jest.fn().mockReturnThis(),
  });

  describe('authorization validations', () => {

    it('returns 401 when authorization header is missing', async () => {

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(null)
      );

      const req = { headers: {} };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(res.status).toHaveBeenCalledWith(401);

      expect(res.json).toHaveBeenCalledWith({
        message: 'User is not authorized'
      });

      expect(next).not.toHaveBeenCalled();
    });

    it('returns 401 when authorization header is null', async () => {

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(null)
      );

      const req = {
        headers: {
          authorization: null
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(res.status).toHaveBeenCalledWith(401);

      expect(next).not.toHaveBeenCalled();
    });

    it('returns 401 when token is missing after Bearer', async () => {

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(null)
      );

      const req = {
        headers: {
          authorization: 'Bearer '
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(res.status).toHaveBeenCalledWith(401);

      expect(res.json).toHaveBeenCalledWith({
        message: 'Unauthorized: Token missing'
      });

      expect(next).not.toHaveBeenCalled();
    });

    it('returns 401 when authorization is empty string', async () => {

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(null)
      );

      const req = {
        headers: {
          authorization: ''
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(res.status).toHaveBeenCalledWith(401);

      expect(next).not.toHaveBeenCalled();
    });
  });

  describe('successful verification flow', () => {

    it('does not call next on successful verification because middleware lacks success next()', async () => {

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => {
          cb(null, { sub: 'user1' });
        }
      );

      const req = {
        headers: {
          authorization: 'Bearer valid.token'
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(next).not.toHaveBeenCalled();

      expect(res.status).not.toHaveBeenCalled();
    });

    it('executes getKey caching flow successfully', async () => {

      const { middleware, mockJwksClient } = await loadWithMocks(
        (_token, getKey, _opts, cb) => {

          getKey(
            { kid: 'kid1' },
            (_err, _key) => {
              cb(null, { sub: 'user1' });
            }
          );
        }
      );

      const req = {
        headers: {
          authorization: 'Bearer good'
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(next).not.toHaveBeenCalled();

      expect(mockJwksClient.getSigningKey)
        .toHaveBeenCalledTimes(1);

      const res2 = makeRes();

      const next2 = jest.fn();

      await middleware(req, res2, next2);

      expect(next2).not.toHaveBeenCalled();

      expect(mockJwksClient.getSigningKey)
        .toHaveBeenCalledTimes(1);
    });

    it('preserves request object integrity', async () => {

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(null)
      );

      const req = {
        headers: {
          authorization: 'Bearer valid.token'
        },
        body: {
          name: 'test'
        },
        params: {
          id: '1'
        },
        custom: 'data'
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(req.body).toEqual({ name: 'test' });

      expect(req.params).toEqual({ id: '1' });

      expect(req.custom).toBe('data');
    });
  });

  describe('jwt error branches', () => {

    it('returns 401 for JsonWebTokenError through break glass auth flow', async () => {

      const err = {
        name: 'JsonWebTokenError',
        message: 'jwt malformed'
      };

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(err)
      );

      const req = {
        headers: {
          authorization: 'Bearer invalid'
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);

      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          message: 'Authentication failed'
        })
      );

      expect(next).not.toHaveBeenCalled();
    });

    it('calls next on expired token branch', async () => {

      const err = {
        message: 'jwt expired'
      };

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(err)
      );

      const req = {
        headers: {
          authorization: 'Bearer expired'
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(next).toHaveBeenCalled();

      expect(res.status).not.toHaveBeenCalled();
    });

    it('calls next on generic validation failure', async () => {

      const err = {
        message: 'Validation failed'
      };

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(err)
      );

      const req = {
        headers: {
          authorization: 'Bearer validation'
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(next).toHaveBeenCalled();
    });

    it('calls next on getSigningKey errors', async () => {

      const err = {
        message: 'getSigningKey failed'
      };

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(err)
      );

      const req = {
        headers: {
          authorization: 'Bearer signingkey'
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(next).toHaveBeenCalled();
    });

    it('calls next on bad request errors', async () => {

      const err = {
        message: 'Bad Request'
      };

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(err)
      );

      const req = {
        headers: {
          authorization: 'Bearer badrequest'
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(next).toHaveBeenCalled();
    });

    it('calls next on ECONNREFUSED errors', async () => {

      const err = {
        message: 'ECONNREFUSED'
      };

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(err)
      );

      const req = {
        headers: {
          authorization: 'Bearer network'
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(next).toHaveBeenCalled();
    });

    it('calls next on unknown errors', async () => {

      const err = {
        name: 'UnknownError',
        message: 'Unexpected error'
      };

      const { middleware } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(err)
      );

      const req = {
        headers: {
          authorization: 'Bearer unknown'
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(next).toHaveBeenCalled();
    });
  });

  describe('additional coverage branches', () => {

    it('covers preload jwks success path', async () => {

      const { mockJwksClient } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(null)
      );

      expect(mockJwksClient.getKeys).toHaveBeenCalled();
    });

    it('covers jwks preload failure branch', async () => {

      const failingGetKeys = jest.fn((cb) =>
        cb(new Error('jwks failed'))
      );

      const { mockJwksClient } = await loadWithMocks(
        (_token, _getKey, _opts, cb) => cb(null),
        {
          getKeys: failingGetKeys,
        }
      );

      expect(mockJwksClient.getKeys).toHaveBeenCalled();
    });

    it('covers getSigningKey callback failure branch', async () => {

      const failingSigningKey = jest.fn((_kid, cb) =>
        cb(new Error('signing key failed'))
      );

      const { middleware } = await loadWithMocks(
        (_token, getKey, _opts, cb) => {

          getKey(
            { kid: 'kid1' },
            () => cb(null)
          );
        },
        {
          getSigningKey: failingSigningKey,
        }
      );

      const req = {
        headers: {
          authorization: 'Bearer token'
        }
      };

      const res = makeRes();

      const next = jest.fn();

      await middleware(req, res, next);

      expect(next).not.toHaveBeenCalled();
    });
  });
})