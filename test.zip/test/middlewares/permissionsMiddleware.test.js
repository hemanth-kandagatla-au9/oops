const axios = require('axios');
const pm = require('../../server/middlewares/permissionsMidlleware');
const responseCodes = require('../../server/utils/responseCodes');

jest.mock('axios');

describe('permissionsMidlleware', () => {
  let OLD_INSIGHTS_URL;

  beforeAll(() => {
    OLD_INSIGHTS_URL = process.env.insights_permission_url;
  });

  beforeEach(() => {
    process.env.insights_permission_url = 'https://permissions.test';
    jest.clearAllMocks();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  afterAll(() => {
    process.env.insights_permission_url = OLD_INSIGHTS_URL;
  });

  describe('fetchUserPermissions', () => {
    test('returns data on success', async () => {
      const mockData = { status: 200, data: { permissions: [] } };
      axios.request.mockResolvedValueOnce({ data: mockData });
      
      const res = await pm.fetchUserPermissions('Bearer token');
      
      expect(res).toEqual(mockData);
      expect(axios.request).toHaveBeenCalledWith(
        expect.objectContaining({
          method: 'get',
          url: 'https://permissions.test/auth/getUserPermission',
          timeout: 20000,
          headers: expect.objectContaining({
            'Authorization': 'Bearer token'
          })
        })
      );
    });

    test('returns 404 when no data received', async () => {
      axios.request.mockResolvedValueOnce({ data: null });
      
      const res = await pm.fetchUserPermissions('Bearer token');
      
      expect(res.status).toBe(responseCodes.NOT_FOUND);
      expect(res.message).toBe('No data received from permission API');
    });

    test('returns 404 when data is undefined', async () => {
      axios.request.mockResolvedValueOnce({ data: undefined });
      
      const res = await pm.fetchUserPermissions('Bearer token');
      
      expect(res.status).toBe(responseCodes.NOT_FOUND);
      expect(res.message).toBe('No data received from permission API');
    });

    test('handles axios request error', async () => {
      const error = new Error('Network failure');
      axios.request.mockRejectedValueOnce(error);
      
      const res = await pm.fetchUserPermissions('Bearer token');
      
      expect(res.status).toBe(responseCodes.SERVER_ERROR);
      expect(res.message).toBe('Network failure');
    });

    test('handles timeout error', async () => {
      const error = new Error('ECONNABORTED');
      axios.request.mockRejectedValueOnce(error);
      
      const res = await pm.fetchUserPermissions('Bearer token');
      
      expect(res.status).toBe(responseCodes.SERVER_ERROR);
      expect(res.message).toBe('ECONNABORTED');
    });

    test('handles permission API returning permission data structure', async () => {
      const mockData = {
        status: 200,
        data: {
          permissions: [
            {
              project: 'agent',
              modules: [
                {
                  module: 'Rise Agent',
                  permissions: [
                    { label: 'Read', hasAccess: true },
                    { label: 'Write', hasAccess: false }
                  ]
                }
              ]
            }
          ]
        }
      };
      axios.request.mockResolvedValueOnce({ data: mockData });
      
      const res = await pm.fetchUserPermissions('Bearer token');
      
      expect(res).toEqual(mockData);
    });
  });

  describe('checkPermission', () => {
    test('returns false for null permission data', () => {
      expect(pm.checkPermission(null, 'read')).toBe(false);
    });

    test('returns false for undefined permission data', () => {
      expect(pm.checkPermission(undefined, 'read')).toBe(false);
    });

    test('returns false for empty object', () => {
      expect(pm.checkPermission({}, 'read')).toBe(false);
    });

    test('returns false when data property is missing', () => {
      expect(pm.checkPermission({ status: 200 }, 'read')).toBe(false);
    });

    test('returns false when permissions property is missing', () => {
      expect(pm.checkPermission({ data: {} }, 'read')).toBe(false);
    });

    test('returns false when permissions is null', () => {
      expect(pm.checkPermission({ data: { permissions: null } }, 'read')).toBe(false);
    });

    test('throws error when permissions is not an array', () => {
      // The middleware doesn't validate permissions is an array before calling find()
      expect(() => pm.checkPermission({ data: { permissions: {} } }, 'read')).toThrow();
    });

    test('returns false when agent project not found', () => {
      const permissionData = {
        data: {
          permissions: [
            { project: 'other', modules: [] }
          ]
        }
      };
      expect(pm.checkPermission(permissionData, 'read')).toBe(false);
    });

    test('returns false when agent project has no modules', () => {
      const permissionData = {
        data: {
          permissions: [
            { project: 'agent', modules: null }
          ]
        }
      };
      expect(pm.checkPermission(permissionData, 'read')).toBe(false);
    });

    test('returns false when Rise Agent module not found', () => {
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { module: 'Other Module', permissions: [] }
              ]
            }
          ]
        }
      };
      expect(pm.checkPermission(permissionData, 'read')).toBe(false);
    });

    test('returns false when Rise Agent module has no permissions', () => {
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { module: 'Rise Agent', permissions: null }
              ]
            }
          ]
        }
      };
      expect(pm.checkPermission(permissionData, 'read')).toBe(false);
    });

    test('returns false when Rise Agent permissions is not an array', () => {
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { module: 'Rise Agent', permissions: {} }
              ]
            }
          ]
        }
      };
      expect(pm.checkPermission(permissionData, 'read')).toBe(false);
    });

    test('returns true when permission exists and hasAccess is true', () => {
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { 
                  module: 'Rise Agent',
                  permissions: [
                    { label: 'Read', hasAccess: true }
                  ]
                }
              ]
            }
          ]
        }
      };
      expect(pm.checkPermission(permissionData, 'read')).toBe(true);
    });

    test('returns false when permission exists but hasAccess is false', () => {
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { 
                  module: 'Rise Agent',
                  permissions: [
                    { label: 'Read', hasAccess: false }
                  ]
                }
              ]
            }
          ]
        }
      };
      expect(pm.checkPermission(permissionData, 'read')).toBe(false);
    });

    test('returns false when permission not found', () => {
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { 
                  module: 'Rise Agent',
                  permissions: [
                    { label: 'Write', hasAccess: true }
                  ]
                }
              ]
            }
          ]
        }
      };
      expect(pm.checkPermission(permissionData, 'read')).toBe(false);
    });

    test('performs case-insensitive permission matching', () => {
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { 
                  module: 'Rise Agent',
                  permissions: [
                    { label: 'READ', hasAccess: true }
                  ]
                }
              ]
            }
          ]
        }
      };
      expect(pm.checkPermission(permissionData, 'read')).toBe(true);
      expect(pm.checkPermission(permissionData, 'READ')).toBe(true);
      expect(pm.checkPermission(permissionData, 'ReAd')).toBe(true);
    });

    test('trims whitespace from permission labels', () => {
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { 
                  module: 'Rise Agent',
                  permissions: [
                    { label: '  Read  ', hasAccess: true }
                  ]
                }
              ]
            }
          ]
        }
      };
      expect(pm.checkPermission(permissionData, '  read  ')).toBe(true);
    });

    test('handles multiple permissions in Rise Agent module', () => {
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { 
                  module: 'Rise Agent',
                  permissions: [
                    { label: 'Read', hasAccess: true },
                    { label: 'Write', hasAccess: false },
                    { label: 'Delete', hasAccess: true }
                  ]
                }
              ]
            }
          ]
        }
      };
      expect(pm.checkPermission(permissionData, 'read')).toBe(true);
      expect(pm.checkPermission(permissionData, 'write')).toBe(false);
      expect(pm.checkPermission(permissionData, 'delete')).toBe(true);
    });

    test('handles hasAccess as non-boolean truthy values', () => {
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { 
                  module: 'Rise Agent',
                  permissions: [
                    { label: 'Read', hasAccess: 1 }
                  ]
                }
              ]
            }
          ]
        }
      };
      expect(pm.checkPermission(permissionData, 'read')).toBe(false);
    });
  });

  describe('requirePermission middleware', () => {
    test('sends 401 when no auth header', async () => {
      const mw = pm.requirePermission('read');
      const req = { headers: {} };
      const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
      const next = jest.fn();
      
      await mw(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'User is not authorized'
      });
      expect(next).not.toHaveBeenCalled();
    });

    test('sends 401 when authorization header is null', async () => {
      const mw = pm.requirePermission('read');
      const req = { headers: { authorization: null } };
      const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
      const next = jest.fn();
      
      await mw(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);
      expect(next).not.toHaveBeenCalled();
    });

    test('sends 401 when headers is falsy and authorization is undefined', async () => {
      const mw = pm.requirePermission('read');
      const req = { headers: false };
      const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
      const next = jest.fn();
      
      await mw(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);
      expect(next).not.toHaveBeenCalled();
    });

    test('calls fetchUserPermissions with auth header', async () => {
      const mw = pm.requirePermission('read');
      const req = { headers: { authorization: 'Bearer token' } };
      const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
      const next = jest.fn();
      
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { 
                  module: 'Rise Agent',
                  permissions: [
                    { label: 'Read', hasAccess: true }
                  ]
                }
              ]
            }
          ]
        }
      };
      axios.request.mockResolvedValueOnce({ data: permissionData });
      
      await mw(req, res, next);
      
      expect(axios.request).toHaveBeenCalledWith(
        expect.objectContaining({
          headers: expect.objectContaining({
            'Authorization': 'Bearer token'
          })
        })
      );
    });

    test('sends 404 when permission API returns 404', async () => {
      const mw = pm.requirePermission('read');
      const req = { headers: { authorization: 'Bearer token' } };
      const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
      const next = jest.fn();
      
      axios.request.mockResolvedValueOnce({ data: null });
      
      await mw(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(responseCodes.NOT_FOUND);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'No data received from permission API'
      });
      expect(next).not.toHaveBeenCalled();
    });

    test('sends 500 when permission API returns 500', async () => {
      const mw = pm.requirePermission('read');
      const req = { headers: { authorization: 'Bearer token' } };
      const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
      const next = jest.fn();
      
      axios.request.mockRejectedValueOnce(new Error('Internal Server Error'));
      
      await mw(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Internal Server Error'
      });
      expect(next).not.toHaveBeenCalled();
    });

    test('sends 403 when user lacks required permission', async () => {
      const mw = pm.requirePermission('write');
      const req = { headers: { authorization: 'Bearer token' } };
      const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
      const next = jest.fn();
      
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { 
                  module: 'Rise Agent',
                  permissions: [
                    { label: 'Read', hasAccess: true }
                  ]
                }
              ]
            }
          ]
        }
      };
      axios.request.mockResolvedValueOnce({ data: permissionData });
      
      await mw(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(responseCodes.FORBIDDEN);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'You do not have permission to perform this action'
      });
      expect(next).not.toHaveBeenCalled();
    });

    test('calls next() when user has required permission', async () => {
      const mw = pm.requirePermission('read');
      const req = { headers: { authorization: 'Bearer token' } };
      const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
      const next = jest.fn();
      
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { 
                  module: 'Rise Agent',
                  permissions: [
                    { label: 'Read', hasAccess: true }
                  ]
                }
              ]
            }
          ]
        }
      };
      axios.request.mockResolvedValueOnce({ data: permissionData });
      
      await mw(req, res, next);
      
      expect(next).toHaveBeenCalled();
      expect(res.status).not.toHaveBeenCalled();
    });

    test('handles exception in middleware', async () => {
      const mw = pm.requirePermission('read');
      const req = { headers: { authorization: 'Bearer token' } };
      const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
      const next = jest.fn();
      
      axios.request.mockRejectedValueOnce(new Error('Unexpected error'));
      
      await mw(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
      expect(res.json).toHaveBeenCalled();
      expect(next).not.toHaveBeenCalled();
    });

    test('validates permission with different names', async () => {
      const mw = pm.requirePermission('write');
      const req = { headers: { authorization: 'Bearer token' } };
      const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
      const next = jest.fn();
      
      const permissionData = {
        data: {
          permissions: [
            { 
              project: 'agent',
              modules: [
                { 
                  module: 'Rise Agent',
                  permissions: [
                    { label: 'Read', hasAccess: true },
                    { label: 'Write', hasAccess: true },
                    { label: 'Delete', hasAccess: false }
                  ]
                }
              ]
            }
          ]
        }
      };
      axios.request.mockResolvedValueOnce({ data: permissionData });
      
      await mw(req, res, next);
      
      expect(next).toHaveBeenCalled();
    });

    test('maintains consistent state across multiple calls', async () => {
      const mw = pm.requirePermission('read');
      
      for (let i = 0; i < 3; i++) {                    // NOSONAR
        const req = { headers: { authorization: 'Bearer token' } };
        const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
        const next = jest.fn();
        
        const permissionData = {
          data: {
            permissions: [
              { 
                project: 'agent',
                modules: [
                  { 
                    module: 'Rise Agent',
                    permissions: [
                      { label: 'Read', hasAccess: true }
                    ]
                  }
                ]
              }
            ]
          }
        };
        axios.request.mockResolvedValueOnce({ data: permissionData });
        
        await mw(req, res, next);
        
        expect(next).toHaveBeenCalled();
      }
    });

    test('catches error when checkPermission throws due to invalid data', async () => {
      const mw = pm.requirePermission('read');
      const req = { headers: { authorization: 'Bearer token' } };
      const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
      const next = jest.fn();
      
      // Return data that will cause checkPermission to throw (permissions is not an array)
      const malformedData = {
        data: {
          permissions: { project: 'agent' }
        }
      };
      axios.request.mockResolvedValueOnce({ data: malformedData });
      
      await mw(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          flag: 'error',
          error: expect.stringContaining('find is not a function')
        })
      );
      expect(next).not.toHaveBeenCalled();
    });
  });
});