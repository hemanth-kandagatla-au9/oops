jest.mock('../../server/utils/mslConfig', () => {
  return {
    loadConfig: jest.fn().mockResolvedValue({
      msalConfig: { auth: { authority: 'https://login.microsoftonline.com/test-tenant' } },
      tokenValidationConfig: { issuer: 'issuer', audience: 'audience' },
    })
  };
});

jest.mock('jwks-rsa', () => jest.fn(() => ({
  getSigningKey: jest.fn((_kid, cb) => cb(null, { getPublicKey: () => 'mock' })),
  getKeys: jest.fn((cb) => cb(null, [])), // NOSONAR
})));

const jwt = require('jsonwebtoken');
const authMiddleware = require('../../server/middlewares/authMiddleware');


describe('authMiddleware break-glass and expired handling', () => {
  afterEach(() => jest.clearAllMocks());

  // test('returns Session Expired when jwt verify error message is jwt expired', async () => {
  //   const req = { headers: { authorization: 'Bearer tok' } };
  //   const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
  //   const next = jest.fn();

  //   jest.spyOn(jwt, 'verify').mockImplementation((token, getKey, opts, cb) => cb({ message: 'jwt expired' })); // NOSONAR

  //   await authMiddleware(req, res, next);

  //   expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);
  //   // expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ message: 'Session Expired' }));
  //   expect(next).not.toHaveBeenCalled();
  // });

  test('invokes break-glass flow when token invalid and succeeds with secret', async () => {
    const req = { headers: { authorization: 'Bearer tok' } };
    const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
    const next = jest.fn();

    // First jwt.verify (middleware) returns JsonWebTokenError
    const err = { name: 'JsonWebTokenError', message: 'jwt malformed' };
    const verifyMock = jest.spyOn(jwt, 'verify')
      .mockImplementationOnce((token, getKey, opts, cb) => cb(err)) // NOSONAR
      // Second jwt.verify (break-glass) succeeds
      .mockImplementationOnce((token, secret, opts, cb) => cb(null));   // NOSONAR

    jest.spyOn(jwt, 'decode').mockReturnValue({ iss: 'iasphere-break-glass' });
    process.env.JWT_SECRET_KEY = 'test-secret';

    await authMiddleware(req, res, next);

    expect(verifyMock).toHaveBeenCalled();
    expect(next).toHaveBeenCalled();
  });
});