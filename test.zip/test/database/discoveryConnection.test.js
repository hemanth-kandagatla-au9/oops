describe('database/discoveryConnection', () => {
  const originalEnv = process.env;
  let consoleSpy;
  let consoleErrorSpy;

  beforeEach(() => {
    jest.resetModules();
    process.env = { ...originalEnv, NODE_ENV: 'test' };
    consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    consoleSpy.mockRestore();
    consoleErrorSpy.mockRestore();
    process.env = originalEnv;
  });

  const loadWithMocks = ({
    mongoConnectionURL = 'localhost:27017/',
    mongoPem = '---PEM---',
    createConnectionImpl,
    existsSync = false,
    mongoTlsEnabled = undefined,
  } = {}) => {
    const mockConn = {
      on: jest.fn(),
    };

    const mongooseMock = {
      createConnection: jest.fn(createConnectionImpl || (() => mockConn)),
      set: jest.fn(),
    };

    const envUtilsMock = {
      getMongoConnectionURL: jest.fn(async () => mongoConnectionURL),
      getMongoPem: jest.fn(async () => mongoPem),
    };

    const fsMock = {
      existsSync: jest.fn(() => existsSync),
      writeFileSync: jest.fn(),
    };

    jest.doMock('../../config', () => ({
      APP_CONFIG: { MONGO: { OPTIONS: {} } },
    }));

    jest.doMock('mongoose', () => mongooseMock);
    jest.doMock('../../server/utils/envUtils', () => envUtilsMock);
    jest.doMock('fs', () => fsMock);

    if (mongoTlsEnabled !== undefined) {
      process.env.MONGO_TLS_ENABLED = mongoTlsEnabled;
    }

    const getDiscoveryConnection = require('../../server/database/discoveryConnection');
    return { getDiscoveryConnection, mongooseMock, envUtilsMock, fsMock, mockConn };
  };

  it('returns null when NODE_ENV is test', async () => {
    process.env.NODE_ENV = 'test';
    const { getDiscoveryConnection, mongooseMock } = loadWithMocks();

    const result = await getDiscoveryConnection();
    expect(result).toBeNull();
    expect(mongooseMock.createConnection).not.toHaveBeenCalled();
  });

  it('creates a new connection when none exists (TLS disabled)', async () => {
    process.env.NODE_ENV = 'dev';
    process.env.DB_CONNECTION_URL = 'localhost:27017/';
    delete process.env.MONGO_TLS_ENABLED;

    const { getDiscoveryConnection, mongooseMock, mockConn } = loadWithMocks();

    const result = await getDiscoveryConnection();
    expect(mongooseMock.createConnection).toHaveBeenCalled();
    expect(mockConn.on).toHaveBeenCalledWith('connected', expect.any(Function));
    expect(mockConn.on).toHaveBeenCalledWith('error', expect.any(Function));
    expect(result).toBe(mockConn);
  });

  it('reuses existing connection on second call', async () => {
    process.env.NODE_ENV = 'dev';
    process.env.DB_CONNECTION_URL = 'localhost:27017/';
    delete process.env.MONGO_TLS_ENABLED;

    const { getDiscoveryConnection, mongooseMock } = loadWithMocks();

    const conn1 = await getDiscoveryConnection();
    const conn2 = await getDiscoveryConnection();

    expect(conn1).toBe(conn2);
    expect(mongooseMock.createConnection).toHaveBeenCalledTimes(1);
  });

  it('creates connection with TLS when MONGO_TLS_ENABLED is true and pem exists', async () => {
    process.env.NODE_ENV = 'dev';
    process.env.DB_CONNECTION_URL = 'localhost:27017/';
    process.env.MONGO_TLS_ENABLED = 'true';

    const { getDiscoveryConnection, mongooseMock } = loadWithMocks({ existsSync: true });

    await getDiscoveryConnection();

    const callArgs = mongooseMock.createConnection.mock.calls[0];
    expect(callArgs[1]).toHaveProperty('tlsCAFile');
  });

  it('writes pem file when TLS enabled but file does not exist', async () => {
    process.env.NODE_ENV = 'dev';
    process.env.DB_CONNECTION_URL = 'localhost:27017/';
    process.env.MONGO_TLS_ENABLED = 'true';

    const { getDiscoveryConnection, fsMock } = loadWithMocks({ existsSync: false });

    await getDiscoveryConnection();

    expect(fsMock.writeFileSync).toHaveBeenCalled();
  });

  it('fires connected event handler without error', async () => {
    process.env.NODE_ENV = 'dev';
    process.env.DB_CONNECTION_URL = 'localhost:27017/';
    delete process.env.MONGO_TLS_ENABLED;

    const handlers = {};
    const mockConn = {
      on: jest.fn((event, handler) => { handlers[event] = handler; }),
    };

    const { getDiscoveryConnection } = loadWithMocks({
      createConnectionImpl: () => mockConn,
    });

    await getDiscoveryConnection();

    // Fire the connected and error event handlers
    expect(() => handlers['connected']()).not.toThrow();
    expect(() => handlers['error'](new Error('test error'))).not.toThrow();
  });

  it('throws and logs error when createConnection throws', async () => {
    process.env.NODE_ENV = 'dev';
    process.env.DB_CONNECTION_URL = 'localhost:27017/';
    delete process.env.MONGO_TLS_ENABLED;

    const { getDiscoveryConnection } = loadWithMocks({
      createConnectionImpl: () => { throw new Error('connection failed'); },
    });

    await expect(getDiscoveryConnection()).rejects.toThrow('connection failed');
    expect(consoleErrorSpy).toHaveBeenCalled();
  });
});
