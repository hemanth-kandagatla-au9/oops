describe('database/connection', () => {
  const originalEnv = process.env;
  let consoleSpy;

  beforeEach(() => {
    jest.resetModules();
    process.env = { ...originalEnv };
    consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
  });

  afterEach(() => {
    consoleSpy.mockRestore();
    process.env = originalEnv;
  });

  const loadWithMocks = ({
    appConfigOptions = { retryWrites: true },
    mongoConnectionURL = 'localhost:27017/',
    mongoPem = '---PEM---',
    mongooseConnectImpl,
    existsSync = false,
  } = {}) => {
    const mongooseMock = {
      connect: jest.fn(mongooseConnectImpl || (async () => ({}))),
      set: jest.fn(),
    };

    const envUtilsMock = {
      getMongoConnectionURL: jest.fn(async () => mongoConnectionURL),
      getMongoPem: jest.fn(async () => mongoPem),
    };

    const fsMock = {
      existsSync: jest.fn(() => existsSync),
      writeFileSync: jest.fn(),
    };

    jest.doMock('../../config', () => ({
      APP_CONFIG: { MONGO: { OPTIONS: appConfigOptions } },
    }));

    jest.doMock('mongoose', () => mongooseMock);
    jest.doMock('../../server/utils/envUtils', () => envUtilsMock);
    jest.doMock('fs', () => fsMock);

    const mod = require('../../server/database/connection');
    return { mod, mongooseMock, envUtilsMock, fsMock };
  };


  it('InitiateMongoServer returns early in NODE_ENV=test', async () => {
    process.env.NODE_ENV = 'test';
    const { mod, mongooseMock } = loadWithMocks();

    await mod.InitiateMongoServer();
    expect(mongooseMock.connect).not.toHaveBeenCalled();
  });



  it('InitiateMongoServer logs connection errors', async () => {
    process.env.NODE_ENV = 'dev';

    const { mod } = loadWithMocks({
      mongooseConnectImpl: async () => {
        throw new Error('connect failed');
      },
    });

    await mod.InitiateMongoServer();
    expect(consoleSpy).toHaveBeenCalledWith(expect.stringContaining('Mongo Connection Err:'));
  });
});
