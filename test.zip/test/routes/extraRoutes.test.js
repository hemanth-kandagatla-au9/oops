describe('additional route modules coverage', () => {
  beforeEach(() => {
    jest.resetModules();
  });

  it('loads healthReady routes', () => {
    jest.doMock('../../server/controllers/agentServiceController', () => ({
      checkHealth: jest.fn(),
      checkReady: jest.fn(),
    }));

    const router = require('../../server/routes/healthReadyRoutes/healthReady.routes');
    const paths = router.stack
      .filter((l) => l.route)
      .map((l) => l.route.path);

    expect(paths).toEqual(expect.arrayContaining(['/healthy', '/ready']));
  });

  it('loads rustAgent routes', () => {
    jest.doMock('../../server/controllers/agentServiceController', () => ({
      getAgentsData: jest.fn(),
      getAgentInfo: jest.fn(),
      health: jest.fn(),
      download: jest.fn(),
    }));
    jest.doMock('../../server/controllers/bulkAgentController', () => ({
      validateAgent: jest.fn(),
    }));
    jest.doMock('../../server/controllers/agentVersionController', () => ({
      manageVersions: jest.fn(),
      deleteVersion: jest.fn(),
    }));
    jest.doMock('../../server/controllers/downloadController', () => ({
      downloadScript: jest.fn(),
      downloadBinaryFile: jest.fn(),
      downloadRustFile: jest.fn(),
    }));

    const router = require('../../server/routes/rustAgentRoutes/rustAgent.routes');
    const paths = router.stack
      .filter((l) => l.route)
      .map((l) => l.route.path);

    expect(paths).toEqual(
      expect.arrayContaining([
        '/',
        '/info',
        '/getAgents',
        '/status',
        '/download',
        '/validate',
        '/versions',
        '/download/scripts',
        '/download/file',
        '/download/file/:path/:file',
      ])
    );
  });

  it('loads uiMonitoring routes', () => {
    jest.doMock('../../server/controllers/ui-monitoring-controller/applicationController', () => ({
      fetchApplicationPerformanceData: jest.fn(),
    }));
    jest.doMock('../../server/controllers/ui-monitoring-controller/infrastructureController', () => ({
      fetchInfrastructureMonitoringData: jest.fn(),
    }));
    jest.doMock('../../server/controllers/ui-monitoring-controller/logsController', () => ({
      fetchLogsData: jest.fn(),
    }));
    jest.doMock('../../server/controllers/ui-monitoring-controller/metricsController', () => ({
      fetchCardData: jest.fn(),
    }));
    jest.doMock('../../server/controllers/ui-monitoring-controller/networkController', () => ({
      fetchNetworkMonitoringData: jest.fn(),
    }));
    jest.doMock('../../server/controllers/ui-monitoring-controller/securityAlertController', () => ({
      fetchAlertsData: jest.fn(),
    }));

    const router = require('../../server/routes/uiMonitoringRoutes/uiMonitoring.routes');
    const paths = router.stack
      .filter((l) => l.route)
      .map((l) => l.route.path);

    expect(paths).toEqual(
      expect.arrayContaining([
        '/application',
        '/infrastructure',
        '/logs',
        '/metrics',
        '/network',
        '/securityAlert',
      ])
    );
  });

  it('loads versionManagement routes', () => {
    jest.doMock('../../server/controllers/version-management-controller/versionManagement.controller', () => ({
      createVersion: jest.fn(),
      fetchVersions: jest.fn(),
      deleteVersion: jest.fn(),
      updateVersion: jest.fn(),
    }));

    const router = require('../../server/routes/versionManagementRoutes/versionManagement.routes');
    const paths = router.stack
      .filter((l) => l.route)
      .map((l) => l.route.path);

    expect(paths).toEqual(expect.arrayContaining(['/','/:id/delete','/:id']));
  });

  it('loads auth routes', () => {
    jest.doMock('../../server/auth/controllers/tokenController', () => ({
      generateTokenEndpoint: jest.fn(),
      validateTokenEndpoint: jest.fn(),
      healthCheck: jest.fn(),
    }));

    jest.doMock('../../server/auth/controllers/authManagementController', () => ({
      getUserDetails: jest.fn(),
      getPermissions: jest.fn(),
      addUser: jest.fn(),
      addPermission: jest.fn(),
      deletePermission: jest.fn(),
      deleteUserDetails: jest.fn(),
      updatePermission: jest.fn(),
      getUserPermissions: jest.fn(),
      assignUserPermissions: jest.fn(),
    }));

    const router = require('../../server/auth/routes/auth.routes');
    const paths = router.stack
      .filter((l) => l.route)
      .map((l) => l.route.path);

    expect(paths).toEqual(
      expect.arrayContaining([
        '/generate-token',
        '/validate-token',
        '/health',
        '/user-details',
        '/permissionsList',
        '/add-user',
      ])
    );
  });
});
