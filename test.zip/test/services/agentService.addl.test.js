const svc = require('../../server/services/agentService');

jest.mock('axios', () => {
  const m = jest.fn();
  m.request = jest.fn();
  return m;
});

jest.mock('../../server/models/tokenLogs', () => ({ findOne: jest.fn() }));
jest.mock('../../server/auth/services/tokenService', () => ({ generateToken: jest.fn() }));
jest.mock('../../server/utils/envUtils', () => ({ getAuthUserPasswordFromSSM: jest.fn(), getOpenSearchPassword: jest.fn() }));
jest.mock('node-fetch', () => jest.fn());

const axios = require('axios');
const tokenLogs = require('../../server/models/tokenLogs');
const fetch = require('node-fetch');

beforeEach(() => {
  jest.clearAllMocks();
  process.env.AUTH_AGENT_USERNAME = 'u';
  process.env.AUTH_PASS = 'p';
  process.env.BULK_ACTION_BASE_URL = 'http://bulk'; // NOSONAR
  process.env.OPENSEARCH_APPLICATION_INDEX = 'appidx';
});

test('getBaseURL uses default port and provided port', async () => {
  expect(await svc.getBaseURL({ hostname: 'host1' })).toBe('https://host1:20140');
  expect(await svc.getBaseURL({ hostname: 'host2', port: 1234 })).toBe('https://host2:1234');
  expect(await svc.getBaseURL({ hostname: 'host3', port: 'undefined' })).toBe('https://host3:20140');
});

test('putShutDown returns data on success', async () => {
  tokenLogs.findOne.mockReturnValue({ sort: jest.fn().mockResolvedValue({ token: 't', action: 'GENERATED', expiresTime: new Date(Date.now() + 10000) }) });
  axios.mockResolvedValue({ status: 200, data: { ok: true } });

  const res = await svc.putShutDown({ hostname: ['h'] });
  expect(axios).toHaveBeenCalled();
  expect(res).toEqual({ ok: true });
});

test('putRestartAgent handles NOT_FOUND', async () => {
  tokenLogs.findOne.mockReturnValue({ sort: jest.fn().mockResolvedValue({ token: 't', action: 'GENERATED', expiresTime: new Date(Date.now() + 10000) }) });
  axios.mockResolvedValue({ status: 404 });

  const res = await svc.putRestartAgent({ hostname: ['h'] });
  expect(res).toEqual({ status: 404, message: 'File not found' });
});

test('putStart returns 500 on request error', async () => {
  tokenLogs.findOne.mockReturnValue({ sort: jest.fn().mockResolvedValue({ token: 't', action: 'GENERATED', expiresTime: new Date(Date.now() + 10000) }) });
  axios.mockRejectedValue(new Error('boom'));

  const res = await svc.putStart({ hostname: ['h'] });
  expect(res).toEqual({ status: 500, message: 'boom' });
});

test('fetchData returns response.data for rust agent', async () => {
  tokenLogs.findOne.mockReturnValue({ sort: jest.fn().mockResolvedValue({ token: 't', action: 'GENERATED', expiresTime: new Date(Date.now() + 10000) }) });
  axios.mockResolvedValue({ status: 200, headers: { 'content-type': 'application/json' }, data: { hello: 'world' } });

  const out = await svc.fetchData('/x', 'GET', null, true, false, false, false);
  expect(out).toEqual({ hello: 'world' });
});

test('fetchData returns undefined on ECONNREFUSED', async () => {
  tokenLogs.findOne.mockReturnValue({ sort: jest.fn().mockResolvedValue({ token: 't', action: 'GENERATED', expiresTime: new Date(Date.now() + 10000) }) });
  axios.mockRejectedValue({ code: 'ECONNREFUSED' });

  const out = await svc.fetchData('/x', 'GET');
  expect(out).toBeUndefined();
});

test('getApplicationLogs returns hit sources and filters nulls', async () => {
  // create a fetch-like response (used by createOpenSearchFetchRequest)
  fetch.mockResolvedValue({
    status: 200,
    headers: { get: () => 'application/json' },
    json: async () => ({ hits: { hits: [{ _source: { a: 1 } }, { _source: null }] } }),
  });

  const out = await svc.getApplicationLogs({ skip: 0, limit: 10, hostname: 'h' });
  expect(fetch).toHaveBeenCalled();
  expect(out).toEqual([{ a: 1 }]);
});
