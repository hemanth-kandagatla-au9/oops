jest.mock('axios');
const axios = require('axios');
const tokenLogs = require('../../server/models/tokenLogs');
const tokenService = require('../../server/auth/services/tokenService');
const envUtils = require('../../server/utils/envUtils');

const svc = require('../../server/services/agentService');
const responseCodes = require('../../server/utils/responseCodes');

jest.mock('../../server/models/tokenLogs', () => ({ findOne: jest.fn() }));
jest.mock('../../server/auth/services/tokenService', () => ({ generateToken: jest.fn() }));
jest.mock('../../server/utils/envUtils', () => ({ getAuthUserPasswordFromSSM: jest.fn(), getOpenSearchPassword: jest.fn() }));

describe('agentService basic', () => {
  afterEach(() => jest.clearAllMocks());

  test('getBaseURL uses default port', async () => {
    const url = await svc.getBaseURL({ hostname: 'host1' });
    expect(url).toBe('https://host1:20140');
  });

  test('getBaseURL uses provided port', async () => {
    const url = await svc.getBaseURL({ hostname: 'host1', port: 8080 });
    expect(url).toBe('https://host1:8080');
  });

  test('createBulkFetchRequest returns data when axios resolves', async () => {
    process.env.BULK_ACTION_BASE_URL = 'http://bulk'; // NOSONAR
    process.env.AUTH_AGENT_USERNAME = 'u1';
    envUtils.getAuthUserPasswordFromSSM.mockResolvedValue('pwd');
    tokenLogs.findOne.mockImplementation(() => ({ sort: jest.fn().mockResolvedValue(null) }));
    tokenService.generateToken.mockResolvedValue({ token: 'mock-token-123' });
    axios.mockResolvedValue({ status: responseCodes.SUCCESS, data: { ok: true } });

    const res = await svc.putShutDown({ hostname: ['h1'] });
    expect(res).toEqual({ ok: true });
    expect(axios).toHaveBeenCalled();
  });
});
