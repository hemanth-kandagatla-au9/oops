jest.mock('axios');
const axios = require('axios');
const tokenLogs = require('../../server/models/tokenLogs');
const tokenService = require('../../server/auth/services/tokenService');
const envUtils = require('../../server/utils/envUtils');
const svc = require('../../server/services/agentService');

jest.mock('../../server/models/tokenLogs', () => ({ findOne: jest.fn() }));
jest.mock('../../server/auth/services/tokenService', () => ({ generateToken: jest.fn() }));
jest.mock('../../server/utils/envUtils', () => ({ getAuthUserPasswordFromSSM: jest.fn(), getOpenSearchPassword: jest.fn() }));

describe('agentService error branches', () => {
  afterEach(() => jest.clearAllMocks());

  test('createBulkFetchRequest returns 500 object on axios error', async () => {
    process.env.BULK_ACTION_BASE_URL = 'http://bulk'; // NOSONAR
    process.env.AUTH_AGENT_USERNAME = 'u1';
    envUtils.getAuthUserPasswordFromSSM.mockResolvedValue('pwd');
    tokenLogs.findOne.mockImplementation(() => ({ sort: jest.fn().mockResolvedValue(null) }));
    tokenService.generateToken.mockResolvedValue({ token: 't' });
    axios.mockRejectedValue(new Error('boom'));

    const res = await svc.putShutDown({ hostname: ['h1'] });
    expect(res.status).toBe(500); // NOSONAR
    expect(res.message).toMatch(/boom/);
  });

  test('fetchData returns undefined when axios/fetch throws ECONNREFUSED', async () => {
    // Mock axios to throw ECONNREFUSED so internal createFetchRequest fails
    axios.mockRejectedValue(Object.assign(new Error('connect'), { code: 'ECONNREFUSED' }));
    const result = await svc.fetchData('/x', 'GET', null, true, false, false, false);
    expect(result).toBeUndefined();
  });
});
