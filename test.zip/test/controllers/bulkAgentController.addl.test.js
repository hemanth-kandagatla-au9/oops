const { bulkStartAgent, bulkStopAgent, bulkRestartAgent, bulkUpgradeAgent, bulkSyncAgent, bulkEnvUpdate } = require('../../server/controllers/bulkAgentController');
const responseCodes = require('../../server/utils/responseCodes');

jest.mock('../../server/services/agentService', () => ({
  putShutDown: jest.fn(),
  putRestartAgent: jest.fn(),
  updateVersion: jest.fn(),
  sycAgentCOnfig: jest.fn(),
  updateEnv: jest.fn()
}));

jest.mock('../../server/utils/agentUtils', () => ({ executeCommandOnAgent: jest.fn() }));
jest.mock('jsonwebtoken');

const svc = require('../../server/services/agentService');
const { executeCommandOnAgent } = require('../../server/utils/agentUtils');
const jwt = require('jsonwebtoken');

describe('bulkAgentController additional tests', () => {
  beforeEach(() => {
    jwt.decode = jest.fn().mockReturnValue({ name: 'testUser', unique_name: 'test@test.com' });
  });

  afterEach(() => jest.clearAllMocks());

  const makeRes = () => {
    const res = {};
    res.status = jest.fn().mockReturnValue(res);
    res.json = jest.fn().mockReturnValue(res);
    return res;
  };

  test('bulkStartAgent calls executeCommandOnAgent and returns 200', async () => {
    const req = { body: [{ hostname: 'h1', osVersion: 'v1' }, { hostname: 'h2', osVersion: 'v2' }] };
    const res = makeRes();

    await bulkStartAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    // setImmediate schedules async work; wait one tick then assert executeCommandOnAgent
    await new Promise(r => setImmediate(r));
    expect(executeCommandOnAgent).toHaveBeenCalled();
  });

  test('bulkStopAgent handles NOT_FOUND response', async () => {
    const req = { 
      body: { hostname: ['h'] },
      headers: { 'authorization': 'Bearer eyJhbGc...' }
    };
    const res = makeRes();
    svc.putShutDown.mockResolvedValue({ status: responseCodes.NOT_FOUND });

    await bulkStopAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.NOT_FOUND);
    expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ flag: 'error' }));
  });

  test('bulkRestartAgent handles SERVER_ERROR response', async () => {
    const req = { 
      body: { hostname: ['h'] },
      headers: { 'authorization': 'Bearer eyJhbGc...' }
    };
    const res = makeRes();
    svc.putRestartAgent.mockResolvedValue({ status: responseCodes.SERVER_ERROR });

    await bulkRestartAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
  });

  test('bulkUpgradeAgent handles success response', async () => {
    const req = { 
      body: { hostname: ['h'] },
      headers: { 'authorization': 'Bearer eyJhbGc...' }
    };
    const res = makeRes();
    svc.updateVersion.mockResolvedValue({ status: responseCodes.SUCCESS, data: { ok: true } });

    await bulkUpgradeAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ flag: 'success' }));
  });

  test('bulkSyncAgent and bulkEnvUpdate propagate success', async () => {
    const req = { 
      body: { hostname: ['h'] },
      headers: { 'authorization': 'Bearer eyJhbGc...' }
    };
    const res = makeRes();
    svc.sycAgentCOnfig.mockResolvedValue({ status: responseCodes.SUCCESS, data: {} });
    svc.updateEnv.mockResolvedValue({ status: responseCodes.SUCCESS, data: {} });

    await bulkSyncAgent(req, res);
    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);

    await bulkEnvUpdate(req, res);
    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
  });

});
