const bulkActionLogsController = require('../../server/controllers/bulkActionLogsController');
const BulkActionLogsModel = require('../../server/models/bulkActionLogsModel');
const responseCodes = require('../../server/utils/responseCodes');

jest.mock('../../server/models/bulkActionLogsModel');

const makeRes = () => {
  const json = jest.fn().mockReturnThis();
  const status = jest.fn().mockReturnThis();
  return { json, status };
};

const mockFindChain = (data = []) => ({
  sort: jest.fn().mockReturnThis(),
  skip: jest.fn().mockReturnThis(),
  limit: jest.fn().mockReturnThis(),
  lean: jest.fn().mockResolvedValue(data),
});

describe('bulkActionLogsController', () => {

  afterEach(() => jest.clearAllMocks());

  describe('getBulkActionLogs', () => {

    test('default success', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();

      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);

      await bulkActionLogsController.getBulkActionLogs(req, res);

      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('Completed status logic', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();

      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        { status: 'Completed', successful: 2, failed: 0, pending: 0 }
      ]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);

      await bulkActionLogsController.getBulkActionLogs(req, res);

      const data = res.json.mock.calls[0][0].data.data[0];
      expect(data.status).toBe('Completed');
    });

    test('Partial status logic', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();

      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        { status: 'Partial', successful: 1, failed: 0, pending: 1 }
      ]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);

      await bulkActionLogsController.getBulkActionLogs(req, res);

      const data = res.json.mock.calls[0][0].data.data[0];
      expect(data.status).toBe('Partial');
    });

    test('Failed status logic', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();

      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        { status: 'Failed', successful: 0, failed: 2, pending: 0 }
      ]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);

      await bulkActionLogsController.getBulkActionLogs(req, res);

      const data = res.json.mock.calls[0][0].data.data[0];
      expect(data.status).toBe('Failed');
    });

    test('status filter works', async () => {
      const req = {
        method: 'POST',
        body: { status: ['Completed'] }
      };
      const res = makeRes();

      // DB returns only the matching record (simulating DB-side filter on status field)
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        { status: 'Completed', successful: 2, failed: 0, pending: 0 }
      ]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);

      await bulkActionLogsController.getBulkActionLogs(req, res);

      const data = res.json.mock.calls[0][0].data.data;
      expect(data.length).toBe(1);
      expect(data[0].status).toBe('Completed');
    });

    test('GET request path', async () => {
      const req = { method: 'GET', query: {} };
      const res = makeRes();

      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);

      await bulkActionLogsController.getBulkActionLogs(req, res);

      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('handles DB error', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();

      BulkActionLogsModel.find = jest.fn(() => {
        throw new Error();
      });

      await bulkActionLogsController.getBulkActionLogs(req, res);

      expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    });

    test('search filter sets _id query', async () => {
      const req = { method: 'POST', body: { search: ' abc123 ' } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('type as array with valid items', async () => {
      const req = { method: 'POST', body: { type: ['agentStop', 'agentStart'] } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('type as array with only empty strings', async () => {
      const req = { method: 'POST', body: { type: ['', '  '] } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('type as string', async () => {
      const req = { method: 'POST', body: { type: 'agentStop' } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('users as array with valid items', async () => {
      const req = { method: 'POST', body: { users: ['user1', 'user2'] } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('users as array with only empty strings', async () => {
      const req = { method: 'POST', body: { users: ['', '  '] } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('users as string', async () => {
      const req = { method: 'POST', body: { users: 'user1' } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('status as string post-filter', async () => {
      const req = { method: 'POST', body: { status: 'Completed' } };
      const res = makeRes();
      // DB returns only the matching record (simulating DB-side filter on status field)
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        { status: 'Completed', successful: 2, failed: 0, pending: 0 }
      ]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      const data = res.json.mock.calls[0][0].data.data;
      expect(data.length).toBe(1);
      expect(data[0].status).toBe('Completed');
    });

    test('dateRange with start and end', async () => {
      const req = {
        method: 'POST',
        body: { dateRange: { start: '2024-01-01', end: '2024-12-31' } }
      };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('dateRange with only start', async () => {
      const req = { method: 'POST', body: { dateRange: { start: '2024-01-01' } } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('dateRange with only end', async () => {
      const req = { method: 'POST', body: { dateRange: { end: '2024-12-31' } } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('sortBy alphabet asc', async () => {
      const req = { method: 'POST', body: { sortBy: 'alphabet', sortOrder: 'asc' } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('sortBy alphabet desc', async () => {
      const req = { method: 'POST', body: { sortBy: 'alphabet', sortOrder: 'desc' } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('sortBy date asc', async () => {
      const req = { method: 'POST', body: { sortBy: 'date', sortOrder: 'asc' } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

    test('status already set on log is preserved', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        { status: 'CustomStatus', successful: 0, failed: 0, pending: 0 }
      ]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      const data = res.json.mock.calls[0][0].data.data[0];
      expect(data.status).toBe('CustomStatus');
    });

    test('status empty when all counters zero', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        { successful: 0, failed: 0, pending: 0 }
      ]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      const data = res.json.mock.calls[0][0].data.data[0];
      expect(data.status).toBe('');
    });

    test('pagination with page number and size', async () => {
      const req = { method: 'POST', body: { pageNo: '1', pageSize: '5' } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      BulkActionLogsModel.countDocuments = jest.fn().mockResolvedValue(20); // NOSONAR
      await bulkActionLogsController.getBulkActionLogs(req, res);
      const pagination = res.json.mock.calls[0][0].data.pagination;
      expect(pagination.pageNo).toBe(1);
      expect(pagination.pageSize).toBe(5); // NOSONAR
      expect(pagination.hasPreviousPage).toBe(true);
      expect(pagination.hasNextPage).toBe(true);
    });

    test('distinct returns null/empty values filtered out', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn()
        .mockResolvedValueOnce([null, '', 'agentStop', undefined])
        .mockResolvedValueOnce([null, '', 'user1']);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      const filters = res.json.mock.calls[0][0].data.filters;
      expect(filters.actions).toEqual(['agentStop']);
      expect(filters.users).toEqual(['user1']);
    });

    test('status as whitespace string results in no filter', async () => {
      const req = { method: 'POST', body: { status: '   ' } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        { successful: 2, failed: 0, pending: 0 }
      ]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      // No filtering applied - both records returned
      const data = res.json.mock.calls[0][0].data.data;
      expect(data.length).toBe(1);
    });

    test('status array with empty strings filtered out (validStatus.length === 0)', async () => {
      const req = { method: 'POST', body: { status: ['', '  '] } };
      const res = makeRes();
      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([]));
      BulkActionLogsModel.distinct = jest.fn().mockResolvedValue([]);
      await bulkActionLogsController.getBulkActionLogs(req, res);
      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });

  });


  describe('getBulkActionLogById', () => {

    test('fallback + logs mapping', async () => {
      const req = { params: { id: '1' } };
      const res = makeRes();

      BulkActionLogsModel.findById = jest.fn().mockResolvedValue({
        agents: [
          { hostname: 'srv1', logs: [{ message: 'ok' }] },
          {},
        ]
      });

      await bulkActionLogsController.getBulkActionLogById(req, res);

      const servers = res.json.mock.calls[0][0].data.servers;
      expect(servers[0].message).toBe('ok');
      expect(servers[1].serverName).toBe('Unknown');
    });

    test('returns 404', async () => {
      const req = { params: { id: '1' } };
      const res = makeRes();

      BulkActionLogsModel.findById = jest.fn().mockResolvedValue(null);

      await bulkActionLogsController.getBulkActionLogById(req, res);

      expect(res.status).toHaveBeenCalledWith(responseCodes.NOT_FOUND);
    });

    test('uses servers field when agents not present', async () => {
      const req = { params: { id: '1' } };
      const res = makeRes();

      BulkActionLogsModel.findById = jest.fn().mockResolvedValue({
        servers: [{ hostname: 'srv1', logs: [] }]
      });

      await bulkActionLogsController.getBulkActionLogById(req, res);

      const servers = res.json.mock.calls[0][0].data.servers;
      expect(servers[0].serverName).toBe('srv1');
    });

    test('uses agent.message when no logs array', async () => {
      const req = { params: { id: '1' } };
      const res = makeRes();

      BulkActionLogsModel.findById = jest.fn().mockResolvedValue({
        agents: [{ hostname: 'srv1', message: 'direct msg', logs: [] }]
      });

      await bulkActionLogsController.getBulkActionLogById(req, res);

      const servers = res.json.mock.calls[0][0].data.servers;
      expect(servers[0].message).toBe('direct msg');
    });

    test('agent with no message and no logs returns N/A', async () => {
      const req = { params: { id: '1' } };
      const res = makeRes();

      BulkActionLogsModel.findById = jest.fn().mockResolvedValue({
        agents: [{ hostname: 'srv1' }]
      });

      await bulkActionLogsController.getBulkActionLogById(req, res);

      const servers = res.json.mock.calls[0][0].data.servers;
      expect(servers[0].message).toBe('N/A');
    });

    test('log with no agents and no servers returns empty servers array', async () => {
      const req = { params: { id: '1' } };
      const res = makeRes();

      BulkActionLogsModel.findById = jest.fn().mockResolvedValue({
        totalAgents: 1, successful: 1
      });

      await bulkActionLogsController.getBulkActionLogById(req, res);

      expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
      const servers = res.json.mock.calls[0][0].data.servers;
      expect(servers).toEqual([]);
    });

    test('agent log with empty message falls back to agent.message', async () => {
      const req = { params: { id: '1' } };
      const res = makeRes();

      BulkActionLogsModel.findById = jest.fn().mockResolvedValue({
        agents: [{ hostname: 'srv1', message: 'fallback', logs: [{ message: '' }] }]
      });

      await bulkActionLogsController.getBulkActionLogById(req, res);

      const servers = res.json.mock.calls[0][0].data.servers;
      expect(servers[0].message).toBe('fallback');
    });

    test('DB error returns 500', async () => {
      const req = { params: { id: '1' } };
      const res = makeRes();

      BulkActionLogsModel.findById = jest.fn().mockRejectedValue(new Error('DB error'));

      await bulkActionLogsController.getBulkActionLogById(req, res);

      expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    });

  });

  describe('getBulkActionLogDataForExcel', () => {

    test('covers all branches', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();

      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        {
          agents: [
            { hostname: 'srv1', logs: [{ message: 'final log' }] },
            { serverName: 'srv2', logs: [] },
            {}
          ]
        }
      ]));

      await bulkActionLogsController.getBulkActionLogDataForExcel(req, res);

      const result = res.json.mock.calls[0][0].data;

      expect(result[0].servers[0].message).toBe('final log');
      expect(result[0].servers[1].serverName).toBe('srv2');
      expect(result[0].servers[2].serverName).toBe('Unknown');
    });

    test('uses log.servers when log.agents not present', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();

      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        {
          servers: [{ hostname: 'srv-a', logs: [] }]
        }
      ]));

      await bulkActionLogsController.getBulkActionLogDataForExcel(req, res);

      const result = res.json.mock.calls[0][0].data;
      expect(result[0].servers[0].serverName).toBe('srv-a');
    });

    test('agent with no message and no logs returns N/A in excel', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();

      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        {
          agents: [{ hostname: 'srv1' }]
        }
      ]));

      await bulkActionLogsController.getBulkActionLogDataForExcel(req, res);

      const result = res.json.mock.calls[0][0].data;
      expect(result[0].servers[0].message).toBe('N/A');
    });

    test('log with no agents and no servers gives empty servers in excel', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();

      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        { jobSequence: 'J1', action: 'agentStop' }
      ]));

      await bulkActionLogsController.getBulkActionLogDataForExcel(req, res);

      const result = res.json.mock.calls[0][0].data;
      expect(result[0].servers).toEqual([]);
    });

    test('agent log with empty message falls back to agent.message in excel', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();

      BulkActionLogsModel.find = jest.fn().mockReturnValue(mockFindChain([
        {
          agents: [{ hostname: 'srv1', message: 'fallback-msg', logs: [{ message: '' }] }]
        }
      ]));

      await bulkActionLogsController.getBulkActionLogDataForExcel(req, res);

      const result = res.json.mock.calls[0][0].data;
      expect(result[0].servers[0].message).toBe('fallback-msg');
    });

    test('excel error', async () => {
      const req = { method: 'POST', body: {} };
      const res = makeRes();

      BulkActionLogsModel.find = jest.fn(() => {
        throw new Error();
      });

      await bulkActionLogsController.getBulkActionLogDataForExcel(req, res);

      expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    });

  });

});