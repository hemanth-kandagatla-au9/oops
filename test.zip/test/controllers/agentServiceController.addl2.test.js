const controller = require('../../server/controllers/agentServiceController');
const responseCodes = require('../../server/utils/responseCodes');

jest.mock('../../server/models/agentModel', () => ({ findOne: jest.fn(), find: jest.fn(), countDocuments: jest.fn() }));
jest.mock('../../server/utils/agentUtils', () => ({ buildQuery: jest.fn(), sanitizePasswordFields: jest.fn(), handleApiResponse: jest.fn(), getDistinctValues: jest.fn(), executeCommandOnAgent: jest.fn() }));

const AgentModel = require('../../server/models/agentModel');
const { sanitizePasswordFields, executeCommandOnAgent, buildQuery } = require('../../server/utils/agentUtils');

const makeRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
};

beforeEach(() => jest.clearAllMocks());

test('startAgentService calls executeCommandOnAgent', async () => {
  const req = { body: { hostname: 'h1', osVersion: 'v1' } };
  const res = makeRes();
  await controller.startAgentService(req, res);
  expect(executeCommandOnAgent).toHaveBeenCalledWith(req, 'h1', 'v1', res);
});

test('getAgentInfo returns NOT_FOUND when no agent', async () => {
  AgentModel.findOne.mockResolvedValue(null);
  const req = { body: { hostname: 'h' } };
  const res = makeRes();
  await controller.getAgentInfo(req, res);
  expect(res.status).toHaveBeenCalledWith(responseCodes.NOT_FOUND);
});

test('getAgentInfo returns formatted agent when found', async () => {
  const fakeAgent = {
    agent_details: { cpu_usage: 0.1234, memory: 1024 * 1024 * 5, disk_usage: 2048 },
    agent_config: { password: 'p' },
    agent_local_config: { password: 'lp' },
    toObject: function() { return { agent_details: this.agent_details, agent_config: this.agent_config, agent_local_config: this.agent_local_config }; }
  };
  AgentModel.findOne.mockResolvedValue(fakeAgent);
  sanitizePasswordFields.mockImplementation(cfg => ({ ...cfg, password: '***' }));
  const req = { body: { hostname: 'h' } };
  const res = makeRes();
  await controller.getAgentInfo(req, res);
  expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
  expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ flag: 'success', data: expect.any(Object) }));
});

test('getAgentsData returns paginated results', async () => {
  const docs = [{ toObject: () => ({ agent_config: {}, agent_local_config: {} }) }, { toObject: () => ({}) }];
  AgentModel.find.mockReturnValue({ skip: () => ({ limit: () => ({ sort: () => Promise.resolve(docs) }) }) });
  AgentModel.countDocuments.mockResolvedValueOnce(2).mockResolvedValueOnce(1).mockResolvedValueOnce(0).mockResolvedValueOnce(0);
  buildQuery.mockReturnValue({});
  sanitizePasswordFields.mockImplementation(cfg => cfg);
  const req = { method: 'POST', body: { pageSize: '1', pageNo: '0' } };
  const res = makeRes();
  await controller.getAgentsData(req, res);
  expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
  expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ flag: 'success' }));
});

test('getAgentsData handles errors', async () => {
  AgentModel.find.mockImplementation(() => { throw new Error('boom'); });
  const req = { method: 'GET', query: {} };
  const res = makeRes();
  await controller.getAgentsData(req, res);
  expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
});

test('checkBasicAuth NOT_FOUND and success branches', async () => {
  AgentModel.findOne.mockResolvedValueOnce(null);
  const req1 = { query: { hostname: 'h' } };
  const res1 = makeRes();
  await controller.checkBasicAuth(req1, res1);
  expect(res1.status).toHaveBeenCalledWith(responseCodes.NOT_FOUND);

  AgentModel.findOne.mockResolvedValueOnce({ agent_details: { version: '2.5' } });
  const req2 = { query: { hostname: 'h2' } };
  const res2 = makeRes();
  await controller.checkBasicAuth(req2, res2);
  expect(res2.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
  expect(res2.json).toHaveBeenCalledWith(expect.objectContaining({ flag: 'success', data: expect.objectContaining({ isBasicAuth: true }) }));

  AgentModel.findOne.mockResolvedValueOnce({ agent_details: { version: '3.5' } });
  const req3 = { query: { hostname: 'h3' } };
  const res3 = makeRes();
  await controller.checkBasicAuth(req3, res3);
  expect(res3.json).toHaveBeenCalledWith(expect.objectContaining({ flag: 'success', data: expect.objectContaining({ isBasicAuth: false }) }));
});

test('checkHealth and checkReady return success', async () => {
  const res = makeRes();
  await controller.checkHealth({}, res);
  expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
  await controller.checkReady({}, res);
  expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
});
