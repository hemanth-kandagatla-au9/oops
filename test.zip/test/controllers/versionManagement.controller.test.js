const controller = require('../../server/controllers/version-management-controller/versionManagement.controller');
const responseCodes = require('../../server/utils/responseCodes');

jest.mock('../../server/services/versionManagementService', () => ({
  saveVersion: jest.fn(),
  getVersions: jest.fn(),
  softDeleteVersion: jest.fn(),
  updateVersionService: jest.fn()
}));

const svc = require('../../server/services/versionManagementService');

describe('versionManagement.controller', () => {
  afterEach(() => jest.clearAllMocks());

  const makeReqRes = () => {
    const req = { body: {}, query: {}, params: {} };
    const res = {};
    res.status = jest.fn().mockReturnValue(res);
    res.json = jest.fn().mockReturnValue(res);
    return { req, res };
  };

  test('createVersion handles save error', async () => {
    const { req, res } = makeReqRes();
    req.body = { agentVersion: '1.0' };
    svc.saveVersion.mockRejectedValue(new Error('boom'));

    await controller.createVersion(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
  });

  test('createVersion handles exists', async () => {
    const { req, res } = makeReqRes();
    req.body = { agentVersion: '1.0' };
    svc.saveVersion.mockResolvedValue(responseCodes.EXISTS);

    await controller.createVersion(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.EXISTS);
  });

  test('createVersion success', async () => {
    const { req, res } = makeReqRes();
    req.body = { agentVersion: '1.0' };
    svc.saveVersion.mockResolvedValue({ id: 'v1' });

    await controller.createVersion(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
  });

  test('fetchVersions handles error', async () => {
    const { req, res } = makeReqRes();
    svc.getVersions.mockRejectedValue(new Error('fail'));

    await controller.fetchVersions(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
  });

  test('fetchVersions success', async () => {
    const { req, res } = makeReqRes();
    svc.getVersions.mockResolvedValue([{ v: 1 }]);

    await controller.fetchVersions(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
  });

  test('deleteVersion invalid id', async () => {
    const { req, res } = makeReqRes();
    req.params.id = 'bad';
    svc.softDeleteVersion.mockResolvedValue('Invalid ObjectId');

    await controller.deleteVersion(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.ERROR);
  });

  test('deleteVersion not found', async () => {
    const { req, res } = makeReqRes();
    req.params.id = 'x';
    svc.softDeleteVersion.mockResolvedValue('Version not found');

    await controller.deleteVersion(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.NOT_FOUND);
  });

  test('deleteVersion success', async () => {
    const { req, res } = makeReqRes();
    req.params.id = 'ok';
    svc.softDeleteVersion.mockResolvedValue({ id: 'ok' });

    await controller.deleteVersion(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
  });

  test('updateVersion invalid id', async () => {
    const { req, res } = makeReqRes();
    req.params.id = 'bad';
    svc.updateVersionService.mockResolvedValue('Invalid ObjectId');

    await controller.updateVersion(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.ERROR);
  });

  test('updateVersion not found', async () => {
    const { req, res } = makeReqRes();
    req.params.id = 'x';
    svc.updateVersionService.mockResolvedValue('Version not found');

    await controller.updateVersion(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.NOT_FOUND);
  });

  test('updateVersion success', async () => {
    const { req, res } = makeReqRes();
    req.params.id = 'ok';
    svc.updateVersionService.mockResolvedValue({ id: 'ok' });

    await controller.updateVersion(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
  });

});
