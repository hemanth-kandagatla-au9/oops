const responseCodes = require('../../server/utils/responseCodes');
const jwt = require('jsonwebtoken');

jest.mock('jsonwebtoken');

jest.mock('../../server/services/agentService', () => ({
  putShutDown: jest.fn(),
  putRestartAgent: jest.fn(),
  updateVersion: jest.fn(),
  sycAgentCOnfig: jest.fn(),
  updateEnv: jest.fn(),
}));

jest.mock('../../server/utils/agentUtils', () => ({
  executeCommandOnAgent: jest.fn(),
}));

const {
  putShutDown,
  putRestartAgent,
  updateVersion,
  sycAgentCOnfig,
  updateEnv,
} = require('../../server/services/agentService');

const { executeCommandOnAgent } = require('../../server/utils/agentUtils');

const {
  bulkStartAgent,
  bulkStopAgent,
  bulkRestartAgent,
  bulkUpgradeAgent,
  validateAgent,
  bulkSyncAgent,
  bulkEnvUpdate,
} = require('../../server/controllers/bulkAgentController');

describe('bulkAgentController', () => {
  let req;
  let res;
  let setImmediateSpy;

  beforeEach(() => {
    jest.clearAllMocks();

    // Set up mock return values for services
    putShutDown.mockResolvedValue({ status: responseCodes.SUCCESS, message: 'Agent stopped' });
    putRestartAgent.mockResolvedValue({ status: responseCodes.SUCCESS, message: 'Agent restarted' });
    updateVersion.mockResolvedValue({ status: responseCodes.SUCCESS, message: 'Agent upgraded' });
    sycAgentCOnfig.mockResolvedValue({ status: responseCodes.SUCCESS, message: 'Config synced' });
    updateEnv.mockResolvedValue({ status: responseCodes.SUCCESS, message: 'Environment updated' });

    // Mock JWT decode
    jwt.decode.mockReturnValue({ name: 'testUser', unique_name: 'test@example.com' });

    req = {
      body: [
        { hostname: 'a1', osVersion: '7.10' },
        { hostname: 'a2', osVersion: '6.5' },
      ],
      query: {},
      headers: {
        authorization: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoidGVzdFVzZXIiLCJlbWFpbCI6InRlc3RAZXhhbXBsZS5jb20ifQ.test'
      }
    };

    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
    };

    setImmediateSpy = jest
      .spyOn(global, 'setImmediate')
      .mockImplementation((fn, ...args) => fn(...args));
  });

  afterEach(() => {
    setImmediateSpy.mockRestore();
  });

  it('bulkStartAgent responds success and triggers executeCommandOnAgent for each agent', async () => {
    await bulkStartAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(executeCommandOnAgent).toHaveBeenCalledTimes(2);
    expect(executeCommandOnAgent).toHaveBeenCalledWith(
      req,
      'a1',
      '7.10',
      res,
      true
    );
  });

  it('bulkStopAgent schedules shutdown for each agent', async () => {
    await bulkStopAgent(req, res);

    // controller calls service once with full body
    expect(putShutDown).toHaveBeenCalledTimes(1);
    expect(putShutDown).toHaveBeenCalledWith(expect.objectContaining({
      0: expect.objectContaining({ hostname: 'a1' })
    }));
    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(res.json).toHaveBeenCalledWith({ 
      flag: 'success', 
      data: expect.objectContaining({ message: 'Agent stopped' }) 
    });
  });

  it('bulkRestartAgent schedules restart for each agent', async () => {
    await bulkRestartAgent(req, res);
    expect(putRestartAgent).toHaveBeenCalledTimes(1);
    expect(putRestartAgent).toHaveBeenCalledWith(expect.objectContaining({
      0: expect.objectContaining({ hostname: 'a1' })
    }));
    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(res.json).toHaveBeenCalledWith({ 
      flag: 'success', 
      data: expect.objectContaining({ message: 'Agent restarted' }) 
    });
  });

  it('bulkUpgradeAgent responds success and calls updateVersion with version data', async () => {
    req.query = { risebotAgentVersion: '9.9.9' };

    await bulkUpgradeAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(updateVersion).toHaveBeenCalledTimes(1);
    expect(updateVersion).toHaveBeenCalledWith(expect.objectContaining({
      0: expect.objectContaining({ hostname: 'a1' })
    }));
    expect(res.json).toHaveBeenCalledWith({ 
      flag: 'success', 
      data: expect.objectContaining({ message: 'Agent upgraded' }) 
    });
  });

  it('bulkSyncAgent schedules config sync for each agent', async () => {
    await bulkSyncAgent(req, res);
    expect(sycAgentCOnfig).toHaveBeenCalledTimes(1);
    expect(sycAgentCOnfig).toHaveBeenCalledWith(expect.objectContaining({
      0: expect.objectContaining({ hostname: 'a1' })
    }));
    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(res.json).toHaveBeenCalledWith({ 
      flag: 'success', 
      data: expect.objectContaining({ message: 'Config synced' }) 
    });
  });

  it('bulkEnvUpdate responds success and calls updateEnv with env data', async () => {
    req.query = { env: 'qa' };

    await bulkEnvUpdate(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(updateEnv).toHaveBeenCalledTimes(1);
    expect(updateEnv).toHaveBeenCalledWith(expect.objectContaining({
      0: expect.objectContaining({ hostname: 'a1' })
    }));
    expect(res.json).toHaveBeenCalledWith({ 
      flag: 'success', 
      data: expect.objectContaining({ message: 'Environment updated' }) 
    });
  });

  it('validateAgent returns isCompatible true', async () => {
    await validateAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(res.json).toHaveBeenCalledWith({ isCompatible: true });
  });

  it('bulkStopAgent returns SERVER_ERROR on invalid input', async () => {
    req.body = null;
    putShutDown.mockRejectedValue(new Error('Invalid input'));

    await bulkStopAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    expect(res.json).toHaveBeenCalledWith({ flag: 'error', error: 'Invalid input' });
    expect(putShutDown).toHaveBeenCalledTimes(1);
  });

  it('bulkStopAgent returns SERVICE error when service returns NOT_FOUND', async () => {
    putShutDown.mockResolvedValue({ status: responseCodes.NOT_FOUND });

    await bulkStopAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.NOT_FOUND);
    expect(res.json).toHaveBeenCalledWith({ flag: 'error', error: 'File Not found' });
  });

  it('bulkRestartAgent returns SERVICE error when service returns SERVER_ERROR', async () => {
    putRestartAgent.mockResolvedValue({ status: responseCodes.SERVER_ERROR });

    await bulkRestartAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    expect(res.json).toHaveBeenCalledWith({ flag: 'error', error: 'Unable to connect to server' });
  });

  it('bulkUpgradeAgent handles errors correctly', async () => {
    updateVersion.mockRejectedValue(new Error('Version not found'));

    req.query = { risebotAgentVersion: '9.9.9' };
    await bulkUpgradeAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    expect(res.json).toHaveBeenCalledWith({ flag: 'error', error: 'Version not found' });
  });

  it('bulkSyncAgent handles sync errors', async () => {
    sycAgentCOnfig.mockRejectedValue(new Error('Sync failed'));

    await bulkSyncAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    expect(res.json).toHaveBeenCalledWith({ flag: 'error', error: 'Sync failed' });
  });

  it('bulkEnvUpdate handles update errors', async () => {
    updateEnv.mockRejectedValue(new Error('Environment update failed'));

    req.query = { env: 'qa' };
    await bulkEnvUpdate(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    expect(res.json).toHaveBeenCalledWith({ flag: 'error', error: 'Environment update failed' });
  });

  it('bulkStartAgent handles errors during batch command', async () => {
    executeCommandOnAgent.mockImplementation(() => {
      throw new Error('Command execution failed');
    });

    await bulkStartAgent(req, res);

    // setImmediate still calls the function even if it throws
    // But the loop continues
    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(executeCommandOnAgent).toHaveBeenCalled();
  });

  it('bulkStopAgent handles missing authorization header without throwing', async () => {
    req.headers = {};
    // jwt.decode should throw or return null when base64Credentials is undefined
    jwt.decode.mockReturnValue(null);

    putShutDown.mockImplementation(() => {
      throw new Error('Missing credentials');
    });

    await bulkStopAgent(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
  });
});
