const controller = require('../../server/controllers/agentServiceController');
const responseCodes = require('../../server/utils/responseCodes');

jest.mock('../../server/models/agentModel', () => ({
  findOne: jest.fn(),
  find: jest.fn(),
  countDocuments: jest.fn()
}));

jest.mock('../../server/utils/agentUtils', () => ({
  sanitizePasswordFields: jest.fn(x => x),
  buildQuery: jest.fn(() => ({})),
  handleApiResponse: jest.fn((req, res, fn) => fn(req, res)),
  executeCommandOnAgent: jest.fn()
}));

const AgentModel = require('../../server/models/agentModel');
const { executeCommandOnAgent, sanitizePasswordFields } = require('../../server/utils/agentUtils');

describe('agentServiceController additional tests', () => {
  afterEach(() => jest.clearAllMocks());

  const makeReqRes = () => {
    const req = { body: {}, query: {}, method: 'POST' };
    const res = {};
    res.status = jest.fn().mockReturnValue(res);
    res.json = jest.fn().mockReturnValue(res);
    return { req, res };
  };

  test('startAgentService calls executeCommandOnAgent', async () => {
    const { req, res } = makeReqRes();
    req.body = { hostname: 'h1', osVersion: 'v' };
    await controller.startAgentService(req, res);
    expect(executeCommandOnAgent).toHaveBeenCalled();
  });

  test('getAgentInfo returns 404 when agent not found', async () => {
    const { req, res } = makeReqRes();
    req.body = { hostname: 'missing' };
    AgentModel.findOne.mockResolvedValue(null);

    await controller.getAgentInfo(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.NOT_FOUND);
  });

  test('getAgentInfo returns sanitized result when found', async () => {
    const { req, res } = makeReqRes();
    req.body = { hostname: 'h1' };
    const mockDoc = {
      agent_details: { cpu_usage: 1.2345, memory: 1048576, disk_usage: 2097152 },
      agent_config: { secret: 'x' },
      agent_local_config: { secret: 'y' },
      toObject: function() { return { agent_details: this.agent_details, agent_config: this.agent_config, agent_local_config: this.agent_local_config }; }
    };
    AgentModel.findOne.mockResolvedValue(mockDoc);

    await controller.getAgentInfo(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(sanitizePasswordFields).toHaveBeenCalled();
  });

  test('getAgentsData returns pagination structure', async () => {
    const { req, res } = makeReqRes();
    req.body = { pageSize: '2', pageNo: '0' };
    const docs = [ { toObject: () => ({ id: 1 }) }, { toObject: () => ({ id: 2 }) } ];
    AgentModel.find.mockReturnValue({ skip: () => ({ limit: () => ({ sort: () => Promise.resolve(docs) }) }) });
    AgentModel.countDocuments.mockResolvedValueOnce(2).mockResolvedValueOnce(1).mockResolvedValueOnce(1).mockResolvedValueOnce(0);

    await controller.getAgentsData(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ flag: 'success' }));
  });

  test('checkBasicAuth returns NOT_FOUND when no host', async () => {
    const { req, res } = makeReqRes();
    req.query = { hostname: 'x' };
    AgentModel.findOne.mockResolvedValue(null);

    await controller.checkBasicAuth(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.NOT_FOUND);
  });

  test('checkBasicAuth returns version info', async () => {
    const { req, res } = makeReqRes();
    req.query = { hostname: 'x' };
    AgentModel.findOne.mockResolvedValue({ agent_details: { version: '2.5' } });

    await controller.checkBasicAuth(req, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ flag: 'success' }));
  });

});
