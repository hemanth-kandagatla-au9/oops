const makeThrowOnceRes = () => {
  const res = {};
  let callCount = 0;
  res.status = jest.fn(() => {
    callCount += 1;
    if (callCount === 1) throw new Error('boom');
    return res;
  });
  res.json = jest.fn(() => res);
  return res;
};

describe('ui monitoring controllers - error paths', () => {
  let consoleSpy;

  beforeEach(() => {
    consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    consoleSpy.mockRestore();
  });

  test.each([
    [
      'application',
      () => require('../../server/controllers/ui-monitoring-controller/applicationController').fetchApplicationPerformanceData,
    ],
    [
      'infrastructure',
      () =>
        require('../../server/controllers/ui-monitoring-controller/infrastructureController')
          .fetchInfrastructureMonitoringData,
    ],
    [
      'logs',
      () => require('../../server/controllers/ui-monitoring-controller/logsController').fetchLogsData,
    ],
    [
      'metrics',
      () => require('../../server/controllers/ui-monitoring-controller/metricsController').fetchCardData,
    ],
    [
      'network',
      () =>
        require('../../server/controllers/ui-monitoring-controller/networkController')
          .fetchNetworkMonitoringData,
    ],
    [
      'securityAlert',
      () =>
        require('../../server/controllers/ui-monitoring-controller/securityAlertController')
          .fetchAlertsData,
    ],
  ])('%s controller handles exceptions and returns 500', async (_name, getHandler) => {
    const handler = getHandler();
    const req = {};
    const res = makeThrowOnceRes();

    await handler(req, res);
    expect(res.status).toHaveBeenLastCalledWith(500);
    expect(res.json).toHaveBeenLastCalledWith(
      expect.objectContaining({ status: 'error', statusCode: 500, message: 'Internal Server Error' })
    );
  });
});
