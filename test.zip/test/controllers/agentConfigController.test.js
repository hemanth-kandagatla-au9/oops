const responseCodes = require('../../server/utils/responseCodes');

jest.mock('../../server/models/agentConfigModel', () => ({
  find: jest.fn(),
  updateOne: jest.fn(),
}));

jest.mock('../../server/utils/envUtils', () => ({
  getOpenSearchLogKey: jest.fn(),
}));

const AgentConfigModel = require('../../server/models/agentConfigModel');
const { getOpenSearchLogKey } = require('../../server/utils/envUtils');

const {
  updateAgentConfigDetails,
  getAgentConfigDetails,
} = require('../../server/controllers/agentConfigController');

describe('agentConfigController', () => {
  let res;

  beforeEach(() => {
    jest.clearAllMocks();
    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
    };

    process.env.LOG_KEY = '12345678901234567890123456789012'; // 32 bytes
  });

  // it('updateAgentConfigDetails encrypts and getAgentConfigDetails decrypts', async () => {
  //   const reqUpdate = { body: { featureFlag: true, threshold: 3 } };

  //   AgentConfigModel.find.mockResolvedValue([{ _id: 'cfg1', configs: 'ignored' }]);

  //   let savedEncrypted;
  //   AgentConfigModel.updateOne.mockImplementation(async (_filter, update) => {
  //     savedEncrypted = update.$set.configs;
  //     return { modifiedCount: 1 };
  //   });

  //   await updateAgentConfigDetails(reqUpdate, res);

  //   expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
  //   expect(AgentConfigModel.updateOne).toHaveBeenCalled();
  //   expect(typeof savedEncrypted).toBe('string');
  //   expect(savedEncrypted.length).toBeGreaterThan(0);

  //   const resGet = {
  //     status: jest.fn().mockReturnThis(),
  //     json: jest.fn().mockReturnThis(),
  //   };

  //   AgentConfigModel.find.mockResolvedValue([{ configs: savedEncrypted }]);

  //   await getAgentConfigDetails({}, resGet);

  //   expect(resGet.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
  //   expect(resGet.json).toHaveBeenCalledWith({
  //     flag: 'success',
  //     data: { featureFlag: true, threshold: 3 },
  //   });
  // });

  // it('getAgentConfigDetails removes password fields and password config entries', async () => {
  //   const reqUpdate = {
  //     body: {
  //       configs: [
  //         { propertyName: 'ip', propertyValue: '0.0.0.0', canModify: false, isVisible: true },
  //         { propertyName: 'password', propertyValue: '123456', canModify: false, isVisible: false },
  //         { propertyName: 'opensearch_password', propertyValue: 'secret', canModify: false, isVisible: false },
  //         { propertyName: 'username', propertyValue: 'user1', canModify: false, isVisible: true },
  //       ],
  //       password: 'top-level-password',
  //       nested: { token: 'abc', safe: 1 },
  //     },
  //   };

  //   AgentConfigModel.find.mockResolvedValue([{ _id: 'cfg1', configs: 'ignored' }]);

  //   let savedEncrypted;
  //   AgentConfigModel.updateOne.mockImplementation(async (_filter, update) => {
  //     savedEncrypted = update.$set.configs;
  //     return { modifiedCount: 1 };
  //   });

  //   await updateAgentConfigDetails(reqUpdate, res);

  //   const resGet = {
  //     status: jest.fn().mockReturnThis(),
  //     json: jest.fn().mockReturnThis(),
  //   };

  //   AgentConfigModel.find.mockResolvedValue([{ configs: savedEncrypted }]);

  //   await getAgentConfigDetails({}, resGet);

  //   const payload = resGet.json.mock.calls[0][0];
  //   expect(payload.flag).toBe('success');

  //   // Keys containing sensitive words are removed
  //   expect(payload.data.password).toBeUndefined();
  //   expect(payload.data.nested.token).toBeUndefined();
  //   expect(payload.data.nested.safe).toBe(1);

  //   // Config entries whose propertyName contains 'password' are removed
  //   expect(Array.isArray(payload.data.configs)).toBe(true);
  //   expect(payload.data.configs.some(c => String(c.propertyName).toLowerCase().includes('password'))).toBe(false);
  //   expect(payload.data.configs.some(c => c.propertyName === 'ip')).toBe(true);
  //   expect(payload.data.configs.some(c => c.propertyName === 'username')).toBe(true);
  // });

  it('falls back to getOpenSearchLogKey when LOG_KEY is missing', async () => {
    delete process.env.LOG_KEY;
    getOpenSearchLogKey.mockResolvedValue('12345678901234567890123456789012');

    const reqUpdate = { body: { a: 1 } };
    AgentConfigModel.find.mockResolvedValue([{ _id: 'cfg1', configs: 'ignored' }]);
    AgentConfigModel.updateOne.mockResolvedValue({ modifiedCount: 1 });

    await updateAgentConfigDetails(reqUpdate, res);

    expect(getOpenSearchLogKey).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
  });

  it('returns SERVER_ERROR when LOG_KEY length is invalid', async () => {
    process.env.LOG_KEY = 'short-key';

    const reqUpdate = { body: { a: 1 } };
    AgentConfigModel.find.mockResolvedValue([{ _id: 'cfg1', configs: 'ignored' }]);

    await updateAgentConfigDetails(reqUpdate, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ flag: 'error' })
    );
  });

  it('getAgentConfigDetails decrypts and returns sanitized data', async () => {
    process.env.LOG_KEY = '12345678901234567890123456789012';

    // First encrypt some data via updateAgentConfigDetails
    const reqUpdate = { body: { configs: [{ propertyName: 'ip', propertyValue: '0.0.0.0', canModify: false, isVisible: true }] } };
    AgentConfigModel.find.mockResolvedValue([{ _id: 'cfg1', configs: 'ignored' }]);
    let savedEncrypted;
    AgentConfigModel.updateOne.mockImplementation(async (_filter, update) => {
      savedEncrypted = update.$set.configs;
      return { modifiedCount: 1 };
    });
    await updateAgentConfigDetails(reqUpdate, res);

    // Now test getAgentConfigDetails
    const resGet = { status: jest.fn().mockReturnThis(), json: jest.fn().mockReturnThis() };
    AgentConfigModel.find.mockResolvedValue([{ _id: 'cfg1', configs: savedEncrypted }]);

    await getAgentConfigDetails({}, resGet);

    expect(resGet.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    expect(resGet.json).toHaveBeenCalledWith(
      expect.objectContaining({ flag: 'success' })
    );
  });

  it('getAgentConfigDetails returns SERVER_ERROR when AgentConfigModel.find fails', async () => {
    AgentConfigModel.find.mockRejectedValue(new Error('DB error'));

    await getAgentConfigDetails({}, res);

    expect(res.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ flag: 'error', error: 'DB error' })
    );
  });
});
