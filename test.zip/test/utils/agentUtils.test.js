// Mock dependencies
jest.mock('../../server/utils/opensearchLogger', () => ({
  LOGGER: {
    errorLog: jest.fn(),
    infoLog: jest.fn(),
    warningLog: jest.fn()
  }
}));

jest.mock('ssh2', () => ({
  Client: jest.fn()
}));

jest.mock('../../server/models/agentModel', () => ({
  findOne: jest.fn(),
  distinct: jest.fn()
}));

jest.mock('../../server/utils/envUtils', () => ({
  getServiceAccountPassword: jest.fn()
}));

const {
  executeCommandOnAgent,
  buildQuery,
  addFilter,
  getFieldName,
  getDistinctValues,
} = require('../../server/utils/agentUtils');

const { LOGGER } = require('../../server/utils/opensearchLogger');
const { Client } = require('ssh2');
const AgentModel = require('../../server/models/agentModel');
const { getServiceAccountPassword } = require('../../server/utils/envUtils');
const responseCodes = require('../../server/utils/responseCodes');

describe('Agent Utils Tests', () => {
  let mockReq, mockRes, mockClient, mockStream;

  beforeEach(() => {
    jest.clearAllMocks();
    
    // Mock environment variables
    process.env.RISE_SA_USERNAME = 'test-user';
    process.env.RISE_SA_PASSWORD = 'test-password';
    
    mockReq = {
      body: { hostname: 'test-host' },
      query: {}
    };
    
    mockRes = {
      status: jest.fn(() => mockRes),
      json: jest.fn(),
      set: jest.fn(),
      send: jest.fn()
    };

    mockStream = {
      on: jest.fn(),
      close: jest.fn()
    };

    mockClient = {
      on: jest.fn(),
      connect: jest.fn(),
      exec: jest.fn(),
      end: jest.fn()
    };

    Client.mockImplementation(() => mockClient);
  });

  describe('executeCommandOnAgent', () => {
    it('should use service command for OS version 6.x', async () => {
      const hostname = 'test-host';
      const osVersion = '6.5';
      
      mockClient.on.mockImplementation((event, callback) => {
        if (event === 'ready') {
          setTimeout(() => callback(), 10);
        }
      });

      mockClient.exec.mockImplementation((command, callback) => {
        expect(command).toBe('sudo service risebot start');
        callback(null, mockStream);
      });

      mockStream.on.mockImplementation((event, callback) => {
        if (event === 'close') {
          setTimeout(() => callback(0), 20);
        }
      });

      await executeCommandOnAgent(mockReq, hostname, osVersion, mockRes);
      
      await new Promise(resolve => setTimeout(resolve, 50));
    });

    it('should handle SSH connection errors', async () => {
      const hostname = 'test-host';
      const osVersion = '7.10';
      const connectionError = new Error('Connection failed');
      
      mockClient.on.mockImplementation((event, callback) => {
        if (event === 'error') {
          setTimeout(() => callback(connectionError), 10);
        }
      });

      await executeCommandOnAgent(mockReq, hostname, osVersion, mockRes);
      
      await new Promise(resolve => setTimeout(resolve, 50));

      expect(LOGGER.errorLog).toHaveBeenCalledWith(mockReq, 'Connection error: Connection failed', hostname);
      expect(mockRes.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    });

    it('should handle command execution errors', async () => {
      const hostname = 'test-host';
      const osVersion = '7.10';
      const execError = new Error('Command failed');
      
      mockClient.on.mockImplementation((event, callback) => {
        if (event === 'ready') {
          setTimeout(() => callback(), 10);
        }
      });

      mockClient.exec.mockImplementation((command, callback) => {
        callback(execError, null);
      });

      await executeCommandOnAgent(mockReq, hostname, osVersion, mockRes);
      
      await new Promise(resolve => setTimeout(resolve, 50));

      expect(LOGGER.errorLog).toHaveBeenCalledWith(mockReq, 'User attempted to start the RiseBot, but it failed due to: Command failed', hostname);
      expect(mockRes.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    });

    it('should handle non-zero exit codes', async () => {
      const hostname = 'test-host';
      const osVersion = '7.10';
      
      mockClient.on.mockImplementation((event, callback) => {
        if (event === 'ready') {
          setTimeout(() => callback(), 10);
        }
      });

      mockClient.exec.mockImplementation((command, callback) => {
        callback(null, mockStream);
      });

      mockStream.on.mockImplementation((event, callback) => {
        if (event === 'close') {
          setTimeout(() => callback(1), 20); // Non-zero exit code
        }
      });

      await executeCommandOnAgent(mockReq, hostname, osVersion, mockRes);
      
      await new Promise(resolve => setTimeout(resolve, 50));

      expect(LOGGER.warningLog).toHaveBeenCalledWith(mockReq, 'User attempted to start the RiseBot, but it failed due to a non-zero exit code: 1.', hostname);
      expect(mockRes.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
    });

    it('should handle bulk operations without response', async () => {
      const hostname = 'test-host';
      const osVersion = '7.10';
      const isBulk = true;
      
      mockClient.on.mockImplementation((event, callback) => {
        if (event === 'ready') {
          setTimeout(() => callback(), 10);
        }
      });

      mockClient.exec.mockImplementation((command, callback) => {
        callback(null, mockStream);
      });

      mockStream.on.mockImplementation((event, callback) => {
        if (event === 'close') {
          setTimeout(() => callback(0), 20);
        }
      });

      await executeCommandOnAgent(mockReq, hostname, osVersion, mockRes, isBulk);
      
      await new Promise(resolve => setTimeout(resolve, 50));

      expect(mockRes.status).not.toHaveBeenCalled();
      expect(mockRes.json).not.toHaveBeenCalled();
    });

    it('should fetch password from secret when env password is missing', async () => {
      delete process.env.RISE_SA_PASSWORD;
      delete process.env.RISE_SA_PASSWORD_VALUE;
      getServiceAccountPassword.mockResolvedValue('secret-password');
      
      const hostname = 'test-host';
      const osVersion = '7.10';
      
      mockClient.on.mockImplementation((event, callback) => {
        if (event === 'ready') {
          setTimeout(() => callback(), 10);
        }
      });

      mockClient.exec.mockImplementation((command, callback) => {
        callback(null, mockStream);
      });

      mockStream.on.mockImplementation((event, callback) => {
        if (event === 'close') {
          setTimeout(() => callback(0), 20);
        }
      });

      await executeCommandOnAgent(mockReq, hostname, osVersion, mockRes);
      
      await new Promise(resolve => setTimeout(resolve, 50));

      expect(getServiceAccountPassword).toHaveBeenCalled();
    });

    it('should use env password without calling secret helper', async () => {
      process.env.RISE_SA_PASSWORD = 'env-password';
      process.env.RISE_SA_PASSWORD_VALUE = 'env-password';

      const hostname = 'test-host';
      const osVersion = '7.10';

      mockClient.on.mockImplementation((event, callback) => {
        if (event === 'ready') {
          setTimeout(() => callback(), 10);
        }
      });

      mockClient.connect.mockImplementation((sshConfig) => {
        expect(sshConfig.password).toBe('env-password');
      });

      mockClient.exec.mockImplementation((command, callback) => {
        callback(null, mockStream);
      });

      mockStream.on.mockImplementation((event, callback) => {
        if (event === 'close') {
          setTimeout(() => callback(0), 20);
        }
      });

      await executeCommandOnAgent(mockReq, hostname, osVersion, mockRes);
      await new Promise(resolve => setTimeout(resolve, 50));

      expect(getServiceAccountPassword).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
    });
  });


  describe('buildQuery', () => {
    it('should build query with status filter', () => {
      const reqbody = { status: 'Active' };
      const query = buildQuery(reqbody);
      
      expect(query.status).toBe('Active');
    });

    it('should not add status filter for Recent status', () => {
      const reqbody = { status: 'Recent' };
      const query = buildQuery(reqbody);
      
      expect(query.status).toBeUndefined();
    });

    it('should build query with search filter', () => {
      const reqbody = { search: 'test-host' };
      const query = buildQuery(reqbody);
      
      expect(query.hostname).toEqual({ $regex: new RegExp('test-host', 'i') });
    });

    it('should build query with hostname array filter', () => {
      const reqbody = { hostnameArr: 'host1, host2, host3' };
      const query = buildQuery(reqbody);
      
      expect(query.hostname).toEqual({ $in: ['host1', 'host2', 'host3'] });
    });

    it('should build query with multiple CMDB filters', () => {
      const reqbody = {
        osTypes: 'linux, windows',
        regions: 'us-east-1, eu-west-1',
        environments: 'prod, dev',
        platforms: 'tech-solmon, galaxy',
        sids: 'DEV, QAS',
        serviceNames: 'service1, service2'
      };
      const query = buildQuery(reqbody);
      
      expect(query['cmdb.ciOsType']).toEqual({ $in: ['linux', 'windows'] });
      expect(query['cmdb.slRegion']).toEqual({ $in: ['us-east-1', 'eu-west-1'] });
      expect(query['cmdb.ciSapNameEnv']).toEqual({ $in: ['prod', 'dev'] });
      expect(query['cmdb.slPlatform']).toEqual({ $in: ['tech-solmon', 'galaxy'] });
      expect(query['cmdb.ciSapNameSid']).toEqual({ $in: ['DEV', 'QAS'] });
      expect(query['cmdb.slName']).toEqual({ $in: ['service1', 'service2'] });
    });

    it('should build query with agent versions filter', () => {
      const reqbody = { agentVersions: '1.0.0, 1.1.0' };
      const query = buildQuery(reqbody);
      
      expect(query['agent_details.version']).toEqual({ $in: ['1.0.0', '1.1.0'] });
    });

    it('should ignore empty or whitespace-only filters', () => {
      const reqbody = {
        search: '   ',
        hostnameArr: '',
        osTypes: '  ',
        agentVersions: ''
      };
      const query = buildQuery(reqbody);
      
      expect(Object.keys(query)).toHaveLength(0);
    });

    it('should handle combination of all filters', () => {
      const reqbody = {
        status: 'Active',
        search: 'test',
        osTypes: 'linux',
        agentVersions: '1.0.0'
      };
      const query = buildQuery(reqbody);
      
      expect(query.status).toBe('Active');
      expect(query.hostname).toEqual({ $regex: new RegExp('test', 'i') });
      expect(query['cmdb.ciOsType']).toEqual({ $in: ['linux'] });
      expect(query['agent_details.version']).toEqual({ $in: ['1.0.0'] });
    });
  });

  describe('addFilter', () => {
    it('should add filter with correct field mapping', () => {
      const reqbody = { testField: 'value1, value2' };
      const query = {};
      
      addFilter(reqbody, query, 'testField', 'prefix');
      
      expect(query['prefix.undefined']).toEqual({ $in: ['value1', 'value2'] });
    });

    it('should not add filter for empty values', () => {
      const reqbody = { testField: '   ' };
      const query = {};
      
      addFilter(reqbody, query, 'testField', 'prefix');
      
      expect(Object.keys(query)).toHaveLength(0);
    });

    it('should trim whitespace from values', () => {
      const reqbody = { testField: ' value1 , value2 ' };
      const query = {};
      
      addFilter(reqbody, query, 'testField', 'prefix');
      
      expect(query['prefix.undefined']).toEqual({ $in: ['value1', 'value2'] });
    });
  });

  describe('getFieldName', () => {
    it('should return correct field names for all mappings', () => {
      expect(getFieldName('osTypes')).toBe('ciOsType');
      expect(getFieldName('regions')).toBe('slRegion');
      expect(getFieldName('environments')).toBe('ciSapNameEnv');
      expect(getFieldName('platforms')).toBe('slPlatform');
      expect(getFieldName('sids')).toBe('ciSapNameSid');
      expect(getFieldName('serviceNames')).toBe('slName');
      expect(getFieldName('agentVersions')).toBe('version');
    });

    it('should return undefined for unknown fields', () => {
      expect(getFieldName('unknownField')).toBeUndefined();
    });
  });

  describe('getDistinctValues', () => {
    it('should return distinct values successfully', async () => {
      const distinctValues = ['linux', 'windows', 'macos'];
      AgentModel.distinct.mockResolvedValue(distinctValues);

      await getDistinctValues('ciOsType', mockRes, 'osTypes', 'data');

      expect(AgentModel.distinct).toHaveBeenCalledWith('cmdb.ciOsType');
      expect(mockRes.status).toHaveBeenCalledWith(responseCodes.SUCCESS);
      expect(mockRes.json).toHaveBeenCalledWith({
        flag: 'success',
        data: { osTypes: distinctValues }
      });
    });

    it('should handle database errors', async () => {
      AgentModel.distinct.mockRejectedValue(new Error('Database error'));

      await getDistinctValues('ciOsType', mockRes, 'osTypes', 'data');

      expect(mockRes.status).toHaveBeenCalledWith(responseCodes.SERVER_ERROR);
      expect(mockRes.json).toHaveBeenCalledWith({
        flag: 'error',
        message: 'Internal server error'
      });
    });

   
  });
});