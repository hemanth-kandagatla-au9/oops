const axios = require('axios');
const responseCodes = require('../utils/responseCodes')

async function fetchUserPermissions(authToken) {           // NOSONAR
  try {
   
   

   const baseUrl = (process.env.insights_permission_url)  // NOSONAR
  const url = `${baseUrl}/auth/getUserPermission`; // NOSONAR
  const config = {   // NOSONAR
  method: 'get',
  maxBodyLength: Infinity,
  url,
  timeout:20000,
  headers: {                              // NOSONAR
    'Content-Type': 'application/json',
    'Accept': 'application/json', 
    'Authorization': authToken
  }

};

const response  = await axios.request(config) // NOSONAR
  console.log('response>>',response) // NOSONAR
  
    if (!response.data) {
       return {status:404,message:"No data received from permission API"};
    }

    return response.data;

  } catch (error) {
    console.error('[Permission] Error fetching permissions from API:', error.message); // NOSONAR

    return {status:500,message:error.message};
  }
}

function checkPermission(permissionData, requiredPermission) {             // NOSONAR

  if (!permissionData || !permissionData.data || !permissionData.data.permissions) {
   
    return false;
  }

  // Find the "agent" project
  const agentProject = permissionData.data.permissions.find(p => p.project === 'agent');
  console.log('agentProject>>',agentProject) // NOSONAR
  if (!agentProject || !agentProject.modules) {
    return false
  }

  const riseAgentModule = agentProject.modules.find(m => m.module === 'Rise Agent');
  if (!riseAgentModule || !riseAgentModule.permissions || !Array.isArray(riseAgentModule.permissions)) {
    return false;
  }


  const normalizedRequired = requiredPermission.toLowerCase().trim();

  for (const permission of riseAgentModule.permissions) {
    const normalizedLabel = permission.label.toLowerCase().trim();

    if (normalizedLabel === normalizedRequired) {
      
      const hasAccess = permission.hasAccess === true // NOSONAR

      return hasAccess;
    } 
}
return false

}
function requirePermission(requiredPermission) {
  return async (req, res, next) => {
    try {
      const authHeader = req.headers && req.headers.authorization;
      if(!authHeader){
         return res.status(responseCodes.UNAUTHORIZED).json({
          success: false,
          message: "User is not authorized"
        });
      }
      
      const permissionData = await fetchUserPermissions(authHeader); // NOSONAR
      if(permissionData.status== responseCodes.NOT_FOUND || permissionData.status == responseCodes.SERVER_ERROR){
        return res.status(permissionData.status).json({
          success: false,
          message: permissionData.message
        });
      }

      const hasPermission = checkPermission(permissionData, requiredPermission);
      console.log('hasPermission',hasPermission) // NOSONAR
      if (!hasPermission) {
        return res.status(responseCodes.FORBIDDEN).json({
          success: false,
          message: "You do not have permission to perform this action"
        });
      }

      next();

    } catch (error) {
      console.error('[Permission] Error checking permission:', error.message); // NOSONAR
      res.status(responseCodes.SERVER_ERROR).json({ flag: "error", error: error.message });

    
    }
  };
}

module.exports = {
  requirePermission,
  fetchUserPermissions,
  checkPermission
};
