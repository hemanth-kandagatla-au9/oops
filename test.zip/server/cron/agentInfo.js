const AgentModel = require("../models/agentModel");
const getSapMasterdataModel = require("../models/sapMasterdataModel");
const { getOpenSearchPassword } = require("../utils/envUtils");
const fetch = require("node-fetch");

require("dotenv").config();

const fetchDataByTimeInterval = async timeIntervalInMinutes => {
    const username = process.env.OPENSEARCH_USER;
    const password = process.env.OPENSEARCH_NON_PROD_PASSWORD ? process.env.OPENSEARCH_NON_PROD_PASSWORD : await getOpenSearchPassword();
    const OPENSEARCH_URL = process.env.OPENSEARCH_URL;
    const healthIndex = process.env.OPENSEARCH_HEALTH_DISCOVERY_INDEX;

    // Calculate the timestamp based on the provided time interval
    const startTime = new Date(Date.now() - timeIntervalInMinutes * 60 * 1000).toISOString();
    const currentTime = new Date().toISOString();

    const requestURL = `${OPENSEARCH_URL}/${healthIndex}/_search?sort=timestamp:desc&size=10000&q=timestamp:[${startTime} TO ${currentTime}]`;
    const requestOptions = {
        method: 'GET',
        headers: {
            Authorization: `Basic ${Buffer.from(`${username}:${password}`, "utf-8").toString("base64")}`,// NOSONAR
        },
    };

    try {
        const response = await fetch(requestURL, requestOptions);
        if (response.ok) {
            const res = await response.json();
            return res.hits.hits;
        } else {
            return [];
        }
    } catch (error) {
        console.error(`Error occurred: ${error}`);// NOSONAR
    }
};


const insertDataintoAgentInfoCollection = async () => {
    console.log('Running agent status cron.........')// NOSONAR
    const username = process.env.OPENSEARCH_USER;
    const healthIndex = process.env.OPENSEARCH_HEALTH_DISCOVERY_INDEX;

    const password = process.env.OPENSEARCH_NON_PROD_PASSWORD ? process.env.OPENSEARCH_NON_PROD_PASSWORD : await getOpenSearchPassword();
    const OPENSEARCH_URL = process.env.OPENSEARCH_URL;
    const sixMinutesAgo = new Date(Date.now() - 6 * 60 * 1000).toISOString();// NOSONAR
    const currentTime = new Date().toISOString();

    const requestURL = `${OPENSEARCH_URL}/${healthIndex}/_search?sort=timestamp:desc&size=10000&q=timestamp:[${sixMinutesAgo} TO ${currentTime}]`;
    const requestOptions = {
        method: 'GET',
        headers: {
            Authorization: `Basic ${Buffer.from(`${username}:${password}`, "utf-8").toString("base64")}`,// NOSONAR
        },

    };

    try {
        const response = await fetch(requestURL, requestOptions);
        if (response.ok) {
            const res = await response.json();
            await insertintoDB(res.hits.hits);
        }

    } catch (error) {
        console.error(`[${new Date().toISOString()}] Error occurred: ${error}`);// NOSONAR

    }



};

const insertintoDB = async (data) => {
    try {

        const sourceObjects = data.map(item => item._source);

        const uniqueHostnames = new Set(sourceObjects.map(item => item.hostname));
        const uniqueSourceObjects = Array.from(uniqueHostnames)
            .map(hostname => sourceObjects.find(item => item.hostname === hostname));

        const bulkUpdateOps = [];
        const bulkInsertOps = [];
        const existingHostnames = new Set();

        let inactiveCount = 0;
        let activeCount = 0;

        for (const sourceObject of uniqueSourceObjects) {
            if (!sourceObject?.hostname) continue;

            const hostname = sourceObject.hostname.toUpperCase();

            sourceObject.hostname = hostname;
           
            // Ensure nested objects exist
            sourceObject.agent_details = sourceObject.agent_details || {};
            sourceObject.agent_config = sourceObject.agent_config || {};

            sourceObject.agent_details.vm_hostname = hostname;
            sourceObject.status = "Active";
            sourceObject.os = sourceObject.agent_details.os_type || '';


            sourceObject.risebot = {
                agentId: sourceObject.agent_config?.agent_id ?? '',
                pid: sourceObject.agent_details?.pid ?? ''
            };

            sourceObject.risebotProperties = {
                agent: {
                    version: sourceObject.agent_details?.version ?? ''
                },
                server: {
                    port: sourceObject.agent_details?.server_port ?? ''
                }
            };

            const now = new Date();

            existingHostnames.add(hostname);
            const existingRecord = await AgentModel.findOne({ hostname });
            console.log('existingRecord>>',existingRecord)// NOSONAR
          
            if (existingRecord) {

                sourceObject.updatedAt = now;

                bulkUpdateOps.push({
                    updateOne: {
                        filter: { hostname },
                        update: { $set: sourceObject }
                    }
                });

            } else {

                sourceObject.createdAt = now;
                sourceObject.updatedAt = now;

                bulkInsertOps.push({
                    insertOne: {
                        document: sourceObject
                    }
                });
            }
        }
        console.log('bulkUpdateOps>>',bulkUpdateOps)// NOSONAR
        console.log('(bulkInsertOps>>',bulkInsertOps)// NOSONAR

        // Mark inactive hosts
        const { modifiedCount } = await AgentModel.updateMany(
            { hostname: { $nin: Array.from(existingHostnames) }, status: { $ne: "Failed" } },
            { $set: { status: "Inactive" } }
        );

        inactiveCount += modifiedCount;

        if (bulkUpdateOps.length > 0) {

    const result = await AgentModel.bulkWrite(bulkUpdateOps);
    const updateCount = result.modifiedCount;

    activeCount += updateCount;

    console.log(`Matched: ${result.matchedCount}`);// NOSONAR
    console.log(`Modified: ${result.modifiedCount}`);// NOSONAR
        }       

        if (bulkInsertOps.length > 0) {
            const { insertedCount } = await AgentModel.bulkWrite(bulkInsertOps);
            console.log(`Added ${insertedCount} new hosts`);// NOSONAR
        }

        console.log(`Updated ${inactiveCount} hosts to 'Inactive'`);// NOSONAR
        console.log(`Updated ${activeCount} hosts to 'Active'`);// NOSONAR

    } catch (error) {
        console.error("Error inserting agents:", error);// NOSONAR
    }
};

const updateFailedAgent = async () => {
    try {
        const twentyFourHoursData = await fetchDataByTimeInterval(24 * 60);
        const sourceObjects = twentyFourHoursData.map(item => item._source);
        const existingHostnames = sourceObjects.map(sourceObject => sourceObject.hostname.toUpperCase());// NOSONAR

        const allAgents = await AgentModel.find({});
        const allHostnames = allAgents.map(agent => agent.hostname);

        const hostnamesNotFoundInLogs = allHostnames.filter(hostname => !existingHostnames.includes(hostname));
        const bulkOps = hostnamesNotFoundInLogs.map(hostname => ({
            updateOne: {
                filter: { hostname: hostname },
                update: { $set: { status: "Failed" } }
            }
        }));

        if (bulkOps.length > 0) {
            await AgentModel.bulkWrite(bulkOps);
        }
    } catch (error) {
        console.error(`[${new Date().toISOString()}] Error occurred: ${error}`);// NOSONAR

    }
};

const updateCMDBData = async () => {
    console.log('Running cmdb data cron.......')// NOSONAR
    const agentsToUpdate = await AgentModel.find({ status: { $ne: "Failed" } });
    for (const agent of agentsToUpdate) {
        const SapMasterdataModel = await getSapMasterdataModel()
        const sapMasterData = await SapMasterdataModel.findOne({ ciOsVmHostname: agent.hostname });
        if (sapMasterData) {
            await AgentModel.updateOne(
                { hostname: agent.hostname },
                {
                    $set: {
                        "cmdb": {
                            "ciOsType": sapMasterData['ciOsType'] ?? "",//OS
                            "slRegion": sapMasterData['slRegion'] ?? "",//Region
                            "slName": sapMasterData['slName'] ?? "",//Service Name
                            "slPlatform": sapMasterData['slPlatform'] ?? "",//Platform
                            "ciSapNameEnv": sapMasterData['ciSapUsedFor'] ?? "",//Env
                            "ciSapNameSid": sapMasterData['ciSapNameSid'] ?? ""   //SID
                        }
                    }
                }
            );

        }
    }
};


module.exports = {
    insertintoDB,
    fetchDataByTimeInterval,
    updateFailedAgent,
    syncAgentStatus: () => insertDataintoAgentInfoCollection(),
    updateFailedAgentStatus: () => updateFailedAgent(),
    syncDiscoveryData: () => updateCMDBData()
};