const express = require("express");
const path = require("path");// NOSONAR
const logger = require("morgan");
const cors = require("cors");
const cron = require('node-cron');
const bodyParser = require("body-parser");
const agentRoutes = require("./routes/agentRoutes/index");
const rustagentRoutes = require("./routes/rustAgentRoutes/rustAgent.routes");
const uiMonitoringRoutes = require("./routes/uiMonitoringRoutes/uiMonitoring.routes");
const versionManagementRoutes = require("./routes/versionManagementRoutes/versionManagement.routes")
const healthReadyRoutes =  require("./routes/healthReadyRoutes/healthReady.routes")
const authRoutes = require("./auth/routes/auth.routes");
const agentController = require("./cron/agentInfo");
const versionSyncController = require("./cron/versionSync");
const { validatewithBasicAuth } = require('./middlewares/agentMiddleware');
const { APP_CONFIG } = require("../config");
const db = require("./database/connection");
const app = express();
const cookieParser =  require('cookie-parser')
const authMiddleware =  require('./middlewares/authMiddleware')
let helmet = require("helmet");

db.InitiateMongoServer()

// Allowed domains for CORS
const allowlist = (process.env.ALLOWED_ORIGIN || '')
  .split(',')
  .map(v => v.trim())
  .filter(Boolean);

const ALLOWED_SUBDOMAIN_SUFFIX = '.jnj.com';

function isAllowedOrigin(origin) {
  // non-browser clients (curl, internal calls)
  if (!origin) return true;

  try {
    const url = new URL(origin);
    const hostname = (url.hostname || '').toLowerCase();

    if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1') return true;
    if (hostname.endsWith(ALLOWED_SUBDOMAIN_SUFFIX)) return true;

    return allowlist.includes(origin);
  } catch {
    return false;
  }
}

// Middleware
app.use(helmet.hidePoweredBy());
app.use(cookieParser())
app.use(
  cors({
    origin: function (origin, callback) {
      if (isAllowedOrigin(origin)) {
        callback(null, true); // allow
      } else {
        callback(new Error("Not allowed by CORS"));
      }
    },
    credentials: true,
  })
);

app.use(logger("dev"));
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true }));
app.use(bodyParser.json({ limit: "50mb" }));

app.set("view engine", "pug");


// Routes
app.use("/", healthReadyRoutes);
app.use("/auth",authRoutes); // NOSONAR
app.use("/uiMonitoring", authMiddleware,uiMonitoringRoutes);
app.use("/agents",authMiddleware, agentRoutes);
app.use("/rustagent",validatewithBasicAuth, rustagentRoutes);
app.use("/versionManagement",authMiddleware,versionManagementRoutes);

app.get('/', (_req, res) =>
  res.send({
    ENV: process.env.NODE_ENV,
    allowedOriginSuffix: ALLOWED_SUBDOMAIN_SUFFIX,
    allowedOrigins: allowlist,
  })
);

if (process.env.NODE_ENV === "local") {
  app.listen(process.env.port, err => {
    if (err) {
      console.log("Error in server setup"); // NOSONAR
    } else {
      console.log("Server listening on Port", process.env.port); // NOSONAR
    }
  });
}

cron.schedule(APP_CONFIG.ACTIVE_AGENTINFO_CRON, () => {
  agentController.syncAgentStatus();
});

cron.schedule(APP_CONFIG.DISCOVERY_SYNC_CRON, () => {
  agentController.syncDiscoveryData();
});
cron.schedule(APP_CONFIG.FAILED_AGENTINFO_CRON, () => {
  agentController.updateFailedAgentStatus();
});
cron.schedule(APP_CONFIG.VERSION_SYNC_CRON, () => {
  versionSyncController.syncVersionData();
});

module.exports = app;