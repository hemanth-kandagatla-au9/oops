//Import dependences
require("dotenv").config();
const { getParam } = require("./ssm.js");

const getRustPassword = async () => {
  const res = await getParam(process.env.RUST_API_PASSWORD);
  return res.Parameter.Value;
};
const getOpenSearchPassword = async () => {
  const res = await getParam(process.env.OPENSEARCH_PASSWORD);
  return res.Parameter.Value;
};

const getServiceAccountPassword = async () => {
  const res = await getParam(process.env.RISE_SA_PASSWORD);
  return res.Parameter.Value;
};

const getMongoConnectionURL = async () => {
  const res = await getParam(process.env.MONGO_CONNECTION_URL);
  return res.Parameter.Value;
};
const getMongoPem = async () => {
  const res = await getParam(process.env.MONGO_TLS_PEM_FILE);
  return res?.Parameter?.Value;
};

const getMSALClientID = async () => {
  const res = await getParam(process.env.MSAL_CLIENT_ID);
  return res?.Parameter.Value;
};

const getMSALTenantID = async () => {
  const res = await getParam(process.env.MSAL_TENANT_ID);
  return res?.Parameter.Value;
};

const getOpenSearchLogKey = async () => {
  const res = await getParam(process.env.CLI_LOG_KEY);
  return res?.Parameter.Value;
};

const getAuthUserPasswordFromSSM = async () => {
  console.log('paramValue>',process.env.AUTH_AGENT_PASS)// NOSONAR
  const res = await getParam(process.env.AUTH_AGENT_PASS);
  return res?.Parameter.Value;
};


module.exports = {
  getMongoPem, getMongoConnectionURL,
  getRustPassword,
  getOpenSearchPassword,
  getServiceAccountPassword,
  getMSALClientID,
  getMSALTenantID,
  getOpenSearchLogKey,
  getAuthUserPasswordFromSSM
};
