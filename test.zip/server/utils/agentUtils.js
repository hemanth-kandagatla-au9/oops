const { LOGGER } = require('./opensearchLogger');
const { Client } = require('ssh2');
const AgentModel = require("../models/agentModel");
const { getServiceAccountPassword } = require("./envUtils");
const responseCodes = require("./responseCodes");


const executeCommandOnAgent = async (req, hostname, osVersion, res, isBulk = false) => {
    const SERVICE_ACCOUNT_USERNAME = process.env.RISE_SA_USERNAME;
    const SERVICE_ACCOUNT_PASSWORD = process.env.RISE_SA_PASSWORD_VALUE ? process.env.RISE_SA_PASSWORD_VALUE : await getServiceAccountPassword();

    const sshConfig = {
        username: SERVICE_ACCOUNT_USERNAME,
        password: SERVICE_ACCOUNT_PASSWORD,
        host: hostname,
        port: 22,
        readyTimeout: 60000,
    };

    const startCommand = getStartCommand(osVersion ?? "7.10");
    const commandTimeout = 60000;
    const client = new Client();

    try {
        await new Promise((resolve, reject) => {
            client.on('error', error => {
                LOGGER.errorLog(req, `Connection error: ${error.message}`, hostname);
                reject(error);
            });
            client.on('ready', () => {
                LOGGER.infoLog(req, 'SSH connection established successfully.', hostname);
                resolve();
            });
            client.connect(sshConfig);
        });

        client.exec(startCommand, (err, stream) => {
            if (err) {
                LOGGER.errorLog(req, `User attempted to start the RiseBot, but it failed due to: ${err.message}`, hostname);
                if (!isBulk) {
                    res.status(responseCodes.SERVER_ERROR).json({ flag: 'error', error: err.message });
                }
                return;
            }

            let commandOutput = '';
            let timeoutId = setTimeout(() => {
                stream.close();
                LOGGER.warningLog(req, 'Command execution timed out.');
                if (!isBulk) {
                    res.status(responseCodes.SERVER_ERROR).json({ flag: 'error', error: 'Command execution timed out.', hostname });
                }
            }, commandTimeout);

            stream.on('data', data => {
                commandOutput += data.toString();
            });

            stream.on('close', code => {
                clearTimeout(timeoutId);
                if (code === 0) {
                    LOGGER.infoLog(req, `User successfully started the RiseBot service from the Agent UI.`, hostname);
                    if (!isBulk) {
                        res.status(responseCodes.SUCCESS).json({ flag: 'success', data: { message: "started", output: commandOutput } });
                    }
                } else {
                    LOGGER.warningLog(req, `User attempted to start the RiseBot, but it failed due to a non-zero exit code: ${code}.`, hostname);
                    if (!isBulk) {
                        res.status(responseCodes.SERVER_ERROR).json({ flag: 'error', error: `Non-zero exit code: ${code}` });
                    }
                }
                client.end();
            });
        });
    } catch (error) {
        LOGGER.errorLog(req, `User attempted to start the RiseBot, but it failed due to: ${error.message}`, hostname);
        if (!isBulk) {
            res.status(responseCodes.SERVER_ERROR).json({ flag: 'error', error: error.message });
        }
    }
};

const getStartCommand = osVersion => osVersion.includes('6.') ? 'sudo service riseagent start' : 'sudo systemctl start riseagent';

const handleApiResponse = async (req, res, apiFunction) => {   // NOSONAR
    try {
        let hostNameData = req.body.hostname || req.query.hostname;   // NOSONAR
        const authHeader = req.headers['authorization'] ||'';
        let base64Credentials
        if(authHeader){
       base64Credentials = authHeader.split(' ')[1];
       }
       const hostName = String(hostNameData);
              
        let port = 20101;
        if (hostName) {                   // NOSONAR
            const result = await AgentModel.findOne({ hostname: hostName });
            if (!result?.agent_details) return res.status(responseCodes.NOT_FOUND).json({ flag: "error", error: "Host not found", data: {} });
            port = result.agent_details.server_port;
        }

        req.body = { ...req.body, "port": port,base64Credentials,"singleHostname":hostNameData[0]}

        let requestData = {};
        requestData = { ...req.query, ...req.body };
        LOGGER.infoLog(req, `Outgoing request data: ${JSON.stringify(sanitizePasswordFields(requestData))}`);
        const data = await apiFunction(requestData);
        LOGGER.infoLog(req, `API response received for host: ${req.body.hostname}`);

        if (data === undefined) {                   //  NOSONAR
            res.status(responseCodes.SUCCESS).json({ flag: "error", error: "Unable to connect to server " + req.body.hostname, data: {} });
        }
        else if (data.status === responseCodes.NOT_FOUND) {    //  NOSONAR
            res.status(responseCodes.NOT_FOUND).json({ flag: "error", error: "File Not found" });
        }
        else if (data.status === responseCodes.SERVER_ERROR) {   // NOSONAR
            res.status(responseCodes.SERVER_ERROR).json({ flag: "error", error: "Unable to connect to server" });
        }
        else if (data.status === responseCodes.ERROR) {          // NOSONAR
            res.status(responseCodes.ERROR).json({ flag: "error", error: data.message || "Unable to connect to server" });
        }

        else if (data.type === "buffer") {    //  NOSONAR
            res.set('Content-Type', data.contentType);
            res.status(responseCodes.SUCCESS).send(data.data);
        }
        else {
           
             res.status(responseCodes.SUCCESS).json({ flag: "success", data });
        
    }
}
    catch (error) {
        LOGGER.errorLog(req, `handleApiResponse failed: ${error.message}`);
        res.status(responseCodes.SERVER_ERROR).json({ flag: "error", error: error.message });
    }
};

const sanitizeString = value => (typeof value === 'string' ? value : String(value ?? ''));
const escapeRegex = value => value.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`);

const buildQuery = reqbody => {
    const query = {};

    // Add filters for status, search, hostnameArr
    if (reqbody.status && typeof reqbody.status === 'string' && reqbody.status !== 'Recent') {
        query.status = sanitizeString(reqbody.status);
    }
    if (reqbody.search && typeof reqbody.search === 'string' && reqbody.search.trim() !== '') {
        query.hostname = { $regex: new RegExp(escapeRegex(reqbody.search.trim()), 'i') };
    }
    if (reqbody.hostnameArr && typeof reqbody.hostnameArr === 'string' && reqbody.hostnameArr.trim() !== '') {
        const hostnames = reqbody.hostnameArr.split(',').map(hostname => sanitizeString(hostname.trim()));
        query.hostname = { $in: hostnames };
    }

    // Add filters for osTypes, regions, environments, platforms, sids, serviceNames
    const filterFields = ['osTypes', 'regions', 'environments', 'platforms', 'sids', 'serviceNames'];
    
    filterFields.forEach(field => addFilter(reqbody, query, field, 'cmdb'));

    addFilter(reqbody, query, 'agentVersions', 'agent_details');
    return query;
};

const addFilter = (reqbody, query, field, prefix) => {
    if (reqbody[field] && typeof reqbody[field] === 'string' && reqbody[field].trim() !== '') {
        const values = reqbody[field].split(',').map(value => sanitizeString(value.trim()));
        query[`${prefix}.${getFieldName(field)}`] = { $in: values };
        
    }
};

const getFieldName = field => {
    if (field === 'osTypes') return 'ciOsType'
    if (field === 'regions') return 'slRegion';
    if (field === 'environments') return 'ciSapNameEnv';
    if (field === 'platforms') return 'slPlatform';
    if (field === 'sids') return 'ciSapNameSid';
    if (field === 'serviceNames') return 'slName';
    if (field === 'agentVersions') return 'version';
};

const getDistinctValues = async (field, res, successKey, responseKey) => {
    try {
        const values = await AgentModel.distinct(`cmdb.${field}`);
        const responseObject = { flag: 'success' };
        responseObject[responseKey] = { [successKey]: values };
        res.status(responseCodes.SUCCESS).json(responseObject);
    } catch {
        res.status(responseCodes.SERVER_ERROR).json({ flag: 'error', message: 'Internal server error' });
    }
};

const SENSITIVE_KEY_PATTERNS = ['password', 'pwd', 'secret', 'token', 'apikey', 'api_key'];

const isSensitiveKey = key => {
    const lowerKey = key.toLowerCase();
    return SENSITIVE_KEY_PATTERNS.some(pattern => lowerKey.includes(pattern));
};

const sanitizeEntry = ([key, value]) => {
    if (isSensitiveKey(key)) return null;
    const sanitizedValue = value && typeof value === 'object'
        ? sanitizePasswordFields(value)
        : value;
    return [key, sanitizedValue];
};

const sanitizePasswordFields = obj => {
    if (!obj || typeof obj !== 'object') return obj;
    if (Array.isArray(obj)) return obj.map(sanitizePasswordFields);

    return Object.fromEntries(
        Object.entries(obj)
            .map(sanitizeEntry)
            .filter(entry => entry !== null)
    );
};

function removePasswordFields(obj) {
  return {
    ...obj,
    configs: obj.configs.filter(
      item =>
        item.propertyName &&
        !item.propertyName.toLowerCase().includes("password")
    )
}
}

module.exports = {
    executeCommandOnAgent,
    handleApiResponse,
    buildQuery,
    addFilter,
    getFieldName,
    getDistinctValues,
    sanitizePasswordFields,
    removePasswordFields
};
