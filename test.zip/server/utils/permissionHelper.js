/**
 * Permission Constants for Rise Agent
 * Simple mapping of permission labels used in the Auth API
 */

const PERMISSIONS = {
  // Basic read access
  READ: 'rise agent : home_read',

  // Job operations
  JOB_START: 'rise agent : job_start',
  JOB_STOP: 'rise agent : job_stop',
  JOB_RESTART: 'rise agent : job_restart',

  // Agent lifecycle operations
  CHECK_STATUS: 'rise agent : check_status',
  START: 'rise agent : start',
  STOP: 'rise agent : stop',
  RESTART: 'rise agent : restart',
  UPGRADE: 'rise agent : upgrade',
  BULK_START: 'rise agent : bulk_start',
  BULK_STOP: 'rise agent : bulk_stop',
  BULK_RESTART: 'rise agent : bulk_restart',
  BULK_UPGRADE: 'rise agent : bulk_upgrade',
  BULK_SYNC_AGENT_CONFIG: 'rise agent : bulk_sync_config',
  BULK_ENV_UPDATE: 'rise agent : bulk_env_upgrade',
  VIEW_BULK_LOGS: 'rise agent : view_bulk_logs',



  // Admin/Advanced permissions (typically restricted)
  USER_AUTHORIZATION_READ: 'rise agent : user_authorization_read',
  PERMISSION_LIST_READ: 'rise agent : permission_list_read',
  GLOBAL_CONFIG_READ: 'rise agent : global_config_read',
  SYNC_STATUS: 'rise agent : sync_status',
  ACCORDIAN: 'rise agent : accordian',
  GLOBAL_CONFIG_UPDATE: 'rise agent : global_config_update',
  USER_AUTHORIZATION_ADDUSER: 'rise agent : user_authorization_adduser',
  USER_AUTHORIZATION_DELETEUSER: 'rise agent : user_authorization_deleteuser',
  DELETE_PERMISSION: 'rise agent : delete_permission',
  ASSIGN_PERMISSION: 'rise agent : assign_permission',
  PERMISSION_ADD: 'rise agent : permission_add',
  HOST_LOGS: 'rise agent : host_logs',
  HOST_CONFIG: 'rise agent : host_config',
  HOST_DETAILS: 'rise agent : host_details',
  HOST_TASK: 'rise agent : host_task',
  VERSION_MANAGEMENT: 'rise agent : versionmanagement_view',
  UPDATE_VERSION_MANAGEMENT: 'rise Agent : versionmanagement_edit',
  SYNC_AGENT_CONFIG: 'rise agent : sync_config',
  UPDATE_ENV: 'rise agent : update_env'
};

module.exports = { PERMISSIONS };
