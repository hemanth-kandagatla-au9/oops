const mongoose = require("mongoose");

const agentConfigSchema = new mongoose.Schema(
  {
    configs: {
      type: String,
    }
  },
  {
    collection: "agentConfig", 
    timestamps: true,
  }
);

module.exports = mongoose.model("AgentConfig", agentConfigSchema);
