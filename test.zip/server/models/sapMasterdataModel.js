const mongoose = require("mongoose");
const getDiscoveryConnection = require("../database/discoveryConnection");

const sapMasterdataSchema = new mongoose.Schema(
  {
    ciOsVmHostname: { type: String },

    ciOsType: { type: String },
    slRegion: { type: String },
    slName: { type: String },
    slPlatform: { type: String },
    ciSapNameEnv: { type: String },
    ciSapNameSid: { type: String },
  },
  {
    timestamps: true,
    strict: false,            
    collection: "sap_masterdatas",
  }
);

let SapMasterdataModel;

const getSapMasterdataModel = async () => {
  if (SapMasterdataModel) return SapMasterdataModel;

  const discoveryConn = await getDiscoveryConnection();

  if (!discoveryConn) {
    SapMasterdataModel =
      mongoose.models.SapMasterdata || mongoose.model("SapMasterdata", sapMasterdataSchema);
    return SapMasterdataModel;
  }

  SapMasterdataModel =
    discoveryConn.models.SapMasterdata ||
    discoveryConn.model("SapMasterdata", sapMasterdataSchema);

  return SapMasterdataModel;
};

module.exports = getSapMasterdataModel;