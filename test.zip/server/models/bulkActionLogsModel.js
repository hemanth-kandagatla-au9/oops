const mongoose = require('mongoose');

const bulkActionLogsSchema = mongoose.Schema({}, { strict: false, collection: 'bulkActionJobs' });

// Create indexes for better query performance
bulkActionLogsSchema.index({ action: 1 });
bulkActionLogsSchema.index({ user: 1 });
bulkActionLogsSchema.index({ status: 1 });
bulkActionLogsSchema.index({ createdAt: -1 });

module.exports = mongoose.model('bulkActionJobs', bulkActionLogsSchema);
