const express = require('express');
const router = express.Router();
const { 
  generateTokenEndpoint, 
  validateTokenEndpoint, 
  healthCheck 
} = require('../controllers/tokenController');
const { getUserDetails,getPermissions,addUser,addPermission,deletePermission,deleteUserDetails,updatePermission,getUserPermissions,assignUserPermissions } =  require('../controllers/authManagementController')
const { requirePermission } = require("../../middlewares/permissionsMidlleware");
const { PERMISSIONS } = require("../../utils/permissionHelper");



/**
 * Authentication Routes
 * Defines all routes for the JWT authentication system
 */


 router.get('/generate-token', generateTokenEndpoint);

router.post('/validate-token', validateTokenEndpoint);


router.get('/health', healthCheck);
router.get('/user-details',requirePermission(PERMISSIONS.USER_AUTHORIZATION_READ),getUserDetails) // NOSONAR
router.get('/permissionsList',requirePermission(PERMISSIONS.PERMISSION_LIST_READ),getPermissions)  // NOSONAR
router.post('/add-user',requirePermission(PERMISSIONS.USER_AUTHORIZATION_ADDUSER),addUser)          // NOSONAR
router.delete('/delete-user',requirePermission(PERMISSIONS.USER_AUTHORIZATION_DELETEUSER),deleteUserDetails) // NOSONAR
router.post('/add-permission',requirePermission(PERMISSIONS.PERMISSION_ADD),addPermission)                 // NOSONAR
router.delete('/permissions/:id',requirePermission(PERMISSIONS.DELETE_PERMISSION), deletePermission) // NOSONAR
router.post('/update-permission',updatePermission)
router.get('/users/:id/user-permissions', getUserPermissions)
router.put('/users/:id/permissions', requirePermission(PERMISSIONS.ASSIGN_PERMISSION),assignUserPermissions); // NOSONAR



module.exports = router;