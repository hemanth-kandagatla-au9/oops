const jwt = require('jsonwebtoken');
/** @type {{ getCachedPrivateKey: () => Promise<string>, getCachedCertificate: () => Promise<string>, getPrivateKeyFromSSM: () => Promise<string>, getCertificateFromSSM: () => Promise<string> }} */
const {getCachedPrivateKey, getCachedCertificate,getPrivateKeyFromSSM,getCertificateFromSSM } = require('../../utils/ssmAuthUtils');
const { getJWTConfig } = require('../utils/authConfig');
const agentUserDataModel = require('../../models/agentUserDetails');
const tokenLogs =  require('../../models/tokenLogs');
const path  = require('path') // NOSONAR: node:path not usable with Jest 27 mocking
const fs = require('fs') // NOSONAR: node:fs not usable with Jest 27 mocking
const bcrypt =  require('bcrypt')

const MAX_FAILED_TOKEN_ATTEMPTS = 3;


/**
 * Token Service
 * Handles JWT token generation and validation using RSA256 with keys from AWS SSM
 */

// RSA key caching is now handled by ssmAuthUtils




/**
 * Generate JWT token with RSA256 signing
 * @param {string} username - Username from authorization header
 * @returns {Promise<object>} Token information object
 * 
 */


async function getPrivateKeyData() {
  try {

  const filePath = path.join(__dirname,"../../../",process.env.JWT_PRIVATE_KEY|| 'private-key.pem');    
  
   if (fs.existsSync(filePath)) {
        const privateKey = fs.readFileSync(filePath, 'utf8');// NOSONAR
        return privateKey 
                  
        } else {
           const pemData = await Promise.resolve(getPrivateKeyFromSSM());
           const privateKey =  pemData
          fs.writeFileSync(filePath, pemData);
          return privateKey

        }

  } catch (error) {
    throw new Error(`Failed to retrieve RSA public key: ${error.message}`);
  }
}

async function getPublicKeyData() {
  try {

  const filePath = path.join(__dirname,"../../../",process.env.JWT_PUBLIC_KEY || 'public-key.pem');    
  
   if (fs.existsSync(filePath)) {
        const publicKey = fs.readFileSync(filePath, 'utf8');// NOSONAR
        return publicKey 
                  
        } else {
           const pemData = await Promise.resolve(getCertificateFromSSM());
           const publicKey =  pemData
          fs.writeFileSync(filePath, pemData);
          return publicKey

        }


  } catch (error) {
    throw new Error(`Failed to retrieve RSA public key: ${error.message}`);
  }
}

async function generateToken(username,password) {
  try {

  
    const privateKey = await getPrivateKeyData();

    const jwtConfig = getJWTConfig();
    const expireTime = jwtConfig.expiresIn
    
     // Fetch user roles from database
    
    let roles = [];
    const agentRoleDoc = await agentUserDataModel.findOne({ 
      username: username 
     
    });

    if(!agentRoleDoc) {
      return []
    }
    if(!agentRoleDoc.isActive){
     throw new Error("User is inactive or not found");
    }
    
    const stringinfyData = JSON.stringify(agentRoleDoc)
    const parsedData = JSON.parse(stringinfyData)
    const hashedPassword = parsedData.password
    const isMatch = await bcrypt.compare(password, hashedPassword);

      if(!isMatch){
        return []
      }
     
    if (parsedData?.roles) {
      roles = agentRoleDoc.roles;
    } 
    
    const payload = {
      sub: username,
      roles: roles
    };

  
    const token = jwt.sign(payload, privateKey, { algorithm: jwtConfig.algorithm, expiresIn:`${expireTime}s` });

   await tokenLogs.create({
    username,
    token,
    action: "GENERATED",
    expiresTime: new Date(Date.now() + expireTime * 1000)
  })
    return {
      token,
      tokenType: "Bearer",
      expiresIn: Number.parseInt(expireTime)
    };
  } catch (error) {
    throw new Error(`Token generation failed: ${error.message}`);
  }
}

/**
 * Validate JWT token using RSA256 verification
 * @param {string} token - JWT token to validate
 * @returns {Promise<object>} Validation result object
 */
/**
 * Handle account lockout logic when a token has invalid signature
 * @param {object} decoded - The decoded (unverified) JWT payload
 */
async function handleInvalidTokenLockout(decoded) {
  if (!decoded?.sub) return;
  const user = await tokenLogs.findOne({ username: decoded.sub }).sort({ createdAt: -1 });
  if (!user) return;

  const incorrectTOkenCount = user.wrongTokenCount + 1;
  if (user.wrongTokenCount >= MAX_FAILED_TOKEN_ATTEMPTS) {
    await agentUserDataModel.findOneAndUpdate(
      { username: user.username },
      { isActive: false }
    );
  }
  await tokenLogs.updateOne(
    { _id: user._id },
    { $set: { action: "FAILED", wrongTokenCount: incorrectTOkenCount } }
  );
}

async function validateToken(token) {
  try {
    if (!token) {
      return {
        valid: false,
        reason: "Token is required"
      };
    }
    const publicKey = await getPublicKeyData();
    
    const jwtConfig = getJWTConfig();

    const decoded = jwt.verify(token, publicKey, { algorithms: [jwtConfig.algorithm] });
    await tokenLogs.findOneAndUpdate(
  { username: decoded.sub },      
  { action: "SUCCESS" },             
  { sort: { createdAt: -1 }, new: true }
);
    return {
      valid: true,
      payload: decoded
    };
  } catch (error) {
    
     // decode token to get username
    
    let reason = "Invalid token";
    if (error.name === 'TokenExpiredError') {
      reason = "Token has expired";
    } else if (error.name === 'JsonWebTokenError') {
      reason = "Invalid token format or signature";
      const decoded = jwt.decode(token);
      await handleInvalidTokenLockout(decoded);
    }

    return {
      valid: false,
      reason: reason
    };
  
  }
}
  


/**
 * Check if SSM keys are accessible
 * @returns {Promise<boolean>} True if keys are accessible
 */
async function validateSSMKeys() {
  try {
    const [privateKey, certificate] = await Promise.all([
      Promise.resolve(getCachedPrivateKey()),
      Promise.resolve(getCachedCertificate())
    ]);
    return Boolean(privateKey && certificate);
  } catch (error) {
    throw new Error(`SSM key validation failed: ${error}`);
  }
}

module.exports = {
  generateToken,
  validateToken,
  validateSSMKeys
  };