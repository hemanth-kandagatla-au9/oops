const AgentModel = require("../models/agentModel");
const AgentVersionModel = require("../models/agentVersionModel");
const { updateVersion } = require("../services/agentService");
const { handleApiResponse } = require("../utils/agentUtils");
const responseCodes = require("../utils/responseCodes");

const manageVersions = async (req, res) => {
    const versions = req.body;
    const method = req.method;

    if (!Array.isArray(versions)) {
        return res.status(responseCodes.ERROR).json({ flag: "error", message: "Invalid input format. Expected an array of version documents." });
    }

    try {
        if (method === 'POST') {
            const insertResults = await Promise.all(versions.map(async version => {
                const existingRecord = await AgentVersionModel.findOne({ agentVersion: version.agentVersion });
                if (existingRecord) {
                    return { success: false, version: version.agentVersion };
                } else {
                    await AgentVersionModel.insertOne(version);
                    return { success: true, version: version.agentVersion };
                }
            }));

            const successCount = insertResults.filter(result => result.success).length;
            const errorCount = insertResults.length - successCount;

            res.status(responseCodes.SUCCESS).json({
                flag: errorCount > 0 ? "partial_success" : "success",
                data: `${successCount} records inserted successfully, ${errorCount} records failed.`
            });

        } else if (method === 'PUT') {
            const updateResults = await Promise.all(versions.map(async version => {
                const result = await AgentVersionModel.updateOne(
                    { agentVersion: version.agentVersion },
                    { $set: version },
                    { upsert: true }
                );
                return { success: result.modifiedCount > 0 || result.upsertedCount > 0, version: version.agentVersion };
            }));

            const successCount = updateResults.filter(result => result.success).length;
            const errorCount = updateResults.length - successCount;

            res.status(responseCodes.SUCCESS).json({
                flag: errorCount > 0 ? "partial_success" : "success",
                data: `${successCount} records updated successfully, ${errorCount} records failed.`
            });

        } else {
            res.status(responseCodes.ERROR).json({ flag: "error", message: "Invalid HTTP method." });
        }
    } catch (error) {
        res.status(responseCodes.SERVER_ERROR).json({ flag: "error", message: `Error occurred ${error}` });
    }
};

const deleteVersion = async (req, res) => {
    const agentVersionData = req.query.agentVersion;
    
    if (!agentVersion) {
        return res.status(responseCodes.ERROR).json({ flag: "error", message: "agentVersion required." });
    }
    const agentVersion = String(agentVersionData);
    try {
        const deleteResult = await AgentVersionModel.deleteOne({ agentVersion });
        res.status(responseCodes.SUCCESS).json({ flag: "success", data: `${deleteResult.deletedCount} record deleted.` });
    } catch (error) {
        res.status(responseCodes.SERVER_ERROR).json({ flag: "error", message: `Deletion error: ${error}` });
    }
};

const getVersionsList = async (_req, res) => {
  try {
    const versions = await AgentVersionModel.aggregate([
      {
        $match: { isDeleted: false }
      },
      {
        $addFields: {
          cleanBuildDate: {
            $trim: {
              input: {
                $arrayElemAt: [
                  { $split: ["$buildDate", " ("] },
                  0
                ]
              }
            }
          }
        }
      },
      {

        $addFields: {
          buildDateAsDate: {
            $dateFromString: {
              dateString: "$cleanBuildDate"
            }
          }
        }
      },
      {

        $sort: {
          buildDateAsDate: -1
        }
      },
      {
        $project: {
          _id: 1,
          agentVersion: 1,
          buildDate: 1,
          compatibleOS: 1,
          upgradeType: 1
        }
      }
    ]);

    const risebotVersions = versions.map(v => ({
      id: v._id,
      agentVersion: v.agentVersion,
      version: v.agentVersion,
      buildDate: v.buildDate,
      compatibleOS: v.compatibleOS || [],
      upgradeType: v.upgradeType || null
    }));

    res.status(responseCodes.SUCCESS).json({
      flag: "success",
      data: { risebotVersions }
    });

  } catch (error) {
    res.status(responseCodes.SERVER_ERROR).json({
      flag: "error",
      message: "Failed to fetch versions",
      error: error.message
    });
  }
};


const getAgentVersions = async (_req, res) => {
    try {
        const values = await AgentModel.distinct(`agent_details.version`);
        const responseObject = { flag: 'success' };
        responseObject['agentVersions'] = { ['versions']: values };
        res.status(responseCodes.SUCCESS).json(responseObject);
    } catch (error) {
        res.status(responseCodes.SERVER_ERROR).json({ flag: 'error', message: 'Internal server error', error: error });
    }
};

module.exports = {
    manageVersions,
    deleteVersion,
    getVersionsList,
    getAgentVersions,
    version: (req, res) => handleApiResponse(req, res, updateVersion),
};