const {
  putShutDown,
  putRestartAgent,
  updateVersion,
  sycAgentCOnfig,
  updateEnv
} = require("../services/agentService");

const { executeCommandOnAgent } = require("../utils/agentUtils");
const responseCodes = require("../utils/responseCodes");
const jwt = require('jsonwebtoken')


const handleServiceResponse = (res, response) => {
  if (response.status === responseCodes.NOT_FOUND) {
    return res.status(responseCodes.NOT_FOUND).json({
      flag: "error",
      error: "File Not found"
    });
  }

  if (response.status === responseCodes.SERVER_ERROR) {
    return res.status(responseCodes.SERVER_ERROR).json({
      flag: "error",
      error: "Unable to connect to server"
    });
  }

  return res.status(responseCodes.SUCCESS).json({
    flag: "success",
    data: response
  });
};

const bulkStartAgent = async (req, res) => {
  try {
    res.status(responseCodes.SUCCESS).json({
      flag: "success",
      message: "Bulk Agent Started"
    });

    for (const agent of req.body) {
      setImmediate(() => {
        executeCommandOnAgent(req, agent.hostname, agent.osVersion, res, true);
      });
    }
  } catch (error) {
    res.status(responseCodes.SERVER_ERROR).json({
      flag: "error",
      error: error.message
    });
  }
};


const handleBulkAction = async (req, res, serviceFn) => {
  try {
    const authHeader = req.headers['authorization'] ||'';
            let base64Credentials
            if(authHeader){
           base64Credentials = authHeader.split(' ')[1];
           }
            const {name,unique_name:email}=  jwt.decode(base64Credentials)
            const username = email.split("@")[0] ?? ""
            req.body = {...req.body,name,email,username}
    const response = await serviceFn(req.body);
    return handleServiceResponse(res, response);
  } catch (error) {
    return res.status(responseCodes.SERVER_ERROR).json({
      flag: "error",
      error: error.message
    });
  }
};

const bulkStopAgent = (req, res) =>
  handleBulkAction(req, res, putShutDown);

const bulkRestartAgent = (req, res) =>
  handleBulkAction(req, res, putRestartAgent);

const bulkUpgradeAgent = (req, res) =>
  handleBulkAction(req, res, updateVersion);

const bulkSyncAgent = (req, res) =>
  handleBulkAction(req, res, sycAgentCOnfig);

const bulkEnvUpdate = (req, res) =>
  handleBulkAction(req, res, updateEnv);

const validateAgent = async (_req, res) => {
  try {
    res.status(responseCodes.SUCCESS).json({ isCompatible: true });
  } catch (error) {
    res.status(responseCodes.SERVER_ERROR).json({
      flag: "error",
      error: error.message
    });
  }
};

module.exports = {
  bulkStartAgent, // NOSONAR
  bulkStopAgent, // NOSONAR
  bulkRestartAgent, // NOSONAR
  bulkUpgradeAgent, // NOSONAR
  validateAgent, // NOSONAR
  bulkSyncAgent, // NOSONAR
  bulkEnvUpdate // NOSONAR
};