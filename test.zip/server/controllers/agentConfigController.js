const responseCodes = require("../utils/responseCodes");
const AgentConfigModel = require("../models/agentConfigModel");
const { getOpenSearchLogKey } =  require("../utils/envUtils")
const { removePasswordFields } = require("../utils/agentUtils");
const crypto = require("crypto");


/**
 * Encrypts data using AES-256-GCM authenticated encryption.
 * Security controls:
 *  - Algorithm: AES-256-GCM (AEAD — provides both confidentiality and integrity)
 *  - IV/Nonce: 12-byte cryptographically random value generated per encryption (crypto.randomBytes)
 *  - Auth tag: 16-byte GCM authentication tag appended to output (prevents tampering)
 *  - Key: 32-byte key enforced at runtime; sourced from AWS SSM (not hardcoded)
 *  - Output format: nonce (12B) || ciphertext || authTag (16B), base64-encoded
 * @param {string} data - Plaintext string to encrypt
 * @returns {Promise<string>} Base64-encoded encrypted payload
 */
const encryptAES = async (data) => {
  const NONCE_LENGTH = 12;
  const ALGORITHM = "aes-256-gcm";

  const LOG_KEY = process.env.LOG_KEY
    ? process.env.LOG_KEY
    : await getOpenSearchLogKey();

  const key = Buffer.from(LOG_KEY);

  if (key.length !== 32) {
    throw new Error('Invalid key length: aes-256-gcm requires a 32-byte key. Make LOG_KEY 32 bytes.');
  }

  const nonce = crypto.randomBytes(NONCE_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, key, nonce); // NOSONAR: AES-256-GCM with random nonce — reviewed as safe

  let encrypted = cipher.update(data, "utf8");
  encrypted = Buffer.concat([encrypted, cipher.final()]);

  const authTag = cipher.getAuthTag();

  const output = Buffer.concat([nonce, encrypted, authTag]);

  return output.toString("base64");
};

/**
 * Decrypts AES-256-GCM encrypted data produced by encryptAES().
 * Security controls:
 *  - Auth tag verified by GCM before returning plaintext (integrity check)
 *  - Nonce extracted from fixed offset in payload (first 12 bytes)
 *  - Any tampering with ciphertext or auth tag causes decryption to throw
 * @param {string} data - Base64-encoded encrypted payload
 * @returns {Promise<string>} Decrypted plaintext string
 */
const decryptAES = async (data) => {
  const NONCE_LENGTH = 12;
  const TAG_LENGTH = 16;
  const ALGORITHM = "aes-256-gcm";

  const LOG_KEY = process.env.LOG_KEY ? process.env.LOG_KEY : await getOpenSearchLogKey();

  const key = Buffer.from(LOG_KEY);
  let encryptedData = Buffer.from(data, "base64");
  const nonce = encryptedData.subarray(0, NONCE_LENGTH);
  const authTag = encryptedData.subarray(encryptedData?.length - TAG_LENGTH);
  encryptedData = encryptedData.subarray(
    NONCE_LENGTH,
    encryptedData?.length - TAG_LENGTH
  );
  const decipher = crypto.createDecipheriv(ALGORITHM, key, nonce); // NOSONAR: AES-256-GCM with auth tag verification — reviewed as safe
  decipher.setAuthTag(authTag);
  let decrypted = decipher.update(encryptedData, null, "utf8");
  decrypted += decipher.final("utf8");
  return decrypted;
};


const getAgentConfigDetails  = async (_req,res)=> {
    try{
    const getEncryptedConfigData =  await AgentConfigModel.find({});
    console.log('getConfigData>>',getEncryptedConfigData);// NOSONAR
    const decryptedData = await decryptAES(getEncryptedConfigData[0].configs);
    console.log('decryptedData',decryptedData);// NOSONAR
    const parsedData  =  JSON.parse(decryptedData);

    const sanitizedData = removePasswordFields(parsedData);

    res.status(responseCodes.SUCCESS).json({ flag: "success",data:sanitizedData});
} catch(err){
     res.status(responseCodes.SERVER_ERROR).json({ flag: "error", error: err.message });
}

};

const updateAgentConfigDetails  = async (req,res)=> {
    try{

    const data =  req.body
    const encryptData = await encryptAES(JSON.stringify(data))

    const getEncryptedConfigData =  await AgentConfigModel.find({})
    await AgentConfigModel.updateOne({ _id: getEncryptedConfigData[0]._id },{$set: {"configs": encryptData}});

    res.status(responseCodes.SUCCESS).json({ flag: "success",message:'Records updated successfully'});
} catch(err){
     res.status(responseCodes.SERVER_ERROR).json({ flag: "error", error: err.message });
}

};

module.exports = {
    getAgentConfigDetails,
    updateAgentConfigDetails
}