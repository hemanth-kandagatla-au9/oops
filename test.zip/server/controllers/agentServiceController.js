const responseCodes = require("../utils/responseCodes");

const AgentModel = require("../models/agentModel");

const { handleApiResponse, getDistinctValues, buildQuery, executeCommandOnAgent, sanitizePasswordFields } = require('../utils/agentUtils');

const { getPid, getConfig, updateLocalConfiguration, getApplicationLogs, putRestartAgent, putShutDown, getHealth, downloadFile,sycAgentCOnfig,updateEnv,updateVersion } = require('../services/agentService');
 
const startAgentService = async (req, res) => {

    executeCommandOnAgent(req, req.body.hostname, req.body.osVersion, res);

};
 
const getAgentInfo = async (req, res) => {

    let hostName = req.body.hostname;

    const result = await AgentModel.findOne({ hostname: hostName });

    const bytesToMB = bytes => (bytes / (1024 * 1024)).toFixed(2);
 
    if (!result) {

        res.status(responseCodes.NOT_FOUND).json({ flag: "error", message: "Host Not found", data: {} });

    }
    else {
 
        result.agent_details.cpu_usage = typeof result.agent_details.cpu_usage !== 'string' ? `${parseFloat(result.agent_details.cpu_usage).toFixed(3)}%` : result.agent_details.cpu_usage;// NOSONAR

        result.agent_details.memory = typeof result.agent_details.memory !== 'string' ? `${bytesToMB(result.agent_details.memory)} MB` : result.agent_details.memory;// NOSONAR

        result.agent_details.disk_usage = typeof result.agent_details.disk_usage !== 'string' ? `${bytesToMB(result.agent_details.disk_usage)} MB` : result.agent_details.disk_usage;// NOSONAR
 
        // Sanitize password fields from config
        const sanitizedResult = result.toObject();
        if (sanitizedResult.agent_config) {
            sanitizedResult.agent_config = sanitizePasswordFields(sanitizedResult.agent_config);
        }
        if (sanitizedResult.agent_local_config) {
            sanitizedResult.agent_local_config = sanitizePasswordFields(sanitizedResult.agent_local_config);
        }

        res.status(responseCodes.SUCCESS).json({ flag: "success", data: sanitizedResult });

    }
 
};
 
const getAgentsData = async (req, res) => {

    try {

        const reqbody = req.method === 'GET' ? req.query : req.body;

        const limit = parseInt(reqbody.pageSize) || 100;

        let pageNo = parseInt(reqbody.pageNo) || 0;

         if(reqbody.search){

           pageNo = 0 

        }
        const skip = (pageNo) * limit;

        const sortBy = reqbody.sortBy || 'createdAt'

        const sortingOrder = reqbody.sortOrder == 'asc'? 1 : -1

        const query = buildQuery(reqbody);

        const resultSet = await AgentModel.find(query)

            .skip(skip)

            .limit(limit)

            .sort({ [sortBy]: sortingOrder });
 
        const totalCount = await AgentModel.countDocuments(query);
 
        let activeCount = 0;

        let inactiveCount = 0;

        let failedCount = 0;
 
        const { status, ...filteredQuery } = query;

        activeCount = await AgentModel.countDocuments({ status: 'Active', ...filteredQuery });

        inactiveCount = await AgentModel.countDocuments({ status: 'Inactive', ...filteredQuery });

        failedCount = await AgentModel.countDocuments({ status: 'Failed', ...filteredQuery });
 
        // Sanitize password fields from all results
        const sanitizedResults = resultSet.map(agent => {
            const agentObj = agent.toObject();
            if (agentObj.agent_config) {
                agentObj.agent_config = sanitizePasswordFields(agentObj.agent_config);
            }
            if (agentObj.agent_local_config) {
                agentObj.agent_local_config = sanitizePasswordFields(agentObj.agent_local_config);
            }
            return agentObj;
        });
 
        const result = {

            pagination: {

                limit,

                pageNo,

                totalPage: totalCount,

                activeCount,

                failedCount,

                inactiveCount,

                allCount: activeCount + inactiveCount + failedCount,

                totalRows: sanitizedResults,

                status: status,

            }

        };

        res.status(responseCodes.SUCCESS).json({ flag: "success", data: result });

    }

    catch (error) {

        res.status(responseCodes.SERVER_ERROR).json({ flag: "error", error: error.message });

    }

};
 
const checkBasicAuth  = async (req,res)=> {
 
    try{
    const hostName = req.query.hostname;
    const hostname = String(hostName);
    const result = await AgentModel.findOne({hostname});
    if (!result) {

        res.status(responseCodes.NOT_FOUND).json({ flag: "error", message: "Host Not found", data: {} });

    }
const version = result.agent_details.version
const isBasicAuth = parseFloat(version) < 3.0;// NOSONAR
 
  const data = {
    hostName,
    version,
    isBasicAuth
  };

res.status(responseCodes.SUCCESS).json({ flag: "success", data });

} catch(err){
     res.status(responseCodes.SERVER_ERROR).json({ flag: "error", error: err.message });

}
 
};
 
 
const getRegions = async (_req, res) => {
    await getDistinctValues("slRegion", res, "regions", "agentRegions");

};
 
const getPlatforms = async (_req, res) => {
    await getDistinctValues("slPlatform", res, "platforms", "agentPlatforms");

};
 
const getEnvironments = async (_req, res) => {
    await getDistinctValues("ciSapNameEnv", res, "environments", "agentEnvironments");

};
 
const getSids = async (_req, res) => {
    await getDistinctValues("ciSapNameSid", res, "sids", "agentSids");

};
 
const getOStypes = async (_req, res) => {
     await getDistinctValues("ciOsType", res, "os", "agentOsTypes")

};
 
const getServiceNames = async (_req, res) => {
    await getDistinctValues("slName", res, "serviceNames", "agentServiceNames");

};
 
const checkHealth  = async (_req,res)=> {
try{
   res.status(responseCodes.SUCCESS).json({ flag: "success"});

} catch(err){
     res.status(responseCodes.SERVER_ERROR).json({ flag: "error", error: err.message });
}
 
};
 
const checkReady  = async (_req,res)=> {// NOSONAR
    try{
   res.status(responseCodes.SUCCESS).json({ flag: "success"});
} catch(err){
     res.status(responseCodes.SERVER_ERROR).json({ flag: "error", error: err.message });
}
};
 
 
// export controller functions

module.exports = {
    startAgentService,
    getAgentInfo,
    getAgentsData,
    getRegions,
    getPlatforms,
    getEnvironments,
    getSids,
    getOStypes,
    getServiceNames,
    checkBasicAuth,
    checkHealth,
    checkReady,
    pid: (req, res) => handleApiResponse(req, res, getPid),
    config: (req, res) => handleApiResponse(req, res, getConfig),
    updateLocalConfiguration: (req, res) => handleApiResponse(req, res, updateLocalConfiguration),
    getApplicationLogs: (req, res) => handleApiResponse(req, res, getApplicationLogs),
    restartAgent: (req, res) => handleApiResponse(req, res, putRestartAgent),
    shutdown: (req, res) => handleApiResponse(req, res, putShutDown),
    health: (req, res) => handleApiResponse(req, res, getHealth),
    download: (req, res) => handleApiResponse(req, res, downloadFile),
    sycAgentCOnfigDetails: (req, res) => handleApiResponse(req, res, sycAgentCOnfig),
    updateEnvEnvData: (req, res) => handleApiResponse(req, res, updateEnv),
    upgradeVersion: (req, res) => handleApiResponse(req, res, updateVersion)
 
};