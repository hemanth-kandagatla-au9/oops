const BulkActionLogsModel = require("../models/bulkActionLogsModel");
const responseCodes = require("../utils/responseCodes");


const buildBulkActionQuery = (reqbody) => {    // NOSONAR

  const query = {};

  if (reqbody.search) {
    query._id = reqbody.search.trim();
  }

  if (!reqbody.type || reqbody.type.length == 0) {
    query.action = { $regex: /^agent/i };
  }

  if (reqbody.type) {

    if (Array.isArray(reqbody.type)) {

      const validActions = reqbody.type.filter(a => a && typeof a === 'string' && a.trim() !== '');

      if (validActions.length > 0) {
        query.action = { $in: validActions };
      }

    } else if (typeof reqbody.type === 'string' && reqbody.type.trim() !== '') {   // NOSONAR

      query.action = reqbody.type.trim();
    }
  }

  if (reqbody.users) {

    if (Array.isArray(reqbody.users)) {

      const validUsers = reqbody.users.filter(u => u && typeof u === 'string' && u.trim() !== '');

      if (validUsers.length > 0) {
        query.triggeredBy = { $in: validUsers };
      }

    } else if (typeof reqbody.users === 'string' && reqbody.users.trim() !== '') {    // NOSONAR

      query.name = reqbody.users.trim();
    }
  }

  if (Array.isArray(reqbody.status) && reqbody.status.length > 0) {

      const validStatus = reqbody.status.filter(s=> s && typeof s === 'string' && s.trim() !== '');
       if (validStatus.length > 0) {
        query.status = { $in: validStatus};
  }
      } else if (reqbody.status && typeof reqbody.status === 'string' && reqbody.status.trim() !== '') {             // NOSONAR

       query.status = reqbody.status.trim(); // NOSONAR
  }

  // DATE RANGE FILTER
  if (reqbody.dateRange && (reqbody.dateRange.start || reqbody.dateRange.end)) {

    query.startedAt = {};

    // START DATE
    if (reqbody.dateRange.start) {

      const startDate = new Date(reqbody.dateRange.start);

      startDate.setHours(0, 0, 0, 0);

      query.startedAt.$gte = startDate;
    }

    // END DATE
    if (reqbody.dateRange.end) {

      const endDate = new Date(reqbody.dateRange.end);

      endDate.setHours(23, 59, 59, 999); // NOSONAR

      query.startedAt.$lte = endDate;
    }
  }

  return query;
};


/**
 * Get all bulk action logs with pagination and filtering
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getBulkActionLogs = async (req, res) => { // NOSONAR

  try {

    const reqbody =
      req.method === 'GET'
        ? req.query
        : req.body;

    const limit =
      parseInt(reqbody.pageSize) || 10;

    const pageNo =
      parseInt(reqbody.pageNo) || 0;

    const skip = pageNo * limit;

    let sortBy = 'startedAt';

    let sortOrder = -1;

    if (reqbody.sortBy === 'alphabet') {

      sortBy = 'action';

      sortOrder =
        reqbody.sortOrder === 'asc'
          ? 1
          : -1;

    } else if (reqbody.sortBy === 'date') {   // NOSONAR

      sortBy = 'startedAt'; // NOSONAR

      sortOrder =
        reqbody.sortOrder === 'asc'
          ? 1
          : -1;
    }

    const query = buildBulkActionQuery(reqbody);  // NOSONAR
    const totalCount = await BulkActionLogsModel.countDocuments(query); // NOSONAR
    const logs = await BulkActionLogsModel.find(query)   // NOSONAR
      .sort({ [sortBy]: sortOrder })
      .skip(skip)
      .limit(limit)
      .lean();

    const actions = await BulkActionLogsModel.distinct('action', { action: { $regex: /^agent/i } });

    const users = await BulkActionLogsModel.distinct('triggeredBy', { action: { $regex: /^agent/i } });

    const mappedLogs = logs.map(log => {              // NOSONAR

      return {
        id: log._id|| '',                // NOSONAR
        jobId: log.jobSequence|| '',
        type: log.action || '',
        status: log.status || '',
        username:log.triggeredBy || '',
        email: log.email || '',
        name: log.name || '',
        startedAt:log.startedAt || null,
        completedAt:log.completedAt || null,

        serverSummary: {

          total:log.totalAgents || 0,
          success:log.successful || 0,
          inprogress:log.pending || 0,
          failed:log.failed || 0  // NOSONAR
        }
      };
    });

    const totalPages = Math.ceil(totalCount / limit);

    const result = {

      pagination: {

        pageNo,

        pageSize: limit,

        totalPages,

        totalRecords: totalCount,

        hasNextPage:
          pageNo < totalPages - 1,

        hasPreviousPage:
          pageNo > 0
      },

      filters: {

        actions:
          actions.filter(
            a => a !== null && a !== undefined && a !== ''
          ),

        users:
          users.filter(
            u => u !== null && u !== undefined && u !== ''
          )
      },

      data: mappedLogs
    };

    return res
      .status(responseCodes.SUCCESS)
      .json({
        flag: 'success',
        data: result
      });

  } catch (error) {

    console.error('Error fetching bulk action logs:',error); // NOSONAR

    return res
      .status(responseCodes.SERVER_ERROR)
      .json({
        flag: 'error',
        message: 'Failed to fetch bulk action logs',
        error:
          error?.message ||
          'Internal Server Error'
      });
  }
};

/**
 * Get a single bulk action log by ID with detailed server information
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getBulkActionLogById = async (req, res) => {     // NOSONAR
  try {
    const { id } = req.params;

    const log = await BulkActionLogsModel.findById(id);

    if (!log) {
      return res.status(responseCodes.NOT_FOUND).json({
        flag: 'error',
        error: 'Bulk action log not found'
      });
    }

    const servers = (log.agents || log.servers || []).map(agent => {
      let message = agent.message || 'N/A';
      if (agent.logs && agent.logs.length > 0) {
        const lastLog = agent.logs[agent.logs.length - 1];
        message = lastLog.message || message;
      }

      return {
        serverName: agent.serverName || agent.hostname || 'Unknown',
        status: agent.status || 'Pending',
        message: message,
        completedAt: agent.completedAt || agent.lastAttemptedAt || log.completedAt
      };
    });

    const totalServers = log.totalAgents || 0;
    const successCount = log.successful || 0;
    const pendingCount = log.pending || 0;
    const failureCount = log.failed || 0;

    const response = {
      id:log._id || '',
      jobId: log.jobSequence || '',
      type: log.action,
      user: log.triggeredBy || 'N/A',
      status: log.status,
      startedAt: log.startedAt,
      completedAt: log.completedAt,
      serverSummary: {
        total: totalServers,
        success: successCount,
        pending: pendingCount,
        failed: failureCount
      },
      servers: servers
    };

    res.status(responseCodes.SUCCESS).json({ flag: 'success', data: response });
  } catch (error) {
    console.error('Error fetching bulk action log:', error); // NOSONAR
    res.status(responseCodes.SERVER_ERROR).json({ flag: 'error', error: error.message });
  }
};


const getBulkActionLogDataForExcel = async (req, res) => {       // NOSONAR
  try {
    
    const query = {};
    query.action = { $regex: /^agent/i };

    const sortBy = 'startedAt';
    let sortOrder = -1;

    const logs = await BulkActionLogsModel.find(query)
      .sort({ [sortBy]: sortOrder }).lean();


    const result = logs.map(log => {
      const agentsList = log.agents || log.servers || [];

      const servers = agentsList.map(agent => {    // NOSONAR
        let message = agent.message || 'N/A';


        if (agent.logs && agent.logs.length > 0) {
          const lastLog = agent.logs[agent.logs.length - 1];
          message = lastLog.message || message;
        }

        return {
          serverName: agent.serverName || agent.hostname || 'Unknown',
          status: agent.status || 'Inprogess',
          message: message,
          completedAt:
            agent.completedAt ||
            agent.lastAttemptedAt ||
            log.completedAt ||
            null,
        };
      });

      return {
        jobId: log.jobSequence || '',
        type: log.action,
        status: log.status,
        user: log.name || 'N/A',
        createdAt: log.startedAt,

        serverSummary: {
          total: log.totalAgents || 0,
          success: log.successful || 0,
          pending: log.pending || 0,
          failure: log.failed || 0,
        },

        servers,
      };
    });

    res.status(responseCodes.SUCCESS).json({
      flag: 'success',
      data: result,
    });

  } catch (error) {
    console.error('Error fetching bulk action log:', error);  // NOSONAR
    res.status(responseCodes.SERVER_ERROR).json({
      flag: 'error',
      error: error.message,
    });
  }
};



module.exports = {
  getBulkActionLogs,
  getBulkActionLogById,
  getBulkActionLogDataForExcel
};
