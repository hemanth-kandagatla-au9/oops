const responseCodes = require("../../utils/responseCodes");
const { cardData } = require("./uiMonitoringConfigs");

const fetchCardData = async (req, res) => {
    try {
        res.status(responseCodes.SUCCESS).json({
            status: 'success',
            statusCode: 200,
            message: 'Data fetched successfully',
            data: cardData
        });
    }
    catch (error) {
        res.status(responseCodes.SERVER_ERROR).json({
            status: 'error',
            statusCode: 500,
            message: 'Internal Server Error',
            error: error.message
        });
    }
}

module.exports = { fetchCardData };