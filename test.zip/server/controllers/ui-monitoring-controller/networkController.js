const responseCodes = require("../../utils/responseCodes");
const { networkMonitoring } = require("./uiMonitoringConfigs");

const fetchNetworkMonitoringData = async (req, res) => {
    try {
        res.status(responseCodes.SUCCESS).json({
            status: 'success',
            statusCode: 200,
            message: 'Data fetched successfully',
            data: networkMonitoring
        });
    }
    catch (error) {
        res.status(responseCodes.SERVER_ERROR).json({
            status: 'error',
            statusCode: 500,
            message: 'Internal Server Error',
            error: error.message
        });
    }
}

module.exports = { fetchNetworkMonitoringData };