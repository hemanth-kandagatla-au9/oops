const responseCodes = require("../../utils/responseCodes");
const { applicationPerformance } = require("./uiMonitoringConfigs");

const fetchApplicationPerformanceData = async (req, res) => {
    try {
        res.status(responseCodes.SUCCESS).json({
            status: 'success',
            statusCode: 200,
            message: 'Data fetched successfully',
            data: applicationPerformance
        });
    }
    catch (error) {
        res.status(responseCodes.SERVER_ERROR).json({
            status: 'error',
            statusCode: 500,
            message: 'Internal Server Error',
            error: error.message
        });
    }
}

module.exports = { fetchApplicationPerformanceData };