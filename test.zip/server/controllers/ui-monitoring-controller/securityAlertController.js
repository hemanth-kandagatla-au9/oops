const responseCodes = require("../../utils/responseCodes");
const { alertsData } = require("./uiMonitoringConfigs");

const fetchAlertsData = async (_req, res) => {
    try {
        res.status(responseCodes.SUCCESS).json({
            status: 'success',
            statusCode: 200,
            message: 'Data fetched successfully',
            data: alertsData
        });
    }
    catch (error) {
        console.error('Error fetching data:', error.message);
        res.status(responseCodes.SERVER_ERROR).json({
            status: 'error',
            statusCode: 500,
            message: 'Internal Server Error',
            error: error.message
        });
    }
}

module.exports = { fetchAlertsData };