const mongoose = require("mongoose");
const path = require("path");
const fs = require("fs");
const { getMongoConnectionURL, getMongoPem } = require("../utils/envUtils");
const { APP_CONFIG } = require("../../config");

let discoveryConn; 

const getTlsOptions = async () => ({
  tls: process.env.MONGO_TLS_ENABLED || true,
  authSource: "admin",
  ...APP_CONFIG.MONGO.OPTIONS
});

const getDiscoveryConnection = async () => {
  try {
    if (discoveryConn) {
      return discoveryConn;
    }

    if (process.env.NODE_ENV === "test") {
      return null;
    }

    let mongoConnectionURL = process.env.DB_CONNECTION_URL
      ? process.env.DB_CONNECTION_URL
      : await getMongoConnectionURL();

    const dbname = process.env.DISCOVERY_DB_NAME || "discovery";
    mongoConnectionURL = `mongodb://${mongoConnectionURL}${dbname}`;

    const tlsOptions = await getTlsOptions();

    if (process.env.MONGO_TLS_ENABLED === "true") {
      const filePath = path.join(
        __dirname,
        "../../",
        process.env.MONGO_KEY || "mongo-sbx-ca.pem"
      );

      if (!fs.existsSync(filePath)) {
        const pemData = await getMongoPem();
        fs.writeFileSync(filePath, pemData);
      }

      tlsOptions.tlsCAFile = filePath;
    } else {
      tlsOptions.tls = false;
    }

    discoveryConn = mongoose.createConnection(
      mongoConnectionURL,
      tlsOptions
    );

    discoveryConn.on("connected", () => {
      console.log("Connected to Discovery DB");// NOSONAR
    });

    discoveryConn.on("error", (err) => {
      console.error(" Discovery DB error:", err);// NOSONAR
    });

    mongoose.set("debug", true);

    return discoveryConn;
  } catch (e) {
    console.error(`Mongo Discovery Connection Error: ${e.message}`);// NOSONAR
    throw e;
  }
};

module.exports = getDiscoveryConnection;
