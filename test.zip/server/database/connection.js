const { getMongoConnectionURL, getMongoPem } = require("../utils/envUtils");
const { APP_CONFIG } = require("../../config");
const mongoose = require('mongoose');
const path = require("node:path");
const fs = require("node:fs");

const getTlsOptions = async () => {
    return {
        tls: process.env.MONGO_TLS_ENABLED || true,
        authSource: 'admin',
        ...APP_CONFIG.MONGO.OPTIONS,
    };
};

const resolveTlsCertPath = async () => {
    const filePath = path.join(
        __dirname,
        "../../",
        process.env.MONGO_KEY || "mongo-sbx-ca.pem"
    );
    if (!fs.existsSync(filePath)) {
        const pemData = await getMongoPem();
        fs.writeFileSync(filePath, pemData);
    }
    return filePath;
};

let mongooseConnection;

const InitiateMongoServer = async () => {
    try {
        if (mongooseConnection) return;
        if (process.env.NODE_ENV === "test") return;

        let mongoConnectionURL = process.env.DB_CONNECTION_URL ? process.env.DB_CONNECTION_URL : await getMongoConnectionURL();
        const dbname = process.env.DATABASE ?? "riseagent";
        mongoConnectionURL = `mongodb://${mongoConnectionURL}${dbname}`;
        const tlsOptions = await getTlsOptions();
        console.log('tlsOptions', tlsOptions);// NOSONAR

        if (process.env.MONGO_TLS_ENABLED) {
            tlsOptions.tlsCAFile = await resolveTlsCertPath();
        } else {
            tlsOptions.tls = false;
        }

        mongooseConnection = await mongoose.connect(mongoConnectionURL, tlsOptions);
        mongoose.set('debug', true);
        console.log(`Connected to DB!!!`);// NOSONAR
    } catch (e) {
        console.log(`Mongo Connection Err: ${e.message}`);// NOSONAR
    }
};


module.exports = {
    InitiateMongoServer,
    getTlsOptions,
};

