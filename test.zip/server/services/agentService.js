const fetch = require("node-fetch");
const {
  getOpenSearchPassword,
  getAuthUserPasswordFromSSM
} = require("../utils/envUtils");

const responseCodes = require("../utils/responseCodes");
const axios = require("axios");
const tokenLogs = require("../models/tokenLogs");
const { generateToken } = require("../auth/services/tokenService");

require("dotenv").config();


const getAuthToken =async () => {
  const username = process.env.AUTH_AGENT_USERNAME;
  const password =
    process.env.AUTH_PASS || (await getAuthUserPasswordFromSSM());

  const user = await tokenLogs.findOne({ username }).sort({ createdAt: -1 });

  if (user && user.token && user.action === "GENERATED") {
    const isExpired = new Date() > user.expiresTime;
    if (!isExpired) return user.token;
  }

  const tokenData = await generateToken(username, password);
  return tokenData.token;
};


const axiosRequest = async (url, method, data, headers = {}) => {
  return axios({
    url,
    method,
    data,
    headers,
    timeout: 10000
  });
};

const createFetchRequest = async (url, method, data = null) => {
  const token = await getAuthToken();

  const headers = {
    Authorization: `Bearer ${token}`
  };

  if (data) headers["Content-Type"] = "application/json";

  return axiosRequest(url, method, data, headers);
};

const createOpenSearchFetchRequest = async (url, method) => {
  const username = process.env.OPENSEARCH_USER;
  const password =
    process.env.OPENSEARCH_NON_PROD_PASSWORD ||
    (await getOpenSearchPassword());

  const OPENSEARCH_URL = process.env.OPENSEARCH_URL;

  return fetch(OPENSEARCH_URL + url, {
    method,
    headers: {
      Authorization: `Basic ${Buffer.from(
        `${username}:${password}`
      ).toString("base64")}`
    }
  });
};

const createMasterAgentFetchRequest = async (url, method) => {
  const username = process.env.MASTERAGENT_USERNAME;
  const password = process.env.MASTERAGENT_PASSWORD;
  const MASTERAGENT_URL = process.env.MASTERAGENT_URL;

  return fetch(MASTERAGENT_URL + url, {
    method,
    headers: {
      Authorization: `Basic ${Buffer.from(
        `${username}:${password}`
      ).toString("base64")}`
    }
  });
};

const createBulkFetchRequest = async (action,data, hostnames = [], payload = {}, singleHostname = null) => {
  try {                    // NOSONAR                      
    const url = `${process.env.BULK_ACTION_BASE_URL}/api/bulk/action`; 
    const token = await getAuthToken();
    const name =  data.name || ''
    const email = data.email|| ''
    const triggeredBy =  data.username || ''
    const response = await axiosRequest(
      url,
      "post",
      { action, hostnames, payload,singleHostname,name,email,triggeredBy },
      {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      }
    );
  
    if (response.status === responseCodes.SUCCESS) {   // NOSONAR

  if ( response?.data &&Object.prototype.hasOwnProperty.call(response.data,"success")) {  //NOSONAR

    if (response.data.success === true) {  // NOSONAR

      return response.data;

    } else {

      return {status: responseCodes.ERROR, message: response?.data?.message};
    }

  } else {
    return response.data;
  }
}

  if (response.status === responseCodes.NOT_FOUND) {
      return { status: responseCodes.NOT_FOUND,message: "File not found"};
    }
  } catch (error) {
    console.log('err>',error) // NOSONAR
    return { status: 500, message: error.message };
  }
};

const fetchData = async (url, method, data = null, isRustAgent = true, isMasterAgent = false, isDownloadApi = false,logsApi = false) => {// NOSONAR

  try {

    const response = isMasterAgent ? await createMasterAgentFetchRequest(url, method) : (isRustAgent ? await createFetchRequest(url, method, data) : await createOpenSearchFetchRequest(url, method));// NOSONAR



    let contentType

    if (response.status === responseCodes.SUCCESS) {

      if(logsApi){

      contentType = response.headers.get('content-type');

      } else{

        contentType = response.headers['content-type'];

      }

      let jsonResponse = {};

      if (isDownloadApi) {

        jsonResponse = { type: "buffer", contentType: contentType, data: await response.buffer() };

      }

      if(logsApi){

        jsonResponse = await response.json();

        return jsonResponse.hits.hits.map(record => record._source).filter(Boolean);

      }

      else  {
        jsonResponse = { type: "unknown", contentType: contentType, data: await response.data };

      }
 
      if (isRustAgent) {

        return response.data;

      }

      if (isMasterAgent) {

        const sortedAgentMetaDataResponse = jsonResponse.agentMetaDataResponse.sort((a, b) => Number(b.buildDate) - Number(a.buildDate));

        return { risebotVersions: sortedAgentMetaDataResponse };

      }
 
    }

    if (response.status === responseCodes.NOT_FOUND) {

      return { status: responseCodes.NOT_FOUND, message: "File not found" }

    }

  } catch (error) {



    if (error.code === "ECONNREFUSED" || error.code === "ENOTFOUND" || error.message) {

      return undefined;

    }

  }
 
};

const getBaseURL = async host => {
  const hostname = host?.hostname;
  const DEFAULT_PORT = 20140;

  const port = host?.port !== undefined && host?.port !== "undefined" ? host.port : DEFAULT_PORT;

  return `https://${hostname}:${port}`;
};

module.exports = {
  fetchData,
  getBaseURL,
  getHealth: async data => createBulkFetchRequest('agent_status',data, data.hostname, {},data.singleHostname),
  downloadFile: async data => fetchData(`${(await getBaseURL(data))}/agent/download/file`, "POST", data, true, false, true), // NOSONAR
  getPid: async data => fetchData(`${(await getBaseURL(data))}/agent/pid`, "GET"), // NOSONAR
  getMetric: async data => fetchData(`${(await getBaseURL(data))}/agent/metric`, "GET"), // NOSONAR
  getConfig: async data => fetchData(`${(await getBaseURL(data))}/agent/config`, "GET"),
  putShutDown: async data => createBulkFetchRequest('agent_stop', data,data.hostname, {},data.singleHostname || null),  // NOSONAR
  putRestartAgent: async data => createBulkFetchRequest('agent_restart', data,data.hostname, {},data.singleHostname || null,),   // NOSONAR
  putStart: async data => createBulkFetchRequest('agent_start_job',data, data.hostname, data.payload || {},data.singleHostname || null),   // NOSONAR
  putStop: async data => createBulkFetchRequest('agent_stop_job',data, data.hostname, data.payload || {},data.singleHostname || null),  // NOSONAR
  putRestart: async data => createBulkFetchRequest('agent_restart_job',data, data.hostname, data.payload || {},data.singleHostname || null), // NOSONAR
  getJobs: async data => fetchData(`${(await getBaseURL(data))}/agent/jobs`, "GET"),
  sycAgentCOnfig: async data => createBulkFetchRequest('agent_config_sync',data, data.hostname,{},data.singleHostname || null), // NOSONAR

  updateEnv: async data => createBulkFetchRequest('agent_env_update', data,data.hostname, { env:data.env },data.singleHostname || null),   // NOSONAR
  getJobDetails: async data => fetchData(`${(await getBaseURL(data))}/agent/jobs?name=${data.scheduledJobId}`, "GET"),
  postJob: async data => fetchData(`${(await getBaseURL(data))}/agent/job`, "POST", data),
  updateJob: async data => fetchData(`${(await getBaseURL(data))}/agent/job`, "PUT", data),
  updateVersion: async data => createBulkFetchRequest('agent_upgrade',data, data.hostname, {version: data.version},data.singleHostname || null),  // NOSONAR
  deleteJob: async data => fetchData(`${await getBaseURL(data)}/agent/job?script_name=${data.scheduledJobId}`, "delete", {}),
  updateLocalConfiguration: async data => fetchData(`${(await getBaseURL(data))}/agent/config`, "PUT", data.propertiesSchemas), // NOSONAR
  getApplicationLogs: async data => fetchData(`/${process.env.OPENSEARCH_APPLICATION_INDEX}/_search?from=${data.skip}&size=${data.limit}&sort=timestamp:desc&q=hostname:${data.hostname}`, "POST", data, false,'','',true), // NOSONAR
  getJobLogs: async data => fetchData(`/${process.env.OPENSEARCH_APPLICATION_INDEX}/_search?from=${data.skip}&size=${data.limit}&sort=timestamp:desc&q=jobname:${data.jobname}`, "POST", data, false), // NOSONAR
  getVersions: async data => fetchData(`/rust-agent/version-list?agentType=rustlinux`, "GET", data, false, true),
  downloadAgent: async data => fetchData(`${(await getBaseURL(data))}/agent/version`, "PUT"), // NOSONAR
}