const mongoose = require("mongoose");
const AgentVersionModel = require("../models/agentVersionModel");
const VersionsModel = require("../models/versionsModel");
const responseCodes = require("../utils/responseCodes");

const getVersions = async query => {// NOSONAR
    try {
        const { operatingSystem, versionStatus, upgradeType,agentVersion, startDate, endDate, page = 1, limit = 10, isDeleted } = query;
        const matchStage = {};
        matchStage.isDeleted = isDeleted;
        if (operatingSystem !== undefined && operatingSystem !== "") {
            matchStage["compatibleOS.agentType"] = { $in: operatingSystem.split(",") };
        }
        if (versionStatus !== undefined && versionStatus !== "") {
            matchStage.versionStatus = { $in: versionStatus.split(",") };
        }
        if (upgradeType !== undefined && upgradeType !== "") {
            matchStage.upgradeType = { $in: upgradeType.split(",") };
        }
        if (agentVersion !== undefined && agentVersion !== "") {
            matchStage.agentVersion = { $in: agentVersion.split(",") };
        }
        if (startDate || endDate) {
            matchStage.releaseDate = {};
            if (startDate !== undefined && startDate !== "") matchStage.releaseDate.$gte = new Date(startDate);
            if (endDate !== undefined && endDate !== "") matchStage.releaseDate.$lte = new Date(endDate);
        }
        const pipeline = [];// NOSONAR
        pipeline.push({ $match: matchStage });
        const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit);
        // Fetch total count
        const countResult = await AgentVersionModel.aggregate([
            { $match: matchStage },
            { $count: "total" }
        ]);
        const total = countResult[0]?.total || 0;
        const aggregationResult = await AgentVersionModel.aggregate([
            { $match: matchStage },
            { $sort: { createdAt: 1 } },
            { $skip: skip },
            { $limit: Number.parseInt(limit) }
        ]);
        return {
            versionData: aggregationResult,
            filterData: await extractFilterOptions(matchStage),
            pagination: {
                total,
                page: Number.parseInt(page),
                limit: Number.parseInt(limit),
                totalPages: Math.ceil(total / limit)
            }
        };
    }
    catch (err) {
        return err;
    }
}

const extractFilterOptions = async (matchStage = {}) => {
    const makeMatchExcluding = excludeFieldPath => {
        const clone = { ...matchStage };
        delete clone[excludeFieldPath];
        return clone;
    };
 
    const [
        agentVersions,
        compatibleOS,
        versionStatuses,
        upgradeTypes
    ] = await Promise.all([
        AgentVersionModel.distinct("agentVersion", makeMatchExcluding("agentVersion")),
        AgentVersionModel.distinct("compatibleOS.agentType", makeMatchExcluding("compatibleOS.agentType")),
        AgentVersionModel.distinct("versionStatus", makeMatchExcluding("versionStatus")),
        AgentVersionModel.distinct("upgradeType", makeMatchExcluding("upgradeType"))
    ]);
 
    return {
        agentVersions: (agentVersions || []).filter(Boolean).sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" })),
        compatibleOS: (compatibleOS || []).filter(Boolean),
        versionStatus: (versionStatuses || []).filter(Boolean),
        upgradeType: (upgradeTypes || []).filter(Boolean)
    };
};

const saveVersion = async (versionData) => {
    try {
        const { agentVersion } = versionData;
        if (!agentVersion || typeof agentVersion !== 'string') {
            return responseCodes.ERROR;
        }
        const query = { agentVersion: agentVersion.trim(), isDeleted: false };
        const versionExists = await AgentVersionModel.find(query);
        if (versionExists.length) {
            return responseCodes.EXISTS;
        }
        else {
            const agentVersion = new AgentVersionModel({ ...versionData });// NOSONAR
            const savedAgentVersion = await agentVersion.save();
            return savedAgentVersion;
        }
    }
    catch (err) {
        return err;
    }
}

const softDeleteVersion = async (id) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(id)) {
            return "Invalid ObjectId";
        }

        const result = await AgentVersionModel.findOneAndUpdate(
            { _id: id, isDeleted: false },
            { isDeleted: true },
            { new: true }
        );
        if (!result) {
            return "Version not found";
        }

        return {
            message: "Version soft-deleted successfully",
            data: result
        };

    } catch (err) {
        return err;
    }
};

const updateVersionService = async (id, updateData) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(id)) {
            return "Invalid ObjectId";
        }

        const result = await AgentVersionModel.findOneAndUpdate(
            { _id: id, isDeleted: false },
            { $set: updateData },
            { new: true }
        );

        if (!result) {
            return "Version not found";
        }

        return {
            message: "Version data updated successfully",
            data: result
        };

    } catch (err) {
        return err;
    }
};

/**
 * Centralized Version Sync Logic
 * Used by both cron jobs and manual sync API
 * Synchronizes version data between collections
 */
const syncVersions = async () => {// NOSONAR
    try {
        
        const startTime = new Date();
        
        // Fetch all versions from the versions collection
        const versions = await VersionsModel.find({});
        
        let syncedCount = 0;
        let updatedCount = 0;
        let errorCount = 0;
        
        // Process each version
        for (const versionData of versions) {
            try {
                if (!versionData.version) {
                    continue;
                }
                
                // Ensure buildDate is a proper Date object
                const buildDate = versionData.buildDate ? new Date(versionData.buildDate) : new Date();
                
                // Check if version already exists in agent_versions
                const existingVersion = await AgentVersionModel.findOne({ 
                    agentVersion: versionData.version,
                    isDeleted: false 
                });
                
                if (existingVersion) {
                    // Convert existing buildDate to Date object for comparison
                    const existingBuildDate = existingVersion.buildDate ? new Date(existingVersion.buildDate) : null;
                    const newBuildDate = new Date(buildDate);
                    
                    // Update existing version's buildDate if different or missing
                    if (!existingBuildDate || existingBuildDate.getTime() !== newBuildDate.getTime()) {// NOSONAR
                        await AgentVersionModel.findByIdAndUpdate(
                            existingVersion._id,
                            { 
                                buildDate: newBuildDate,
                                updatedAt: new Date()
                            }
                        );
                        
                        updatedCount++;
                    } else {
                        console.log(`Version ${versionData.version} buildDate unchanged: ${existingBuildDate}`);
                    }
                } else {
                    // Create new agent version record
                    const newAgentVersion = {
                        agentVersion: versionData.version,
                        buildDate: new Date(buildDate),
                        compatibleOS: [],
                        releaseDate: new Date(),
                        versionStatus: "Current",
                        upgradeType: "Optional",
                        createdAt: new Date(),
                        updatedAt: new Date(),
                        isDeleted: false
                    };
                    
                    await AgentVersionModel.create(newAgentVersion);
                    syncedCount++;
                }
                
            } catch (syncError) {
                errorCount++;
                console.error(`Error syncing version ${versionData.version}:`, syncError.message);// NOSONAR
            }
        }
        
        const endTime = new Date();
        const duration = endTime - startTime;
        
        return {
            success: true,
            syncedCount,
            updatedCount,
            errorCount,
            duration: duration
        };
        
    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
};

module.exports = { saveVersion, getVersions, softDeleteVersion, updateVersionService, syncVersions };