const express = require("express");
const router = express.Router();
const { requirePermission } = require("../../middlewares/permissionsMidlleware");
const { PERMISSIONS } = require("../../utils/permissionHelper");
const versionManagementController = require("../../controllers/version-management-controller/versionManagement.controller");

router.post("/", requirePermission(PERMISSIONS.VERSION_MANAGEMENT), versionManagementController.createVersion);  // NOSONAR
router.get("/", requirePermission(PERMISSIONS.VERSION_MANAGEMENT), versionManagementController.fetchVersions);  // NOSONAR
router.patch("/:id/delete", requirePermission(PERMISSIONS.VERSION_MANAGEMENT), versionManagementController.deleteVersion); // NOSONAR
router.patch("/:id", requirePermission(PERMISSIONS.VERSION_MANAGEMENT), versionManagementController.updateVersion); // NOSONAR

module.exports = router;