const express = require("express");
const router = express.Router();
const agentServiceController = require("../../controllers/agentServiceController");


router.get("/healthy",agentServiceController.checkHealth)
router.get("/ready",agentServiceController.checkReady)


module.exports = router;
