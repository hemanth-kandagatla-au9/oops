const express = require("express");
const router = express.Router();
const { requirePermission } = require("../../middlewares/permissionsMidlleware");
const { PERMISSIONS } = require("../../utils/permissionHelper");
const bulkController = require("../../controllers/bulkAgentController");
const bulkActionLogsController = require("../../controllers/bulkActionLogsController");

// Bulk operation routes with permission checks
router.post("/bulk/start", requirePermission(PERMISSIONS.BULK_START), bulkController.bulkStartAgent); // NOSONAR
router.post("/bulk/stop", requirePermission(PERMISSIONS.BULK_STOP), bulkController.bulkStopAgent); // NOSONAR
router.post("/bulk/restart", requirePermission(PERMISSIONS.BULK_RESTART), bulkController.bulkRestartAgent); // NOSONAR
router.put("/bulk/upgrade", requirePermission(PERMISSIONS.BULK_UPGRADE), bulkController.bulkUpgradeAgent); // NOSONAR
router.post("/bulk/sync-agentConfig", requirePermission(PERMISSIONS.BULK_SYNC_AGENT_CONFIG), bulkController.bulkSyncAgent); // NOSONAR
router.put("/bulk/update-env", requirePermission(PERMISSIONS.BULK_ENV_UPDATE), bulkController.bulkEnvUpdate); // NOSONAR

router.post("/bulk-action-logs",  requirePermission(PERMISSIONS.VIEW_BULK_LOGS ),bulkActionLogsController.getBulkActionLogs);  // NOSONAR
router.get("/bulk-action-logs", requirePermission(PERMISSIONS.VIEW_BULK_LOGS), bulkActionLogsController.getBulkActionLogs);       // NOSONAR
router.get("/bulk-action-logs/:id", requirePermission(PERMISSIONS.VIEW_BULK_LOGS), bulkActionLogsController.getBulkActionLogById); // NOSONAR
router.get("/export-bulk-action-logs",requirePermission(PERMISSIONS.VIEW_BULK_LOGS), bulkActionLogsController.getBulkActionLogDataForExcel); // NOSONAR



module.exports = router;