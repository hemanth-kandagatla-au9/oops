const express = require("express");

const router = express.Router();

const { requirePermission } = require("../../middlewares/permissionsMidlleware");
const { PERMISSIONS } = require("../../utils/permissionHelper");

const metricsController = require("../../controllers/metricsController");

const agentServiceController = require("../../controllers/agentServiceController");

const agentSyncController = require("../../controllers/syncController");

const agentConfigController =  require("../../controllers/agentConfigController")

// Agent lifecycle and config routes with permission checks

router.get("/", agentServiceController.getAgentsData);

router.post("/", agentServiceController.getAgentsData);

router.post("/info", agentServiceController.getAgentInfo);

router.get("/pid", agentServiceController.pid);

router.get("/metrics", metricsController.getMetricsData);

router.get("/config", agentServiceController.config);

router.put("/local-configuration",  agentServiceController.updateLocalConfiguration);

router.post("/logs",  requirePermission(PERMISSIONS.HOST_LOGS),agentServiceController.getApplicationLogs);

router.get("/regions", agentServiceController.getRegions);

router.get("/platforms", agentServiceController.getPlatforms);

router.get("/environments", agentServiceController.getEnvironments);

router.get("/sids", agentServiceController.getSids);

router.get("/os-types", agentServiceController.getOStypes);

router.get("/service-names", agentServiceController.getServiceNames);

router.get("/check-basic-auth", agentServiceController.checkBasicAuth);

router.get("/agent-config-details", requirePermission(PERMISSIONS.GLOBAL_CONFIG_READ), agentConfigController.getAgentConfigDetails)


// Agent API

router.post("/startagent", requirePermission(PERMISSIONS.START), agentServiceController.startAgentService);

router.put("/restart", requirePermission(PERMISSIONS.RESTART),agentServiceController.restartAgent);

router.post("/stopAgent",requirePermission(PERMISSIONS.STOP), agentServiceController.shutdown);

router.post("/health", requirePermission(PERMISSIONS.CHECK_STATUS),agentServiceController.health);

router.post("/update-agentconfig",requirePermission(PERMISSIONS.GLOBAL_CONFIG_UPDATE),agentConfigController.updateAgentConfigDetails);

router.post("/sync-agentConfig",requirePermission(PERMISSIONS.SYNC_AGENT_CONFIG),agentServiceController.sycAgentCOnfigDetails);

router.post("/update-env",requirePermission(PERMISSIONS.UPDATE_ENV), agentServiceController.updateEnvEnvData);

router.put("/agent-upgrade", requirePermission(PERMISSIONS.UPGRADE), agentServiceController.upgradeVersion);
 
// Sync API

router.put("/syncAgentStatus", requirePermission(PERMISSIONS.SYNC_STATUS),agentSyncController.syncAgentStatus);

router.put("/syncVersions", agentSyncController.manualVersionSync);

router.put("/syncCMDBData", agentSyncController.syncCMDBData);
 
module.exports = router;
 