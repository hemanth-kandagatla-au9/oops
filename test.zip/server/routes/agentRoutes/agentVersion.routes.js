const express = require("express");
const router = express.Router();
const { requirePermission } = require("../../middlewares/permissionsMidlleware");
const { PERMISSIONS } = require("../../utils/permissionHelper");
const agentVersionController = require("../../controllers/agentVersionController");
const versionManagementController = require("../../controllers/version-management-controller/versionManagement.controller")

router.get("/versionlist", agentVersionController.getVersionsList);
router.get("/agent-versions", agentVersionController.getAgentVersions);

router.put("/updateVersion/:id", requirePermission(PERMISSIONS.UPDATE_VERSION_MANAGEMENT), versionManagementController.updateVersion);
router.put("/upgradeVersion",requirePermission(PERMISSIONS.UPDATE), agentVersionController.version);

module.exports = router;