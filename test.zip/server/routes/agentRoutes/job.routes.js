const express = require("express");
const router = express.Router();
const { requirePermission } = require("../../middlewares/permissionsMidlleware");
const { PERMISSIONS } = require("../../utils/permissionHelper");
const jobsController = require("../../controllers/jobController");

// Job-related routes with permission checks
router.post("/jobs", jobsController.jobs); // NOSONAR
router.post("/jobs/start", requirePermission(PERMISSIONS.JOB_START), jobsController.start); // NOSONAR
router.post("/jobs/stop", requirePermission(PERMISSIONS.JOB_STOP), jobsController.stopjob); // NOSONAR
router.put("/jobs/restart", requirePermission(PERMISSIONS.JOB_RESTART), jobsController.restart); // NOSONAR

router.post("/job", jobsController.getJobDetails);
router.post("/postjob", jobsController.postJob);
router.put("/updatejob", jobsController.updateJob);
router.delete("/deletejob", jobsController.deleteJob);
router.post("/joblogs", jobsController.getJobLogs);

module.exports = router;