require("dotenv").config();

const APP_CONFIG = {
  MONGO: {
    OPTIONS: {
      useNewUrlParser: true,
      useUnifiedTopology: true
    },
  },
  ACTIVE_AGENTINFO_CRON: '*/5 * * * * ',
  FAILED_AGENTINFO_CRON: '0 0 * * *',
  VERSION_SYNC_CRON: '0 */6 * * *', // Every 6 hours
  DISCOVERY_SYNC_CRON: '0 */6 * * *' // Every 6 hours
};

module.exports = {
  APP_CONFIG,
};
