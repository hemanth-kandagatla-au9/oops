export interface ApiResponse<T = any> {
  status: boolean;
  message: string;
  data: T;
}

export interface PaginatedResponse<T = any> {
  status: boolean;
  message: string;
  data: T[];
  total: number;
  page: number;
  limit: number;
}

export interface Rule {
  _id: string;
  rule_id: string;
  name: string;
  description: string;
  rule_type: string;
  severity: string;
  status: string;
  conditions: RuleCondition[];
  tags: string[];
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface RuleCondition {
  attribute: string;
  operator: string;
  value: string;
}

export interface Policy {
  _id: string;
  policy_id: string;
  name: string;
  description: string;
  policy_type: string;
  status: string;
  rules: string[];
  tags: string[];
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface PolicyGroup {
  _id: string;
  group_id: string;
  name: string;
  description: string;
  policies: string[];
  tags: string[];
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface Assignment {
  _id: string;
  assignment_id: string;
  policy_id: string;
  target_type: string;
  target_id: string;
  status: string;
  assigned_by: string;
  assigned_at: string;
  expires_at?: string;
}

export interface Artifact {
  _id: string;
  artifact_id: string;
  name: string;
  description: string;
  artifact_type: string;
  file_path: string;
  version: string;
  checksum: string;
  uploaded_by: string;
  uploaded_at: string;
}

export interface ComplianceRecord {
  _id: string;
  compliance_id: string;
  assignment_id: string;
  policy_id: string;
  target_id: string;
  status: string;
  score: number;
  details: string;
  evaluated_at: string;
}

export interface ComplianceSummary {
  compliant: number;
  non_compliant: number;
  pending: number;
  total: number;
}

export interface AuditLog {
  _id: string;
  user_id: string;
  action: string;
  module: string;
  endpoint: string;
  method: string;
  status_code: number;
  timestamp: string;
  ip_address?: string;
}
