import React from "react";
import { Route, Redirect, RouteProps } from "react-router-dom";
import { POLICYOPS_PATH } from "./constant";
import { Box, CircularProgress } from "@mui/material";
import Cookies from "universal-cookie";

interface PrivateRouteProps extends RouteProps {
  component: React.ComponentType<any>;
  module?: string | string[];
  permissions: any;
  permissionType?: "read" | "write";
  isPermissionsLoading?: boolean;
}

const cookies = new Cookies();

const PrivateRoute: React.FC<PrivateRouteProps> = ({
  component: Component,
  module,
  permissions,
  permissionType = "read",
  isPermissionsLoading = false,
  ...rest
}) => {
  const isAuthenticated = cookies.get("isAuthenticated");

  return (
    <Route
      {...rest}
      render={(props) => {
        if (isPermissionsLoading) {
          return (
            <Box display="flex" justifyContent="center" alignItems="center" height="50vh">
              <CircularProgress />
            </Box>
          );
        }

        if (!isAuthenticated) {
          return <Redirect to={POLICYOPS_PATH.ROOT} />;
        }

        return <Component {...props} />;
      }}
    />
  );
};

export default PrivateRoute;
