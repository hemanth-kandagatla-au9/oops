export const POLICYOPS_PATH = {
  ROOT: "/",
  DASHBOARD: "/dashboard",
  RULES: "/rules",
  POLICIES: "/policies",
  POLICY_GROUPS: "/policy-groups",
  ASSIGNMENTS: "/assignments",
  ARTIFACTS: "/artifacts",
  COMPLIANCE: "/compliance",
  AUDIT: "/audit",
  SETTINGS: "/settings",
  LOGOUT: "/logout",
  UNAUTHORIZED: "/unauthorized",
  SESSION_EXPIRED: "/session-expired",
};

export const TOAST_MESSAGES = {
  CREATE_SUCCESS: "Created successfully!",
  UPDATE_SUCCESS: "Updated successfully!",
  DELETE_SUCCESS: "Deleted successfully!",
  ERROR: "Something went wrong. Please try again.",
  CONFLICT: "Resource already exists.",
  NOT_FOUND: "Resource not found.",
};

export const TABLE_HEADERS = {
  NAME: "Name",
  DESCRIPTION: "Description",
  STATUS: "Status",
  CREATED_BY: "Created By",
  CREATED_AT: "Created At",
  UPDATED_AT: "Updated At",
  ACTIONS: "Actions",
  SEVERITY: "Severity",
  TYPE: "Type",
  VERSION: "Version",
  SCORE: "Score",
  TARGET: "Target",
};

export const POLICYOPS_MODULE = "policyops";
