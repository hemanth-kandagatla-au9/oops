import React, { useEffect } from "react";
import { Switch, Route, Redirect, useHistory, useLocation } from "react-router-dom";
import "./App.scss";
import LoginPage from "./pages/login/LoginPage";
import LogoutPage from "./pages/logout/LogoutPage";
import PrivateRoute from "./utils/PrivateRoute";
import { LandingPageLayout } from "./pages/landing/LandingPage";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer } from "react-toastify";
import { POLICYOPS_PATH } from "./utils/constant";
import { useSelector } from "react-redux";
import { RootState } from "./redux/store";
import UnauthorizedPage from "./pages/unauthorized/UnauthorizedPage";
import SessionExpiredPage from "./pages/sessionExpired/SessionExpired";
import DashboardPage from "./pages/dashboard/DashboardPage";
import RulesPage from "./pages/rules/RulesPage";
import PoliciesPage from "./pages/policies/PoliciesPage";
import PolicyGroupsPage from "./pages/policyGroups/PolicyGroupsPage";
import AssignmentsPage from "./pages/assignments/AssignmentsPage";
import ArtifactsPage from "./pages/artifacts/ArtifactsPage";
import CompliancePage from "./pages/compliance/CompliancePage";
import AuditPage from "./pages/audit/AuditPage";
import SettingsPage from "./pages/settings/SettingsPage";
import Cookies from "universal-cookie";
import { Box, CircularProgress, Typography } from "@mui/material";

const cookies = new Cookies();
const SKIP_AUTH_PATHS: string[] = [
  POLICYOPS_PATH.UNAUTHORIZED,
  POLICYOPS_PATH.LOGOUT,
  POLICYOPS_PATH.SESSION_EXPIRED,
];

const App: React.FC = () => {
  const permissionState = useSelector((state: RootState) => state.permissions.permissions);
  const isLoading = useSelector((state: RootState) => state.permissions.isLoading);
  const isSessionExpired = useSelector((state: RootState) => state.permissions.isSessionExpired);
  const history = useHistory();
  const location = useLocation();
  const isAuthenticated = !!cookies.get("isAuthenticated");
  const isSkipAuthPage = SKIP_AUTH_PATHS.includes(location.pathname);

  useEffect(() => {
    if (isSessionExpired) {
      history.replace(POLICYOPS_PATH.SESSION_EXPIRED);
    }
  }, [isSessionExpired, history]);

  useEffect(() => {
    if (isLoading || isSkipAuthPage) return;
    if (!isAuthenticated && !SKIP_AUTH_PATHS.includes(location.pathname)) {
      history.replace("/");
    }
  }, [isAuthenticated, isLoading, isSkipAuthPage, history, location.pathname]);

  if (isSkipAuthPage) {
    return (
      <Switch>
        <Route path={POLICYOPS_PATH.LOGOUT} component={LogoutPage} />
        <Route exact path={POLICYOPS_PATH.UNAUTHORIZED} component={UnauthorizedPage} />
        <Route exact path={POLICYOPS_PATH.SESSION_EXPIRED} component={SessionExpiredPage} />
      </Switch>
    );
  }

  if (isLoading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh" flexDirection="column">
        <CircularProgress />
        <Typography variant="body2" sx={{ mt: 2 }}>Loading PolicyOps...</Typography>
      </Box>
    );
  }

  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />
      <LandingPageLayout>
        <Switch>
          <Route exact path="/" render={() => <Redirect to={POLICYOPS_PATH.DASHBOARD} />} />
          <PrivateRoute
            path={POLICYOPS_PATH.DASHBOARD}
            component={DashboardPage}
            permissions={permissionState}
            module="policyops"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.RULES}
            component={RulesPage}
            permissions={permissionState}
            module="rules"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.POLICIES}
            component={PoliciesPage}
            permissions={permissionState}
            module="policies"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.POLICY_GROUPS}
            component={PolicyGroupsPage}
            permissions={permissionState}
            module="policy_groups"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.ASSIGNMENTS}
            component={AssignmentsPage}
            permissions={permissionState}
            module="assignments"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.ARTIFACTS}
            component={ArtifactsPage}
            permissions={permissionState}
            module="artifacts"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.COMPLIANCE}
            component={CompliancePage}
            permissions={permissionState}
            module="compliance"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.AUDIT}
            component={AuditPage}
            permissions={permissionState}
            module="audit"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.SETTINGS}
            component={SettingsPage}
            permissions={permissionState}
            module="policyops"
          />
        </Switch>
      </LandingPageLayout>
    </>
  );
};

export default App;
