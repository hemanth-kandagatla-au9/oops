import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const policyGroupsSlice = createApi({
  reducerPath: "policyGroupsApi",
  baseQuery,
  tagTypes: ["PolicyGroup"],
  endpoints: (builder) => ({
    getPolicyGroups: builder.query<any, { page?: number; limit?: number }>({
      query: ({ page = 1, limit = 10 }) => `/policy-groups?page=${page}&limit=${limit}`,
      providesTags: ["PolicyGroup"],
    }),
    getPolicyGroupById: builder.query<any, string>({
      query: (id) => `/policy-groups/${id}`,
    }),
    createPolicyGroup: builder.mutation<any, Partial<any>>({
      query: (body) => ({ url: "/policy-groups", method: "POST", body }),
      invalidatesTags: ["PolicyGroup"],
    }),
    updatePolicyGroup: builder.mutation<any, { id: string; data: Partial<any> }>({
      query: ({ id, data }) => ({ url: `/policy-groups/${id}`, method: "PUT", body: data }),
      invalidatesTags: ["PolicyGroup"],
    }),
    deletePolicyGroup: builder.mutation<any, string>({
      query: (id) => ({ url: `/policy-groups/${id}`, method: "DELETE" }),
      invalidatesTags: ["PolicyGroup"],
    }),
  }),
});

export const {
  useGetPolicyGroupsQuery,
  useGetPolicyGroupByIdQuery,
  useCreatePolicyGroupMutation,
  useUpdatePolicyGroupMutation,
  useDeletePolicyGroupMutation,
} = policyGroupsSlice;
