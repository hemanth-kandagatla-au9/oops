import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const rulesSlice = createApi({
  reducerPath: "rulesApi",
  baseQuery,
  tagTypes: ["Rule"],
  endpoints: (builder) => ({
    getRules: builder.query<any, { page?: number; limit?: number; status?: string }>({
      query: ({ page = 1, limit = 10, status }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (status) params.append("status", status);
        return `/rules?${params.toString()}`;
      },
      providesTags: ["Rule"],
    }),
    getRuleById: builder.query<any, string>({
      query: (id) => `/rules/${id}`,
      providesTags: (_result, _error, id) => [{ type: "Rule", id }],
    }),
    createRule: builder.mutation<any, Partial<any>>({
      query: (body) => ({ url: "/rules", method: "POST", body }),
      invalidatesTags: ["Rule"],
    }),
    updateRule: builder.mutation<any, { id: string; data: Partial<any> }>({
      query: ({ id, data }) => ({ url: `/rules/${id}`, method: "PUT", body: data }),
      invalidatesTags: (_result, _error, { id }) => [{ type: "Rule", id }],
    }),
    deleteRule: builder.mutation<any, string>({
      query: (id) => ({ url: `/rules/${id}`, method: "DELETE" }),
      invalidatesTags: ["Rule"],
    }),
  }),
});

export const {
  useGetRulesQuery,
  useGetRuleByIdQuery,
  useCreateRuleMutation,
  useUpdateRuleMutation,
  useDeleteRuleMutation,
} = rulesSlice;
