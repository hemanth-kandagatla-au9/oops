import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const auditSlice = createApi({
  reducerPath: "auditApi",
  baseQuery,
  tagTypes: ["AuditLog"],
  endpoints: (builder) => ({
    getAuditLogs: builder.query<any, { page?: number; limit?: number; module?: string }>({
      query: ({ page = 1, limit = 20, module }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (module) params.append("module", module);
        return `/audit?${params.toString()}`;
      },
      providesTags: ["AuditLog"],
    }),
  }),
});

export const { useGetAuditLogsQuery } = auditSlice;
