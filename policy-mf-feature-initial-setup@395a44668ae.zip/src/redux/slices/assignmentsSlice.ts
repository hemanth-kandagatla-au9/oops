import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const assignmentsSlice = createApi({
  reducerPath: "assignmentsApi",
  baseQuery,
  tagTypes: ["Assignment"],
  endpoints: (builder) => ({
    getAssignments: builder.query<any, { page?: number; limit?: number; policyId?: string; status?: string }>({
      query: ({ page = 1, limit = 10, policyId, status }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (policyId) params.append("policy_id", policyId);
        if (status) params.append("status", status);
        return `/assignments?${params.toString()}`;
      },
      providesTags: ["Assignment"],
    }),
    getAssignmentById: builder.query<any, string>({
      query: (id) => `/assignments/${id}`,
    }),
    createAssignment: builder.mutation<any, Partial<any>>({
      query: (body) => ({ url: "/assignments", method: "POST", body }),
      invalidatesTags: ["Assignment"],
    }),
    updateAssignment: builder.mutation<any, { id: string; data: Partial<any> }>({
      query: ({ id, data }) => ({ url: `/assignments/${id}`, method: "PUT", body: data }),
      invalidatesTags: ["Assignment"],
    }),
    revokeAssignment: builder.mutation<any, string>({
      query: (id) => ({ url: `/assignments/${id}`, method: "DELETE" }),
      invalidatesTags: ["Assignment"],
    }),
  }),
});

export const {
  useGetAssignmentsQuery,
  useGetAssignmentByIdQuery,
  useCreateAssignmentMutation,
  useUpdateAssignmentMutation,
  useRevokeAssignmentMutation,
} = assignmentsSlice;
