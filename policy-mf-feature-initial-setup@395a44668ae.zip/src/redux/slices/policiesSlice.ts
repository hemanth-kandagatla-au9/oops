import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const policiesSlice = createApi({
  reducerPath: "policiesApi",
  baseQuery,
  tagTypes: ["Policy"],
  endpoints: (builder) => ({
    getPolicies: builder.query<any, { page?: number; limit?: number; status?: string; policyType?: string }>({
      query: ({ page = 1, limit = 10, status, policyType }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (status) params.append("status", status);
        if (policyType) params.append("policyType", policyType);
        return `/policies?${params.toString()}`;
      },
      providesTags: ["Policy"],
    }),
    getPolicyById: builder.query<any, string>({
      query: (id) => `/policies/${id}`,
      providesTags: (_result, _error, id) => [{ type: "Policy", id }],
    }),
    createPolicy: builder.mutation<any, Partial<any>>({
      query: (body) => ({ url: "/policies", method: "POST", body }),
      invalidatesTags: ["Policy"],
    }),
    updatePolicy: builder.mutation<any, { id: string; data: Partial<any> }>({
      query: ({ id, data }) => ({ url: `/policies/${id}`, method: "PUT", body: data }),
      invalidatesTags: (_result, _error, { id }) => [{ type: "Policy", id }],
    }),
    deletePolicy: builder.mutation<any, string>({
      query: (id) => ({ url: `/policies/${id}`, method: "DELETE" }),
      invalidatesTags: ["Policy"],
    }),
  }),
});

export const {
  useGetPoliciesQuery,
  useGetPolicyByIdQuery,
  useCreatePolicyMutation,
  useUpdatePolicyMutation,
  useDeletePolicyMutation,
} = policiesSlice;
