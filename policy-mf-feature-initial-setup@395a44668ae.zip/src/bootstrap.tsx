import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import { store, persistor } from "./redux/store";
import {
  PublicClientApplication,
  EventType,
  AuthenticationResult,
  EventMessage,
} from "@azure/msal-browser";
import { MsalProvider } from "@azure/msal-react";
import { msalConfig } from "./utils/msalConfig";
import { registerMsalInstance } from "./utils/tokenService";

const IS_INSIDE_HOST = !!(window as any).__POWERED_BY_IASPHERE__;

if (IS_INSIDE_HOST) {
  // Running inside IASphere host shell
  ReactDOM.render(
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <BrowserRouter>
          <App />
        </BrowserRouter>
      </PersistGate>
    </Provider>,
    document.getElementById("root")
  );
} else {
  // Standalone mode
  const msalInstance = new PublicClientApplication(msalConfig);
  registerMsalInstance(msalInstance);

  msalInstance.initialize().then(() => {
    msalInstance.addEventCallback((event: EventMessage) => {
      if (
        event.eventType === EventType.LOGIN_SUCCESS &&
        (event.payload as AuthenticationResult).account
      ) {
        msalInstance.setActiveAccount((event.payload as AuthenticationResult).account);
      }
    });

    ReactDOM.render(
      <MsalProvider instance={msalInstance}>
        <Provider store={store}>
          <PersistGate loading={null} persistor={persistor}>
            <BrowserRouter>
              <App />
            </BrowserRouter>
          </PersistGate>
        </Provider>
      </MsalProvider>,
      document.getElementById("root")
    );
  });
}
