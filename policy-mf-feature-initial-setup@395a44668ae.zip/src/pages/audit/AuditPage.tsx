import React from "react";
import { Box, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import { useGetAuditLogsQuery } from "../../redux/slices/auditSlice";

const AuditPage: React.FC = () => {
  const { data, isLoading } = useGetAuditLogsQuery({ page: 1, limit: 20 });
  const logs = data?.data ?? [];

  return (
    <Box p={3}>
      <Box mb={3}>
        <Typography variant="h5" fontWeight="bold">
          Audit Log
        </Typography>
        <Typography variant="body2" color="text.secondary">
          View all PolicyOps activity and changes
        </Typography>
      </Box>

      {isLoading ? (
        <Typography>Loading...</Typography>
      ) : logs.length === 0 ? (
        <Paper elevation={2} sx={{ p: 4, textAlign: "center", borderRadius: 2 }}>
          <Typography variant="h6" color="text.secondary">
            No audit records
          </Typography>
          <Typography variant="body2" color="text.secondary" mt={1}>
            Audit logs are captured automatically for all PolicyOps activities.
          </Typography>
        </Paper>
      ) : (
        <TableContainer component={Paper} elevation={2} sx={{ borderRadius: 2 }}>
          <Table>
            <TableHead>
              <TableRow sx={{ bgcolor: "grey.50" }}>
                <TableCell>Timestamp</TableCell>
                <TableCell>User</TableCell>
                <TableCell>Action</TableCell>
                <TableCell>Module</TableCell>
                <TableCell>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {logs.map((log: any) => (
                <TableRow key={log._id} hover>
                  <TableCell>{new Date(log.timestamp).toLocaleString()}</TableCell>
                  <TableCell>{log.user_id}</TableCell>
                  <TableCell>{log.action}</TableCell>
                  <TableCell>{log.module}</TableCell>
                  <TableCell>{log.status_code}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Box>
  );
};

export default AuditPage;
