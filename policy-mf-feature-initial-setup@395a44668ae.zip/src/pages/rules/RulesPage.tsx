import React from "react";
import { Box, Button, Paper, Typography } from "@mui/material";
import { Plus } from "lucide-react";

const RulesPage: React.FC = () => {
  return (
    <Box p={3}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h5" fontWeight="bold">
            Rules
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Define and manage policy rules
          </Typography>
        </Box>
        <Button variant="contained" startIcon={<Plus size={16} />}>
          Create Rule
        </Button>
      </Box>

      <Paper elevation={2} sx={{ p: 4, textAlign: "center", borderRadius: 2 }}>
        <Typography variant="h6" color="text.secondary" gutterBottom>
          No rules yet
        </Typography>
        <Typography variant="body2" color="text.secondary" mb={3}>
          Create your first rule to get started with policy management.
        </Typography>
        <Button variant="outlined" startIcon={<Plus size={16} />}>
          Create First Rule
        </Button>
      </Paper>
    </Box>
  );
};

export default RulesPage;
