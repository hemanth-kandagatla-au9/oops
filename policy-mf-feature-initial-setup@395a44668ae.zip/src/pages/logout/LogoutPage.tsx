import React, { useEffect } from "react";
import { Box, Typography } from "@mui/material";
import { useHistory } from "react-router-dom";
import { POLICYOPS_PATH } from "../../utils/constant";

const LogoutPage: React.FC = () => {
  const history = useHistory();

  useEffect(() => {
    // Clear auth cookies on logout
    document.cookie = "isAuthenticated=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    setTimeout(() => history.push(POLICYOPS_PATH.ROOT), 2000);
  }, [history]);

  return (
    <Box display="flex" justifyContent="center" alignItems="center" height="100vh" flexDirection="column">
      <Typography variant="h5">You have been logged out.</Typography>
      <Typography variant="body2" mt={1} color="text.secondary">
        Redirecting to login...
      </Typography>
    </Box>
  );
};

export default LogoutPage;
