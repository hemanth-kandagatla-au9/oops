import React from "react";
import { Box, Button, Paper, Typography } from "@mui/material";
import { Upload } from "lucide-react";

const ArtifactsPage: React.FC = () => {
  return (
    <Box p={3}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h5" fontWeight="bold">
            Artifacts
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Manage configuration artifacts and templates
          </Typography>
        </Box>
        <Button variant="contained" startIcon={<Upload size={16} />}>
          Upload Artifact
        </Button>
      </Box>

      <Paper elevation={2} sx={{ p: 4, textAlign: "center", borderRadius: 2 }}>
        <Typography variant="h6" color="text.secondary" gutterBottom>
          No artifacts yet
        </Typography>
        <Typography variant="body2" color="text.secondary" mb={3}>
          Upload configuration scripts, templates, and files used by policies.
        </Typography>
        <Button variant="outlined" startIcon={<Upload size={16} />}>
          Upload First Artifact
        </Button>
      </Paper>
    </Box>
  );
};

export default ArtifactsPage;
