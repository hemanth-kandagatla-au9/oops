import React from "react";
import { Box, Button, Paper, Typography } from "@mui/material";
import { Plus } from "lucide-react";

const AssignmentsPage: React.FC = () => {
  return (
    <Box p={3}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h5" fontWeight="bold">
            Assignments
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Assign policies to targets
          </Typography>
        </Box>
        <Button variant="contained" startIcon={<Plus size={16} />}>
          Create Assignment
        </Button>
      </Box>

      <Paper elevation={2} sx={{ p: 4, textAlign: "center", borderRadius: 2 }}>
        <Typography variant="h6" color="text.secondary" gutterBottom>
          No assignments yet
        </Typography>
        <Typography variant="body2" color="text.secondary" mb={3}>
          Assign policies to servers, groups or environments to enforce compliance.
        </Typography>
        <Button variant="outlined" startIcon={<Plus size={16} />}>
          Create First Assignment
        </Button>
      </Paper>
    </Box>
  );
};

export default AssignmentsPage;
