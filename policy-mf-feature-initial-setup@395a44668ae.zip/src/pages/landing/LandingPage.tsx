import React from "react";
import Cookies from "universal-cookie";
import LoginPage from "../login/LoginPage";
import { useLocation } from "react-router-dom";
import "../../styles/pages/landing/Landingpage.scss";
import Sidebar from "../../components/landing/Sidebar";
import Header from "../../components/landing/Header";

interface LandingPageLayoutProps {
  children: React.ReactNode;
}

const cookies = new Cookies();

export const LandingPageLayout: React.FC<LandingPageLayoutProps> = ({ children }) => {
  const isAuthenticated = cookies.get("isAuthenticated");
  const location = useLocation();

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return (
    <div className="landing-page">
      <Sidebar />
      <div className="main-content">
        <Header />
        <div className="page-content">{children}</div>
      </div>
    </div>
  );
};

export default LandingPageLayout;
