import React from "react";
import { Box, Button, Paper, Typography } from "@mui/material";
import { Plus } from "lucide-react";

const PoliciesPage: React.FC = () => {
  return (
    <Box p={3}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h5" fontWeight="bold">
            Policies
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Create and manage configuration policies
          </Typography>
        </Box>
        <Button variant="contained" startIcon={<Plus size={16} />}>
          Create Policy
        </Button>
      </Box>

      <Paper elevation={2} sx={{ p: 4, textAlign: "center", borderRadius: 2 }}>
        <Typography variant="h6" color="text.secondary" gutterBottom>
          No policies yet
        </Typography>
        <Typography variant="body2" color="text.secondary" mb={3}>
          Create your first policy to enforce configuration standards.
        </Typography>
        <Button variant="outlined" startIcon={<Plus size={16} />}>
          Create First Policy
        </Button>
      </Paper>
    </Box>
  );
};

export default PoliciesPage;
