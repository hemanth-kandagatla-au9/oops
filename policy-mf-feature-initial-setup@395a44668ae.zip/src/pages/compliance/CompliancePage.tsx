import React from "react";
import { Box, Chip, Grid, Paper, Typography } from "@mui/material";
import { useGetComplianceSummaryQuery } from "../../redux/slices/complianceSlice";

const CompliancePage: React.FC = () => {
  const { data: summary } = useGetComplianceSummaryQuery();

  return (
    <Box p={3}>
      <Box mb={3}>
        <Typography variant="h5" fontWeight="bold">
          Compliance
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Monitor policy compliance status across your infrastructure
        </Typography>
      </Box>

      <Grid container spacing={3} mb={4}>
        <Grid item xs={12} sm={4}>
          <Paper elevation={2} sx={{ p: 3, textAlign: "center", borderRadius: 2, borderTop: "4px solid #10b981" }}>
            <Typography variant="h4" fontWeight="bold" color="#10b981">
              {summary?.compliant ?? 0}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Compliant
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Paper elevation={2} sx={{ p: 3, textAlign: "center", borderRadius: 2, borderTop: "4px solid #ef4444" }}>
            <Typography variant="h4" fontWeight="bold" color="#ef4444">
              {summary?.non_compliant ?? 0}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Non-Compliant
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Paper elevation={2} sx={{ p: 3, textAlign: "center", borderRadius: 2, borderTop: "4px solid #f59e0b" }}>
            <Typography variant="h4" fontWeight="bold" color="#f59e0b">
              {summary?.pending ?? 0}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Pending
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      <Paper elevation={2} sx={{ p: 4, textAlign: "center", borderRadius: 2 }}>
        <Typography variant="h6" color="text.secondary">
          No compliance records found
        </Typography>
        <Typography variant="body2" color="text.secondary" mt={1}>
          Compliance records are generated after policies are assigned and evaluated.
        </Typography>
      </Paper>
    </Box>
  );
};

export default CompliancePage;
