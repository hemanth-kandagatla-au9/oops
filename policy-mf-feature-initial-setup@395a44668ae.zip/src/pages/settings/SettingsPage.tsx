import React from "react";
import { Box, Divider, List, ListItem, ListItemText, Paper, Typography } from "@mui/material";

const SettingsPage: React.FC = () => {
  return (
    <Box p={3}>
      <Box mb={3}>
        <Typography variant="h5" fontWeight="bold">
          Settings
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Configure PolicyOps module settings and preferences
        </Typography>
      </Box>

      <Paper elevation={2} sx={{ borderRadius: 2 }}>
        <List>
          <ListItem divider>
            <ListItemText
              primary="General Settings"
              secondary="Configure general PolicyOps preferences"
            />
          </ListItem>
          <ListItem divider>
            <ListItemText
              primary="Notification Settings"
              secondary="Manage compliance alert notifications"
            />
          </ListItem>
          <ListItem>
            <ListItemText
              primary="Access Control"
              secondary="Manage roles and permissions"
            />
          </ListItem>
        </List>
      </Paper>
    </Box>
  );
};

export default SettingsPage;
