import React from "react";
import { Box, Typography, Button } from "@mui/material";

const LoginPage: React.FC = () => {
  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      height="100vh"
      sx={{ background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)" }}
    >
      <Typography variant="h3" color="white" fontWeight="bold" mb={2}>
        IASphere PolicyOps
      </Typography>
      <Typography variant="subtitle1" color="rgba(255,255,255,0.8)" mb={4}>
        Configuration Management Platform
      </Typography>
      <Button
        variant="contained"
        size="large"
        sx={{ bgcolor: "white", color: "#667eea", "&:hover": { bgcolor: "rgba(255,255,255,0.9)" } }}
        onClick={() => {
          // MSAL login redirect handled by bootstrap
        }}
      >
        Sign in with Microsoft
      </Button>
    </Box>
  );
};

export default LoginPage;
