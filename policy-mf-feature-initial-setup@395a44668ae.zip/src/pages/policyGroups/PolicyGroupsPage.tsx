import React from "react";
import { Box, Button, Paper, Typography } from "@mui/material";
import { Plus } from "lucide-react";

const PolicyGroupsPage: React.FC = () => {
  return (
    <Box p={3}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h5" fontWeight="bold">
            Policy Groups
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Organize policies into logical groups
          </Typography>
        </Box>
        <Button variant="contained" startIcon={<Plus size={16} />}>
          Create Group
        </Button>
      </Box>

      <Paper elevation={2} sx={{ p: 4, textAlign: "center", borderRadius: 2 }}>
        <Typography variant="h6" color="text.secondary" gutterBottom>
          No policy groups yet
        </Typography>
        <Typography variant="body2" color="text.secondary" mb={3}>
          Group related policies together for easier management.
        </Typography>
        <Button variant="outlined" startIcon={<Plus size={16} />}>
          Create First Group
        </Button>
      </Paper>
    </Box>
  );
};

export default PolicyGroupsPage;
