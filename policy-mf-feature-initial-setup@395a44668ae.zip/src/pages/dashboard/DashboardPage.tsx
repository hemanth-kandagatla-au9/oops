import React from "react";
import { Box, Grid, Paper, Typography, Chip } from "@mui/material";
import { Shield, FileText, Users, Package, CheckCircle, Activity } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, color }) => (
  <Paper elevation={2} sx={{ p: 3, borderRadius: 2, borderLeft: `4px solid ${color}` }}>
    <Box display="flex" justifyContent="space-between" alignItems="center">
      <Box>
        <Typography variant="body2" color="text.secondary">
          {title}
        </Typography>
        <Typography variant="h4" fontWeight="bold" mt={0.5}>
          {value}
        </Typography>
      </Box>
      <Box sx={{ color, fontSize: 40 }}>{icon}</Box>
    </Box>
  </Paper>
);

const DashboardPage: React.FC = () => {
  return (
    <Box p={3}>
      <Box mb={3}>
        <Typography variant="h5" fontWeight="bold">
          PolicyOps Dashboard
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Configuration Management Platform Overview
        </Typography>
      </Box>

      <Grid container spacing={3} mb={4}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard title="Total Rules" value="—" icon={<Shield size={32} />} color="#6366f1" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard title="Active Policies" value="—" icon={<FileText size={32} />} color="#0ea5e9" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard title="Assignments" value="—" icon={<Users size={32} />} color="#f59e0b" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard title="Compliance Score" value="—" icon={<CheckCircle size={32} />} color="#10b981" />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper elevation={2} sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" fontWeight="bold" mb={2}>
              Recent Activity
            </Typography>
            <Typography variant="body2" color="text.secondary">
              No recent activity. Start by creating rules and policies.
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper elevation={2} sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" fontWeight="bold" mb={2}>
              Compliance Status
            </Typography>
            <Box display="flex" gap={1} flexWrap="wrap">
              <Chip label="Compliant: 0" color="success" size="small" />
              <Chip label="Non-Compliant: 0" color="error" size="small" />
              <Chip label="Pending: 0" color="warning" size="small" />
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default DashboardPage;
