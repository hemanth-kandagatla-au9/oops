import React from "react";
import { AppBar, Avatar, Box, IconButton, Menu, MenuItem, Toolbar, Typography } from "@mui/material";
import { LogOut, User } from "lucide-react";
import { useState } from "react";
import { useHistory } from "react-router-dom";
import { POLICYOPS_PATH } from "../../utils/constant";

const Header: React.FC = () => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const history = useHistory();

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    handleMenuClose();
    history.push(POLICYOPS_PATH.LOGOUT);
  };

  return (
    <AppBar
      position="static"
      elevation={1}
      sx={{ bgcolor: "white", color: "text.primary", borderBottom: "1px solid rgba(0,0,0,0.08)" }}
    >
      <Toolbar>
        <Box flexGrow={1} />
        <IconButton onClick={handleMenuOpen} size="small">
          <Avatar sx={{ width: 32, height: 32, bgcolor: "#6366f1", fontSize: 14 }}>
            <User size={16} />
          </Avatar>
        </IconButton>
        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleMenuClose}
          transformOrigin={{ horizontal: "right", vertical: "top" }}
          anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
        >
          <MenuItem onClick={handleLogout}>
            <LogOut size={16} style={{ marginRight: 8 }} />
            Logout
          </MenuItem>
        </Menu>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
