import React from "react";
import { Box, Drawer, List, ListItemButton, ListItemIcon, ListItemText, Typography } from "@mui/material";
import {
  LayoutDashboard,
  Shield,
  FileText,
  Layers,
  Users,
  Package,
  CheckCircle,
  ClipboardList,
  Settings,
} from "lucide-react";
import { useHistory, useLocation } from "react-router-dom";
import { POLICYOPS_PATH } from "../../utils/constant";
import { useSelector } from "react-redux";
import { hasModuleAccess, MODULE_LIST } from "../../utils/permissionsUtil";
import { RootState } from "../../redux/store";

const DRAWER_WIDTH = 240;

interface NavItem {
  label: string;
  icon: React.ReactNode;
  path: string;
  module: string;
}

const navItems: NavItem[] = [
  { label: "Dashboard", icon: <LayoutDashboard size={20} />, path: POLICYOPS_PATH.DASHBOARD, module: MODULE_LIST.DASHBOARD },
  { label: "Rules", icon: <Shield size={20} />, path: POLICYOPS_PATH.RULES, module: MODULE_LIST.RULES },
  { label: "Policies", icon: <FileText size={20} />, path: POLICYOPS_PATH.POLICIES, module: MODULE_LIST.POLICIES },
  { label: "Policy Groups", icon: <Layers size={20} />, path: POLICYOPS_PATH.POLICY_GROUPS, module: MODULE_LIST.POLICY_GROUPS },
  { label: "Assignments", icon: <Users size={20} />, path: POLICYOPS_PATH.ASSIGNMENTS, module: MODULE_LIST.ASSIGNMENTS },
  { label: "Artifacts", icon: <Package size={20} />, path: POLICYOPS_PATH.ARTIFACTS, module: MODULE_LIST.ARTIFACTS },
  { label: "Compliance", icon: <CheckCircle size={20} />, path: POLICYOPS_PATH.COMPLIANCE, module: MODULE_LIST.COMPLIANCE },
  { label: "Audit", icon: <ClipboardList size={20} />, path: POLICYOPS_PATH.AUDIT, module: MODULE_LIST.AUDIT },
  { label: "Settings", icon: <Settings size={20} />, path: POLICYOPS_PATH.SETTINGS, module: MODULE_LIST.SETTINGS },
];

const Sidebar: React.FC = () => {
  const history = useHistory();
  const location = useLocation();
  const permissions = useSelector((state: RootState) => state.permissions.permissions);

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: DRAWER_WIDTH,
        flexShrink: 0,
        "& .MuiDrawer-paper": {
          width: DRAWER_WIDTH,
          boxSizing: "border-box",
          background: "#1e293b",
          color: "white",
        },
      }}
    >
      <Box sx={{ p: 2, borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
        <Typography variant="h6" fontWeight="bold" color="white">
          PolicyOps
        </Typography>
        <Typography variant="caption" color="rgba(255,255,255,0.6)">
          Configuration Management
        </Typography>
      </Box>

      <List sx={{ mt: 1, px: 1 }}>
        {navItems.map((item) => {
          const hasPermission = hasModuleAccess(permissions, item.module);
          if (!hasPermission) return null;

          const isActive = location.pathname.startsWith(item.path);
          return (
            <ListItemButton
              key={item.path}
              selected={isActive}
              onClick={() => history.push(item.path)}
              sx={{
                borderRadius: 1,
                mb: 0.5,
                "&.Mui-selected": { bgcolor: "rgba(99,102,241,0.3)" },
                "&:hover": { bgcolor: "rgba(255,255,255,0.08)" },
                color: "rgba(255,255,255,0.85)",
              }}
            >
              <ListItemIcon sx={{ minWidth: 36, color: isActive ? "#6366f1" : "rgba(255,255,255,0.6)" }}>
                {item.icon}
              </ListItemIcon>
              <ListItemText
                primary={item.label}
                primaryTypographyProps={{ variant: "body2", fontWeight: isActive ? 600 : 400 }}
              />
            </ListItemButton>
          );
        })}
      </List>
    </Drawer>
  );
};

export default Sidebar;
