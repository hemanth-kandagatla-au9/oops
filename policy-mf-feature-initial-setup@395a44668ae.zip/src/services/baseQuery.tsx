import { fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { getAccessToken } from "../utils/tokenService";

export const prepareHeaders = async (headers: Headers) => {
  const accessToken = await getAccessToken();
  if (accessToken) {
    headers.set("Authorization", `Bearer ${accessToken}`);
  }
  return headers;
};

export const baseQuery = fetchBaseQuery({
  baseUrl: process.env.POLICYOPS_API,
  prepareHeaders,
});
