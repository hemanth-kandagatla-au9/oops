const { merge } = require("webpack-merge");
const webpack = require("webpack");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const commonConfig = require("./webpack.config.cjs");
const deps = require("./package.json").dependencies;

const localConfig = merge(commonConfig, {
  mode: "development",
  output: {
    publicPath: "http://localhost:3003/",
  },
  devtool: "eval-source-map",
  stats: {
    warningsFilter: [/No version specified and unable to automatically determine one/],
  },
  plugins: [
    new ModuleFederationPlugin({
      name: "policyops",
      filename: "remoteEntry.js",
      exposes: {
        "./policyopsModule": "./src/App.tsx",
        "./Dashboard": "./src/federation/Dashboard.tsx",
        "./Rules": "./src/federation/Rules.tsx",
        "./Policies": "./src/federation/Policies.tsx",
        "./PolicyGroups": "./src/federation/PolicyGroups.tsx",
        "./Assignments": "./src/federation/Assignments.tsx",
        "./Artifacts": "./src/federation/Artifacts.tsx",
        "./Compliance": "./src/federation/Compliance.tsx",
        "./Audit": "./src/federation/Audit.tsx",
        "./Settings": "./src/federation/Settings.tsx",
      },
      shared: {
        react: { singleton: true, requiredVersion: deps.react },
        "react/jsx-runtime": { singleton: true, requiredVersion: deps.react },
        "react/jsx-dev-runtime": { singleton: true, requiredVersion: deps.react },
        "react-redux": { singleton: true, requiredVersion: deps["react-redux"] },
        "react-router-dom": { singleton: true, requiredVersion: deps["react-router-dom"] },
        "@mui/x-data-grid": { singleton: true, requiredVersion: deps["@mui/x-data-grid"] },
        "@reduxjs/toolkit": { singleton: true, requiredVersion: deps["@reduxjs/toolkit"] },
      },
    }),
    new webpack.DefinePlugin({
      "window.__POWERED_BY_HOST__": JSON.stringify(true),
      "process.env": JSON.stringify({
        APP_ENV: "local",
        GENERATE_SOURCEMAP: false,
        SKIP_PREFLIGHT_CHECK: true,
        FAST_REFRESH: true,
        AUTH_URL: "https://predev.policyops-auth.ias.apps.jnj.com/",
        POLICYOPS_API: "http://localhost:8001/app-policyops",
        REACT_APP_REDIRECTURI_PLATFORM: "http://localhost:3006/",
        REACT_APP_CLIENTID: "407b5b20-2700-4aa2-86a0-d1abfea64386",
        REACT_APP_AUTHORITY_URL:
          "https://login.microsoftonline.com/3ac94b33-9135-4821-9502-eafda6592a35/",
        REACT_APP_REDIRECTURI: "http://localhost:3003/",
        REACT_APP_POSTLOGOUTREDIRECTURI: "http://localhost:3003/logout",
        REACT_APP_SECRETKEY: process.env.REACT_APP_SECRETKEY || "",
        TEST_API_PASSWORD: "testpass",
      }),
    }),
  ],
});

module.exports = localConfig;
