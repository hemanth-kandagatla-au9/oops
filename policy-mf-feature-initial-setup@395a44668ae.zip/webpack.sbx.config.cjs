const { merge } = require("webpack-merge");
const webpack = require("webpack");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const commonConfig = require("./webpack.config.cjs");
const deps = require("./package.json").dependencies;

const sbxConfig = merge(commonConfig, {
  mode: "production",
  output: {
    publicPath: "https://sbx.policyops.ias.apps.jnj.com/",
  },
  plugins: [
    new ModuleFederationPlugin({
      name: "policyops",
      filename: "remoteEntry.js",
      exposes: {
        "./policyopsModule": "./src/App.tsx",
        "./Dashboard": "./src/federation/Dashboard.tsx",
        "./Rules": "./src/federation/Rules.tsx",
        "./Policies": "./src/federation/Policies.tsx",
        "./PolicyGroups": "./src/federation/PolicyGroups.tsx",
        "./Assignments": "./src/federation/Assignments.tsx",
        "./Artifacts": "./src/federation/Artifacts.tsx",
        "./Compliance": "./src/federation/Compliance.tsx",
        "./Audit": "./src/federation/Audit.tsx",
        "./Settings": "./src/federation/Settings.tsx",
      },
      shared: {
        ...deps,
        react: { singleton: true, requiredVersion: deps.react },
        "react-dom": { singleton: true, requiredVersion: deps["react-dom"] },
        "react-router-dom": { singleton: true, requiredVersion: deps["react-router-dom"] },
        "@reduxjs/toolkit": { singleton: true, requiredVersion: deps["@reduxjs/toolkit"] },
      },
    }),
    new webpack.DefinePlugin({
      "process.env": JSON.stringify({
        APP_ENV: "sbx",
        POLICYOPS_API: "https://sbx.policyops.ias.apps.jnj.com/api/policyops",
        REACT_APP_REDIRECTURI: "https://sbx.policyops.ias.apps.jnj.com/",
        REACT_APP_CLIENTID: "407b5b20-2700-4aa2-86a0-d1abfea64386",
        REACT_APP_AUTHORITY_URL:
          "https://login.microsoftonline.com/3ac94b33-9135-4821-9502-eafda6592a35/",
        REACT_APP_POSTLOGOUTREDIRECTURI: "https://sbx.policyops.ias.apps.jnj.com/logout",
        REACT_APP_SECRETKEY: process.env.REACT_APP_SECRETKEY || "",
      }),
    }),
  ],
});

module.exports = sbxConfig;
