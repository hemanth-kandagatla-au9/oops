import React, { useState } from 'react'
import {
  Box, Button, Drawer, Dialog, DialogTitle, DialogContent, DialogActions,
  Typography, Divider, IconButton, Select, MenuItem, TextField,
  Table, TableHead, TableBody, TableRow, TableCell, Tabs, Tab,
  Checkbox, FormControlLabel, FormControl, InputLabel, OutlinedInput,
  InputAdornment,
} from '@mui/material'
import {
  LineChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis, Legend,
  PieChart, Pie, Cell,
} from 'recharts'
import {
  PlusCircle, FileText, Filter, Search, ChevronLeft, ChevronRight,
  X, Check, CheckCircle2, Info, Calendar, AlertTriangle, ShieldAlert,
  HardDrive, Activity, Layers, SlidersHorizontal, Clock, Shield,
} from 'lucide-react'
import { toast } from 'react-toastify'

// ─── Types ────────────────────────────────────────────────────────────────────
interface ExceptionRow {
  id: string; name: string; scope: string; category: string
  target: string; risk: string; status: string; expiry: string; owner: string
}

// ─── Static data ──────────────────────────────────────────────────────────────
const INITIAL_DATA: ExceptionRow[] = [
  { id: 'EX-8842', name: 'Legacy SAP HANA OS Waiver', scope: 'Dynamic Filter', category: 'Legacy Application', target: 'Environment=PROD, App=SAP', risk: 'High', status: 'Active', expiry: '2026-09-01', owner: 'Rkuma374' },
  { id: 'EX-8843', name: 'Weekend DB Patching Window', scope: 'Server Group', category: 'Maintenance Activity', target: 'GRP-PROD-DB-01', risk: 'Low', status: 'Pending Approval', expiry: '2026-06-20', owner: 'Vkuma214' },
  { id: 'EX-8844', name: 'Temporarily Ignore CIS Rule 4.1.2', scope: 'Rule', category: 'Application Compatibility', target: 'CIS RHEL 8 - Rule 4.1.2', risk: 'Medium', status: 'Active', expiry: '2026-12-31', owner: 'Raugus10' },
  { id: 'EX-8845', name: 'Middleware Tomcat Rollback', scope: 'Workflow', category: 'Emergency Change', target: 'Deployment_Pipeline_Mid', risk: 'Critical', status: 'Expired', expiry: '2026-06-15', owner: 'Rkuma374' },
  { id: 'EX-8846', name: 'Global Password Policy Extension', scope: 'Policy', category: 'Temporary Business Req', target: 'Corp-IAM-Policy-v2', risk: 'High', status: 'Active', expiry: '2026-07-01', owner: 'Raugus10' },
]

const TREND_DATA = [
  { month: 'Jan', Active: 110, Created: 40, Expired: 24 },
  { month: 'Feb', Active: 127, Created: 30, Expired: 13 },
  { month: 'Mar', Active: 134, Created: 45, Expired: 38 },
  { month: 'Apr', Active: 141, Created: 50, Expired: 43 },
  { month: 'May', Active: 156, Created: 35, Expired: 20 },
  { month: 'Jun', Active: 142, Created: 25, Expired: 39 },
]

const CATEGORY_DATA = [
  { name: 'Legacy App', value: 35, color: '#3b82f6' },
  { name: 'Maintenance', value: 25, color: '#10b981' },
  { name: 'App Compat', value: 20, color: '#f59e0b' },
  { name: 'Security Risk', value: 15, color: '#ef4444' },
  { name: 'Other', value: 5, color: '#64748b' },
]

// ─── Helpers ──────────────────────────────────────────────────────────────────
function statusStyle(s: string) {
  if (s === 'Active') return { color: '#15803d', bgcolor: '#f0fdf4', border: '1px solid #bbf7d0' }
  if (s === 'Pending Approval') return { color: '#1d4ed8', bgcolor: '#eff6ff', border: '1px solid #bfdbfe' }
  return { color: '#64748b', bgcolor: '#f1f5f9', border: '1px solid #e2e8f0' }
}
function statusDot(s: string) {
  if (s === 'Active') return '#22c55e'
  if (s === 'Pending Approval') return '#3b82f6'
  return '#94a3b8'
}
function riskStyle(r: string) {
  if (r === 'Critical') return { color: '#b91c1c', bgcolor: '#fef2f2', border: '1px solid #fecaca' }
  if (r === 'High') return { color: '#c2410c', bgcolor: '#fff7ed', border: '1px solid #fed7aa' }
  if (r === 'Medium') return { color: '#a16207', bgcolor: '#fefce8', border: '1px solid #fef08a' }
  return { color: '#15803d', bgcolor: '#f0fdf4', border: '1px solid #bbf7d0' }
}

// ─── KPI Card ─────────────────────────────────────────────────────────────────
function KpiCard({ label, value, delta, deltaColor, onClick }: {
  label: string; value: string; delta: string; deltaColor: string; onClick?: () => void
}) {
  return (
    <Box onClick={onClick} sx={{
      bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '8px', p: 2,
      boxShadow: '0 1px 3px rgba(0,0,0,0.05)', cursor: onClick ? 'pointer' : 'default',
      '&:hover': onClick ? { borderColor: '#93c5fd' } : {},
      transition: 'border-color 0.15s',
    }}>
      <Typography sx={{ fontSize: '0.68rem', fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.06em', mb: 1 }}>
        {label}
      </Typography>
      <Box display="flex" alignItems="flex-end" justifyContent="space-between">
        <Typography sx={{ fontSize: '1.5rem', fontWeight: 700, color: value === 'High' ? '#dc2626' : '#111827', lineHeight: 1 }}>
          {value}
        </Typography>
        <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: deltaColor }}>{delta}</Typography>
      </Box>
    </Box>
  )
}

// ─── Scope cards for Wizard step 1 ───────────────────────────────────────────
const SCOPE_OPTIONS = [
  { icon: <ShieldAlert size={18} />, label: 'Policy Level', desc: 'Exempt targets from an entire policy.' },
  { icon: <SlidersHorizontal size={18} />, label: 'Rule Level', desc: 'Exempt targets from a specific rule.' },
  { icon: <Filter size={18} />, label: 'Dynamic Filter', desc: 'Target based on tags, env, or custom facts.' },
  { icon: <HardDrive size={18} />, label: 'Server / Group', desc: 'Target specific static infrastructure.' },
  { icon: <AlertTriangle size={18} />, label: 'Compliance Finding', desc: 'Directly waive an existing failed check.' },
  { icon: <Activity size={18} />, label: 'Operational Workflow', desc: 'Skip standard automation workflows.' },
]

const WIZARD_STEPS = ['Scope Definition', 'Target Selection', 'Exception Details', 'Validity Window', 'Governance', 'Review & Submit']

// ─── Main component ───────────────────────────────────────────────────────────
const ExceptionHubPage: React.FC = () => {
  const [tableData, setTableData] = useState<ExceptionRow[]>(INITIAL_DATA)
  const [statusFilter, setStatusFilter] = useState('All')
  const [search, setSearch] = useState('')

  // Drawer
  const [drawerRow, setDrawerRow] = useState<ExceptionRow | null>(null)
  const [drawerTab, setDrawerTab] = useState(0)

  // Wizard
  const [wizardOpen, setWizardOpen] = useState(false)
  const [wizardStep, setWizardStep] = useState(1)
  const [wizardName, setWizardName] = useState('')
  const [wizardScope, setWizardScope] = useState('Dynamic Filter')

  const filteredRows = tableData.filter(r => {
    const matchStatus = statusFilter === 'All' || r.status === statusFilter
    const matchSearch = search === '' || r.name.toLowerCase().includes(search.toLowerCase()) || r.id.toLowerCase().includes(search.toLowerCase())
    return matchStatus && matchSearch
  })

  const openWizard = () => { setWizardStep(1); setWizardName(''); setWizardOpen(true) }
  const closeWizard = () => setWizardOpen(false)

  const submitException = () => {
    closeWizard()
    toast.success('Exception Request Submitted Successfully!')
    const newRow: ExceptionRow = {
      id: `EX-${Math.floor(8847 + Math.random() * 100)}`,
      name: wizardName || 'Dynamic Filter Exemption',
      scope: 'Dynamic Filter', category: 'Legacy Application',
      target: 'Environment=PROD, App=SAP', status: 'Pending Approval',
      owner: 'Rkuma374', expiry: '2026-09-17', risk: 'High',
    }
    setTableData(prev => [newRow, ...prev])
  }

  const nextStep = () => {
    if (wizardStep === 3 && !wizardName.trim()) {
      toast.info('Please provide an Exception Name.')
      return
    }
    if (wizardStep < 6) setWizardStep(s => s + 1)
  }

  const FIELD_SX = {
    '& .MuiOutlinedInput-root': { borderRadius: '6px', fontSize: '0.875rem', bgcolor: 'white' },
    '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e8f0' },
  }

  return (
    <Box sx={{ height: '100%', overflowY: 'auto', bgcolor: '#f8fafc', fontFamily: 'Inter, sans-serif' }}>
      <Box sx={{ maxWidth: 1600, mx: 'auto', p: 3, display: 'flex', flexDirection: 'column', gap: 3 }}>

        {/* ── Page Header ── */}
        <Box display="flex" justifyContent="space-between" alignItems="flex-end" flexWrap="wrap" gap={2}>
          <Box>
            <Typography sx={{ fontSize: '1.375rem', fontWeight: 700, color: '#111827' }}>Exception Hub</Typography>
            <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280', mt: 0.25 }}>
              Manage global policy, rule, and operational exceptions.
            </Typography>
          </Box>
          <Box display="flex" gap={1.5}>
            <Button size="small" startIcon={<FileText size={14} />}
              onClick={() => toast.info('Exporting report...')}
              sx={{ textTransform: 'none', fontWeight: 500, fontSize: '0.8125rem', color: '#374151', border: '1px solid #d1d5db', bgcolor: 'white', borderRadius: '6px', px: 2, '&:hover': { bgcolor: '#f9fafb' } }}>
              Export Report
            </Button>
            <Button size="small" startIcon={<PlusCircle size={14} />}
              onClick={openWizard}
              sx={{ textTransform: 'none', fontWeight: 600, fontSize: '0.8125rem', bgcolor: '#2563eb', color: 'white', borderRadius: '6px', px: 2, '&:hover': { bgcolor: '#1d4ed8' } }}>
              Request Exception
            </Button>
          </Box>
        </Box>

        {/* ── KPI Grid ── */}
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 2 }}>
          <KpiCard label="Active Exceptions" value="142" delta="+12%" deltaColor="#2563eb" onClick={() => setStatusFilter('Active')} />
          <KpiCard label="Pending Approval" value="18" delta="-2" deltaColor="#16a34a" onClick={() => setStatusFilter('Pending Approval')} />
          <KpiCard label="Expiring Soon (7d)" value="24" delta="+5" deltaColor="#dc2626" onClick={() => setStatusFilter('All')} />
          <KpiCard label="Total Exceptions" value="1,284" delta="+150" deltaColor="#2563eb" onClick={() => setStatusFilter('All')} />
          <KpiCard label="Servers Impacted" value="4,592" delta="+8%" deltaColor="#2563eb" />
          <KpiCard label="Risk Exposure" value="High" delta="Critical" deltaColor="#dc2626" />
        </Box>

        {/* ── Charts Row ── */}
        <Box sx={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 3 }}>
          {/* Trend */}
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
            <Box sx={{ px: 2.5, py: 2, borderBottom: '1px solid #f1f5f9', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#1e293b' }}>Exception Trend Analysis</Typography>
              <Select size="small" defaultValue="6m"
                sx={{ fontSize: '0.75rem', bgcolor: '#f8fafc', '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e8f0' }, borderRadius: '6px', height: 28 }}>
                <MenuItem value="6m" sx={{ fontSize: '0.75rem' }}>Last 6 Months</MenuItem>
                <MenuItem value="30d" sx={{ fontSize: '0.75rem' }}>Last 30 Days</MenuItem>
              </Select>
            </Box>
            <Box sx={{ p: 2.5, height: 280 }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={TREND_DATA} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: '#1e293b', border: 'none', borderRadius: 4, color: 'white', fontSize: 12 }} />
                  <Legend iconSize={10} wrapperStyle={{ fontSize: 11 }} />
                  <Line type="monotone" dataKey="Active" stroke="#2563eb" strokeWidth={2.5} dot={{ r: 3, fill: '#fff', strokeWidth: 2 }} />
                  <Line type="monotone" dataKey="Created" stroke="#10b981" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="Expired" stroke="#cbd5e1" strokeWidth={2} dot={false} strokeDasharray="4 2" />
                </LineChart>
              </ResponsiveContainer>
            </Box>
          </Box>

          {/* Donut */}
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
            <Box sx={{ px: 2.5, py: 2, borderBottom: '1px solid #f1f5f9' }}>
              <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#1e293b' }}>Exceptions by Category</Typography>
            </Box>
            <Box sx={{ p: 2, height: 280, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={CATEGORY_DATA} cx="45%" cy="50%" innerRadius={60} outerRadius={90} dataKey="value" paddingAngle={2}>
                    {CATEGORY_DATA.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Legend iconSize={10} wrapperStyle={{ fontSize: 11 }} layout="vertical" align="right" verticalAlign="middle" />
                  <Tooltip formatter={(v: number) => [`${v}%`, '']} />
                </PieChart>
              </ResponsiveContainer>
            </Box>
          </Box>
        </Box>

        {/* ── Data Table ── */}
        <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', overflow: 'hidden' }}>
          {/* Filters */}
          <Box sx={{ p: 1.5, borderBottom: '1px solid #e5e7eb', display: 'flex', flexWrap: 'wrap', gap: 1.5, alignItems: 'center', bgcolor: '#f9fafb' }}>
            <Box display="flex" alignItems="center" gap={1} sx={{ border: '1px solid #d1d5db', bgcolor: 'white', borderRadius: '6px', px: 1.5, py: 0.75 }}>
              <Filter size={14} color="#9ca3af" />
              <Select size="small" defaultValue="all-scope" disableUnderline variant="standard"
                sx={{ fontSize: '0.8125rem', color: '#374151', fontWeight: 500, minWidth: 110, '& .MuiSelect-select': { p: 0 } }}
                onChange={() => toast.info('Scope filtered')}>
                <MenuItem value="all-scope">All Scopes</MenuItem>
                <MenuItem value="policy">Policy Level</MenuItem>
                <MenuItem value="rule">Rule Level</MenuItem>
                <MenuItem value="dynamic">Dynamic Filter</MenuItem>
              </Select>
            </Box>
            <Select size="small" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
              sx={{ fontSize: '0.8125rem', bgcolor: 'white', borderRadius: '6px', height: 36, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#d1d5db' }, minWidth: 120 }}>
              {['All', 'Active', 'Pending Approval', 'Expired'].map(s => (
                <MenuItem key={s} value={s} sx={{ fontSize: '0.8125rem' }}>{s === 'All' ? 'All Status' : s}</MenuItem>
              ))}
            </Select>
            <Select size="small" defaultValue="all-risk"
              sx={{ fontSize: '0.8125rem', bgcolor: 'white', borderRadius: '6px', height: 36, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#d1d5db' }, minWidth: 100 }}
              onChange={() => toast.info('Risk filtered')}>
              <MenuItem value="all-risk">All Risk</MenuItem>
              <MenuItem value="critical">Critical</MenuItem>
              <MenuItem value="high">High</MenuItem>
            </Select>
            <Box flex={1} />
            <OutlinedInput size="small" value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Filter this view..." startAdornment={<InputAdornment position="start"><Search size={14} color="#9ca3af" /></InputAdornment>}
              sx={{ fontSize: '0.8125rem', bgcolor: 'white', borderRadius: '6px', width: 240, height: 36, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#d1d5db' } }} />
          </Box>

          {/* Table */}
          <Box sx={{ overflowX: 'auto' }}>
            <Table size="small">
              <TableHead>
                <TableRow sx={{ bgcolor: 'white', borderBottom: '2px solid #f1f5f9' }}>
                  {['Exception Name & ID', 'Scope Target', 'Category', 'Risk Level', 'Status', 'Expiry', ''].map(h => (
                    <TableCell key={h} sx={{ fontSize: '0.7rem', fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.06em', py: 1.5, whiteSpace: 'nowrap' }}>
                      {h}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredRows.map(row => {
                  const ss = statusStyle(row.status)
                  const rs = riskStyle(row.risk)
                  return (
                    <TableRow key={row.id} hover onClick={() => { setDrawerRow(row); setDrawerTab(0) }}
                      sx={{ cursor: 'pointer', '&:hover': { bgcolor: '#eff6ff' }, '& td': { borderBottom: '1px solid #f3f4f6' } }}>
                      <TableCell sx={{ py: 1.75 }}>
                        <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#111827' }}>{row.name}</Typography>
                        <Typography sx={{ fontSize: '0.72rem', color: '#6b7280', fontFamily: 'monospace', mt: 0.25 }}>{row.id} · {row.owner}</Typography>
                      </TableCell>
                      <TableCell sx={{ py: 1.75, maxWidth: 200 }}>
                        <Typography sx={{ fontSize: '0.8125rem', color: '#111827', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{row.target}</Typography>
                        <Typography sx={{ fontSize: '0.72rem', color: '#6b7280', mt: 0.25 }}>{row.scope}</Typography>
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.8125rem', color: '#6b7280', py: 1.75 }}>{row.category}</TableCell>
                      <TableCell sx={{ py: 1.75 }}>
                        <Box sx={{ display: 'inline-block', px: 1.25, py: 0.3, borderRadius: '999px', fontSize: '0.72rem', fontWeight: 600, ...rs }}>{row.risk}</Box>
                      </TableCell>
                      <TableCell sx={{ py: 1.75 }}>
                        <Box display="flex" alignItems="center" gap={0.75} sx={{ display: 'inline-flex', px: 1.25, py: 0.3, borderRadius: '999px', fontSize: '0.72rem', fontWeight: 600, ...ss }}>
                          <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: statusDot(row.status), flexShrink: 0 }} />
                          {row.status}
                        </Box>
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.8125rem', color: '#6b7280', py: 1.75 }}>{row.expiry}</TableCell>
                      <TableCell align="right" sx={{ py: 1.75 }}>
                        <Button size="small" onClick={e => { e.stopPropagation(); setDrawerRow(row); setDrawerTab(0) }}
                          sx={{ textTransform: 'none', fontSize: '0.72rem', fontWeight: 500, color: '#2563eb', px: 1, py: 0.25, borderRadius: '4px', '&:hover': { bgcolor: '#eff6ff' } }}>
                          Review
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </Box>

          {/* Pagination footer */}
          <Box sx={{ px: 2, py: 1.25, borderTop: '1px solid #f1f5f9', bgcolor: 'rgba(249,250,251,0.5)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography sx={{ fontSize: '0.72rem', color: '#6b7280' }}>
              Showing 1 to {filteredRows.length} of {filteredRows.length} entries
            </Typography>
            <Box display="flex" gap={0.5}>
              <IconButton size="small" disabled sx={{ border: '1px solid #e5e7eb', borderRadius: '4px', p: 0.5 }}><ChevronLeft size={14} /></IconButton>
              <IconButton size="small" sx={{ border: '1px solid #e5e7eb', borderRadius: '4px', p: 0.5 }}><ChevronRight size={14} /></IconButton>
            </Box>
          </Box>
        </Box>
      </Box>

      {/* ── Detail Drawer ── */}
      <Drawer anchor="right" open={!!drawerRow} onClose={() => setDrawerRow(null)}
        PaperProps={{ sx: { width: { xs: '100%', sm: 580 }, display: 'flex', flexDirection: 'column' } }}>
        {drawerRow && (() => {
          const ss = statusStyle(drawerRow.status)
          const rs = riskStyle(drawerRow.risk)
          return (
            <>
              <Box sx={{ px: 3, py: 2.5, borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                  <Box display="flex" alignItems="center" gap={1.5} mb={0.75}>
                    <Box sx={{ display: 'inline-block', px: 1.25, py: 0.2, borderRadius: '999px', fontSize: '0.65rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', ...ss }}>
                      {drawerRow.status}
                    </Box>
                    <Typography sx={{ fontSize: '0.8rem', color: '#6b7280', fontFamily: 'monospace' }}>{drawerRow.id}</Typography>
                  </Box>
                  <Typography sx={{ fontSize: '1.125rem', fontWeight: 700, color: '#111827' }}>{drawerRow.name}</Typography>
                </Box>
                <IconButton size="small" onClick={() => setDrawerRow(null)} sx={{ color: '#9ca3af', '&:hover': { color: '#374151', bgcolor: '#f3f4f6' } }}>
                  <X size={18} />
                </IconButton>
              </Box>

              <Tabs value={drawerTab} onChange={(_, v) => setDrawerTab(v)}
                sx={{ px: 3, borderBottom: '1px solid #e2e8f0', minHeight: 40, '& .MuiTab-root': { textTransform: 'none', fontSize: '0.8125rem', fontWeight: 500, minHeight: 40, py: 0 } }}>
                {['Overview', 'Impact Analysis', 'Approvals', 'Audit Trail'].map((t, i) => (
                  <Tab key={t} label={t} value={i} />
                ))}
              </Tabs>

              <Box sx={{ flex: 1, overflowY: 'auto', p: 3, bgcolor: '#f8fafc' }}>
                {/* Overview */}
                {drawerTab === 0 && (
                  <Box display="flex" flexDirection="column" gap={2}>
                    <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
                      {[
                        { label: 'Scope', value: drawerRow.scope, icon: <Layers size={16} color="#3b82f6" /> },
                        { label: 'Target', value: drawerRow.target },
                        { label: 'Risk Level', isRisk: true },
                        { label: 'Valid Until', value: drawerRow.expiry, icon: <Calendar size={14} color="#9ca3af" /> },
                      ].map((item, i) => (
                        <Box key={i} sx={{ bgcolor: 'white', p: 2, borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 1px 2px rgba(0,0,0,0.04)' }}>
                          <Typography sx={{ fontSize: '0.68rem', color: '#6b7280', textTransform: 'uppercase', fontWeight: 600, mb: 0.75 }}>{item.label}</Typography>
                          {item.isRisk ? (
                            <Box sx={{ display: 'inline-block', px: 1.25, py: 0.3, borderRadius: '4px', fontSize: '0.75rem', fontWeight: 600, ...rs }}>{drawerRow.risk}</Box>
                          ) : (
                            <Box display="flex" alignItems="center" gap={0.75}>
                              {item.icon}
                              <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#111827', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.value}</Typography>
                            </Box>
                          )}
                        </Box>
                      ))}
                    </Box>
                    <Box sx={{ bgcolor: 'white', p: 2.5, borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                      <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#111827', mb: 1 }}>Business Justification</Typography>
                      <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280', lineHeight: 1.6, bgcolor: '#f9fafb', p: 1.5, borderRadius: '6px', border: '1px solid #f1f5f9' }}>
                        This exception is required because the legacy application hosted on this server cluster does not support the new authentication module deployed in the standard CIS baseline. Upgrading the application is scheduled for Q4 2026. Temporarily accepting risk to prevent production outage.
                      </Typography>
                    </Box>
                    <Box sx={{ bgcolor: 'white', p: 2.5, borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                      <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#111827', mb: 1.5, pb: 1, borderBottom: '1px solid #f1f5f9' }}>Configuration Details</Typography>
                      {[
                        ['Category', drawerRow.category],
                        ['Auto Expiry Action', 'Revoke & Enforce'],
                        ['Exception Action', 'Ignore Compliance Failure'],
                      ].map(([k, v]) => (
                        <Box key={k} display="flex" justifyContent="space-between" alignItems="center" sx={{ py: 0.75, borderBottom: '1px solid #f9fafb' }}>
                          <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280' }}>{k}</Typography>
                          <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: k === 'Exception Action' ? '#1d4ed8' : '#111827', bgcolor: k === 'Exception Action' ? '#eff6ff' : 'transparent', px: k === 'Exception Action' ? 1 : 0, py: 0.25, borderRadius: '4px', border: k === 'Exception Action' ? '1px solid #bfdbfe' : 'none' }}>
                            {v}
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  </Box>
                )}

                {/* Impact */}
                {drawerTab === 1 && (
                  <Box display="flex" flexDirection="column" gap={2}>
                    <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 2 }}>
                      {[['14', 'Policies Impacted'], ['2,405', 'Servers Covered'], ['8.4%', 'Fleet Exposure']].map(([v, l]) => (
                        <Box key={l} sx={{ bgcolor: 'white', p: 2, borderRadius: '8px', border: '1px solid #e2e8f0', textAlign: 'center' }}>
                          <Typography sx={{ fontSize: '1.5rem', fontWeight: 700, color: l === 'Fleet Exposure' ? '#ea580c' : '#111827' }}>{v}</Typography>
                          <Typography sx={{ fontSize: '0.68rem', color: '#6b7280', textTransform: 'uppercase', fontWeight: 600, mt: 0.5 }}>{l}</Typography>
                        </Box>
                      ))}
                    </Box>
                    <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '8px', overflow: 'hidden' }}>
                      <Box sx={{ px: 2, py: 1.5, bgcolor: '#f9fafb', borderBottom: '1px solid #e2e8f0' }}>
                        <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#111827' }}>Dynamic Filter Resolution Matrix</Typography>
                      </Box>
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell sx={{ fontSize: '0.75rem', fontWeight: 500, color: '#6b7280' }}>Filter Criteria</TableCell>
                            <TableCell align="right" sx={{ fontSize: '0.75rem', fontWeight: 500, color: '#6b7280' }}>Matched Entities</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          <TableRow><TableCell sx={{ fontFamily: 'monospace', fontSize: '0.75rem' }}>Environment == "PROD"</TableCell><TableCell align="right" sx={{ fontSize: '0.8125rem' }}>8,402</TableCell></TableRow>
                          <TableRow><TableCell sx={{ fontFamily: 'monospace', fontSize: '0.75rem', color: '#2563eb' }}>AND Application == "SAP"</TableCell><TableCell align="right" sx={{ fontSize: '0.8125rem', fontWeight: 700 }}>2,405</TableCell></TableRow>
                        </TableBody>
                      </Table>
                    </Box>
                  </Box>
                )}

                {/* Approvals */}
                {drawerTab === 2 && (
                  <Box display="flex" flexDirection="column" gap={2}>
                    {[
                      { title: 'Direct Manager Approval', icon: <CheckCircle2 size={16} color="#22c55e" />, color: '#22c55e', bgcolor: '#f0fdf4', border: '1px solid #bbf7d0', time: 'Mar 12, 2026 14:30', detail: 'Approver: M. Scott (mscott44)', note: '"Approved as temporary measure. Ensure Q4 upgrade is prioritized."', status: 'approved' },
                      { title: 'InfoSec Architecture Review', icon: <Clock size={16} color="#eab308" />, color: '#eab308', bgcolor: '#fefce8', border: '1px solid #fef08a', time: null, detail: 'Queue: Global-Security-Arch-Team', note: null, status: 'pending' },
                    ].map(item => (
                      <Box key={item.title} sx={{ bgcolor: 'white', p: 2.5, borderRadius: '8px', border: item.border, position: 'relative', overflow: 'hidden' }}>
                        <Box sx={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 4, bgcolor: item.color }} />
                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                          <Box display="flex" alignItems="center" gap={1}>
                            {item.icon}
                            <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#111827' }}>{item.title}</Typography>
                          </Box>
                          {item.time
                            ? <Typography sx={{ fontSize: '0.72rem', color: '#6b7280' }}>{item.time}</Typography>
                            : <Box sx={{ px: 1.25, py: 0.25, bgcolor: '#fefce8', color: '#a16207', border: '1px solid #fef08a', borderRadius: '4px', fontSize: '0.65rem', fontWeight: 700 }}>PENDING</Box>}
                        </Box>
                        <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280' }}>{item.detail}</Typography>
                        {item.note && <Typography sx={{ fontSize: '0.72rem', color: '#6b7280', fontStyle: 'italic', mt: 0.75, bgcolor: '#f9fafb', p: 1.25, borderRadius: '4px', border: '1px solid #f1f5f9' }}>{item.note}</Typography>}
                      </Box>
                    ))}
                  </Box>
                )}

                {/* Audit Trail */}
                {drawerTab === 3 && (
                  <Box sx={{ pl: 2.5, borderLeft: '2px solid #e2e8f0', ml: 1 }}>
                    {[
                      { dot: '#d1d5db', time: 'Mar 12, 2026 14:30', title: 'Approval Registered', desc: 'M. Scott (mscott44) approved the request.' },
                      { dot: '#3b82f6', time: 'Mar 12, 2026 10:15', title: 'Exception Request Submitted', desc: 'Created by Rkuma374 and submitted for review.' },
                    ].map((item, i) => (
                      <Box key={i} sx={{ mb: 3, position: 'relative' }}>
                        <Box sx={{ position: 'absolute', width: 12, height: 12, bgcolor: item.dot, borderRadius: '50%', left: -20, top: 4, border: '2px solid white', boxShadow: item.dot !== '#d1d5db' ? '0 0 0 2px rgba(59,130,246,0.2)' : 'none' }} />
                        <Typography sx={{ fontSize: '0.72rem', color: '#6b7280', mb: 0.25 }}>{item.time}</Typography>
                        <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#111827' }}>{item.title}</Typography>
                        <Typography sx={{ fontSize: '0.75rem', color: '#6b7280' }}>{item.desc}</Typography>
                      </Box>
                    ))}
                  </Box>
                )}
              </Box>

              <Box sx={{ px: 3, py: 2, borderTop: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Button size="small" onClick={() => toast.info('Revocation initiated')}
                  sx={{ textTransform: 'none', fontSize: '0.8125rem', fontWeight: 500, color: '#dc2626', '&:hover': { color: '#b91c1c' } }}>
                  Revoke Exception
                </Button>
                <Box display="flex" gap={1.5}>
                  <Button size="small" onClick={() => setDrawerRow(null)}
                    sx={{ textTransform: 'none', fontSize: '0.8125rem', fontWeight: 500, color: '#374151', border: '1px solid #d1d5db', borderRadius: '6px', px: 2 }}>
                    Close
                  </Button>
                  <Button size="small" onClick={() => toast.info('Drafting modification')}
                    sx={{ textTransform: 'none', fontSize: '0.8125rem', fontWeight: 600, bgcolor: '#2563eb', color: 'white', borderRadius: '6px', px: 2, '&:hover': { bgcolor: '#1d4ed8' } }}>
                    Modify & Renew
                  </Button>
                </Box>
              </Box>
            </>
          )
        })()}
      </Drawer>

      {/* ── Creation Wizard ── */}
      <Dialog open={wizardOpen} onClose={closeWizard} maxWidth="lg" fullWidth
        PaperProps={{ sx: { borderRadius: '12px', height: '85vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' } }}>
        {/* Header */}
        <Box sx={{ px: 3, py: 2.5, borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
          <Box>
            <Typography sx={{ fontSize: '1.125rem', fontWeight: 700, color: '#111827', display: 'flex', alignItems: 'center', gap: 1 }}>
              <FileText size={20} color="#2563eb" style={{ display: 'inline' }} /> Enterprise Exception Request
            </Typography>
            <Typography sx={{ fontSize: '0.75rem', color: '#6b7280', mt: 0.25 }}>
              Follow the governance workflow to document and approve risk acceptance.
            </Typography>
          </Box>
          <IconButton size="small" onClick={closeWizard} sx={{ color: '#9ca3af' }}><X size={18} /></IconButton>
        </Box>

        {/* Body: sidebar + content */}
        <Box sx={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
          {/* Sidebar */}
          <Box sx={{ width: 220, bgcolor: '#f9fafb', borderRight: '1px solid #e2e8f0', p: 3, flexShrink: 0, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 2.5 }}>
            {WIZARD_STEPS.map((label, i) => {
              const step = i + 1
              const isActive = step === wizardStep
              const isDone = step < wizardStep
              return (
                <Box key={label} display="flex" alignItems="center" gap={1.5}
                  onClick={() => isDone && setWizardStep(step)}
                  sx={{ cursor: isDone ? 'pointer' : 'default', color: isActive ? '#2563eb' : isDone ? '#16a34a' : '#9ca3af', fontWeight: isActive ? 700 : isDone ? 500 : 400 }}>
                  <Box sx={{
                    width: 28, height: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.8125rem', flexShrink: 0,
                    bgcolor: isActive ? '#2563eb' : isDone ? 'white' : 'white',
                    color: isActive ? 'white' : isDone ? '#16a34a' : '#9ca3af',
                    border: isActive ? '2px solid #2563eb' : isDone ? '2px solid #22c55e' : '2px solid #d1d5db',
                  }}>
                    {isDone ? <Check size={14} /> : step}
                  </Box>
                  <Typography sx={{ fontSize: '0.8125rem', fontWeight: 'inherit', color: 'inherit' }}>{label}</Typography>
                </Box>
              )
            })}
          </Box>

          {/* Content */}
          <Box sx={{ flex: 1, overflowY: 'auto', p: 4 }}>
            {/* Step 1: Scope Definition */}
            {wizardStep === 1 && (
              <Box maxWidth={560}>
                <Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#111827', mb: 0.5 }}>Step 1: Define Exception Scope</Typography>
                <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280', mb: 3, pb: 2, borderBottom: '1px solid #f1f5f9' }}>
                  Select the hierarchical level or entity type for this exception.
                </Typography>
                <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
                  {SCOPE_OPTIONS.map(opt => (
                    <Box key={opt.label} onClick={() => setWizardScope(opt.label)}
                      sx={{
                        border: wizardScope === opt.label ? '2px solid #2563eb' : '1px solid #e2e8f0',
                        bgcolor: wizardScope === opt.label ? '#eff6ff' : 'white',
                        borderRadius: '8px', p: 2, cursor: 'pointer',
                        boxShadow: '0 1px 2px rgba(0,0,0,0.04)',
                        '&:hover': { borderColor: '#93c5fd' }, transition: 'border-color 0.15s',
                      }}>
                      <Box display="flex" alignItems="center" gap={1} mb={0.75} sx={{ color: wizardScope === opt.label ? '#2563eb' : '#6b7280' }}>
                        {opt.icon}
                        <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: wizardScope === opt.label ? '#1d4ed8' : '#111827' }}>{opt.label}</Typography>
                      </Box>
                      <Typography sx={{ fontSize: '0.72rem', color: '#6b7280' }}>{opt.desc}</Typography>
                    </Box>
                  ))}
                </Box>
              </Box>
            )}

            {/* Step 2: Target Selection */}
            {wizardStep === 2 && (
              <Box maxWidth={600}>
                <Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#111827', mb: 0.5 }}>Step 2: Target Selection</Typography>
                <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280', mb: 3, pb: 2, borderBottom: '1px solid #f1f5f9' }}>
                  Define the dynamic filter rules to target the specific entities for this exception.
                </Typography>
                <Box sx={{ bgcolor: 'white', p: 2.5, borderRadius: '8px', border: '1px solid #e2e8f0', mb: 2 }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                    <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#111827' }}>Dynamic Filter Conditions</Typography>
                    <Button size="small" startIcon={<PlusCircle size={12} />} onClick={() => toast.info('Added empty condition row')}
                      sx={{ textTransform: 'none', fontSize: '0.72rem', fontWeight: 500, color: '#1d4ed8', bgcolor: '#eff6ff', borderRadius: '4px', px: 1.25, py: 0.25, '&:hover': { bgcolor: '#dbeafe' } }}>
                      Add Condition
                    </Button>
                  </Box>
                  {[{ connector: null, field: 'Environment', op: 'Equals (==)', val: 'PROD' }, { connector: 'AND', field: 'Application', op: 'Equals (==)', val: 'SAP' }].map((cond, i) => (
                    <Box key={i} display="flex" alignItems="center" gap={1.5} mb={i === 0 ? 1.5 : 0}>
                      {cond.connector && <Box sx={{ minWidth: 48, textAlign: 'center', fontSize: '0.72rem', fontWeight: 700, color: '#2563eb', bgcolor: '#eff6ff', py: 0.75, borderRadius: '4px' }}>AND</Box>}
                      <Select size="small" defaultValue={cond.field} sx={{ flex: 1, fontSize: '0.8125rem', ...FIELD_SX['& .MuiOutlinedInput-root'] && {} }}>
                        {['Environment', 'Application', 'OS Version', 'Tags'].map(o => <MenuItem key={o} value={o} sx={{ fontSize: '0.8125rem' }}>{o}</MenuItem>)}
                      </Select>
                      <Select size="small" defaultValue={cond.op} sx={{ flex: 1, fontSize: '0.8125rem' }}>
                        {['Equals (==)', 'Not Equals (!=)', 'Contains'].map(o => <MenuItem key={o} value={o} sx={{ fontSize: '0.8125rem' }}>{o}</MenuItem>)}
                      </Select>
                      <TextField size="small" defaultValue={cond.val} sx={{ flex: 1, '& .MuiInputBase-input': { fontSize: '0.8125rem' } }} />
                      <IconButton size="small" sx={{ color: '#9ca3af', '&:hover': { color: '#dc2626' } }}><X size={16} /></IconButton>
                    </Box>
                  ))}
                </Box>
                <Box sx={{ bgcolor: '#eff6ff', p: 2.5, borderRadius: '8px', border: '1px solid #bfdbfe', display: 'flex', alignItems: 'flex-start', gap: 1.5 }}>
                  <Info size={20} color="#2563eb" style={{ flexShrink: 0, marginTop: 2 }} />
                  <Box>
                    <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#1e3a8a' }}>Live Impact Preview</Typography>
                    <Typography sx={{ fontSize: '0.8125rem', color: '#1d4ed8', mt: 0.5 }}>
                      This dynamic filter currently matches <strong style={{ background: 'white', padding: '0 4px', borderRadius: 4, border: '1px solid #bfdbfe' }}>2,405 servers</strong> and intersects with <strong style={{ background: 'white', padding: '0 4px', borderRadius: 4, border: '1px solid #bfdbfe' }}>14 active policies</strong> across your fleet.
                    </Typography>
                  </Box>
                </Box>
              </Box>
            )}

            {/* Step 3: Exception Details */}
            {wizardStep === 3 && (
              <Box maxWidth={520}>
                <Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#111827', mb: 0.5 }}>Step 3: Exception Details</Typography>
                <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280', mb: 3, pb: 2, borderBottom: '1px solid #f1f5f9' }}>
                  Provide required business context and risk assessment.
                </Typography>
                <Box display="flex" flexDirection="column" gap={2.5}>
                  <Box>
                    <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 0.75 }}>Exception Name <span style={{ color: '#ef4444' }}>*</span></Typography>
                    <TextField fullWidth size="small" value={wizardName} onChange={e => setWizardName(e.target.value)}
                      placeholder="e.g., Q3 Migration Waiver for SAP Auth"
                      sx={{ '& .MuiInputBase-input': { fontSize: '0.8125rem' }, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e8f0' } }} />
                  </Box>
                  <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
                    <Box>
                      <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 0.75 }}>Category <span style={{ color: '#ef4444' }}>*</span></Typography>
                      <Select fullWidth size="small" defaultValue="Legacy Application" sx={{ fontSize: '0.8125rem', '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e8f0' } }}>
                        {['Legacy Application', 'Maintenance Window', 'Vendor Dependency', 'Application Compatibility'].map(o => <MenuItem key={o} value={o} sx={{ fontSize: '0.8125rem' }}>{o}</MenuItem>)}
                      </Select>
                    </Box>
                    <Box>
                      <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 0.75 }}>Assessed Risk Level <span style={{ color: '#ef4444' }}>*</span></Typography>
                      <Select fullWidth size="small" defaultValue="High Risk" sx={{ fontSize: '0.8125rem', color: '#c2410c', '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e8f0' } }}>
                        {['High Risk', 'Critical Risk', 'Medium Risk', 'Low Risk'].map(o => <MenuItem key={o} value={o} sx={{ fontSize: '0.8125rem' }}>{o}</MenuItem>)}
                      </Select>
                    </Box>
                  </Box>
                  <Box>
                    <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 0.75 }}>Business Justification <span style={{ color: '#ef4444' }}>*</span></Typography>
                    <TextField fullWidth multiline rows={4} size="small" placeholder="Provide detailed technical and business reasoning..."
                      sx={{ '& .MuiInputBase-input': { fontSize: '0.8125rem' }, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e8f0' } }} />
                  </Box>
                  <Box sx={{ bgcolor: '#f9fafb', border: '1px solid #e2e8f0', borderRadius: '6px', p: 2 }}>
                    <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 1 }}>Exception Action Configuration</Typography>
                    {['Ignore Compliance Failure in Reporting', 'Suppress Drift Notifications'].map(label => (
                      <FormControlLabel key={label} control={<Checkbox defaultChecked size="small" />}
                        label={<Typography sx={{ fontSize: '0.8125rem', color: '#374151' }}>{label}</Typography>}
                        sx={{ display: 'flex', mb: 0.5 }} />
                    ))}
                  </Box>
                </Box>
              </Box>
            )}

            {/* Step 4: Validity Window */}
            {wizardStep === 4 && (
              <Box maxWidth={520}>
                <Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#111827', mb: 0.5 }}>Step 4: Validity Window</Typography>
                <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280', mb: 3, pb: 2, borderBottom: '1px solid #f1f5f9' }}>
                  Set the active timeframe and automatic revocation rules.
                </Typography>
                <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 3, mb: 3 }}>
                  {[['Start Date', '2026-06-17'], ['End Date', '2026-09-17']].map(([label, val]) => (
                    <Box key={label}>
                      <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 0.75 }}>{label} <span style={{ color: '#ef4444' }}>*</span></Typography>
                      <TextField fullWidth size="small" type="date" defaultValue={val}
                        InputProps={{ startAdornment: <InputAdornment position="start"><Calendar size={14} color="#9ca3af" /></InputAdornment> }}
                        sx={{ '& .MuiInputBase-input': { fontSize: '0.8125rem' }, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e8f0' } }} />
                    </Box>
                  ))}
                </Box>
                <Box display="flex" flexDirection="column" gap={2}>
                  {[
                    { title: 'Auto-Revoke on Expiry', desc: 'Automatically remove the exception and resume standard policy enforcement when the end date is reached.' },
                    { title: 'Require Periodic Review', desc: 'Assign a review task to the owner at standard intervals to validate if the exception is still required.' },
                  ].map(item => (
                    <Box key={item.title} sx={{ border: '1px solid #e2e8f0', borderRadius: '8px', p: 2.5, '&:hover': { borderColor: '#93c5fd', bgcolor: '#f0f9ff' }, transition: 'all 0.15s', cursor: 'pointer' }}>
                      <FormControlLabel control={<Checkbox defaultChecked size="small" />}
                        label={
                          <Box>
                            <Typography sx={{ fontSize: '0.8125rem', fontWeight: 700, color: '#111827' }}>{item.title}</Typography>
                            <Typography sx={{ fontSize: '0.75rem', color: '#6b7280', mt: 0.25 }}>{item.desc}</Typography>
                          </Box>
                        } sx={{ alignItems: 'flex-start', '& .MuiCheckbox-root': { mt: 0.25 } }} />
                      {item.title.includes('Periodic') && (
                        <Select size="small" defaultValue="90" sx={{ mt: 1.5, fontSize: '0.8125rem', '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e8f0' } }}>
                          <MenuItem value="30" sx={{ fontSize: '0.8125rem' }}>Every 30 Days</MenuItem>
                          <MenuItem value="60" sx={{ fontSize: '0.8125rem' }}>Every 60 Days</MenuItem>
                          <MenuItem value="90" sx={{ fontSize: '0.8125rem' }}>Every 90 Days</MenuItem>
                        </Select>
                      )}
                    </Box>
                  ))}
                </Box>
              </Box>
            )}

            {/* Step 5: Governance */}
            {wizardStep === 5 && (
              <Box maxWidth={520}>
                <Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#111827', mb: 0.5 }}>Step 5: Governance & Approvals</Typography>
                <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280', mb: 3, pb: 2, borderBottom: '1px solid #f1f5f9' }}>
                  Configure the required approval workflows and audit trails.
                </Typography>
                <Box mb={3}>
                  <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 1.5 }}>Required Approvers <span style={{ color: '#ef4444' }}>*</span></Typography>
                  <Box display="flex" flexDirection="column" gap={1.5}>
                    {[
                      { label: 'Direct Manager Approval', right: 'M. Scott (mscott44)', border: '#e2e8f0', disabled: true },
                      { label: 'InfoSec Architecture Team', right: 'Required: High Risk', border: '#93c5fd', badge: true },
                      { label: 'Change Advisory Board (CAB)', right: 'Optional', border: '#e2e8f0', optional: true },
                    ].map(item => (
                      <Box key={item.label} display="flex" alignItems="center" justifyContent="space-between"
                        sx={{ p: 1.75, border: `1px solid ${item.border}`, borderRadius: '8px', bgcolor: item.disabled ? '#f9fafb' : item.badge ? '#eff6ff' : 'white', cursor: item.disabled ? 'not-allowed' : 'pointer' }}>
                        <Box display="flex" alignItems="center" gap={1.5}>
                          <Checkbox defaultChecked={!item.optional} disabled={item.disabled} size="small" />
                          <Typography sx={{ fontSize: '0.8125rem', fontWeight: item.badge ? 700 : 600, color: item.badge ? '#1e3a8a' : '#111827' }}>{item.label}</Typography>
                        </Box>
                        <Typography sx={{ fontSize: '0.72rem', fontFamily: item.disabled ? 'monospace' : 'inherit', color: item.badge ? '#1d4ed8' : '#6b7280', bgcolor: item.badge ? '#dbeafe' : item.disabled ? 'white' : 'transparent', px: item.badge || item.disabled ? 1.25 : 0, py: 0.25, borderRadius: '4px', border: item.badge ? '1px solid #bfdbfe' : item.disabled ? '1px solid #e2e8f0' : 'none', fontWeight: item.badge ? 700 : 400 }}>
                          {item.right}
                        </Typography>
                      </Box>
                    ))}
                  </Box>
                </Box>
                <Box sx={{ borderTop: '1px solid #f1f5f9', pt: 2.5 }}>
                  <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 0.75 }}>ServiceNow Change Request (Optional)</Typography>
                  <TextField fullWidth size="small" placeholder="e.g., CHG0099824"
                    sx={{ '& .MuiInputBase-input': { fontSize: '0.8125rem' }, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e8f0' } }} />
                  <Box display="flex" alignItems="center" gap={0.75} mt={0.75}>
                    <Info size={12} color="#9ca3af" />
                    <Typography sx={{ fontSize: '0.72rem', color: '#6b7280' }}>Link an approved ITIL Change Request ticket for automated audit correlation.</Typography>
                  </Box>
                </Box>
              </Box>
            )}

            {/* Step 6: Review & Submit */}
            {wizardStep === 6 && (
              <Box maxWidth={520}>
                <Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#111827', mb: 0.5 }}>Step 6: Review & Submit</Typography>
                <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280', mb: 3, pb: 2, borderBottom: '1px solid #f1f5f9' }}>
                  Review the impact analysis before generating the approval workflow.
                </Typography>
                <Box sx={{ bgcolor: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: '8px', p: 2.5, mb: 3 }}>
                  <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#1e3a8a', display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
                    <Activity size={16} /> Projected Impact Analysis
                  </Typography>
                  <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 2 }}>
                    {[['1', 'Policies', false], ['8,402', 'Servers', false], ['High', 'Risk Exposure', true]].map(([v, l, isRed]) => (
                      <Box key={String(l)} sx={{ bgcolor: 'white', p: 1.5, borderRadius: '6px', border: '1px solid #bfdbfe', textAlign: 'center' }}>
                        <Typography sx={{ fontSize: '1.25rem', fontWeight: 700, color: isRed ? '#ea580c' : '#111827' }}>{v}</Typography>
                        <Typography sx={{ fontSize: '0.65rem', textTransform: 'uppercase', fontWeight: 600, color: '#6b7280', mt: 0.5 }}>{l}</Typography>
                      </Box>
                    ))}
                  </Box>
                </Box>
                <Box sx={{ bgcolor: '#f9fafb', p: 2.5, borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                  {[['Target', 'Dynamic: Env=PROD'], ['Duration', '90 Days (Auto-Expires)'], ['Required Approvers', 'Direct Manager, InfoSec']].map(([k, v]) => (
                    <Box key={k} display="flex" justifyContent="space-between" sx={{ py: 0.875, borderBottom: '1px solid #e5e7eb', '&:last-child': { borderBottom: 'none', pb: 0 } }}>
                      <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280' }}>{k}</Typography>
                      <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#111827', fontFamily: k === 'Target' ? 'monospace' : 'inherit' }}>{v}</Typography>
                    </Box>
                  ))}
                </Box>
              </Box>
            )}
          </Box>
        </Box>

        {/* Footer */}
        <Box sx={{ px: 3, py: 2, borderTop: '1px solid #e2e8f0', bgcolor: '#f9fafb', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
          <Button size="small" onClick={closeWizard}
            sx={{ textTransform: 'none', fontSize: '0.8125rem', fontWeight: 500, color: '#374151', border: '1px solid #d1d5db', bgcolor: 'white', borderRadius: '6px', px: 2, '&:hover': { bgcolor: '#f9fafb' } }}>
            Cancel
          </Button>
          <Box display="flex" gap={1.5}>
            {wizardStep > 1 && (
              <Button size="small" startIcon={<ChevronLeft size={14} />} onClick={() => setWizardStep(s => s - 1)}
                sx={{ textTransform: 'none', fontSize: '0.8125rem', fontWeight: 500, color: '#374151', border: '1px solid #d1d5db', bgcolor: 'white', borderRadius: '6px', px: 2 }}>
                Back
              </Button>
            )}
            <Button size="small"
              startIcon={wizardStep === 6 ? <CheckCircle2 size={14} /> : undefined}
              endIcon={wizardStep < 6 ? <ChevronRight size={14} /> : undefined}
              onClick={wizardStep === 6 ? submitException : nextStep}
              sx={{ textTransform: 'none', fontSize: '0.8125rem', fontWeight: 600, bgcolor: wizardStep === 6 ? '#16a34a' : '#2563eb', color: 'white', borderRadius: '6px', px: 2.5, '&:hover': { bgcolor: wizardStep === 6 ? '#15803d' : '#1d4ed8' } }}>
              {wizardStep === 6 ? 'Submit Request' : 'Next Step'}
            </Button>
          </Box>
        </Box>
      </Dialog>
    </Box>
  )
}

export default ExceptionHubPage
