import React, { useState, useEffect, useRef, useCallback } from 'react'
import { useHistory, useLocation } from 'react-router-dom'

import PageHeader from './components/PageHeader'
import StatsHeader from './components/StatsHeader'
import PoliciesToolbar, { EMPTY_POLICY_FILTERS, PolicyFilters } from './components/PoliciesToolbar'
import PoliciesGrid from './components/PoliciesGrid'
import JsonPolicyEditorDialog, { DEFAULT_POLICY_JSON } from './components/JsonPolicyEditorDialog'
import CardGridShimmer from '../../components/CardGridShimmer'
import { useDebouncedValue } from '../../components/useDebouncedValue'

import {
  Policy,
  PolicyStatus,
  RuleSeverity,
  StatsOverview,
} from '../../utils/enums'

import { POLICYOPS_PATH } from '../../utils/constant'
import './policies.scss'
import { useGetPoliciesQuery } from '../../redux/slices/policiesSlice'

/* Toggle mock */
const MOCK_MODE = false

/* Mock stats */
const mockStats: StatsOverview = {
  policies: 6,
  policies_delta: 2,
  rules: 60,
  rules_delta: 38,
  assigned_systems: 2845,
  systems_delta: 212,
  compliance_coverage: 98.7,
  compliance_delta: 0.4,

  totalPolicies: 0,
  policiesDelta: undefined,
  totalRules: null,
  rulesDelta: undefined,
  assignedSystems: null,
  systemsDelta: undefined,
  complianceCoverage: null,
  coverageDelta: undefined,
}

const PolicyStudioPage: React.FC = () => {
  const history = useHistory()

  const location = useLocation<{ reset?: boolean }>()

  const PAGE_SIZE = 10

  const [search, setSearch] = useState('')
  const debouncedSearch = useDebouncedValue(search, 400)
  const [appliedFilters, setAppliedFilters] = useState<PolicyFilters>(EMPTY_POLICY_FILTERS)
  const [jsonEditorOpen, setJsonEditorOpen] = useState(false)
  const [jsonEditorValue, setJsonEditorValue] = useState(DEFAULT_POLICY_JSON)
  const [page, setPage] = useState(1)
  const [allPolicies, setAllPolicies] = useState<any[]>([])

  const { data, isLoading, isFetching, isError, refetch } = useGetPoliciesQuery({
    page,
    limit: PAGE_SIZE,
    search: debouncedSearch?.trim() || undefined,
    policyType: appliedFilters.policyType || undefined,
    status: appliedFilters.status || undefined,
  })

  const [knownTotal, setKnownTotal] = useState(0)
  const skipFilterResetRef = useRef(true)
  const pageRef = useRef(page)

  useEffect(() => {
    pageRef.current = page
  }, [page])

  useEffect(() => {
    if (typeof data?.total === 'number') setKnownTotal(data.total)
  }, [data?.total])

  useEffect(() => {
    if (!data?.data) return

    setAllPolicies((prev) => {
      if (pageRef.current === 1) return data.data

      const seen = new Set(prev.map((p) => p.policyId))
      const newItems = data.data.filter((item: { policyId: string }) => !seen.has(item.policyId))

      return newItems.length ? [...prev, ...newItems] : prev
    })
  }, [data])

  useEffect(() => {
    if (skipFilterResetRef.current) {
      skipFilterResetRef.current = false
      return
    }

    setPage(1)
    setAllPolicies([])
    setKnownTotal(0)
  }, [debouncedSearch, appliedFilters])


  useEffect(() => {
    if (location.state?.reset) {
      setPage(1)
    }
  }, [location.state])





  const normalizePolicies: any = (items: any[]): Policy[] =>
    items.map((item) => ({
      _id: item.policyId,
      policy_id: item.policyId,
      name: item.name,
      description: item.description,

      status: item.status as PolicyStatus,
      environment: 'Production',
      owner: item.createdBy,

      executionInfo: {

        executionMode: item?.executionInfo?.executionMode || 'ENFORCE',
        failureHandling: item?.executionInfo?.failureHandling || 'CONTINUE'

      },
      rules: (item.rules || []).map((r: any, i: number) => ({
        id: r.ruleId,
        rule_id: r.ruleId,
        name: r.name,
        description: '',
        severity: RuleSeverity.MEDIUM,
        rule_version:
          Number(r.versionNumber?.split('.')[0]) || 1,
        order: r.sequenceNumber || i + 1,
      })),

      created_by: item.createdBy,
      created_at: item.createdAt,
      updated_at: item.updatedAt,
      updated_by: item.updatedBy,

      version:
        Number(item.versionNumber?.split('.')[0]) || 1,

      compliance_coverage: 80 + Math.random() * 20,
      compliance_impact: 'Medium',
      risk_reduction: 50,

      systems_protected: 0,
      assignments: 0,
      servers: [],
      tags: item.tags || [],
    }))

  const sourceItems =
    allPolicies.length > 0 ? allPolicies : page === 1 ? data?.data ?? [] : []

  const policies = normalizePolicies(sourceItems)

  const computedStats: StatsOverview = {
    policies: data?.total ?? 0,
    policies_delta: 0,

    rules: data?.config_count ?? 0,
    rules_delta: 0,

    assigned_systems: 0,
    systems_delta: 0,

    compliance_coverage: 0,
    compliance_delta: 0,

    totalPolicies: 0,
    policiesDelta: undefined,
    totalRules: null,
    rulesDelta: undefined,
    assignedSystems: null,
    systemsDelta: undefined,
    complianceCoverage: null,
    coverageDelta: undefined,
  }

  const hasMore = knownTotal > 0 && allPolicies.length < knownTotal
  const tableLoading = (isLoading || isFetching) && page === 1

  const gridRef = useRef<HTMLDivElement | null>(null)
  const observerRef = useRef<HTMLDivElement | null>(null)
  const loadingMoreRef = useRef(false)
  const isFetchingRef = useRef(isFetching)
  const hasMoreRef = useRef(hasMore)

  useEffect(() => {
    isFetchingRef.current = isFetching
    if (!isFetching) loadingMoreRef.current = false
  }, [isFetching])

  // Reset the loading guard whenever new items are actually accumulated so that
  // cache hits (where isFetching stays false) don't permanently block further pages.
  const prevLengthRef = useRef(0)
  useEffect(() => {
    if (allPolicies.length > prevLengthRef.current) {
      loadingMoreRef.current = false
    }
    prevLengthRef.current = allPolicies.length
  }, [allPolicies.length])

  useEffect(() => {
    hasMoreRef.current = hasMore
  }, [hasMore])

  const loadNextPage = useCallback(() => {
    if (!hasMoreRef.current || loadingMoreRef.current || isFetchingRef.current) return
    loadingMoreRef.current = true
    setPage((prev) => prev + 1)
  }, [])

  const checkAndLoadMore = useCallback(() => {
    const node = observerRef.current
    if (!node || !hasMoreRef.current || loadingMoreRef.current || isFetchingRef.current) return

    const container = gridRef.current
    const containerBottom = container
      ? container.scrollTop + container.clientHeight
      : window.innerHeight
    const sentinelTop = container
      ? node.offsetTop
      : node.getBoundingClientRect().top
    if (sentinelTop <= containerBottom + 200) {
      loadNextPage()
    }
  }, [loadNextPage])

  useEffect(() => {
    const node = observerRef.current
    if (!node || !hasMore) return

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          loadNextPage()
        }
      },
      { root: gridRef.current ?? null, rootMargin: '200px', threshold: 0 },
    )

    observer.observe(node)
    return () => observer.disconnect()
  }, [hasMore, loadNextPage, allPolicies.length])

  useEffect(() => {
    const container = gridRef.current
    if (!container) return
    container.addEventListener('scroll', checkAndLoadMore, { passive: true })
    return () => container.removeEventListener('scroll', checkAndLoadMore)
  }, [checkAndLoadMore])

  useEffect(() => {
    if (tableLoading || isFetching) return
    checkAndLoadMore()
  }, [allPolicies.length, hasMore, tableLoading, isFetching, checkAndLoadMore])

  useEffect(() => {
    const handleVisible = () => {
      if (document.visibilityState === 'visible') {
        requestAnimationFrame(checkAndLoadMore)
      }
    }

    document.addEventListener('visibilitychange', handleVisible)
    window.addEventListener('focus', handleVisible)

    return () => {
      document.removeEventListener('visibilitychange', handleVisible)
      window.removeEventListener('focus', handleVisible)
    }
  }, [checkAndLoadMore])

  useEffect(() => {
    requestAnimationFrame(checkAndLoadMore)
  }, [location.pathname, checkAndLoadMore])

  const handleDeleteSuccess = () => {
    setPage(1)
    setAllPolicies([])
    setKnownTotal(0)
  }


  return (
    <div className="policies-page">
      {/* ── Fixed header ── */}
      <div className="policies-page__header">
        <PageHeader
          title="Policy Studio"
          subtitle="Create, organize, and deploy governance policies across hybrid cloud environments."
          search={search}
          onSearch={setSearch}
          onCreateRule={() => history.push(`${POLICYOPS_PATH.RULES}/new`)}
          onCreatePolicy={() => history.push(`${POLICYOPS_PATH.POLICIES}/new`)}
          onJsonEditor={() => setJsonEditorOpen(true)}
        />

        <JsonPolicyEditorDialog
          open={jsonEditorOpen}
          onClose={() => setJsonEditorOpen(false)}
          value={jsonEditorValue}
          onChange={setJsonEditorValue}
        />

        <StatsHeader
          stats={MOCK_MODE ? mockStats : computedStats}
          loading={(isLoading || isFetching) && page === 1}
        />

        <PoliciesToolbar
          count={data?.total ?? 0}
          search={search}
          onSearch={setSearch}
          filters={appliedFilters}
          onFiltersChange={setAppliedFilters}
          onRefresh={() => {
            setPage(1)
            setAllPolicies([])
            setKnownTotal(0)
            refetch()
          }}
        />
      </div>

      {/* ── Scrollable cards ── */}
      <div ref={gridRef} className="policies-page__grid">
        {tableLoading ? (
          <CardGridShimmer count={6} />
        ) : isError ? (
          <div className="ps-empty">
            <p>Failed to load policies. Please try again.</p>
          </div>
        ) : (
          <>
            <PoliciesGrid
              policies={policies}
              onDeleteSuccess={handleDeleteSuccess}
            />

            {isFetching && page > 1 && (
              <CardGridShimmer count={2} />
            )}

            <div ref={observerRef} style={{ height: 40, marginTop: 8 }} />
          </>
        )}
      </div>
    </div>
  )
}

export default PolicyStudioPage