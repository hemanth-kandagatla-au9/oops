import React from 'react'
import { Rule, PolicyRule } from '../../../utils/enums'
import '../policies.scss'
import { Typography } from '@mui/material'

const severityClass = (severity = '') => {
  const s = severity?.toLowerCase()
  if (s === 'critical') return 'policy-preview-modal__rule-severity--critical'
  if (s === 'high') return 'policy-preview-modal__rule-severity--high'
  if (s === 'medium') return 'policy-preview-modal__rule-severity--medium'
  return 'policy-preview-modal__rule-severity--low'
}

const capitalize = (s = '') =>
  s.charAt(0).toUpperCase() + s.slice(1)

const RuleIcon = ({ label = 'R' }: { label?: string }) => (
  <div className="policy-preview-modal__rule-icon">
    <span>{label.slice(0, 1).toUpperCase()}</span>
  </div>
)

interface Props {
  name: string
  description: string
  category: string
  executionMode: string
  failureHandling: string
  tags: string[]
  rules: (PolicyRule & { ruleData?: Rule })[]
  type?: 'view' | 'assignment'

  variant?: 'version'

  assignmentType?: string
  targetType?: string
  status?: string
  policyMode?: string
  priority?: string
  targets?: string
}

const PolicyReviewContent: React.FC<Props> = ({
  name,
  description,
  category,
  executionMode,
  failureHandling,
  tags,
  rules,
  type,
  variant,
  assignmentType,
  targetType,
  status,
  policyMode,
  priority,
  targets
}) => {
  return (
    <div
      className={
        variant === 'version'
          ? 'policy-preview-modal__content-grid-version'
          : type === 'view'
            ? 'policy-preview-modal__content-grid-view'
            : 'policy-preview-modal__content-grid'
      }
    >

      {/* LEFT */}
      <div className="policy-preview-modal__details-panel">
        <div className="policy-preview-modal__section-title">
          Policy Details
        </div>

        <div className="policy-preview-modal__detail-list">

          <div className="policy-preview-modal__detail-item">
            <span>{type === 'assignment' ? 'Assignment Name:' : 'Policy Name:'}</span>
            <strong>{name || '—'}</strong>
          </div>

          <div className="policy-preview-modal__detail-item">
            <span>{type === 'assignment' ? 'Assignment Description:' : 'Policy Description:'}</span>
            <strong>{description || '—'}</strong>
          </div>
          {type === 'view' && (
            <>
              <div className="policy-preview-modal__detail-item">
                <span>'Policy Category:</span>
                <strong>{category || '—'}</strong>
              </div>
              <div className="policy-preview-modal__detail-item">
                <span>Failure Handling:</span>
                <strong>{failureHandling || '—'}</strong>
              </div>
            </>
          )}


          {/* <div className="policy-preview-modal__detail-item">
            <span>Execution Mode:</span>
            <strong>{executionMode || '—'}</strong>
          </div> */}



          {type === 'assignment' && (
            <>
              <div className="policy-preview-modal__detail-item">
                <span>Assignment Type:</span>
                <strong>{assignmentType || '—'}</strong>
              </div>

              <div className="policy-preview-modal__detail-item">
                <span>Target Type:</span>
                <strong>{targetType || '—'}</strong>
              </div>

              <div className="policy-preview-modal__detail-item">
                <span>Status:</span>
                <strong>{status || '—'}</strong>
              </div>

              <div className="policy-preview-modal__detail-item">
                <span>Policy Mode:</span>
                <strong>{policyMode || '—'}</strong>
              </div>

              <div className="policy-preview-modal__detail-item">
                <span>Priority:</span>
                <strong>{priority || '—'}</strong>
              </div>

              <div className="policy-preview-modal__detail-item">
                <span>Targets:</span>
                <strong>{targets || '—'}</strong>
              </div>
            </>
          )}

          <div className="policy-preview-modal__detail-item">
            <span>Tags:</span>

            <div className="policy-preview-modal__tags">
              {tags.length ? (
                tags.map((t, i) => (
                  <div key={i} className="policy-preview-modal__tag">
                    {t}
                  </div>
                ))
              ) : (
                <strong>—</strong>
              )}
            </div>
          </div>

        </div>
      </div>

      {/* RIGHT */}
      <div className="policy-preview-modal__rules-panel">
        <div className="policy-preview-modal__section-title">{type === 'assignment' ? 'Policies' : 'Rules'}</div>

        <div className="policy-preview-modal__rules-list">
          {rules.map((rule, idx) => {
            const severity = rule.ruleData?.severity ?? ''

            return (
              <div key={rule.rule_id} className="policy-preview-modal__rule-row">
                <div className="policy-preview-modal__rule-left">

                  <span className="policy-preview-modal__rule-order">
                    {String(idx + 1).padStart(2, '0')}
                  </span>

                  <RuleIcon label={rule.ruleData?.rule_type} />

                  <div className="policy-preview-modal__rule-info">
                    <div className="policy-preview-modal__rule-name">
                      {rule.ruleData?.name}
                    </div>
                    <div className="policy-preview-modal__rule-desc">
                      {rule.ruleData?.description}
                    </div>
                  </div>

                </div>

                <Typography variant="caption" color="text.secondary">{`Version: ${rule.ruleData?.versionNumber || rule.ruleData?.version || 1}`}</Typography>

              </div>
            )
          })}
        </div>
      </div>

    </div>
  )
}

export default PolicyReviewContent