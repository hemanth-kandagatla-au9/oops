import React, { useState } from 'react'
import { Box, Button, Dialog, Divider, IconButton, Typography } from '@mui/material'
import Editor from '@monaco-editor/react'
import type { editor, IPosition } from 'monaco-editor'
import { AlertCircle, CheckCircle, Code, Copy, X } from 'lucide-react'
import { toast } from 'react-toastify'
import { useCreateJsonPolicyMutation, useValidateJsonPolicyMutation } from '../../../redux/slices/policiesSlice'

interface ApiError {
  policyErrors: string[]
  ruleErrors: string[]
  message: string
}

const extractListFromMessage = (msg: string, key: string): string[] => {
  const match = msg.match(new RegExp(`${key}[^[]*\\[([^\\]]*?)\\]`))
  if (!match) return []
  return match[1]
    .split(/,\s*(?=["'])/)
    .map(s => s.replace(/^['"\s]+|['"\s]+$/g, '').trim())
    .filter(Boolean)
}

const parseApiError = (error: unknown): ApiError => {
  const err = error as {
    data?: { message?: string; rule_errors?: string[]; policy_errors?: string[] }
    message?: string
  }
  const rawMessage = err?.data?.message?.trim() ?? err?.message?.trim() ?? ''

  // prefer direct array fields; fall back to parsing the message string
  const policyErrors = (err?.data?.policy_errors ?? []).filter(Boolean).length > 0
    ? (err?.data?.policy_errors ?? []).filter(Boolean)
    : extractListFromMessage(rawMessage, 'policy_errors')

  const ruleErrors = (err?.data?.rule_errors ?? []).filter(Boolean).length > 0
    ? (err?.data?.rule_errors ?? []).filter(Boolean)
    : extractListFromMessage(rawMessage, 'rule_errors')

  return { policyErrors, ruleErrors, message: rawMessage }
}

interface ErrorRow { node: string; message: string }

const ErrorModal: React.FC<{ error: ApiError; onClose: () => void }> = ({ error, onClose }) => {
  const rows: ErrorRow[] = [
    ...error.policyErrors.map(msg => ({ node: 'Policy', message: msg })),
    ...error.ruleErrors.map(msg   => ({ node: 'Rule',   message: msg })),
  ]
  if (rows.length === 0 && error.message) {
    rows.push({ node: '—', message: error.message })
  }
  const total = rows.length

  const COL = { sno: 56, entity: 140 }
  const HEADER_SX = { fontSize: '0.78rem', fontWeight: 600, color: '#6b7280', py: 1.25, px: 2, whiteSpace: 'nowrap' as const }

  return (
    <Dialog open onClose={onClose} maxWidth="md" fullWidth sx={{ zIndex: 1400 }}
      PaperProps={{ sx: { borderRadius: '12px', overflow: 'hidden', maxHeight: '80vh' } }}>

      {/* Header */}
      <Box sx={{ px: 3, pt: 2.5, pb: 1.5, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <Box display="flex" alignItems="center" gap={1.5}>
          <Box sx={{ width: 32, height: 32, borderRadius: '50%', bgcolor: '#fef2f2', border: '1px solid #fecaca', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <AlertCircle size={16} color="#dc2626" />
          </Box>
          <Box>
            <Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#dc2626', lineHeight: 1.3 }}>
              Validation Failed
            </Typography>
            <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280', mt: 0.25 }}>
              {total} validation error{total !== 1 ? 's' : ''} found.
            </Typography>
          </Box>
        </Box>
        <IconButton size="small" onClick={onClose} sx={{ color: '#9ca3af', mt: 0.25, '&:hover': { color: '#374151', bgcolor: '#f3f4f6' } }}>
          <X size={16} />
        </IconButton>
      </Box>

      <Divider />

      {/* Table */}
      <Box sx={{ overflowY: 'auto' }}>
        {/* Column headers */}
        <Box sx={{ display: 'flex', bgcolor: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>
          <Box sx={{ ...HEADER_SX, width: COL.sno, flexShrink: 0 }}>S.No</Box>
          <Box sx={{ ...HEADER_SX, width: COL.entity, flexShrink: 0 }}>Config Entity</Box>
          <Box sx={{ ...HEADER_SX, flex: 1 }}>Error Message</Box>
        </Box>

        {/* Rows */}
        {rows.map((row, i) => (
          <Box key={i} sx={{ display: 'flex', alignItems: 'center', borderBottom: '1px solid #f3f4f6', bgcolor: i % 2 === 0 ? 'white' : '#fafafa', '&:last-child': { borderBottom: 'none' } }}>
            <Box sx={{ width: COL.sno, flexShrink: 0, px: 2, py: 1.5 }}>
              <Typography sx={{ fontSize: '0.8125rem', color: '#6b7280', fontWeight: 500 }}>{i + 1}</Typography>
            </Box>
            <Box sx={{ width: COL.entity, flexShrink: 0, px: 2, py: 1.5 }}>
              <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#111827' }}>{row.node}</Typography>
            </Box>
            <Box sx={{ flex: 1, px: 2, py: 1.5 }}>
              <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#111827', lineHeight: 1.5 }}>{row.message}</Typography>
            </Box>
          </Box>
        ))}
      </Box>

      {/* Footer */}
      <Divider />
      <Box sx={{ px: 3, py: 1.75, display: 'flex', justifyContent: 'flex-end', bgcolor: '#f9fafb' }}>
        <Button size="small" onClick={onClose}
          sx={{ textTransform: 'none', fontWeight: 600, fontSize: '0.8125rem', bgcolor: '#1e293b', color: 'white', px: 2.5, borderRadius: '8px', '&:hover': { bgcolor: '#0f172a' } }}>
          Close
        </Button>
      </Box>
    </Dialog>
  )
}

export const DEFAULT_POLICY_JSON = `{
  "policyName": "Linux Baseline Policy",
  "description": "Standard Linux compliance policy",
  "policyCategory": "Compliance",
  "failureHandling": "Stop",
  "rules": [
    {
      "name": "Install Vim",
      "type": "PACKAGE",
      "team": "Operations",
      "category": "Security",
      "package": {
        "packageName": "vim",
        "action": "Must be Installed",
        "source": {
            "url": "https://packages.ubuntu.com/focal/vim",
            "checksum": "abc123def456ghi789jkl012mno345pq"
        },
        "primaryAction": ["Install/Enforce Package"]
      }
    },
    {
      "name": "Service Rules",
      "type": "SERVICE",
      "category": "Availability",
      "service": {
        "serviceName": "Nginx",
        "state": "Must be Running",
        "primaryAction": ["Start Service"]
      }
    },
    {
      "name": "Script Rule",
      "type": "SCRIPT",
      "category": "Configuration",
      "script": {
        "scriptPath": "/opt/tmp/example.sh",
        "checkIfContentExists": true,
        "scriptSnippet": "systemctl status nginx",
        "primaryAction": ["Execute Secondary Fix Script"]
      }
    },
    {
      "name": "User Rule",
      "type": "USER",
      "category": "Security",
      "user": {
        "username": "riseagent",
        "checkUserExists": true,
        "checkUid": false,
        "expectedUid": "",
        "checkGid": false,
        "expectedGid": "",
        "checkLock": false,
        "lockStateValue": "Must be Locked"
      }
    },
    {
      "name": "Ensure Config File Exists",
      "type": "FILE",
      "category": "Configuration",
      "file": {
        "path": "/opt/tmp/app.conf",
        "action": "File Must Exist",
        "source": {
            "url": "https://example.com/app.conf",
            "checksum": "def456ghi789jkl012mno345pqabc123"
        },
        "expectedOwner": "root",
        "expectedGroup": "root",
        "permissions": "744",
        "primaryAction": ["Restore File Content"]
    }
    }
  ]
}`;

interface JsonPolicyEditorDialogProps {
  open: boolean
  onClose: () => void
  value: string
  onChange: (value: string) => void
  minimal?: boolean
  title?: string
  description?: string
}

const JsonPolicyEditorDialog: React.FC<JsonPolicyEditorDialogProps> = ({
  open,
  onClose,
  value,
  onChange,
}) => {
  const [jsonValidState, setJsonValidState] = useState<'idle' | 'valid' | 'invalid'>('idle')
  const [apiError, setApiError] = useState<ApiError | null>(null)
  const [createJsonPolicy] = useCreateJsonPolicyMutation()
  const [validateJsonPolicy] = useValidateJsonPolicyMutation()

  const parsePolicyJson = () => {
    try {
      return JSON.parse(value)
    } catch {
      setJsonValidState('invalid')
      setApiError({ policyErrors: [], ruleErrors: [], message: 'Invalid JSON — please fix syntax errors before submitting.' })
      return null
    }
  }

  const handleClose = () => {
    setJsonValidState('idle')
    onClose()
  }

  return (
    <>
    <Dialog
      open={open}
      onClose={handleClose}
      fullScreen
      PaperProps={{ sx: { display: "flex", flexDirection: "column", bgcolor: "#1e1e1e" } }}
    >
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          px: 2,
          py: 1.5,
          bgcolor: "#252526",
          borderBottom: "1px solid #334155",
        }}
      >
        <Box display="flex" alignItems="center" gap={1.5}>
          <Code size={18} color="#93c5fd" />
          <Typography fontWeight={600} color="#f1f5f9" fontSize="0.8125rem">
            JSON Policy Editor
          </Typography>
        </Box>
        <Box display="flex" alignItems="center" gap={1}>
          <Button
            size="small"
            startIcon={jsonValidState === "invalid" ? <AlertCircle size={14} /> : <CheckCircle size={14} />}
            onClick={() => {
              const policyObject = parsePolicyJson();
              if (!policyObject) return;

              validateJsonPolicy(policyObject)
                .unwrap()
                .then((response) => {
                  if (response?.status === false) {
                    setJsonValidState('invalid')
                    setApiError(parseApiError({ data: response }))
                    return
                  }
                  setJsonValidState('valid')
                  toast.success('JSON is valid!')
                })
                .catch((error) => {
                  setJsonValidState('invalid')
                  setApiError(parseApiError(error))
                })
            }}
            sx={{
              textTransform: "none",
              fontWeight: 600,
              fontSize: "0.6875rem",
              px: 1.25,
              py: 0.35,
              borderRadius: "6px",
              bgcolor:
                jsonValidState === "valid" ? "#166534" : jsonValidState === "invalid" ? "#7f1d1d" : "transparent",
              color: jsonValidState === "valid" ? "#bbf7d0" : jsonValidState === "invalid" ? "#fecaca" : "#94a3b8",
              border: "1px solid",
              borderColor:
                jsonValidState === "valid" ? "#166534" : jsonValidState === "invalid" ? "#7f1d1d" : "#334155",
              "&:hover": {
                bgcolor:
                  jsonValidState === "valid"
                    ? "#14532d"
                    : jsonValidState === "invalid"
                      ? "#6b1a1a"
                      : "rgba(255,255,255,0.08)",
              },
            }}
          >
            Validate JSON
          </Button>
          <Button
            size="small"
            startIcon={<Copy size={13} />}
            onClick={() => navigator.clipboard.writeText(value).then(() => toast.success("Copied to clipboard"))}
            sx={{
              textTransform: "none",
              fontWeight: 600,
              fontSize: "0.6875rem",
              px: 1.25,
              py: 0.35,
              borderRadius: "6px",
              color: "#cbd5e1",
              border: "1px solid #334155",
              "&:hover": { bgcolor: "rgba(255,255,255,0.08)", color: "#f1f5f9" },
            }}
          >
            Copy JSON
          </Button>
          <Button
            size="small"
            onClick={() => {
              const policyObject = parsePolicyJson();
              if (!policyObject) return;

              createJsonPolicy({ ...policyObject, STATUS: 'DRAFT' })
                .unwrap()
                .then(() => {
                  toast.success('Policy created successfully')
                  handleClose()
                })
                .catch((error) => setApiError(parseApiError(error)))
            }}
            sx={{
              textTransform: "none",
              fontWeight: 600,
              fontSize: "0.6875rem",
              px: 1.25,
              py: 0.35,
              borderRadius: "6px",
              color: "#cbd5e1",
              border: "1px solid #334155",
              "&:hover": { bgcolor: "rgba(255,255,255,0.08)", color: "#f1f5f9" },
            }}
          >
            Save Draft
          </Button>
          <Button
            size="small"
            onClick={() => {
              const policyObject = parsePolicyJson();
              if (!policyObject) return;

              createJsonPolicy(policyObject)
                .unwrap()
                .then(() => {
                  toast.success('Policy created successfully')
                  handleClose()
                })
                .catch((error) => setApiError(parseApiError(error)))
            }}
            sx={{
              textTransform: "none",
              fontWeight: 600,
              fontSize: "0.6875rem",
              px: 1.25,
              py: 0.35,
              borderRadius: "6px",
              bgcolor: "#2563eb",
              color: "#fff",
              border: "1px solid #2563eb",
              boxShadow: "none",
              "&:hover": { bgcolor: "#1d4ed8", boxShadow: "none" },
            }}
          >
            Publish
          </Button>
          <IconButton
            size="small"
            onClick={handleClose}
            sx={{ color: "#94a3b8", ml: 0.5, "&:hover": { color: "#f1f5f9", bgcolor: "rgba(255,255,255,0.08)" } }}
          >
            <X size={18} />
          </IconButton>
        </Box>
      </Box>
      <Box sx={{ flex: 1, minHeight: 0, overflow: 'hidden' }}>
        <Editor
          height="100%"
          defaultLanguage="json"
          value={value}
          onChange={(v) => {
            onChange(v ?? "");
            setJsonValidState("idle");
          }}
          theme="vs-dark"
          beforeMount={(monaco) => {
            monaco.languages.registerCompletionItemProvider("json", {
              provideCompletionItems: (model: editor.ITextModel, position: IPosition) => {
                const word = model.getWordUntilPosition(position);
                const range = {
                  startLineNumber: position.lineNumber,
                  endLineNumber: position.lineNumber,
                  startColumn: word.startColumn,
                  endColumn: word.endColumn,
                };
                return {
                  suggestions: [
                    {
                      label: "policy-template",
                      kind: monaco.languages.CompletionItemKind.Snippet,
                      documentation: "Full policy template with rules array",
                      insertText:
                        '{\n  "policyName": "${1:MyPolicy}",\n  "description": "${2:Description}",\n  "executionMode": "ENFORCE",\n  "rules": [\n    $0\n  ]\n}',
                      insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                      range,
                    },
                    {
                      label: "package-rule",
                      kind: monaco.languages.CompletionItemKind.Snippet,
                      documentation: "Package install rule",
                      insertText:
                        '{\n  "name": "${1:Install Package}",\n  "type": "PACKAGE",\n  "package": {\n    "name": "${2:package-name}",\n    "action": "INSTALL",\n    "version": "${3:latest}"\n  }\n}',
                      insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                      range,
                    },
                    {
                      label: "file-rule",
                      kind: monaco.languages.CompletionItemKind.Snippet,
                      documentation: "File ensure-exists rule",
                      insertText:
                        '{\n  "name": "${1:Ensure Config File Exists}",\n  "type": "FILE",\n  "file": {\n    "path": "${2:/opt/app/config.conf}",\n    "action": "${3|ENSURE_EXISTS,VALIDATE_PERMISSION,VALIDATE_OWNER,VALIDATE_GROUP,VALIDATE_CHECKSUM,VALIDATE_CONTENT,DELETE|}"\n  }\n}',
                      insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                      range,
                    },
                    {
                      label: "service-rule",
                      kind: monaco.languages.CompletionItemKind.Snippet,
                      documentation: "Service state rule",
                      insertText:
                        '{\n  "name": "${1:Service Name}",\n  "type": "SERVICE",\n  "service": {\n    "name": "${2:service-name}",\n    "state": "${3|running,stopped|}",\n    "enabled": ${4|true,false|}\n  }\n}',
                      insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                      range,
                    },
                  ],
                };
              },
            });
          }}
          options={{
            minimap: { enabled: false },
            fontSize: 13,
            lineNumbers: "on",
            scrollBeyondLastLine: false,
            wordWrap: "on",
            tabSize: 2,
            formatOnPaste: true,
            automaticLayout: true,
            suggestOnTriggerCharacters: true,
            quickSuggestions: true,
          }}
        />
      </Box>
    </Dialog>

    {apiError && <ErrorModal error={apiError} onClose={() => setApiError(null)} />}
    </>
  );
}

export default JsonPolicyEditorDialog
