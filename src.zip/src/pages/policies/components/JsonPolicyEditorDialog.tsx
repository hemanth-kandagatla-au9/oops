import React, { useState } from 'react'
import { Box, Button, Dialog, IconButton, Typography } from '@mui/material'
import Editor from '@monaco-editor/react'
import type { editor, IPosition } from 'monaco-editor'
import { AlertCircle, CheckCircle, Code, Copy, X } from 'lucide-react'
import { toast } from 'react-toastify'
import { useCreateJsonPolicyMutation, useValidateJsonPolicyMutation } from '../../../redux/slices/policiesSlice'

export const DEFAULT_POLICY_JSON = `{
  "policyName": "Linux Baseline Policy",
  "description": "Standard Linux compliance policy",
  "policyCategory": "Compliance",
  "failureHandling": "Stop",
  "rules": [
    {
      "name": "Install Vim",
      "type": "PACKAGE",
      "team": "Operations",
      "category": "Security",
      "package": {
        "packageName": "vim",
        "action": "Must be Installed",
        "source": {
            "url": "https://packages.ubuntu.com/focal/vim",
            "checksum": "abc123def456ghi789jkl012mno345pq"
        },
        "primaryAction": ["Install/Enforce Package"]
      }
    },
    {
      "name": "Service Rules",
      "type": "SERVICE",
      "category": "Availability",
      "service": {
        "serviceName": "Nginx",
        "state": "Must be Running",
        "primaryAction": ["Start Service"]
      }
    },
    {
      "name": "Script Rule",
      "type": "SCRIPT",
      "category": "Configuration",
      "script": {
        "scriptPath": "/opt/tmp/example.sh",
        "checkIfContentExists": true,
        "scriptSnippet": "systemctl status nginx",
        "primaryAction": ["Execute Secondary Fix Script"]
      }
    },
    {
      "name": "User Rule",
      "type": "USER",
      "category": "Security",
      "user": {
        "username": "riseagent",
        "checkUserExists": true,
        "checkUid": false,
        "expectedUid": "",
        "checkGid": false,
        "expectedGid": "",
        "checkLock": false,
        "lockStateValue": "Must be Locked"
      }
    },
    {
      "name": "Ensure Config File Exists",
      "type": "FILE",
      "category": "Configuration",
      "file": {
        "path": "/opt/tmp/app.conf",
        "action": "File Must Exist",
        "source": {
            "url": "https://example.com/app.conf",
            "checksum": "def456ghi789jkl012mno345pqabc123"
        },
        "expectedOwner": "root",
        "expectedGroup": "root",
        "permissions": "744",
        "primaryAction": ["Restore File Content"]
    }
    }
  ]
}`;

interface JsonPolicyEditorDialogProps {
  open: boolean
  onClose: () => void
  value: string
  onChange: (value: string) => void
}

const JsonPolicyEditorDialog: React.FC<JsonPolicyEditorDialogProps> = ({
  open,
  onClose,
  value,
  onChange,
}) => {
  const [jsonValidState, setJsonValidState] = useState<'idle' | 'valid' | 'invalid'>('idle')
  const [createJsonPolicy] = useCreateJsonPolicyMutation()
  const [validateJsonPolicy] = useValidateJsonPolicyMutation();

  const parsePolicyJson = () => {
    try {
      return JSON.parse(value);
    } catch {
      setJsonValidState("invalid");
      toast.error("Invalid JSON");
      return null;
    }
  };

  const getApiErrorMessage = (error: unknown, fallback: string) => {
    const err = error as {
      data?: {
        message?: string;
        rule_errors?: string[];
        policy_errors?: string[];
      };
      message?: string;
    };

    const message = err?.data?.message?.trim();
    if (message) return message;

    const ruleErrors = err?.data?.rule_errors?.filter(Boolean) ?? [];
    const policyErrors = err?.data?.policy_errors?.filter(Boolean) ?? [];
    const combinedErrors = [...policyErrors, ...ruleErrors];
    if (combinedErrors.length > 0) return combinedErrors.join(", ");

    const genericMessage = err?.message?.trim();
    if (genericMessage) return genericMessage;

    return fallback;
  };

  const handleClose = () => {
    setJsonValidState('idle')
    onClose()
  }

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      fullScreen
      PaperProps={{ sx: { display: "flex", flexDirection: "column", bgcolor: "#1e1e1e" } }}
    >
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          px: 2,
          py: 1.5,
          bgcolor: "#252526",
          borderBottom: "1px solid #334155",
        }}
      >
        <Box display="flex" alignItems="center" gap={1.5}>
          <Code size={18} color="#93c5fd" />
          <Typography fontWeight={600} color="#f1f5f9" fontSize="0.8125rem">
            JSON Policy Editor
          </Typography>
        </Box>
        <Box display="flex" alignItems="center" gap={1}>
          <Button
            size="small"
            startIcon={jsonValidState === "invalid" ? <AlertCircle size={14} /> : <CheckCircle size={14} />}
            onClick={() => {
              const policyObject = parsePolicyJson();
              if (!policyObject) return;

              validateJsonPolicy(policyObject)
                .unwrap()
                .then((response) => {
                  if (response?.status === false) {
                    setJsonValidState("invalid");
                    toast.error(getApiErrorMessage({ data: response }, "Invalid JSON"));
                    return;
                  }

                  setJsonValidState("valid");
                  toast.success("JSON is valid!");
                  // handleClose();
                })
                .catch((error) => {
                  setJsonValidState("invalid");
                  toast.error(getApiErrorMessage(error, "Invalid JSON"));
                });
            }}
            sx={{
              textTransform: "none",
              fontWeight: 600,
              fontSize: "0.6875rem",
              px: 1.25,
              py: 0.35,
              borderRadius: "6px",
              bgcolor:
                jsonValidState === "valid" ? "#166534" : jsonValidState === "invalid" ? "#7f1d1d" : "transparent",
              color: jsonValidState === "valid" ? "#bbf7d0" : jsonValidState === "invalid" ? "#fecaca" : "#94a3b8",
              border: "1px solid",
              borderColor:
                jsonValidState === "valid" ? "#166534" : jsonValidState === "invalid" ? "#7f1d1d" : "#334155",
              "&:hover": {
                bgcolor:
                  jsonValidState === "valid"
                    ? "#14532d"
                    : jsonValidState === "invalid"
                      ? "#6b1a1a"
                      : "rgba(255,255,255,0.08)",
              },
            }}
          >
            Validate JSON
          </Button>
          <Button
            size="small"
            startIcon={<Copy size={13} />}
            onClick={() => navigator.clipboard.writeText(value).then(() => toast.success("Copied to clipboard"))}
            sx={{
              textTransform: "none",
              fontWeight: 600,
              fontSize: "0.6875rem",
              px: 1.25,
              py: 0.35,
              borderRadius: "6px",
              color: "#cbd5e1",
              border: "1px solid #334155",
              "&:hover": { bgcolor: "rgba(255,255,255,0.08)", color: "#f1f5f9" },
            }}
          >
            Copy JSON
          </Button>
          <Button
            size="small"
            onClick={() => {
              const policyObject = parsePolicyJson();
              if (!policyObject) return;

              createJsonPolicy({ ...policyObject, STATUS: "DRAFT" })
                .unwrap()
                .then(() => {
                  toast.success("Policy created successfully");
                  handleClose();
                })
                .catch((error) => toast.error(getApiErrorMessage(error, "Failed to create policy")))
            }}
            sx={{
              textTransform: "none",
              fontWeight: 600,
              fontSize: "0.6875rem",
              px: 1.25,
              py: 0.35,
              borderRadius: "6px",
              color: "#cbd5e1",
              border: "1px solid #334155",
              "&:hover": { bgcolor: "rgba(255,255,255,0.08)", color: "#f1f5f9" },
            }}
          >
            Save Draft
          </Button>
          <Button
            size="small"
            onClick={() => {
              const policyObject = parsePolicyJson();
              if (!policyObject) return;

              createJsonPolicy(policyObject)
                .unwrap()
                .then(() => {
                  toast.success("Policy created successfully");
                  handleClose();
                })
                .catch((error) => toast.error(getApiErrorMessage(error, "Failed to create policy")));
            }}
            sx={{
              textTransform: "none",
              fontWeight: 600,
              fontSize: "0.6875rem",
              px: 1.25,
              py: 0.35,
              borderRadius: "6px",
              bgcolor: "#2563eb",
              color: "#fff",
              border: "1px solid #2563eb",
              boxShadow: "none",
              "&:hover": { bgcolor: "#1d4ed8", boxShadow: "none" },
            }}
          >
            Publish
          </Button>
          <IconButton
            size="small"
            onClick={handleClose}
            sx={{ color: "#94a3b8", ml: 0.5, "&:hover": { color: "#f1f5f9", bgcolor: "rgba(255,255,255,0.08)" } }}
          >
            <X size={18} />
          </IconButton>
        </Box>
      </Box>
      <Box sx={{ flex: 1, minHeight: 0, overflow: "hidden" }}>
        <Editor
          height="100%"
          defaultLanguage="json"
          value={value}
          onChange={(v) => {
            onChange(v ?? "");
            setJsonValidState("idle");
          }}
          theme="vs-dark"
          beforeMount={(monaco) => {
            monaco.languages.registerCompletionItemProvider("json", {
              provideCompletionItems: (model: editor.ITextModel, position: IPosition) => {
                const word = model.getWordUntilPosition(position);
                const range = {
                  startLineNumber: position.lineNumber,
                  endLineNumber: position.lineNumber,
                  startColumn: word.startColumn,
                  endColumn: word.endColumn,
                };
                return {
                  suggestions: [
                    {
                      label: "policy-template",
                      kind: monaco.languages.CompletionItemKind.Snippet,
                      documentation: "Full policy template with rules array",
                      insertText:
                        '{\n  "policyName": "${1:MyPolicy}",\n  "description": "${2:Description}",\n  "executionMode": "ENFORCE",\n  "rules": [\n    $0\n  ]\n}',
                      insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                      range,
                    },
                    {
                      label: "package-rule",
                      kind: monaco.languages.CompletionItemKind.Snippet,
                      documentation: "Package install rule",
                      insertText:
                        '{\n  "name": "${1:Install Package}",\n  "type": "PACKAGE",\n  "package": {\n    "name": "${2:package-name}",\n    "action": "INSTALL",\n    "version": "${3:latest}"\n  }\n}',
                      insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                      range,
                    },
                    {
                      label: "file-rule",
                      kind: monaco.languages.CompletionItemKind.Snippet,
                      documentation: "File ensure-exists rule",
                      insertText:
                        '{\n  "name": "${1:Ensure Config File Exists}",\n  "type": "FILE",\n  "file": {\n    "path": "${2:/opt/app/config.conf}",\n    "action": "${3|ENSURE_EXISTS,VALIDATE_PERMISSION,VALIDATE_OWNER,VALIDATE_GROUP,VALIDATE_CHECKSUM,VALIDATE_CONTENT,DELETE|}"\n  }\n}',
                      insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                      range,
                    },
                    {
                      label: "service-rule",
                      kind: monaco.languages.CompletionItemKind.Snippet,
                      documentation: "Service state rule",
                      insertText:
                        '{\n  "name": "${1:Service Name}",\n  "type": "SERVICE",\n  "service": {\n    "name": "${2:service-name}",\n    "state": "${3|running,stopped|}",\n    "enabled": ${4|true,false|}\n  }\n}',
                      insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                      range,
                    },
                  ],
                };
              },
            });
          }}
          options={{
            minimap: { enabled: false },
            fontSize: 13,
            lineNumbers: "on",
            scrollBeyondLastLine: false,
            wordWrap: "on",
            tabSize: 2,
            formatOnPaste: true,
            automaticLayout: true,
            suggestOnTriggerCharacters: true,
            quickSuggestions: true,
          }}
        />
      </Box>
    </Dialog>
  );
}

export default JsonPolicyEditorDialog
