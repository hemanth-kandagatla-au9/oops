import React, { useMemo, useState } from 'react'
import { Box, IconButton, Tooltip, Typography } from '@mui/material'
import { RefreshCw } from 'lucide-react'
import SearchFilterBar from '../../../components/SearchFilterBar'
import ListFilterPopover, { FilterFieldConfig } from '../../../components/ListFilterPopover'
import AppliedFilterTags from '../../../components/AppliedFilterTags'

const POLICY_FILTER_FIELDS: FilterFieldConfig[] = [
  {
    key: 'policyType',
    label: 'Policy Category',
    type: 'select',
    options: [
      { value: 'Security', label: 'Security' },
      { value: 'Compliance', label: 'Compliance' },
    ],
  },
  {
    key: 'status',
    label: 'Status',
    type: 'radio',
    options: [
      { value: 'DRAFT', label: 'Draft' },
      { value: 'PUBLISHED', label: 'Published' },
      { value: 'ARCHIVED', label: 'Archived' },
    ],
  },
]

export interface PolicyFilters {
  policyType: string
  status: string
  [key: string]: string
}

export const EMPTY_POLICY_FILTERS: PolicyFilters = {
  policyType: '',
  status: '',
}

interface PoliciesToolbarProps {
  count: number
  search: string
  onSearch: (value: string) => void
  filters: PolicyFilters
  onFiltersChange: (filters: PolicyFilters) => void
  onRefresh?: () => void
}

const PoliciesToolbar: React.FC<PoliciesToolbarProps> = ({
  count,
  search,
  onSearch,
  filters,
  onFiltersChange,
  onRefresh,
}) => {
  const [filterAnchor, setFilterAnchor] = useState<HTMLElement | null>(null)
  const [draftFilters, setDraftFilters] = useState<PolicyFilters>(EMPTY_POLICY_FILTERS)

  const hasActiveFilters = Boolean(filters.policyType || filters.status)

  const appliedFilterTags = useMemo(() => {
    const tags: { key: string; label: string }[] = []
    if (filters.policyType) {
      tags.push({ key: 'policyType', label: `Policy Category: ${filters.policyType}` })
    }
    if (filters.status) {
      tags.push({ key: 'status', label: `Status: ${filters.status}` })
    }
    return tags
  }, [filters])

  const openFilterPopover = (anchor: HTMLElement) => {
    setDraftFilters(filters)
    setFilterAnchor(anchor)
  }

  const applyFilters = () => {
    onFiltersChange(draftFilters)
    setFilterAnchor(null)
  }

  const clearDraftFilters = () => {
    setDraftFilters(EMPTY_POLICY_FILTERS)
  }

  const clearAllAppliedFilters = () => {
    onFiltersChange(EMPTY_POLICY_FILTERS)
    setDraftFilters(EMPTY_POLICY_FILTERS)
  }

  const removeAppliedFilter = (key: string) => {
    onFiltersChange({ ...filters, [key]: '' })
  }

  const handleDraftChange = (key: string, value: string) => {
    setDraftFilters((prev) => ({ ...prev, [key]: value }))
  }

  return (
    <>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={appliedFilterTags.length ? 0 : 2.5} flexWrap="wrap" gap={2}>
        <Box display="flex" alignItems="center" gap={1}>
          <Typography variant="subtitle1" fontWeight={600} color="#0f172a">
            Policies
          </Typography>
          {/* <Box sx={{ px: 1, py: 0.2, bgcolor: '#dbeafe', borderRadius: '999px', minWidth: 28, textAlign: 'center' }}>
            <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: '#2563eb' }}>
              {String(count).padStart(2, '0')}
            </Typography>
          </Box> */}
        </Box>

        <Box display="flex" alignItems="center" gap={1}>
          {onRefresh && (
            <Tooltip title="Refresh">
              <IconButton
                size="small"
                onClick={onRefresh}
                sx={{
                  border: '1px solid #e2e8f0',
                  borderRadius: '999px',
                  width: 36,
                  height: 36,
                  color: '#64748b',
                  '&:hover': { bgcolor: '#f8fafc', borderColor: '#cbd5e1' },
                }}
              >
                <RefreshCw size={15} />
              </IconButton>
            </Tooltip>
          )}
          <SearchFilterBar
            search={search}
            onSearchChange={onSearch}
            searchPlaceholder="Search by policy name"
            onFilterClick={(e: React.MouseEvent<HTMLElement>) => openFilterPopover(e.currentTarget)}
            hasActiveFilters={hasActiveFilters}
          />
        </Box>
      </Box>

      <AppliedFilterTags
        tags={appliedFilterTags}
        onRemove={removeAppliedFilter}
        onClearAll={clearAllAppliedFilters}
      />

      <ListFilterPopover
        open={Boolean(filterAnchor)}
        anchorEl={filterAnchor}
        onClose={() => setFilterAnchor(null)}
        fields={POLICY_FILTER_FIELDS}
        draftValues={draftFilters}
        onDraftChange={handleDraftChange}
        onApply={applyFilters}
        onClear={clearDraftFilters}
      />
    </>
  )
}

export default PoliciesToolbar
