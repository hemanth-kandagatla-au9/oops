import React, { useEffect, useState } from 'react'
import { Policy } from '../../../utils/enums'
import '../policies.scss'
import { POLICYOPS_PATH } from '../../../utils/constant'
import { useHistory } from 'react-router-dom'
import { MoreVertical } from 'lucide-react'
import { Menu, MenuItem, IconButton, Dialog, DialogContent, Tab, Tabs, CircularProgress } from '@mui/material'

import { useDeletePolicyMutation, useGetPolicyVersionsQuery } from '../../../redux/slices/policiesSlice'
import { useGetAssignmentVersionsQuery, useRevokeAssignmentMutation } from '../../../redux/slices/assignmentsSlice'
import { toast } from 'react-toastify'
import PolicyReviewContent from './PolicyPreviewModal'

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

const formatCardDateTime = (value?: string | null): string => {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return '—'
  const day = date.getDate()
  const month = MONTHS[date.getMonth()]
  const year = date.getFullYear()
  const hours = String(date.getHours()).padStart(2, '0')
  const minutes = String(date.getMinutes()).padStart(2, '0')
  return `${day} ${month} ${year}, ${hours}:${minutes}`
}

interface AssignmentCardPolicy extends Policy {
  assignmentMeta?: {
    priority?: string
    policyMode?: string
    assignmentType?: string
    isGlobal?: boolean
  }
}

interface Props {
  policy: Policy | AssignmentCardPolicy
  onClick?: () => void
  onDeleteSuccess?: () => void
  onView?: () => void

  type?: 'policy' | 'assignment'
}

const PRIORITY_COLOR: Record<string, string> = {
  CRITICAL: '#ef4444',
  HIGH: '#f97316',
  MEDIUM: '#2563eb',
  LOW: '#64748b',
}

const PolicyCard: React.FC<Props> = ({ policy, onClick, onDeleteSuccess, type, onView }) => {
  const assignmentPolicy = policy as AssignmentCardPolicy
  const assignmentPriority = assignmentPolicy.assignmentMeta?.priority ?? ''
  const priorityColor = PRIORITY_COLOR[assignmentPriority.toUpperCase()] ?? '#64748b'
  const isGlobalTarget = Boolean(assignmentPolicy.assignmentMeta?.isGlobal)
  const targetsLabel = isGlobalTarget ? 'Global' : String(policy.systems_protected ?? 0)
  const cardTags = (policy.tags ?? []).filter(Boolean)


  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null)
  const [deletePolicy, { isLoading: deletingPolicy }] = useDeletePolicyMutation()
  const [revokeAssignment, { isLoading: deletingAssignment }] = useRevokeAssignmentMutation()
  const deleting = deletingPolicy || deletingAssignment
  const [versionOpen, setVersionOpen] = useState(false)
  const [selectedVersion, setSelectedVersion] = useState(0)

  const open = Boolean(anchorEl)

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>) => {
    event.stopPropagation()
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const history = useHistory()

  const handleCardClick = () => {
    if (onClick) {
      onClick()
    } else {
      history.push(`${POLICYOPS_PATH.POLICIES}/${policy._id}/view`)
    }
  }

  const handleEdit = () => {
    handleClose()

    if (type === 'assignment') {
      history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/${policy._id}/edit`, { editMode: true })
    } else {
      history.push(`${POLICYOPS_PATH.POLICIES}/${policy._id}/edit`)

    }
  }

  const handleView = () => {
    handleClose()

    if (type === 'assignment') {
      if (onView) {
        onView()
      } else {
        history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/${policy._id}/edit`)
      }
    } else {
      history.push(`${POLICYOPS_PATH.POLICIES}/${policy._id}/view`)
    }
  }


  const handleDelete = async () => {
    handleClose()

    try {
      if (type === 'assignment') {
        await revokeAssignment(policy._id).unwrap()
        toast.success('Assignment deleted successfully')
      } else {
        await deletePolicy(policy._id).unwrap()
        toast.success('Policy deleted successfully')
      }

      onDeleteSuccess?.()

    } catch (err) {
      const message = (err as { data?: { message?: string } })?.data?.message
      toast.error(message || `Failed to delete ${type === 'assignment' ? 'assignment' : 'policy'}`)
    }
  }

  const auditPolicy = policy as Policy & {
    updatedBy?: string
    createdBy?: string
    updatedAt?: string
    createdAt?: string
  }

  const displayUser = auditPolicy.updated_by
    || auditPolicy.updatedBy
    || auditPolicy.created_by
    || auditPolicy.createdBy
    || auditPolicy.owner
    || '—'

  const updatedAtValue = auditPolicy.updated_at || auditPolicy.updatedAt
  const createdAtValue = auditPolicy.created_at || auditPolicy.createdAt
  const displayDateValue = updatedAtValue || createdAtValue

  const displayDate = formatCardDateTime(displayDateValue)

  const avatarLetter = displayUser !== '—' ? displayUser.charAt(0).toUpperCase() : '?'

  const getNormalizedVersion = (version: any) => {
    const isAssignment = type === 'assignment'

    return {
      name: version?.name,
      description: version?.description,

      //  Dynamic label
      category: isAssignment
        ? version?.assignmentType
        : version?.policyType,

      executionMode: isAssignment
        ? version?.executionConfig?.executionMode || '—'
        : version?.executionInfo?.executionMode || '—',

      failureHandling: isAssignment
        ? version?.executionConfig?.failureHandling || '—'
        : version?.executionInfo?.failureHandling || '—',

      tags: version?.tags || [],

      //  KEY DIFFERENCE
      rules: isAssignment
        ? (version?.policies || []).map((p: any) => ({
          rule_id: p.policyId,
          ruleData: {
            id: p.policyId,
            name: p.name,
            description: p.name,
            versionNumber: p.versionNumber,
            rule_type: 'P',   
          }
        }))
        : (version?.rules || []).map((r: any) => ({
          rule_id: r.ruleId,
          ruleData: {
            id: r.ruleId,
            name: r.name,
            description: r.name,
            versionNumber: r.versionNumber,
            rule_type: 'R',  
          }
        }))
    }
  }

  const isAssignment = type === 'assignment'

  const {
    data: policyVersionsResponse,
    isLoading: policyVersionsLoading,
  } = useGetPolicyVersionsQuery(policy._id, {
    skip: !versionOpen || isAssignment,   
  })

  const {
    data: assignmentVersionsResponse,
    isLoading: assignmentVersionsLoading,
  } = useGetAssignmentVersionsQuery(policy._id, {
    skip: !versionOpen || !isAssignment,  
  })


  const versionData = isAssignment
    ? assignmentVersionsResponse?.data || []
    : policyVersionsResponse?.data?.versions || []

  const versionsLoading = isAssignment
    ? assignmentVersionsLoading
    : policyVersionsLoading

  console.log('Fetched versions:', assignmentVersionsResponse)

  useEffect(() => {
    if (versionOpen && versionData.length) {
      const currentIndex = versionData.findIndex((v: any) => v.isDefault)
      setSelectedVersion(currentIndex !== -1 ? currentIndex : 0)
    }
  }, [versionOpen, versionData])

  return (
    <div className="ps-policy-card" onClick={handleCardClick} role="button" tabIndex={0}>
      {/* Header */}
      <div className="ps-policy-card__header">
        <p className="ps-policy-card__name">{policy.name}</p>

        {/* RIGHT SIDE */}
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          {/* Status */}
          <span className={`ps-status-badge ps-status-badge--${policy.status.toLowerCase()}`}>{policy.status}</span>

          {/* 3 DOT MENU */}
          <IconButton size="small" onClick={handleMenuClick} sx={{ color: "#94a3b8" }}>
            <MoreVertical size={16} />
          </IconButton>

          <Menu
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            onClick={(e) => e.stopPropagation()}
            PaperProps={{
              sx: {
                borderRadius: "10px",
                mt: 1,
                minWidth: 140,
                boxShadow: "0px 4px 16px rgba(0,0,0,0.08)",
              },
            }}
          >
            <MenuItem onClick={handleView}>View</MenuItem>
            <MenuItem onClick={handleEdit}>Edit</MenuItem>
            <MenuItem
              onClick={() => {
                handleClose()
                setVersionOpen(true)
              }}
            >
              Version
            </MenuItem>
            <MenuItem onClick={handleDelete} disabled={deleting} sx={{ color: "#ef4444" }}>
              Delete
            </MenuItem>
          </Menu>
        </div>
      </div>

      {/* Meta */}
      {type === "assignment" ? (
        <>
          <div className="ps-policy-card__meta">
            <div className="ps-policy-card__meta-item">
              <span className="ps-policy-card__meta-label">Priority</span>
              <span className="ps-policy-card__meta-value" style={{ color: priorityColor }}>
                {assignmentPriority || "—"}
              </span>
            </div>

            <div className="ps-policy-card__meta-item ps-policy-card__meta-item--right">
              <span className="ps-policy-card__meta-label">Targets</span>
              <span className="ps-policy-card__meta-value">{targetsLabel}</span>
            </div>
          </div>

          <div
            className="ps-policy-card__tags"
            style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 6, marginBottom: 8 }}
          >
            <span className="ps-policy-card__meta-label">Tags</span>
            {cardTags.map((tag) => (
              <span
                key={tag}
                className="ps-policy-card__tag"
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  padding: "2px 8px",
                  borderRadius: "999px",
                  backgroundColor: "#eff6ff",
                  color: "#1d4ed8",
                  border: "1px solid #bfdbfe",
                  fontSize: "0.72rem",
                  fontWeight: 600,
                  lineHeight: 1.4,
                }}
              >
                {tag}
              </span>
            ))}
          </div>
        </>
      ) : (
        <>
          <div className="ps-policy-card__meta">
            <div className="ps-policy-card__meta-item">
              <span className="ps-policy-card__meta-label">Policy Category</span>
              <span className="ps-policy-card__meta-value">{policy.executionInfo?.executionMode || "—"}</span>
            </div>

            <div className="ps-policy-card__meta-item ps-policy-card__meta-item--right">
              <span className="ps-policy-card__meta-label">Rules</span>
              <span className="ps-policy-card__meta-value">{policy.rules.length}</span>
            </div>
          </div>

          <div
            className="ps-policy-card__tags"
            style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 6, marginBottom: 8 }}
          >
            <span className="ps-policy-card__meta-label">Tags</span>
            {cardTags.map((tag) => (
              <span
                key={tag}
                className="ps-policy-card__tag"
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  padding: "2px 8px",
                  borderRadius: "999px",
                  backgroundColor: "#eff6ff",
                  color: "#1d4ed8",
                  border: "1px solid #bfdbfe",
                  fontSize: "0.72rem",
                  fontWeight: 600,
                  lineHeight: 1.4,
                }}
              >
                {tag}
              </span>
            ))}
          </div>
        </>
      )}

      {/* Footer */}
      <div className="ps-policy-card__footer">
        <div className="ps-policy-card__user">
          <div className="ps-policy-card__avatar-placeholder">{avatarLetter}</div>
          <span className="ps-policy-card__username">{displayUser}</span>
        </div>

        <div className="ps-policy-card__date">
          {displayDate}
        </div>
      </div>

      {/* Version Modal */}
      <Dialog open={versionOpen} onClose={() => setVersionOpen(false)} maxWidth="md" fullWidth onClick={(e) => e.stopPropagation()} >
        {/* <DialogTitle>Version Info</DialogTitle> */}

        <DialogContent>
          {/* Header */}
          <div className="policy-preview-modal__header">
            <div className="policy-preview-modal__title">
              Version Info
            </div>

            <button
              className="policy-preview-modal__close-btn"
              onClick={() => setVersionOpen(false)}
            >
              ✕
            </button>
          </div>
          {versionsLoading ? (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                minHeight: 200,
              }}
            >
              <CircularProgress />
            </div>
          ) : versionData.length === 0 ? (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                minHeight: 200,
              }}
            >
              No versions are available
            </div>
          ) : (
            versionData[selectedVersion] && (

              <div className="policy-preview-modal">



                {/* Tabs */}
                <div className="pdp-tabs-bar" style={{ padding: "12px 24px 0px 24px" }}>
                  <Tabs
                    value={selectedVersion}
                    onChange={(_, val) => setSelectedVersion(val)}
                  >

                    {versionData.map((v: any) => (
                      <Tab
                        key={v.versionNumber}
                        label={`${v.versionNumber}${v.isDefault ? " (Current)" : ""}`}
                      />
                    ))}

                  </Tabs>

                </div>

                {/* Body */}
                <div className="policy-preview-modal__body">

                  {(() => {
                    const v = getNormalizedVersion(versionData[selectedVersion])

                    return (
                      <PolicyReviewContent
                        name={v.name}
                        description={v.description}
                        category={v.category}
                        executionMode={v.executionMode}
                        failureHandling={v.failureHandling}
                        tags={v.tags}
                        rules={v.rules}
                        type={isAssignment ? 'assignment' : 'view'}
                        variant="version"

                        //  ADD THIS
                        assignmentType={versionData[selectedVersion]?.assignmentType}
                        targetType={versionData[selectedVersion]?.targetType}
                        status={versionData[selectedVersion]?.status}
                        policyMode={versionData[selectedVersion]?.policyMode}
                        priority={versionData[selectedVersion]?.priority}
                        targets={
                          (versionData[selectedVersion]?.targets || [])
                            .map((t: any) => t.hostname)
                            .join(', ')
                        }
                      />
                    )
                  })()}

                </div>

              </div>
            )
          )}
        </DialogContent>
      </Dialog>

    </div>
  );
}

export default PolicyCard
