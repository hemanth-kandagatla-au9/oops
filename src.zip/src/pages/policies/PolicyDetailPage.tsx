import React, { useState } from 'react'
import { useParams, useHistory } from 'react-router-dom'
import './policies.scss'
import { Box, Typography, Button, Alert, IconButton } from '@mui/material'
import { POLICYOPS_PATH } from '../../utils/constant'
import { useGetPolicyByIdQuery } from '../../redux/slices/policiesSlice'
import { ChevronLeft, Pencil } from 'lucide-react'
import PolicyReviewContent from './components/PolicyPreviewModal'
import ScmTab from '../../components/ScmTab'
import DetailSkeleton from '../../components/DetailSkeleton'

const PolicyDetailPage: React.FC = () => {
  const history = useHistory()
  const [activeTab, setActiveTab] = useState('overview')
  const { id } = useParams<{ id: string }>()

  const { data, isLoading, isError } = useGetPolicyByIdQuery(id, { skip: !id })
  const policy = data?.data

  const mappedRules = (policy?.rules || []).map((r: any, idx: number) => ({
    rule_id: r.ruleId || r.rule_id,
    rule_version: 1,
    order: r.sequenceNumber || idx + 1,
    ruleData: {
      name: r.name,
      description: r.description || '',
      severity: r.severity || 'medium',
      rule_type: r.ruleType || 'R',
      versionNumber: r.versionNumber || 1,
    },
  }))

  if (isLoading) return <DetailSkeleton />
  if (isError || !policy) return <Box p={3}><Alert severity="error">Policy not found</Alert></Box>

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', bgcolor: '#ffffff' }}>

      {/* ── Top bar ── */}
      <Box sx={{ bgcolor: '#ffffff', borderBottom: '1px solid #e2e8f0', px: 3, pt: 1.5, pb: 1.5 }}>
        <Box display="flex" alignItems="center" justifyContent="space-between">

          <Box display="flex" alignItems="center" gap={1}>
            <IconButton size="small" onClick={() => history.push(POLICYOPS_PATH.POLICIES)}
              sx={{ color: '#64748b', border: '1px solid #e2e8f0', borderRadius: '8px', p: '4px', '&:hover': { bgcolor: '#f8fafc', color: '#102459' } }}>
              <ChevronLeft size={16} />
            </IconButton>
            <Box>
              <Typography variant="caption"
                sx={{ color: '#2563eb', cursor: 'pointer', fontWeight: 500, display: 'block', lineHeight: 1.4, '&:hover': { textDecoration: 'underline' } }}
                onClick={() => history.push(POLICYOPS_PATH.POLICIES)}>
                Policies
              </Typography>
              <Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: '#102459', lineHeight: 1.2 }}>
                {policy.name}
              </Typography>
            </Box>
          </Box>

          <Box display="flex" gap={1}>
            <Button size="small" variant="outlined" endIcon={<Pencil size={14} />}
              onClick={() => history.push(`${POLICYOPS_PATH.POLICIES}/${id}/edit`)}
              sx={{ borderColor: '#e2e8f0', color: '#374151', fontWeight: 500, fontSize: '0.875rem', textTransform: 'none', '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' } }}>
              Modify
            </Button>
          </Box>
        </Box>
      </Box>

      {/* ── Tab bar ── */}
      <Box sx={{ display: 'flex', borderBottom: '1px solid #e2e8f0', bgcolor: 'white', px: 3 }}>
        {[['overview', 'Overview'], ['scm', 'SCM']].map(([key, label]) => (
          <Box key={key} onClick={() => setActiveTab(key)}
            sx={{
              px: 2, py: 1.5, cursor: 'pointer', fontSize: '0.875rem',
              fontWeight: activeTab === key ? 600 : 400,
              color: activeTab === key ? '#2563eb' : '#64748b',
              borderBottom: `2px solid ${activeTab === key ? '#2563eb' : 'transparent'}`,
              transition: 'color 0.15s', userSelect: 'none',
              '&:hover': { color: '#2563eb' },
            }}>
            {label}
          </Box>
        ))}
      </Box>

      {/* ── Body ── */}
      <Box sx={{ flex: 1, overflowY: 'auto', bgcolor: '#f8fafc' }}>
        {activeTab === 'overview' && (
          <div className="pdp-content">
            <PolicyReviewContent
              name={policy.name || ''}
              description={policy.description || ''}
              category={policy.policyType || ''}
              executionMode={policy.executionInfo?.executionMode || ''}
              failureHandling={policy.executionInfo?.failureHandling || ''}
              tags={policy.tags || []}
              rules={mappedRules}
              type="view"
            />
          </div>
        )}
        {activeTab === 'scm' && (
          <Box sx={{ p: 3 }}>
            <ScmTab name={policy.name || ''} type="policy" />
          </Box>
        )}
      </Box>

    </Box>
  )
}

export default PolicyDetailPage
