import React, { useEffect, useState } from 'react'
import {
  Box, Typography, Button, CircularProgress, Alert, Paper,
  Divider, IconButton, Dialog, DialogTitle, DialogContent,
  DialogContentText, DialogActions, Grid, Chip, Stack,
  Tab,
  Tabs,
} from '@mui/material'
import { ChevronLeft, Edit2, Copy, CheckCircle } from 'lucide-react'
import { useHistory, useLocation, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import {
  useGetRuleByIdQuery,
  useUpdateRuleMutation,
  useCloneRuleMutation,
  useGetRuleVersionsQuery,
} from '../../redux/slices/rulesSlice'
import ScmTab from '../../components/ScmTab'
import { POLICYOPS_PATH } from '../../utils/constant'
import "../policies/policies.scss"

const TAG_COLORS = [
  { bg: '#eff6ff', color: '#2563eb', border: '#bfdbfe' },
  { bg: '#f0fdf4', color: '#16a34a', border: '#bbf7d0' },
  { bg: '#faf5ff', color: '#7c3aed', border: '#e9d5ff' },
  { bg: '#fff7ed', color: '#d97706', border: '#fde68a' },
  { bg: '#fdf2f8', color: '#db2777', border: '#fbcfe8' },
  { bg: '#f0fdfa', color: '#0d9488', border: '#99f6e4' },
]
const tagColor = (i: number) => TAG_COLORS[i % TAG_COLORS.length]

const STATUS_PILL: Record<string, { bg: string; color: string; border: string }> = {
  published: { bg: '#f0fdf4', color: '#16a34a', border: '#bbf7d0' },
  draft: { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' },
  archived: { bg: '#fff7ed', color: '#d97706', border: '#fed7aa' },
}
const SEVERITY_PILL: Record<string, { bg: string; color: string; border: string }> = {
  critical: { bg: '#fef2f2', color: '#dc2626', border: '#fecaca' },
  high: { bg: '#fffbeb', color: '#d97706', border: '#fde68a' },
  medium: { bg: '#eff6ff', color: '#2563eb', border: '#bfdbfe' },
  low: { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' },
}

const Pill: React.FC<{ label: string; map: Record<string, { bg: string; color: string; border: string }> }> = ({ label, map }) => {
  const key = (label ?? '').toLowerCase()
  const s = map[key] ?? { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' }
  return (
    <Box sx={{
      px: 1.5, py: 0.3, borderRadius: '999px',
      bgcolor: s.bg, color: s.color, border: `1px solid ${s.border}`,
      fontSize: '0.72rem', fontWeight: 600, display: 'inline-block', whiteSpace: 'nowrap',
    }}>
      {key.charAt(0).toUpperCase() + key.slice(1)}
    </Box>
  )
}

const formatKey = (key: string) =>
  key
    .replace(/([a-z\d])([A-Z])/g, '$1 $2')
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2')
    .replace(/^[a-z]/, (c) => c.toUpperCase())

const InfoRow: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <Box display="flex" alignItems="flex-start" py={1} sx={{ '&:not(:last-child)': { borderBottom: '1px solid #f8fafc' } }}>
    <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', minWidth: 200, flexShrink: 0 }}>{label}</Typography>
    <Box flex={1}>
      {typeof value === 'string'
        ? <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#102459', wordBreak: 'break-word' }}>{value}</Typography>
        : value}
    </Box>
  </Box>
)

const RuleDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>()
  const history = useHistory()

  const location = useLocation()

  const isVersionView =
    new URLSearchParams(location.search).get('tab') === 'versions'

  const [selectedVersion, setSelectedVersion] = useState(0)


  const {
    data: versionsResponse,
    isLoading: versionsLoading,
  } = useGetRuleVersionsQuery(id, {
    skip: !isVersionView,
  })

  const versionData = versionsResponse?.data || []


  const sortedVersions = [...versionData].sort(
    (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  )

  useEffect(() => {
    if (isVersionView && versionData.length && selectedVersion === 0) {
      setSelectedVersion(0)
    }
  }, [isVersionView])

  const [confirmAction, setConfirmAction] = useState<'publish' | 'archive' | null>(null)
  const [activeTab, setActiveTab] = useState('details')

  const { data, isLoading, isError } = useGetRuleByIdQuery(id)
  const [updateRule, { isLoading: statusUpdating }] = useUpdateRuleMutation()
  const [cloneRule] = useCloneRuleMutation()

  const baseRule = data?.data

  const currentRule = isVersionView
    ? sortedVersions[selectedVersion]
    : baseRule

  const rule: any = data?.data

  const handlePublish = async () => {
    setConfirmAction(null)
    try {
      await updateRule({ id, data: { ...rule, status: 'PUBLISHED' } }).unwrap()
      toast.success(`"${rule.name}" published`)
    }
    catch { toast.error('Publish failed.') }
  }
  const handleArchive = async () => {
    setConfirmAction(null)
    try {
      await updateRule({ id, data: { ...rule, status: 'ARCHIVED' } }).unwrap()
      toast.success(`"${rule.name}" archived`)
    }
    catch { toast.error('Archive failed.') }
  }
  const handleClone = async () => {
    try { await cloneRule(id).unwrap(); toast.success(`"${rule.name}" cloned as draft`) }
    catch { toast.error('Clone failed.') }
  }

  if (isLoading) return <Box sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><CircularProgress /></Box>
  if (isError || !rule) return <Box p={3}><Alert severity="error">Rule not found</Alert></Box>

  const statusKey = (currentRule?.status ?? '').toLowerCase()

  const configEntries = Object.entries(currentRule?.configuration ?? currentRule?.definition ?? {})

  const driftEntries = Object.entries(currentRule?.driftresponse ?? {})

  const gov = currentRule?.governance ?? {}

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', bgcolor: '#ffffff' }}>

      {/* ── Top bar ── */}
      <Box sx={{ bgcolor: '#ffffff', borderBottom: '1px solid #e2e8f0', px: 3, pt: 1.5, pb: 1.5 }}>
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Box display="flex" alignItems="center" gap={1}>
            <IconButton
              size="small"
              onClick={() => history.push(POLICYOPS_PATH.RULES)}
              sx={{ color: '#64748b', border: '1px solid #e2e8f0', borderRadius: '8px', p: '4px', '&:hover': { bgcolor: '#f8fafc', color: '#102459' } }}
            >
              <ChevronLeft size={16} />
            </IconButton>
            <Box>
              <Typography
                variant="caption"
                sx={{ color: '#2563eb', cursor: 'pointer', fontWeight: 500, display: 'block', lineHeight: 1.4, '&:hover': { textDecoration: 'underline' } }}
                onClick={() => history.push(POLICYOPS_PATH.RULES)}
              >
                Rule
              </Typography>
              <Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: '#102459', lineHeight: 1.2 }}>{currentRule?.name}</Typography>
            </Box>
          </Box>

          <Box display="flex" gap={1} alignItems="center">
            {!isVersionView && statusKey !== 'archived' && (
              <Button
                size="small"
                variant="outlined"
                endIcon={<Edit2 size={14} />}
                sx={{ borderColor: '#e2e8f0', color: '#374151', fontWeight: 500, fontSize: '0.875rem', textTransform: 'none', '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' } }}
                onClick={() => history.push(`${POLICYOPS_PATH.RULES}/${id}/edit`)}
              >
                Modify
              </Button>
            )}
            {!isVersionView && (
              <Button size="small" variant="outlined" startIcon={<Copy size={14} />}
                sx={{ borderColor: '#e2e8f0', color: '#374151', textTransform: 'none' }}
                onClick={handleClone}>Clone</Button>)}
            {!isVersionView && statusKey === 'draft' && (
              <Button size="small" variant="contained" startIcon={<CheckCircle size={14} />}
                sx={{ bgcolor: '#16a34a', boxShadow: 'none', textTransform: 'none', '&:hover': { bgcolor: '#15803d', boxShadow: 'none' } }}
                onClick={() => setConfirmAction('publish')}>Publish</Button>
            )}
          </Box>
        </Box>
      </Box>

      {isVersionView && (
        <Box sx={{ mb: 2 }}>
          {versionsLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 2 }}>
              <CircularProgress size={20} />
            </Box>
          ) : sortedVersions.length === 0 ? (
            <Typography sx={{ fontSize: '0.85rem', color: '#64748b' }}>
              No versions available
            </Typography>
          ) : (
            <div className="pdp-tabs-bar" style={{ padding: "12px 24px 0px 24px" }}>

              <Tabs
                value={selectedVersion}
                onChange={(_, val) => setSelectedVersion(val)}
              >
                {sortedVersions.map((v: any, index) => (
                  <Tab
                    key={v.version}
                    label={`v${v.version}${index === 0 ? ' (Latest)' : ''}`}
                  />
                ))}
              </Tabs>
            </div>
          )}
        </Box>
      )}


      {/* ── Tab bar ── */}
      {!isVersionView && (
        <Box sx={{ borderBottom: '1px solid #e2e8f0', px: 3, bgcolor: '#ffffff' }}>
          <Tabs
            value={activeTab}
            onChange={(_, val) => setActiveTab(val)}
            sx={{
              minHeight: 40,
              '& .MuiTab-root': { minHeight: 40, fontSize: '0.8125rem', fontWeight: 500, textTransform: 'none', color: '#64748b', px: 2, py: 0 },
              '& .Mui-selected': { color: '#2563eb', fontWeight: 600 },
              '& .MuiTabs-indicator': { bgcolor: '#2563eb' },
            }}
          >
            <Tab label="Details" value="details" />
            <Tab label="SCM" value="scm" />
          </Tabs>
        </Box>
      )}

      {/* ── Body ── */}
      <Box sx={{ flex: 1, overflowY: 'auto', bgcolor: '#f8fafc', p: 3 }}>
        {activeTab === 'scm' ? (
          <ScmTab name={rule.name} type="rule" />
        ) : (
        <Paper elevation={0} sx={{ borderRadius: '12px', border: '1px solid #e2e8f0', bgcolor: 'white', overflow: 'hidden' }}>

          {/* Basic Information */}
          <Box sx={{ px: 3.5, pt: 3, pb: 2.5 }}>
            <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#102459', mb: 1.75 }}>Basic Information</Typography>
            <InfoRow label="Rule Name" value={currentRule?.name || '-'} />
            <InfoRow label="Rule Category" value={currentRule?.rulecategory || currentRule?.rule_type || '-'} />
            <InfoRow label="Severity" value={<Pill label={currentRule?.severity} map={SEVERITY_PILL} />} />
            <InfoRow label="Description" value={currentRule?.description || '-'} />
            {(currentRule?.tags ?? []).length > 0 && (
              <InfoRow label="Tags" value={
                <Stack direction="row" flexWrap="wrap" gap={0.75}>
                  {(currentRule?.tags as string[]).map((tag, i) => {
                    const c = tagColor(i)
                    return (
                      <Chip key={tag} label={tag} size="small"
                        sx={{ borderRadius: '999px', bgcolor: c.bg, color: c.color, border: `1px solid ${c.border}`, fontSize: '0.75rem', fontWeight: 500, height: 22 }} />
                    )
                  })}
                </Stack>
              } />
            )}
          </Box>

          <Divider sx={{ borderColor: '#f1f5f9' }} />

          {/* Configuration + Response & Governance */}
          <Grid container>
            <Grid item xs={12} md={6} sx={{ px: 3.5, pt: 3, pb: 3.5, borderRight: { md: '1px solid #f1f5f9' } }}>
              <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#102459', mb: 1.75 }}>Configuration</Typography>
              {configEntries.length > 0
                ? configEntries.map(([key, value]) => (
                  <InfoRow key={key} label={formatKey(key)} value={String(value)} />
                ))
                : <Typography sx={{ fontSize: '0.8125rem', color: '#94a3b8', fontStyle: 'italic' }}>No configuration data</Typography>
              }
            </Grid>
            <Grid item xs={12} md={6} sx={{ px: 3.5, pt: 3, pb: 3.5 }}>
              <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#102459', mb: 1.75 }}>Response and Governance</Typography>
              {driftEntries.map(([key, value]) => (
                <InfoRow key={key} label={formatKey(key)} value={String(value)} />
              ))}
              {driftEntries.length > 0 && (gov.ownerTeam || gov.associatedChangeTicket) && (
                <Divider sx={{ my: 1.5, borderColor: '#f1f5f9' }} />
              )}
              {gov.ownerTeam && <InfoRow label="Owner Team" value={String(gov.ownerTeam)} />}
              {gov.associatedChangeTicket && <InfoRow label="Associated Change Ticket" value={String(gov.associatedChangeTicket)} />}
              {!driftEntries.length && !gov.ownerTeam && !gov.associatedChangeTicket && (
                <Typography sx={{ fontSize: '0.8125rem', color: '#94a3b8', fontStyle: 'italic' }}>No response data</Typography>
              )}
            </Grid>
          </Grid>

        </Paper>
        )}
      </Box>

      {/* Confirm publish */}
      <Dialog open={confirmAction === 'publish'} onClose={() => setConfirmAction(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: '12px' } }}>
        <DialogTitle sx={{ fontSize: '1rem', fontWeight: 600, color: '#102459' }}>Publish Rule</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ fontSize: '0.875rem' }}>
            Publish "{currentRule?.name}"? This locks the rule (v{currentRule?.version}) and makes it available for policies.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
          <Button size="small" onClick={() => setConfirmAction(null)} sx={{ color: '#64748b' }}>Cancel</Button>
          <Button size="small" variant="contained" onClick={handlePublish} disabled={statusUpdating}
            sx={{ bgcolor: '#16a34a', boxShadow: 'none', '&:hover': { bgcolor: '#15803d', boxShadow: 'none' } }}>
            Publish
          </Button>
        </DialogActions>
      </Dialog>

      {/* Confirm archive */}
      <Dialog open={confirmAction === 'archive'} onClose={() => setConfirmAction(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: '12px' } }}>
        <DialogTitle sx={{ fontSize: '1rem', fontWeight: 600, color: '#102459' }}>Archive Rule</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ fontSize: '0.875rem' }}>
            Archive "{currentRule?.name}"? It will be retired and can no longer be added to new policies.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
          <Button size="small" onClick={() => setConfirmAction(null)} sx={{ color: '#64748b' }}>Cancel</Button>
          <Button size="small" variant="outlined" onClick={handleArchive} disabled={statusUpdating}
            sx={{ borderColor: '#fed7aa', color: '#d97706', '&:hover': { bgcolor: '#fffbeb' } }}>
            Archive
          </Button>
        </DialogActions>
      </Dialog>

    </Box>
  )
}

export default RuleDetailPage
