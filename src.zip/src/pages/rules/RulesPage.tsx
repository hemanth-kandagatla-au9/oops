import React, { useState } from 'react'
import {
  Box, Button, Checkbox, Chip, DialogActions, DialogContent, FormControl,
  IconButton, InputAdornment, ListItemText, MenuItem, Popover,
  Select, TextField, Tooltip, Typography,
} from '@mui/material'
import Dialog from '@mui/material/Dialog'
import { Plus, Search, SlidersHorizontal, Copy, Eye, Pencil, Trash2, X, RefreshCw } from 'lucide-react'
import { useHistory } from 'react-router-dom'
import { toast } from 'react-toastify'
import dayjs from 'dayjs'
import {
  useGetRulesQuery,
  useGetRuleCategoriesMetadataQuery,
  useGetRuleCategoriesQuery,
  useCloneRuleMutation,
  useDeleteRuleMutation,
} from '../../redux/slices/rulesSlice'
import { POLICYOPS_PATH } from '../../utils/constant'
import PolicyTable, { TableColumn } from '../../components/PolicyTable'
import LinkCell from '../../components/LinkCell'

// ── Status pill ───────────────────────────────────────────────────────────────
const STATUS_PILL: Record<string, { bg: string; color: string; border: string; label: string }> = {
  published: { bg: '#f0fdf4', color: '#16a34a', border: '#bbf7d0', label: 'Published' },
  draft:     { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0', label: 'Draft'     },
  archived:  { bg: '#fff7ed', color: '#d97706', border: '#fed7aa', label: 'Archived'  },
}

const RuleStatusPill: React.FC<{ status: string }> = ({ status }) => {
  const key = (status ?? '').toLowerCase()
  const s = STATUS_PILL[key] ?? STATUS_PILL.draft
  return (
    <Box sx={{ px: 1.5, py: 0.35, borderRadius: '999px', bgcolor: s.bg, color: s.color, border: `1px solid ${s.border}`, fontSize: '0.72rem', fontWeight: 600, display: 'inline-block', whiteSpace: 'nowrap' }}>
      {s.label}
    </Box>
  )
}

const getRuleId = (row: any) => row.id ?? row._id ?? row.rule_id ?? ''

// ── Page ──────────────────────────────────────────────────────────────────────
const RulesPage: React.FC = () => {
  const history = useHistory()
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(0)
  const [pageSize, setPageSize] = useState(10)

  // applied filters (wired to query)
  const [statusFilter, setStatusFilter]     = useState<string[]>([])
  const [severityFilter, setSeverityFilter] = useState<string[]>([])
  const [checkTypeFilter, setCheckTypeFilter] = useState('')
  const [categoryFilter, setCategoryFilter]   = useState('')

  // pending filters (edited inside popover before Apply)
  const [filterAnchorEl, setFilterAnchorEl]         = useState<HTMLButtonElement | null>(null)
  const [pendingStatus, setPendingStatus]             = useState<string[]>([])
  const [pendingSeverity, setPendingSeverity]         = useState<string[]>([])
  const [pendingCheckType, setPendingCheckType]       = useState('')
  const [pendingCategory, setPendingCategory]         = useState('')

  const { data: categoriesMetaData } = useGetRuleCategoriesMetadataQuery()
  const { data: ruleCategoriesData } = useGetRuleCategoriesQuery()
  const checkTypeOptions: { categoryCode: string; name: string }[] = categoriesMetaData?.data ?? []
  const categoryOptions: string[] = (ruleCategoriesData?.data ?? []).map((c: any) => c.name ?? c)

  const filterOpen = Boolean(filterAnchorEl)
  const activeFilterCount = [statusFilter.length > 0, severityFilter.length > 0, !!checkTypeFilter, !!categoryFilter].filter(Boolean).length

  const openFilter = (e: React.MouseEvent<HTMLButtonElement>) => {
    setPendingStatus(statusFilter)
    setPendingSeverity(severityFilter)
    setPendingCheckType(checkTypeFilter)
    setPendingCategory(categoryFilter)
    setFilterAnchorEl(e.currentTarget)
  }

  const closeFilter = () => setFilterAnchorEl(null)

  const handleApplyFilters = () => {
    setStatusFilter(pendingStatus)
    setSeverityFilter(pendingSeverity)
    setCheckTypeFilter(pendingCheckType)
    setCategoryFilter(pendingCategory)
    setPage(0)
    closeFilter()
  }

  const handleClearFilters = () => {
    setPendingStatus([]); setPendingSeverity([]); setPendingCheckType(''); setPendingCategory('')
    setStatusFilter([]); setSeverityFilter([]); setCheckTypeFilter(''); setCategoryFilter('')
    setPage(0)
  }

  const { data, isLoading, isFetching, isError, refetch } = useGetRulesQuery({
    page: page + 1,
    limit: pageSize,
    search:     search                                || undefined,
    status:     statusFilter.length   ? statusFilter.join(',')   : undefined,
    severity:   severityFilter.length ? severityFilter.join(',') : undefined,
    checkType:  checkTypeFilter                      || undefined,
    category:   categoryFilter                       || undefined,
  })

  const [cloneRule] = useCloneRuleMutation()
  const [deleteRule, { isLoading: deleting }] = useDeleteRuleMutation()
  const [deleteTarget, setDeleteTarget] = useState<any>(null)

  const rules: any[] = data?.data ?? []
  const total: number = data?.total ?? 0

  const handleClone = async (row: any) => {
    const id = getRuleId(row)
    try { await cloneRule(id).unwrap(); toast.success(`"${row.name}" cloned as draft`) }
    catch { toast.error('Clone failed.') }
  }

  const handleDelete = async () => {
    const id = getRuleId(deleteTarget)
    setDeleteTarget(null)
    try { await deleteRule(id).unwrap(); toast.success(`"${deleteTarget.name}" deleted`) }
    catch { toast.error('Delete failed.') }
  }

  const columns: TableColumn[] = [
    {
      key: 'name', header: 'Rule Name', width: '22%',
      render: (row: any) => (
        <LinkCell label={row.name} secondary={row.description} onClick={() => history.push(`${POLICYOPS_PATH.RULES}/${getRuleId(row)}`)} />
      ),
    },
    {
      key: 'checkType', header: 'Type', width: '14%',
      render: (row: any) => (
        <Typography variant="body2" noWrap sx={{ color: '#102459', fontWeight: 500, fontSize: '0.875rem' }}>
          {row.checkType || row.rule_type || '-'}
        </Typography>
      ),
    },
    {
      key: 'rulecategory', header: 'Category', width: '14%',
      render: (row: any) => (
        <Typography variant="body2" noWrap sx={{ color: '#102459', fontWeight: 500, fontSize: '0.875rem' }}>
          {row.rulecategory || '-'}
        </Typography>
      ),
    },
    {
      key: 'severity', header: 'Severity', width: '10%',
      render: (row: any) => {
        const key = (row.severity ?? '').toLowerCase()
        const SEV: Record<string, { bg: string; color: string; border: string }> = {
          critical: { bg: '#fef2f2', color: '#dc2626', border: '#fecaca' },
          high:     { bg: '#fffbeb', color: '#d97706', border: '#fde68a' },
          medium:   { bg: '#eff6ff', color: '#2563eb', border: '#bfdbfe' },
          low:      { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' },
        }
        const s = SEV[key] ?? SEV.low
        return (
          <Box sx={{ px: 1.25, py: 0.3, borderRadius: '999px', bgcolor: s.bg, color: s.color, border: `1px solid ${s.border}`, fontSize: '0.72rem', fontWeight: 600, display: 'inline-block', whiteSpace: 'nowrap' }}>
            {key.charAt(0).toUpperCase() + key.slice(1) || '-'}
          </Box>
        )
      },
    },
    {
      key: 'version', header: 'Version', width: '10%',
      render: (row: any) => (
        <Box sx={{ px: 1.5, py: 0.4, borderRadius: 1.5, border: '1px solid #cbd5e1', bgcolor: '#f1f5f9', fontSize: '0.78rem', fontWeight: 600, color: '#102459', display: 'inline-block', whiteSpace: 'nowrap' }}>
          V{row.version}
        </Box>
      ),
    },
    {
      key: 'status', header: 'Status', width: '10%',
      render: (row: any) => <RuleStatusPill status={row.status} />,
    },
    {
      key: 'createdAt', header: 'Created At', width: '14%',
      render: (row: any) => {
        const ts = row.createdAt ?? row.created_at
        if (!ts) return <Typography sx={{ fontSize: '0.8125rem', color: '#64748b' }}>-</Typography>
        return (
          <Box>
            <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#102459' }}>
              {dayjs(ts).format('MMM D, YYYY')}
            </Typography>
            <Typography sx={{ fontSize: '0.75rem', color: '#64748b', mt: 0.25 }}>
              {dayjs(ts).format('HH:mm:ss')}
            </Typography>
          </Box>
        )
      },
    },
    {
      key: 'actions', header: 'Action', width: '10%', minWidth: 130, align: 'right', noClip: true,
      render: (row: any) => {
        const id = getRuleId(row)
        const statusKey = (row.status ?? '').toLowerCase()
        return (
          <Box display="flex" gap={0.25} justifyContent="flex-end">
            <Tooltip title="Edit">
              <IconButton size="small" sx={{ color: '#94a3b8', '&:hover': { color: '#2563eb', bgcolor: '#eff6ff' }, borderRadius: '6px' }}
                onClick={(e) => { e.stopPropagation(); history.push(`${POLICYOPS_PATH.RULES}/${id}/edit`) }} disabled={statusKey === 'archived'}>
                <Pencil size={15} />
              </IconButton>
            </Tooltip>
            <Tooltip title="View">
              <IconButton size="small" sx={{ color: '#94a3b8', '&:hover': { color: '#2563eb', bgcolor: '#eff6ff' }, borderRadius: '6px' }}
                onClick={(e) => { e.stopPropagation(); history.push(`${POLICYOPS_PATH.RULES}/${id}`) }}>
                <Eye size={15} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Clone">
              <IconButton size="small" sx={{ color: '#94a3b8', '&:hover': { color: '#2563eb', bgcolor: '#eff6ff' }, borderRadius: '6px' }}
                onClick={(e) => { e.stopPropagation(); handleClone(row) }}>
                <Copy size={15} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Delete">
              <IconButton size="small" sx={{ color: '#94a3b8', '&:hover': { color: '#dc2626', bgcolor: '#fef2f2' }, borderRadius: '6px' }}
                onClick={(e) => { e.stopPropagation(); setDeleteTarget(row) }}>
                <Trash2 size={15} />
              </IconButton>
            </Tooltip>
          </Box>
        )
      },
    },
  ]

  return (
    <Box p={2.5} sx={{ height: '100%', display: 'flex', flexDirection: 'column', boxSizing: 'border-box' }}>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1.5}>
        <Box>
          <Box display="flex" alignItems="center" gap={1}>
            <Typography variant="h5" fontWeight={700}>Rules Repository</Typography>
            <Box sx={{ px: 1, py: 0.15, bgcolor: '#eff6ff', borderRadius: '999px', border: '1px solid #dbeafe' }}>
              <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: '#2563eb' }}>{total}</Typography>
            </Box>
          </Box>
          <Typography variant="body2" color="text.secondary" mt={0.25}>A descriptive body text comes here</Typography>
        </Box>

        <Box display="flex" alignItems="center" gap={1.5}>
          <TextField
            size="small" placeholder="Search" value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(0) }}
            InputProps={{ startAdornment: <InputAdornment position="start"><Search size={15} color="#94a3b8" /></InputAdornment> }}
            sx={{ width: 220, '& .MuiOutlinedInput-root': { borderRadius: '999px', fontSize: '0.85rem', bgcolor: 'white', '& fieldset': { borderColor: '#e2e8f0' } } }}
          />
          <Tooltip title="Refresh">
            <IconButton size="small" onClick={() => refetch()} disabled={isFetching}
              sx={{ border: '1px solid #e2e8f0', borderRadius: '8px', color: '#64748b', bgcolor: 'white', p: '6px', '&:hover': { bgcolor: '#f8fafc', color: '#2563eb', borderColor: '#2563eb' } }}>
              <Box component="span" sx={{
                display: 'inline-flex',
                '@keyframes rfSpin': { from: { transform: 'rotate(0deg)' }, to: { transform: 'rotate(360deg)' } },
                animation: isFetching ? 'rfSpin 0.7s linear infinite' : 'none',
              }}>
                <RefreshCw size={15} />
              </Box>
            </IconButton>
          </Tooltip>
          <Button
            variant="outlined" size="small"
            startIcon={<SlidersHorizontal size={14} />}
            onClick={openFilter}
            sx={{ borderColor: activeFilterCount ? '#2563eb' : '#e2e8f0', color: activeFilterCount ? '#2563eb' : '#374151', fontSize: '0.85rem', bgcolor: 'white', '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' }, position: 'relative' }}
          >
            Filter{activeFilterCount > 0 ? ` (${activeFilterCount})` : ''}
          </Button>
          <Button
            variant="contained" size="small" endIcon={<Plus size={14} />}
            onClick={() => history.push(`${POLICYOPS_PATH.RULES}/new`)}
            sx={{ bgcolor: '#2563eb', fontSize: '0.85rem', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}
          >
            Configure Rule
          </Button>
        </Box>
      </Box>

      {/* Table */}
      <Box sx={{ flex: 1, minHeight: 0 }}>
        <PolicyTable
          columns={columns} rows={rules} total={total} page={page} pageSize={pageSize}
          onPageChange={setPage} onPageSizeChange={(s: number) => { setPageSize(s); setPage(0) }}
          loading={isLoading} error={isError} errorMessage="Failed to load rules"
          sx={{ height: '100%' }}
        />
      </Box>

      {/* ── Filter popover ────────────────────────────────────────────────── */}
      <Popover
        open={filterOpen}
        anchorEl={filterAnchorEl}
        onClose={closeFilter}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        PaperProps={{ sx: { mt: 1, width: 380, borderRadius: '12px', boxShadow: '0 8px 30px rgba(0,0,0,0.12)', border: '1px solid #e2e8f0', overflow: 'hidden' } }}
      >
        {/* header */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2.5, py: 2, borderBottom: '1px solid #f1f5f9' }}>
          <Typography sx={{ fontWeight: 700, fontSize: '0.9375rem', color: '#0f172a' }}>Filter</Typography>
          <IconButton size="small" onClick={closeFilter} sx={{ color: '#94a3b8', p: 0.5, '&:hover': { bgcolor: '#f1f5f9' } }}>
            <X size={15} />
          </IconButton>
        </Box>

        <Box sx={{ px: 2.5, py: 2, display: 'flex', flexDirection: 'column', gap: 2.5 }}>
          {/* Status */}
          <Box>
            <Typography sx={{ fontWeight: 600, fontSize: '0.8125rem', color: '#374151', mb: 1 }}>Status</Typography>
            <FormControl fullWidth size="small">
              <Select
                multiple displayEmpty
                value={pendingStatus}
                onChange={(e) => setPendingStatus(e.target.value as string[])}
                renderValue={(selected) =>
                  (selected as string[]).length === 0
                    ? <em style={{ color: '#94a3b8', fontStyle: 'normal' }}>Select</em>
                    : <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                        {(selected as string[]).map((v) => (
                          <Chip key={v} label={v.charAt(0).toUpperCase() + v.slice(1)} size="small"
                            sx={{ height: 20, fontSize: '0.75rem', bgcolor: '#eff6ff', color: '#2563eb', border: '1px solid #bfdbfe', borderRadius: '999px' }} />
                        ))}
                      </Box>
                }
                sx={{ borderRadius: '8px', fontSize: '0.875rem', bgcolor: 'white' }}
              >
                {['published', 'draft', 'archived'].map((v) => (
                  <MenuItem key={v} value={v} dense>
                    <Checkbox size="small" checked={pendingStatus.indexOf(v) > -1}
                      sx={{ p: 0.5, mr: 0.5, '&.Mui-checked': { color: '#2563eb' } }} />
                    <ListItemText primary={v.charAt(0).toUpperCase() + v.slice(1)} primaryTypographyProps={{ fontSize: '0.875rem' }} />
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>

          {/* Severity */}
          <Box>
            <Typography sx={{ fontWeight: 600, fontSize: '0.8125rem', color: '#374151', mb: 1 }}>Severity</Typography>
            <FormControl fullWidth size="small">
              <Select
                multiple displayEmpty
                value={pendingSeverity}
                onChange={(e) => setPendingSeverity(e.target.value as string[])}
                renderValue={(selected) =>
                  (selected as string[]).length === 0
                    ? <em style={{ color: '#94a3b8', fontStyle: 'normal' }}>Select</em>
                    : <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                        {(selected as string[]).map((v) => (
                          <Chip key={v} label={v.charAt(0).toUpperCase() + v.slice(1)} size="small"
                            sx={{ height: 20, fontSize: '0.75rem', bgcolor: '#eff6ff', color: '#2563eb', border: '1px solid #bfdbfe', borderRadius: '999px' }} />
                        ))}
                      </Box>
                }
                sx={{ borderRadius: '8px', fontSize: '0.875rem', bgcolor: 'white' }}
              >
                {['critical', 'high', 'medium', 'low'].map((v) => (
                  <MenuItem key={v} value={v} dense>
                    <Checkbox size="small" checked={pendingSeverity.indexOf(v) > -1}
                      sx={{ p: 0.5, mr: 0.5, '&.Mui-checked': { color: '#2563eb' } }} />
                    <ListItemText primary={v.charAt(0).toUpperCase() + v.slice(1)} primaryTypographyProps={{ fontSize: '0.875rem' }} />
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>

          {/* Check Type */}
          <Box>
            <Typography sx={{ fontWeight: 600, fontSize: '0.8125rem', color: '#374151', mb: 1 }}>Check Type</Typography>
            <FormControl fullWidth size="small">
              <Select displayEmpty value={pendingCheckType} onChange={(e) => setPendingCheckType(e.target.value)}
                sx={{ borderRadius: '8px', fontSize: '0.875rem', bgcolor: 'white' }}>
                <MenuItem value=""><em style={{ color: '#94a3b8', fontStyle: 'normal' }}>Select</em></MenuItem>
                {checkTypeOptions.map((opt) => <MenuItem key={opt.categoryCode} value={opt.name}>{opt.name}</MenuItem>)}
              </Select>
            </FormControl>
          </Box>

          {/* Category */}
          <Box>
            <Typography sx={{ fontWeight: 600, fontSize: '0.8125rem', color: '#374151', mb: 1 }}>Category</Typography>
            <FormControl fullWidth size="small">
              <Select displayEmpty value={pendingCategory} onChange={(e) => setPendingCategory(e.target.value)}
                sx={{ borderRadius: '8px', fontSize: '0.875rem', bgcolor: 'white' }}>
                <MenuItem value=""><em style={{ color: '#94a3b8', fontStyle: 'normal' }}>Select</em></MenuItem>
                {categoryOptions.map((cat) => <MenuItem key={cat} value={cat}>{cat}</MenuItem>)}
              </Select>
            </FormControl>
          </Box>
        </Box>

        {/* footer */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2.5, py: 2, borderTop: '1px solid #f1f5f9' }}>
          <Button variant="text" onClick={handleClearFilters}
            sx={{ color: '#2563eb', textTransform: 'none', fontWeight: 500, fontSize: '0.875rem', p: 0, '&:hover': { bgcolor: 'transparent', textDecoration: 'underline' } }}>
            Clear All
          </Button>
          <Button variant="contained" onClick={handleApplyFilters}
            sx={{ bgcolor: '#2563eb', textTransform: 'none', fontWeight: 600, fontSize: '0.875rem', px: 3, borderRadius: '8px', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}>
            Apply
          </Button>
        </Box>
      </Popover>

      {/* ── Delete confirm dialog ─────────────────────────────────────────── */}
      <Dialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: '16px', p: 1 } }}>
        <DialogContent sx={{ pt: 3.5, pb: 1, px: 3.5, textAlign: 'center' }}>
          <Box sx={{ width: 52, height: 52, borderRadius: '50%', bgcolor: '#fef2f2', border: '1px solid #fecaca', display: 'flex', alignItems: 'center', justifyContent: 'center', mx: 'auto', mb: 2 }}>
            <Trash2 size={22} color="#dc2626" />
          </Box>
          <Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a', mb: 1 }}>Delete Rule</Typography>
          <Typography sx={{ fontSize: '0.8375rem', color: '#64748b', lineHeight: 1.6 }}>
            Are you sure you want to delete <Box component="span" sx={{ fontWeight: 600, color: '#0f172a' }}>"{deleteTarget?.name}"</Box>?
            <br />This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3, pt: 2, gap: 1.5, justifyContent: 'center' }}>
          <Button variant="outlined" onClick={() => setDeleteTarget(null)} sx={{ borderColor: '#e2e8f0', color: '#475569', px: 3, borderRadius: '8px', textTransform: 'none', fontWeight: 500, '&:hover': { bgcolor: '#f8fafc' } }}>Cancel</Button>
          <Button variant="contained" onClick={handleDelete} disabled={deleting}
            sx={{ bgcolor: '#dc2626', px: 3, borderRadius: '8px', textTransform: 'none', fontWeight: 500, boxShadow: 'none', '&:hover': { bgcolor: '#b91c1c', boxShadow: 'none' } }}>
            {deleting ? 'Deleting…' : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default RulesPage
