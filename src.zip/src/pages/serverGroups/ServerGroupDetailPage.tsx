import React, { useCallback, useEffect, useMemo, useState } from 'react'
import {
  Alert, Box, Button, Chip, CircularProgress, IconButton, Paper, Stack, Tooltip, Typography,
} from '@mui/material'
import { ChevronLeft, Edit2 } from 'lucide-react'
import { useHistory, useParams } from 'react-router-dom'
import PolicyTable, { TableColumn } from '../../components/PolicyTable'
import { POLICYOPS_PATH } from '../../utils/constant'
import {
  PreviewServer,
  parseGroupRulesFromApi,
  parsePreviewServersResponse,
  resolveRuleLogic,
  resolveServerGroupRecord,
  toPreviewGroupRules,
  useGetServerGroupByIdQuery,
  usePreviewServerGroupServersMutation,
} from '../../redux/slices/serverGroupsSlice'

const SERVER_GROUPS_PATH = POLICYOPS_PATH.SERVER_GROUPS

const TAG_CHIP_SX = {
  borderRadius: '999px',
  bgcolor: '#eff6ff',
  color: '#2563eb',
  border: '1px solid #bfdbfe',
  fontSize: '0.75rem',
  fontWeight: 500,
  height: 22,
}

const TYPE_PILL: Record<string, { bg: string; color: string; border: string }> = {
  dynamic: { bg: '#eff6ff', color: '#2563eb', border: '#bfdbfe' },
  static: { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' },
}

const Pill: React.FC<{ label: string; map: Record<string, { bg: string; color: string; border: string }> }> = ({ label, map }) => {
  const key = (label ?? '').toLowerCase()
  const s = map[key] ?? { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' }
  return (
    <Box sx={{
      px: 1.5, py: 0.3, borderRadius: '999px',
      bgcolor: s.bg, color: s.color, border: `1px solid ${s.border}`,
      fontSize: '0.72rem', fontWeight: 600, display: 'inline-block', whiteSpace: 'nowrap',
    }}>
      {label || '—'}
    </Box>
  )
}

const InfoRow: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <Box display="flex" alignItems="flex-start" py={1} sx={{ '&:not(:last-child)': { borderBottom: '1px solid #f8fafc' } }}>
    <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', minWidth: 200, flexShrink: 0 }}>{label}</Typography>
    <Box flex={1}>
      {typeof value === 'string'
        ? <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#102459', wordBreak: 'break-word' }}>{value}</Typography>
        : value}
    </Box>
  </Box>
)

const SectionCard: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <Paper elevation={0} sx={{ borderRadius: '12px', border: '1px solid #e2e8f0', bgcolor: 'white', overflow: 'hidden' }}>
    <Box sx={{ px: 3.5, pt: 3, pb: 3.5 }}>
      <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#102459', mb: 1.75 }}>{title}</Typography>
      {children}
    </Box>
  </Paper>
)

const formatKey = (key: string) =>
  key
    .replace(/([a-z\d])([A-Z])/g, '$1 $2')
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2')
    .replace(/_/g, ' ')
    .replace(/^[a-z]/, (c) => c.toUpperCase())

const formatRuleLogicLabel = (logic?: string) => {
  const upper = String(logic ?? 'AND').toUpperCase()
  return upper === 'OR' || upper === 'ANY' ? 'OR (Match ANY)' : 'AND (Match ALL)'
}

const formatOperatorLabel = (operator: string) =>
  operator.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase())

const PREVIEW_SERVER_COLUMNS: { key: keyof PreviewServer; label: string }[] = [
  { key: 'hostname', label: 'Hostname' },
  { key: 'region', label: 'Region' },
  { key: 'environment', label: 'Environment' },
  { key: 'service', label: 'Service' },
  { key: 'sid', label: 'SID' },
  { key: 'application', label: 'Application' },
  { key: 'businessService', label: 'Business Service' },
  { key: 'owner', label: 'Owner' },
  { key: 'serverType', label: 'Server Type' },
  { key: 'os', label: 'OS' },
  { key: 'status', label: 'Status' },
  { key: 'createdDate', label: 'Created Date' },
  { key: 'lastUpdated', label: 'Last Updated' },
]

const formatPreviewDate = (value?: string): string => {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleString()
}

const formatPreviewCell = (key: keyof PreviewServer, server: PreviewServer): string => {
  const value = server[key] ?? (key === 'environment' ? server.env : undefined)
  if (value === undefined || value === null || value === '') return '—'
  if (key === 'createdDate' || key === 'lastUpdated') return formatPreviewDate(String(value))
  return String(value)
}

const TruncatedCell: React.FC<{ value: string }> = ({ value }) => (
  <Tooltip title={value} arrow placement="top" disableHoverListener={value === '—'}>
    <Typography
      variant="body2"
      color="text.secondary"
      noWrap
      sx={{ overflow: 'hidden', textOverflow: 'ellipsis', display: 'block', width: '100%' }}
    >
      {value}
    </Typography>
  </Tooltip>
)

const buildServerColumns = (): TableColumn[] =>
  PREVIEW_SERVER_COLUMNS.map((col) => ({
    key: col.key,
    header: col.label,
    width: col.key === 'hostname' ? 200 : undefined,
    minWidth: col.key === 'hostname' ? 200 : col.key === 'businessService' ? 160 : 120,
    render: (row: PreviewServer) => (
      <TruncatedCell value={formatPreviewCell(col.key, row)} />
    ),
  }))

const formatType = (raw?: string) => {
  if (!raw) return '—'
  const lower = raw.toLowerCase()
  if (lower === 'dynamic') return 'Dynamic'
  if (lower === 'static') return 'Static'
  return raw
}

const ServerGroupDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>()
  const history = useHistory()
  const [previewPage, setPreviewPage] = useState(0)
  const [previewPageSize, setPreviewPageSize] = useState(10)
  const [previewServers, setPreviewServers] = useState<PreviewServer[]>([])
  const [previewTotal, setPreviewTotal] = useState(0)
  const [previewError, setPreviewError] = useState('')

  const { data, isLoading, isFetching, isError } = useGetServerGroupByIdQuery(id!)
  const [previewServersApi, { isLoading: previewLoading }] = usePreviewServerGroupServersMutation()

  const serverColumns = useMemo(() => buildServerColumns(), [])

  const group = useMemo(() => resolveServerGroupRecord(data), [data])
  const groupRules = useMemo(() => parseGroupRulesFromApi(group), [group])
  const ruleLogic = useMemo(() => resolveRuleLogic(group), [group])

  const loadPreview = useCallback(async (page: number, pageSize: number) => {
    if (!group) return
    setPreviewError('')
    try {
      const result = await previewServersApi({
        groupRules: toPreviewGroupRules(groupRules),
        ruleLogic,
        page: page + 1,
        limit: pageSize,
      }).unwrap()
      const { servers, total } = parsePreviewServersResponse(result)
      setPreviewServers(servers)
      setPreviewTotal(total)
    } catch {
      setPreviewServers([])
      setPreviewTotal(0)
      setPreviewError('Failed to load matching servers.')
    }
  }, [group, groupRules, previewServersApi, ruleLogic])

  useEffect(() => {
    setPreviewPage(0)
    setPreviewServers([])
    setPreviewTotal(0)
    setPreviewError('')
  }, [id])

  useEffect(() => {
    if (!group || isLoading) return
    loadPreview(previewPage, previewPageSize)
  }, [group, isLoading, previewPage, previewPageSize, loadPreview])

  if (isLoading || (isFetching && !group?.name)) {
    return (
      <Box sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress />
      </Box>
    )
  }

  if (isError || !group?.name) {
    return (
      <Box p={3}>
        <Alert severity="error">Server group not found</Alert>
      </Box>
    )
  }

  const groupType = formatType(String(group.groupType ?? group.type ?? group.group_type ?? ''))
  const tags: string[] = Array.isArray(group.tags) ? group.tags.map(String) : []

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', bgcolor: '#ffffff' }}>

      {/* Top bar */}
      <Box sx={{ bgcolor: '#ffffff', borderBottom: '1px solid #e2e8f0', px: 3, pt: 1.5, pb: 1.5 }}>
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Box display="flex" alignItems="center" gap={1}>
            <IconButton
              size="small"
              onClick={() => history.push(SERVER_GROUPS_PATH)}
              sx={{ color: '#64748b', border: '1px solid #e2e8f0', borderRadius: '8px', p: '4px', '&:hover': { bgcolor: '#f8fafc', color: '#102459' } }}
            >
              <ChevronLeft size={16} />
            </IconButton>
            <Box>
              <Typography
                variant="caption"
                sx={{ color: '#2563eb', cursor: 'pointer', fontWeight: 500, display: 'block', lineHeight: 1.4, '&:hover': { textDecoration: 'underline' } }}
                onClick={() => history.push(SERVER_GROUPS_PATH)}
              >
                Server Groups
              </Typography>
              <Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: '#102459', lineHeight: 1.2 }}>
                {group.name}
              </Typography>
            </Box>
          </Box>

          <Box display="flex" gap={1} alignItems="center">
            <Button
              size="small"
              variant="outlined"
              endIcon={<Edit2 size={14} />}
              sx={{ borderColor: '#e2e8f0', color: '#374151', fontWeight: 500, fontSize: '0.875rem', textTransform: 'none', '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' } }}
              onClick={() => history.push(`${SERVER_GROUPS_PATH}/${id}/edit`)}
            >
              Modify
            </Button>
          </Box>
        </Box>
      </Box>

      {/* Body — wizard steps as sections */}
      <Box sx={{ flex: 1, overflowY: 'auto', bgcolor: '#f8fafc', p: 3 }}>
        <Box display="flex" flexDirection="column" gap={2}>

          {/* Step 1: Basic Info */}
          <SectionCard title="Basic Information">
            <InfoRow label="Group Name" value={String(group.name || '-')} />
            <InfoRow label="Group Type" value={<Pill label={groupType} map={TYPE_PILL} />} />
            <InfoRow label="Description" value={String(group.description || '-')} />
            <InfoRow label="Rule Logic" value={formatRuleLogicLabel(String(group.ruleLogic ?? group.rule_logic ?? ''))} />
            {tags.length > 0 && (
              <InfoRow
                label="Tags"
                value={(
                  <Stack direction="row" flexWrap="wrap" gap={0.75}>
                    {tags.map((tag) => (
                      <Chip key={tag} label={tag} size="small" sx={TAG_CHIP_SX} />
                    ))}
                  </Stack>
                )}
              />
            )}
          </SectionCard>

          {/* Step 2: Define Rules */}
          <SectionCard title="Define Rules">
            {groupRules.length > 0 ? (
              groupRules.map((rule, index) => (
                <InfoRow
                  key={`${rule.field}-${index}`}
                  label={`Condition ${index + 1}`}
                  value={`${formatKey(rule.field)} ${formatOperatorLabel(rule.operator)} ${rule.values.length ? rule.values.join(', ') : '—'}`}
                />
              ))
            ) : (
              <Typography sx={{ fontSize: '0.8125rem', color: '#94a3b8', fontStyle: 'italic' }}>
                No rules defined for this group.
              </Typography>
            )}
          </SectionCard>

          {/* Step 3: Matching Servers */}
          <Paper elevation={0} sx={{ borderRadius: '12px', border: '1px solid #e2e8f0', bgcolor: 'white', overflow: 'hidden', p: 2.5 }}>
            <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#102459', mb: 0.5 }}>
              Matching Servers
            </Typography>
            <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', mb: 2 }}>
              {previewLoading ? 'Loading matching servers…' : `${previewTotal} server(s) match your rules`}
            </Typography>
            <PolicyTable
              columns={serverColumns}
              rows={previewServers}
              total={previewTotal}
              page={previewPage}
              pageSize={previewPageSize}
              onPageChange={setPreviewPage}
              onPageSizeChange={(size) => { setPreviewPageSize(size); setPreviewPage(0) }}
              loading={previewLoading}
              error={!!previewError}
              errorMessage={previewError || 'Failed to load matching servers'}
              emptyMessage="No matching servers found."
              getRowId={(row: PreviewServer) => row.hostname}
              sx={{ border: 'none' }}
            />
          </Paper>

        </Box>
      </Box>
    </Box>
  )
}

export default ServerGroupDetailPage
