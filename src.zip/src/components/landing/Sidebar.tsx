import React, { useState } from 'react'
import {
  Box, Divider, IconButton, List, ListItemButton,
  ListItemIcon, ListItemText, Tooltip, Typography,
} from '@mui/material'
import { ChevronsLeft, ChevronsRight, BarChart2, Server, ShieldAlert, Rocket } from "lucide-react";
import { useHistory, useLocation } from 'react-router-dom'
import { POLICYOPS_PATH } from '../../utils/constant'
import { useSelector } from 'react-redux'
import { hasModuleAccess, MODULE_LIST } from '../../utils/permissionsUtil'
import { RootState } from '../../redux/store'
import LogsGrey from "../../assets/sidebarIcon/LogsGrey.svg"
import LogsBlue from "../../assets/sidebarIcon/LogsBlue.svg"
import rulesGrey from "../../assets/sidebarIcon/rulesGrey.svg"
import rulesBlue from "../../assets/sidebarIcon/rulesBlue.svg"
import PolicyGrey from "../../assets/sidebarIcon/PolicyGrey.svg"
import PolicyBlue from "../../assets/sidebarIcon/PolicyBlue.svg"
import PolicyGroupGrey from "../../assets/sidebarIcon/PolicyGroupGrey.svg"
import PolicyGroupBlue from "../../assets/sidebarIcon/PolicyGroupBlue.svg"
import AssignnmentGrey from "../../assets/sidebarIcon/AssignnmentGrey.svg"
import AssignnmentBlue from "../../assets/sidebarIcon/AssignnmentBlue.svg"
import HomeGrey from "../../assets/sidebarIcon/HomeGrey.svg"
import HomeBlue from "../../assets/sidebarIcon/HomeBlue.svg"
import chatbotGrey from "../../assets/sidebarIcon/chatbotGrey.svg"
import chatbotBlue from "../../assets/sidebarIcon/chatbotBlue.svg"
import AuditGrey from "../../assets/sidebarIcon/AuditGrey.svg"
import AuditBlue from "../../assets/sidebarIcon/AuditBlue.svg"

const COLLAPSED_WIDTH = 56
const EXPANDED_WIDTH = 220

const ACTIVE_BG = '#eff6ff'
const ACTIVE_COLOR = '#2563eb'
const INACTIVE_COLOR = '#64748b'
const HOVER_BG = '#f8fafc'
const SECTION_LABEL_COLOR = '#94a3b8'

interface NavItem {
  label: string
  path: string
  module: string
  disabled?: boolean
  // SVG-file-based icons (most items)
  activeIcon?: string
  inactiveIcon?: string
  // Lucide-React icon rendered inline (no SVG file needed)
  lucideIcon?: React.ReactNode
}

// Operation section
const operationItems: NavItem[] = [
  {
    label: 'Executive Overview',
    lucideIcon: <BarChart2 size={20} />,
    path: POLICYOPS_PATH.SAP_BUSINESS_VALUE,
    module: MODULE_LIST.DASHBOARD,
  },
  {
    label: 'Dashboard', activeIcon: HomeBlue,
    inactiveIcon: HomeGrey, path: POLICYOPS_PATH.DASHBOARD, module: MODULE_LIST.DASHBOARD
  },
  {
    label: 'Drift', activeIcon: LogsBlue,
    inactiveIcon: LogsGrey, path: POLICYOPS_PATH.DRIFT, module: MODULE_LIST.COMPLIANCE
  },
  {
    label: 'Audit', activeIcon: AuditBlue,
    inactiveIcon: AuditGrey, path: POLICYOPS_PATH.AUDIT, module: MODULE_LIST.AUDIT
  },
  {
    label: 'ConfigSphere Assistant', activeIcon: chatbotGrey,
    inactiveIcon: chatbotBlue, path: '/chat', module: MODULE_LIST.DASHBOARD,
  },
  {
    label: 'Exception Hub',
    lucideIcon: <ShieldAlert size={20} />,
    path: POLICYOPS_PATH.EXCEPTION_HUB,
    module: MODULE_LIST.DASHBOARD,
  },
  {
    label: 'Migration Center',
    lucideIcon: <Rocket size={20} />,
    path: POLICYOPS_PATH.MIGRATION_CENTER,
    module: MODULE_LIST.DASHBOARD,
  },
]

// Configuration section — Rules, Policy, Policy Group, Assignment
const configItems: NavItem[] = [
  {
    label: 'Rules', activeIcon: rulesBlue,
    inactiveIcon: rulesGrey, path: POLICYOPS_PATH.RULES, module: MODULE_LIST.RULES
  },
  {
    label: 'Policy', activeIcon: PolicyBlue,
    inactiveIcon: PolicyGrey, path: POLICYOPS_PATH.POLICIES, module: MODULE_LIST.POLICIES
  },
  {
    label: 'Policy Group', activeIcon: PolicyGroupBlue,
    inactiveIcon: PolicyGroupGrey, path: POLICYOPS_PATH.POLICY_GROUPS, module: MODULE_LIST.POLICY_GROUPS
  },
  {
    label: 'Server Groups',
    lucideIcon: <Server size={20} />,
    path: POLICYOPS_PATH.SERVER_GROUPS,
    module: MODULE_LIST.SERVER_GROUPS ?? MODULE_LIST.POLICY_GROUPS,
  },
  {
    label: 'Assignment', activeIcon: AssignnmentBlue,
    inactiveIcon: AssignnmentGrey, path: POLICYOPS_PATH.ASSIGNMENTS, module: MODULE_LIST.ASSIGNMENTS
  },
]

const Sidebar: React.FC = () => {
  const [expanded, setExpanded] = useState(false)
  const history = useHistory()
  const location = useLocation()
  const permissions = useSelector((state: RootState) => state.permissions.permissions)

  const isActive = (path: string) => location.pathname.startsWith(path)

  const navItemSx = (active: boolean, disabled?: boolean) => ({
    minHeight: 36,
    px: expanded ? 1.5 : 0,
    justifyContent: expanded ? 'flex-start' : 'center',
    borderRadius: 1,
    mx: 0.75,
    mb: 0,
    position: 'relative',
    opacity: disabled ? 0.4 : 1,
    color: active ? ACTIVE_COLOR : INACTIVE_COLOR,
    bgcolor: active ? ACTIVE_BG : 'transparent',
    '&::before': active ? {
      content: '""',
      position: 'absolute',
      left: 0,
      top: '20%',
      height: '60%',
      width: 3,
      bgcolor: ACTIVE_COLOR,
      borderRadius: '0 2px 2px 0',
    } : {},
    '&:hover': {
      bgcolor: disabled ? 'transparent' : active ? ACTIVE_BG : HOVER_BG,
      color: disabled ? INACTIVE_COLOR : active ? ACTIVE_COLOR : '#1e293b',
    },
  })

  const renderItem = (item: NavItem) => {
    if (!hasModuleAccess(permissions, item.module)) return null
    const active = isActive(item.path)

    const iconNode = item.lucideIcon ? (
      // Lucide icon — inherits `color` from the ListItemButton via currentColor
      item.lucideIcon
    ) : (
      <img
        src={active ? item.activeIcon : item.inactiveIcon}
        alt={item.label}
        width={20}
        height={20}
      />
    )

    const btn = (
      <ListItemButton
        key={item.path}
        onClick={() => !item.disabled && history.push(item.path)}
        sx={navItemSx(active, item.disabled)}
        disableRipple={!!item.disabled}
      >
        <ListItemIcon sx={{
          minWidth: expanded ? 36 : 'unset',
          justifyContent: 'center',
          color: 'inherit',
        }}>
          {iconNode}
        </ListItemIcon>
        {expanded && (
          <ListItemText
            primary={item.disabled ? `${item.label} (soon)` : item.label}
            primaryTypographyProps={{
              variant: 'body2',
              fontWeight: active ? 600 : 400,
              noWrap: true,
            }}
          />
        )}
      </ListItemButton>
    )

    const tooltipTitle = item.disabled ? `${item.label} — coming soon` : item.label
    return expanded ? btn : (
      <Tooltip key={item.path} title={tooltipTitle} placement="right" arrow>
        {btn}
      </Tooltip>
    )
  }

  const sectionLabel = (text: string) =>
    expanded ? (
      <Typography
        variant="caption"
        sx={{
          color: SECTION_LABEL_COLOR, fontWeight: 600, letterSpacing: '0.06em',
          px: 2.25, pt: 1, pb: 0.25, display: 'block',
          textTransform: 'uppercase', fontSize: '0.65rem',
        }}
      >
        {text}
      </Typography>
    ) : null

  return (
    <Box
      sx={{
        width: expanded ? EXPANDED_WIDTH : COLLAPSED_WIDTH,
        height: '100%',
        flexShrink: 0,
        bgcolor: 'white',
        borderRight: '1px solid #e2e8f0',
        borderRadius: 0,
        display: 'flex',
        flexDirection: 'column',
        transition: 'width 0.2s ease',
        overflow: 'hidden',
      }}
    >
      {/* ── Nav items ── */}
      <Box sx={{
        flex: 1,
        overflowY: 'auto',
        overflowX: 'hidden',
        pt: 0.5,
        scrollbarWidth: expanded ? 'auto' : 'none',
        '&::-webkit-scrollbar': { display: expanded ? 'block' : 'none' },
      }}>

        {/* Operation */}
        <List disablePadding>
          {sectionLabel('Operation')}
          {operationItems.map(renderItem)}
        </List>

        {/* Thin line separator */}
        <Divider sx={{ mx: 1, my: 0.5 }} />

        {/* Configuration */}
        <List disablePadding>
          {sectionLabel('Configuration')}
          {configItems.map(renderItem)}
        </List>

      </Box>

      {/* ── Collapse toggle ── */}
      <Box sx={{ borderTop: '1px solid #e2e8f0', py: 0.5 }}>
        <Box
          display="flex"
          justifyContent={expanded ? 'flex-end' : 'center'}
          px={expanded ? 1 : 0}
        >
          <Tooltip title={expanded ? 'Collapse' : 'Expand'} placement="right">
            <IconButton
              size="small"
              onClick={() => setExpanded((prev) => !prev)}
              disableRipple
              sx={{
                color: SECTION_LABEL_COLOR,
                bgcolor: 'transparent',
                '&:hover': { color: '#1e293b', bgcolor: 'transparent' },
                '&.Mui-focusVisible': { bgcolor: 'transparent' },
              }}
            >
              {expanded ? <ChevronsLeft size={18} /> : <ChevronsRight size={18} />}
            </IconButton>
          </Tooltip>
        </Box>
      </Box>
    </Box>
  )
}

export default Sidebar
