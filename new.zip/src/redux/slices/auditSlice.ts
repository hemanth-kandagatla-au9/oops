import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const auditSlice = createApi({
  reducerPath: "auditApi",
  baseQuery,
  tagTypes: ["AuditLog"],
  endpoints: (builder) => ({
    getAuditLogs: builder.query<any, {
      page?: number; limit?: number;
      module?: string; request_method?: string;
      requested_by?: string; search?: string;
      from_date?: string; to_date?: string;
    }>({
      query: ({ page = 1, limit = 10, module, request_method, requested_by, search, from_date, to_date }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (module) params.append("module", module);
        if (request_method) params.append("request_method", request_method);
        if (requested_by) params.append("requested_by", requested_by);
        if (search) params.append("search", search);
        if (from_date) params.append("from_date", from_date);
        if (to_date) params.append("to_date", to_date);
        return `/audit?${params.toString()}`;
      },
      providesTags: ["AuditLog"],
    }),
    getAuditById: builder.query<any, string>({
      query: (id) => `/audit/${id}`,
      providesTags: (_result, _error, id) => [{ type: "AuditLog", id }],
    }),
    exportAudit: builder.query<any, { format?: string }>({
      query: ({ format = "json" }) => `/audit/export?format=${format}`,
    }),
    getAuditUsers: builder.query<any, void>({
      query: () => `/audit/user`,
    }),
  }),
});

export const {
  useGetAuditLogsQuery,
  useGetAuditByIdQuery,
  useExportAuditQuery,
  useGetAuditUsersQuery,
} = auditSlice;
