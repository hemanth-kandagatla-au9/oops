import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export type DriftLogQueryParams = {
  page?: number;
  limit?: number;
  status?: string;
  severity?: string;
  hostname?: string;
  search?: string;
  driftDetected?: boolean;
  region?: string;
  os?: string;
  sid?: string;
  owner?: string;
  application?: string;
  environment?: string;
  ruleId?: string;
  ruleName?: string;
  ruleType?: string;
  policyId?: string;
  policyName?: string;
  executionStatus?: string;
  businessUnit?: string;
  assignmentName?: string;
  assignmentId?: string;
  filePath?: string;
  serviceName?: string;
  actionTaken?: string;
};

const appendDriftLogFilters = (params: URLSearchParams, filters: DriftLogQueryParams) => {
  const {
    status,
    severity,
    hostname,
    search,
    driftDetected,
    region,
    os,
    sid,
    owner,
    application,
    environment,
    ruleId,
    ruleName,
    ruleType,
    policyId,
    policyName,
    executionStatus,
    businessUnit,
    assignmentName,
    assignmentId,
    filePath,
    serviceName,
    actionTaken,
  } = filters;
  if (status) params.append("status", status);
  if (severity) params.append("severity", severity);
  if (hostname) params.append("hostname", hostname);
  if (search) params.append("search", search);
  if (driftDetected !== undefined) params.append("driftDetected", String(driftDetected));
  if (region) params.append("region", region);
  if (os) params.append("os", os);
  if (sid) params.append("sid", sid);
  if (owner) params.append("owner", owner);
  if (application) params.append("application", application);
  if (environment) params.append("environment", environment);
  if (ruleId) params.append("ruleId", ruleId);
  if (ruleName) params.append("ruleName", ruleName);
  if (ruleType) params.append("ruleType", ruleType);
  if (policyId) params.append("policyId", policyId);
  if (policyName) params.append("policyName", policyName);
  if (executionStatus) params.append("executionStatus", executionStatus);
  if (businessUnit) params.append("businessUnit", businessUnit);
  if (assignmentName) params.append("assignmentName", assignmentName);
  if (assignmentId) params.append("assignmentId", assignmentId);
  if (filePath) params.append("filePath", filePath);
  if (serviceName) params.append("serviceName", serviceName);
  if (actionTaken) params.append("actionTaken", actionTaken);
};

export const complianceSlice = createApi({
  reducerPath: "complianceApi",
  baseQuery,
  tagTypes: ["Compliance"],
  endpoints: (builder) => ({
    getComplianceRecords: builder.query<any, { page?: number; limit?: number; status?: string }>({
      query: ({ page = 1, limit = 10, status }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (status) params.append("status", status);
        return `/compliance?${params.toString()}`;
      },
      providesTags: ["Compliance"],
    }),
    getComplianceSummary: builder.query<any, void>({
      query: () => "/compliance/summary",
    }),
    getComplianceById: builder.query<any, string>({
      query: (id) => `/compliance/${id}`,
    }),
    createComplianceRecord: builder.mutation<any, Partial<any>>({
      query: (body) => ({ url: "/compliance", method: "POST", body }),
      invalidatesTags: ["Compliance"],
    }),
    getDashboardSummary: builder.query<any, void>({
      query: () => "/dashboard/summary",
    }),
    getComplianceTrend: builder.query<any, void>({
      query: () => "/compliance/trend",
    }),
    getDriftEvents: builder.query<any, DriftLogQueryParams>({
      query: ({ page = 1, limit = 10, ...filters }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        appendDriftLogFilters(params, filters);
        return `/drift-logs?${params.toString()}`;
      },
    }),
    getDriftLogMetrics: builder.query<any, Omit<DriftLogQueryParams, "page" | "limit">>({
      query: (filters) => {
        const params = new URLSearchParams();
        appendDriftLogFilters(params, filters);
        return `/drift-logs/metrics?${params.toString()}`;
      },
    }),
    getDriftLogFilters: builder.query<any, void>({
      query: () => "/drift-logs/filters-data",
    }),
    postCommandLogs: builder.mutation<
      any,
      { hostname: string; command: string }
    >({
      query: ({ hostname, command }) => {
        const params = new URLSearchParams();
        if (hostname) params.append("hostname", hostname);
        if (command) params.append("command", command);
        return {
          url: `/drift-logs/command-logs?${params.toString()}`,
          method: "POST",
          body: { hostname, command },
        };
      },
    }),
    getRemediationEvents: builder.query<any, { page?: number; limit?: number }>({
      query: ({ page = 1, limit = 10 }) =>
        `/remediation-events?page=${page}&limit=${limit}`,
    }),
  }),
});

export const {
  useGetComplianceRecordsQuery,
  useGetComplianceSummaryQuery,
  useGetComplianceByIdQuery,
  useCreateComplianceRecordMutation,
  useGetDashboardSummaryQuery,
  useGetComplianceTrendQuery,
  useGetDriftEventsQuery,
  useGetDriftLogMetricsQuery,
  useGetDriftLogFiltersQuery,
  usePostCommandLogsMutation,
  useGetRemediationEventsQuery,
} = complianceSlice;
