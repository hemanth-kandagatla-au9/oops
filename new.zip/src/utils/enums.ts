import { Key, ReactNode } from "react"

export enum PolicyStatus {
  DRAFT = "draft",
  PUBLISHED = "published",
  ARCHIVED = "archived",
  ACTIVE = "active",
  STAGING = "staging",
}

export type PolicyEnvironment = 'Production' | 'Staging' | 'Development'

export interface PolicyRule {
  id: Key | null | undefined
  name: ReactNode
  description: ReactNode
  severity: RuleSeverity
  rule_id: string
  checkType?: string
  rule_version: number
  order: number
}

export interface StatsOverview {
  totalPolicies: number
  policiesDelta: string | undefined
  totalRules: null
  rulesDelta: string | undefined
  assignedSystems: null
  systemsDelta: string | undefined
  complianceCoverage: null
  coverageDelta: string | undefined
  policies: number
  policies_delta: number
  rules: number
  rules_delta: number
  assigned_systems: number
  systems_delta: number
  compliance_coverage: number
  compliance_delta: number
}

export interface Rule {
  id: string
  rule_id?: string
  version?: number
  status?: string
  name: string
  description?: string
  rule_type?: string        // 'File' | 'Package' | 'Service' | 'Script'
  severity: string          // RuleSeverity
  definition?: Record<string, any>
  execution?: Record<string, any>
  created_by?: string
  created_at?: string
  updated_at?: string
  checkType?: string
  tags?: string[]
  versionNumber?: number
}

export interface ExecutionInfo{
executionMode: string
failureHandling: string
}

export interface Policy {
  _id: string
  policy_id: string
  version: number
  name: string
  description: string
  status: PolicyStatus
  environment: PolicyEnvironment
  executionInfo: ExecutionInfo
  owner: string
  rules: PolicyRule[]
  created_by: string
  created_at: string
  updated_at: string
  updated_by?: string
  published_by?: string
  published_at?: string
  tags: string[]

  // Derived UI fields
  compliance_coverage: number
  compliance_impact: 'High' | 'Medium' | 'Low'
  risk_reduction: number
  systems_protected: number
  assignments: number
  servers: string[]
}

export enum RuleStatus {
  DRAFT = "draft",
  PUBLISHED = "published",
  ARCHIVED = "archived",
}

export enum RuleSeverity {
  LOW = "low",
  MEDIUM = "medium",
  HIGH = "high",
  CRITICAL = "critical",
}

export enum ComplianceStatus {
  COMPLIANT = "compliant",
  NON_COMPLIANT = "non_compliant",
  PENDING = "pending",
  TOTAL = "total",
}

export enum AssignmentStatus {
  DRAFT = "draft",
  PUBLISHED = "published",
  ARCHIVED = "archived",
}

export enum EnforcementMode {
  AUDIT = "audit",
  MONITOR = "monitor",
  ENFORCE = "enforce",
}

export enum AgentStatus {
  ONLINE = "online",
  STALE = "stale",
  OFFLINE = "offline",
}
