import React, { useState } from 'react'
import {
  Box, Typography, Button, Chip, CircularProgress, Alert, Paper,
  Grid, Tab, Tabs, IconButton,
} from '@mui/material'
import { DataGrid, GridColDef } from '@mui/x-data-grid'
import { ArrowLeft, RefreshCw } from 'lucide-react'
import { useHistory, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'
import {
  useGetAgentByIdQuery,
  useGetExecutionHistoryQuery,
  useSyncAgentMutation,
} from '../../redux/slices/agentsSlice'
import DetailSkeleton from '../../components/DetailSkeleton'
import { POLICYOPS_PATH } from '../../utils/constant'

dayjs.extend(relativeTime)

const STATUS_COLORS: Record<string, any> = { online: 'success', stale: 'warning', offline: 'error' }
const EXEC_STATUS_COLORS: Record<string, any> = { passed: 'success', failed: 'error', timeout: 'warning' }

interface TabPanelProps { children?: React.ReactNode; value: number; index: number }
const TabPanel: React.FC<TabPanelProps> = ({ children, value, index }) => (
  <Box hidden={value !== index} pt={2}>{value === index && children}</Box>
)

const InfoRow: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <Box display="flex" py={1.5} borderBottom="1px solid" borderColor="divider" alignItems="flex-start">
    <Typography variant="body2" color="text.secondary" sx={{ minWidth: 180, fontWeight: 500, flexShrink: 0 }}>{label}</Typography>
    <Box flex={1}>{typeof value === 'string' ? <Typography variant="body2">{value}</Typography> : value}</Box>
  </Box>
)

const AgentDetailPage: React.FC = () => {
  const { hostname } = useParams<{ hostname: string }>()
  const history = useHistory()
  const [tab, setTab] = useState(0)
  const [execPage, setExecPage] = useState(0)

  const { data, isLoading, isError, refetch: refetchAgent } = useGetAgentByIdQuery(hostname)
  const { data: execData, isLoading: execLoading, refetch: refetchExec } = useGetExecutionHistoryQuery(
    { hostname, page: execPage + 1, limit: 10 },
    { skip: tab !== 1 }
  )
  const [syncAgent, { isLoading: syncing }] = useSyncAgentMutation()

  const agent = data?.data
  const execHistory = execData?.data ?? []
  const execTotal = execData?.total ?? 0

  const handleSync = async () => {
    if (!agent) return
    try {
      await syncAgent(agent._id).unwrap()
      toast.success(`Sync initiated for ${agent.hostname}`)
      refetchAgent()
    } catch {
      toast.error('Sync failed.')
    }
  }

  const execColumns: GridColDef[] = [
    {
      field: 'rule_id', headerName: 'Rule', flex: 1, minWidth: 140,
      renderCell: (params) => (
        <Typography variant="body2" color="primary" sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}
          onClick={() => history.push(`${POLICYOPS_PATH.RULES}/${params.value}`)}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'rule_version', headerName: 'Rule v', width: 80,
      renderCell: (params) => <Typography variant="body2" color="text.secondary">v{params.value}</Typography>,
    },
    {
      field: 'status', headerName: 'Result', width: 110,
      renderCell: (params) => (
        <Chip label={params.value} size="small" color={EXEC_STATUS_COLORS[params.value] ?? 'default'} />
      ),
    },
    {
      field: 'start_time', headerName: 'Started', width: 160,
      renderCell: (params) => (
        <Typography variant="body2" color="text.secondary">
          {dayjs(params.value).format('MMM D HH:mm:ss')}
        </Typography>
      ),
    },
    {
      field: 'duration', headerName: 'Duration', width: 100,
      renderCell: (params) => (
        <Typography variant="body2" color="text.secondary">
          {params.value ? `${(params.value / 1000).toFixed(1)}s` : '—'}
        </Typography>
      ),
    },
    {
      field: 'output', headerName: 'Output', flex: 1.5, minWidth: 200,
      renderCell: (params) => (
        <Typography variant="body2" color="text.secondary" noWrap title={params.value}>
          {params.value || '—'}
        </Typography>
      ),
    },
  ]

  if (isLoading) return <DetailSkeleton />
  if (isError || !agent) return <Box p={3}><Alert severity="error">Agent not found</Alert></Box>

  const isOnline = agent.status === 'online'
  const heartbeatAge = dayjs().diff(dayjs(agent.last_heartbeat), 'minute')

  return (
    <Box p={3}>
      {/* Breadcrumb */}
      <Box display="flex" alignItems="center" gap={1} mb={2}>
        <IconButton size="small" onClick={() => history.push(POLICYOPS_PATH.AGENTS)}><ArrowLeft size={18} /></IconButton>
        <Typography variant="body2" color="text.secondary"
          sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}
          onClick={() => history.push(POLICYOPS_PATH.AGENTS)}>Agents</Typography>
        <Typography variant="body2" color="text.secondary">/</Typography>
        <Typography variant="body2">{agent.hostname}</Typography>
      </Box>

      {/* Header */}
      <Paper elevation={0} variant="outlined" sx={{ p: 3, mb: 3, borderRadius: 2 }}>
        <Box display="flex" justifyContent="space-between" alignItems="flex-start" flexWrap="wrap" gap={2}>
          <Box>
            <Box display="flex" alignItems="center" gap={1.5} mb={1} flexWrap="wrap">
              <Typography variant="h5" fontWeight="bold">{agent.hostname}</Typography>
              <Chip label={agent.status} size="small" color={STATUS_COLORS[agent.status] ?? 'default'} />
              <Chip label={`v${agent.agent_version}`} size="small" variant="outlined" />
              <Chip label={agent.environment} size="small" variant="outlined" />
            </Box>
            <Box display="flex" gap={3} flexWrap="wrap">
              <Box>
                <Typography variant="caption" color="text.secondary">Last heartbeat</Typography>
                <Typography variant="body2" fontWeight={500} color={heartbeatAge > 60 ? 'error.main' : 'text.primary'}>
                  {dayjs(agent.last_heartbeat).fromNow()}
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">Last sync</Typography>
                <Typography variant="body2" fontWeight={500}>{dayjs(agent.last_sync).fromNow()}</Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">Assignments</Typography>
                <Typography variant="body2" fontWeight={500}>
                  {agent.assignment_ids.length > 0 ? `${agent.assignment_ids.length} active` : 'None'}
                </Typography>
              </Box>
            </Box>
          </Box>
          <Button variant="contained" startIcon={<RefreshCw size={15} />}
            onClick={handleSync} disabled={syncing || !isOnline}
            color={isOnline ? 'primary' : 'inherit'}>
            {syncing ? 'Syncing...' : 'Sync Now'}
          </Button>
        </Box>
      </Paper>

      {/* Offline warning */}
      {agent.status === 'offline' && (
        <Alert severity="error" sx={{ mb: 2 }}>
          This agent is offline. Last seen {dayjs(agent.last_heartbeat).fromNow()}. Check server connectivity.
        </Alert>
      )}
      {agent.status === 'stale' && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          This agent is stale — heartbeat received {dayjs(agent.last_heartbeat).fromNow()}. Agent may be experiencing issues.
        </Alert>
      )}

      {/* Tabs */}
      <Paper elevation={0} variant="outlined" sx={{ borderRadius: 2 }}>
        <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ px: 2, borderBottom: '1px solid', borderColor: 'divider' }}>
          <Tab label="Agent Info" />
          <Tab label="Execution History" onClick={() => refetchExec()} />
        </Tabs>

        <Box px={3} pb={3}>
          {/* Agent Info */}
          <TabPanel value={tab} index={0}>
            <Grid container spacing={4}>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" fontWeight="bold" mb={1.5} color="text.secondary" textTransform="uppercase" letterSpacing={0.5}>
                  Agent Details
                </Typography>
                <InfoRow label="Agent ID" value={agent.agent_id} />
                <InfoRow label="Hostname" value={agent.hostname} />
                <InfoRow label="Environment" value={<Chip label={agent.environment} size="small" variant="outlined" />} />
                <InfoRow label="Agent Version" value={`v${agent.agent_version}`} />
                <InfoRow label="Status" value={<Chip label={agent.status} size="small" color={STATUS_COLORS[agent.status]} />} />
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" fontWeight="bold" mb={1.5} color="text.secondary" textTransform="uppercase" letterSpacing={0.5}>
                  Sync Status
                </Typography>
                <InfoRow label="Last Heartbeat" value={
                  <Box>
                    <Typography variant="body2">{dayjs(agent.last_heartbeat).format('MMM D, YYYY HH:mm:ss')}</Typography>
                    <Typography variant="caption" color="text.secondary">{dayjs(agent.last_heartbeat).fromNow()}</Typography>
                  </Box>
                } />
                <InfoRow label="Last Sync" value={
                  <Box>
                    <Typography variant="body2">{dayjs(agent.last_sync).format('MMM D, YYYY HH:mm:ss')}</Typography>
                    <Typography variant="caption" color="text.secondary">{dayjs(agent.last_sync).fromNow()}</Typography>
                  </Box>
                } />
                <InfoRow label="Active Assignments" value={
                  agent.assignment_ids.length > 0 ? (
                    <Box display="flex" flexDirection="column" gap={0.5}>
                      {agent.assignment_ids.map((aId: string) => (
                        <Typography key={aId} variant="body2" color="primary"
                          sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}
                          onClick={() => history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/${aId}`)}>
                          {aId}
                        </Typography>
                      ))}
                    </Box>
                  ) : <Typography variant="body2" color="text.disabled">No assignments</Typography>
                } />
              </Grid>
            </Grid>
          </TabPanel>

          {/* Execution History */}
          <TabPanel value={tab} index={1}>
            {execLoading ? (
              <Box display="flex" justifyContent="center" py={4}><CircularProgress /></Box>
            ) : execHistory.length === 0 ? (
              <Box py={4} textAlign="center">
                <Typography variant="body2" color="text.secondary">No execution history found for this agent.</Typography>
              </Box>
            ) : (
              <DataGrid
                rows={execHistory}
                columns={execColumns}
                getRowId={(row) => row.execution_id}
                pageSize={25}
                rowsPerPageOptions={[25, 50, 100]}
                autoHeight
                disableSelectionOnClick
                paginationMode="server"
                rowCount={execTotal}
                page={execPage}
                onPageChange={setExecPage}
                sx={{ border: 'none' }}
              />
            )}
          </TabPanel>
        </Box>
      </Paper>
    </Box>
  )
}

export default AgentDetailPage
