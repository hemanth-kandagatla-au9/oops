import React from 'react'
import { Skeleton, Tooltip } from '@mui/material'
import { Activity, Database, Server, ShieldCheck } from 'lucide-react'
import { StatsOverview } from '../../../utils/enums'
import '../policies.scss'

type IconVariant = 'blue' | 'green' | 'amber'

interface StatCardProps {
  label: string
  value: string | number
  delta?: string
  deltaPositive?: boolean
  icon: React.ReactNode
  iconVariant: IconVariant
  disabled?: boolean
  tooltip?: string
}

const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  delta,
  deltaPositive,
  icon,
  iconVariant,
  disabled,
  tooltip,
}) => {
  const cardContent = (
    <div className={`stats-card ${disabled ? 'stats-card--disabled' : ''}`}>
      <div className="stats-card__content">
        <p className="stats-card__label">{label}</p>
        <p className="stats-card__value">{value}</p>
        {/* <div className="stats-card__delta-row">
          <span className={`stats-card__delta stats-card__delta--${deltaPositive ? 'up' : 'down'}`}>
            {delta}
          </span>
        </div> */}
      </div>
      <div className={`stats-card__icon stats-card__icon--${iconVariant}`}>
        {icon}
      </div>
    </div>
  )

  return disabled ? (
    <Tooltip title={tooltip || 'Coming soon'} arrow>
      <div style={{ flex: 1, width: '100%' }}>{cardContent}</div>
    </Tooltip>
  ) : (
    <div style={{ flex: 1 }}>{cardContent}</div>
  )

}

interface StatsHeaderProps {
  stats?: StatsOverview
  loading?: boolean
}

const StatsHeader: React.FC<StatsHeaderProps> = ({ stats, loading }) => {
  if (loading) {
    return (
      <div className="stats-header">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="stats-card--skeleton">
            <Skeleton width="60%" height={16} />
            <Skeleton width="80%" height={32} />
            <Skeleton width="50%" height={14} />
          </div>
        ))}
      </div>
    )
  }

  const safeStats: StatsOverview = {
    policies: Number(stats?.policies ?? 0),
    policies_delta: Number(stats?.policies_delta ?? 0),

    rules: Number(stats?.rules ?? 0),
    rules_delta: Number(stats?.rules_delta ?? 0),

    assigned_systems: Number(stats?.assigned_systems ?? 0),
    systems_delta: Number(stats?.systems_delta ?? 0),

    compliance_coverage: Number(stats?.compliance_coverage ?? 0),
    compliance_delta: Number(stats?.compliance_delta ?? 0),
    totalPolicies: 0,
    policiesDelta: undefined,
    totalRules: null,
    rulesDelta: undefined,
    assignedSystems: null,
    systemsDelta: undefined,
    complianceCoverage: null,
    coverageDelta: undefined
  }

  const formatDelta = (value: number, suffix: string) => {
    if (value === 0) return '—'
    return `${value > 0 ? '↑' : '↓'} ${Math.abs(value)} ${suffix}`
  }

  return (
    <div className="stats-header">

      <StatCard
        label="Policies"
        value={safeStats.policies}
        // delta={formatDelta(safeStats.policies_delta, 'this month')}
        // deltaPositive={safeStats.policies_delta >= 0}
        icon={<Database size={18} />}
        iconVariant="blue"
      />

      <StatCard
        label="Rules"
        value={`${safeStats.rules} Rules`}
        // delta={formatDelta(safeStats.rules_delta, 'this month')}
        // deltaPositive={safeStats.rules_delta >= 0}
        icon={<Activity size={18} />}
        iconVariant="green"
      />

      <StatCard
        label="Assigned Systems"
        value={`${safeStats.assigned_systems.toLocaleString()} Systems`}
        // delta={formatDelta(safeStats.systems_delta, 'this week')}
        // deltaPositive={safeStats.systems_delta >= 0}
        icon={<Server size={18} />}
        iconVariant="green"
        disabled
        tooltip="Coming soon"
      />

      <StatCard
        label="Compliance Coverage"
        value={`${safeStats.compliance_coverage}%`}
        // delta={formatDelta(safeStats.compliance_delta, '% vs last week')}
        // deltaPositive={safeStats.compliance_delta >= 0}
        icon={<ShieldCheck size={18} />}
        iconVariant="amber"
        disabled
        tooltip="Coming soon"
      />
    </div>
  )
}

export default StatsHeader