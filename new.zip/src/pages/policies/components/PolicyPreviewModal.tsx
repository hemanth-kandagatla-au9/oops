import React from 'react'
import { Rule, PolicyRule } from '../../../utils/enums'
import '../policies.scss'

const severityClass = (severity = '') => {
  const s = severity?.toLowerCase()
  if (s === 'critical') return 'policy-preview-modal__rule-severity--critical'
  if (s === 'high') return 'policy-preview-modal__rule-severity--high'
  if (s === 'medium') return 'policy-preview-modal__rule-severity--medium'
  return 'policy-preview-modal__rule-severity--low'
}

const capitalize = (s = '') =>
  s.charAt(0).toUpperCase() + s.slice(1)

const RuleIcon = ({ label = 'R' }: { label?: string }) => (
  <div className="policy-preview-modal__rule-icon">
    <span>{label.slice(0, 1).toUpperCase()}</span>
  </div>
)

interface Props {
  name: string
  description: string
  category: string
  executionMode: string
  failureHandling: string
  tags: string[]
  rules: (PolicyRule & { ruleData?: Rule })[]
  type?: 'view' ,
}

const PolicyReviewContent: React.FC<Props> = ({
  name,
  description,
  category,
  executionMode,
  failureHandling,
  tags,
  rules,
  type,
}) => {
  return (
    <div 
className={
    type === 'view'
      ? 'policy-preview-modal__content-grid-view'
      : 'policy-preview-modal__content-grid'
  }
>

      {/* LEFT */}
      <div className="policy-preview-modal__details-panel">
        <div className="policy-preview-modal__section-title">
          Policy Details
        </div>

        <div className="policy-preview-modal__detail-list">

          <div className="policy-preview-modal__detail-item">
            <span>Policy Name:</span>
            <strong>{name || '—'}</strong>
          </div>

          <div className="policy-preview-modal__detail-item">
            <span>Description:</span>
            <strong>{description || '—'}</strong>
          </div>

          <div className="policy-preview-modal__detail-item">
            <span>Policy Category:</span>
            <strong>{category || '—'}</strong>
          </div>

          {/* <div className="policy-preview-modal__detail-item">
            <span>Execution Mode:</span>
            <strong>{executionMode || '—'}</strong>
          </div> */}

          <div className="policy-preview-modal__detail-item">
            <span>Failure Handling:</span>
            <strong>{failureHandling || '—'}</strong>
          </div>

          <div className="policy-preview-modal__detail-item">
            <span>Tags:</span>

            <div className="policy-preview-modal__tags">
              {tags.length ? (
                tags.map((t, i) => (
                  <div key={i} className="policy-preview-modal__tag">
                    {t}
                  </div>
                ))
              ) : (
                <strong>—</strong>
              )}
            </div>
          </div>

        </div>
      </div>

      {/* RIGHT */}
      <div className="policy-preview-modal__rules-panel">
        <div className="policy-preview-modal__section-title">Rules</div>

        <div className="policy-preview-modal__rules-list">
          {rules.map((rule, idx) => {
            const severity = rule.ruleData?.severity ?? ''

            return (
              <div key={rule.rule_id} className="policy-preview-modal__rule-row">
                <div className="policy-preview-modal__rule-left">

                  <span className="policy-preview-modal__rule-order">
                    {String(idx + 1).padStart(2, '0')}
                  </span>

                  <RuleIcon label={rule.ruleData?.rule_type} />

                  <div className="policy-preview-modal__rule-info">
                    <div className="policy-preview-modal__rule-name">
                      {rule.ruleData?.name}
                    </div>
                    <div className="policy-preview-modal__rule-desc">
                      {rule.ruleData?.description}
                    </div>
                  </div>

                </div>

                <span
                  className={[
                    'policy-preview-modal__rule-severity',
                    severityClass(severity),
                  ].join(' ')}
                >
                  {capitalize(severity)}
                </span>

              </div>
            )
          })}
        </div>
      </div>

    </div>
  )
}

export default PolicyReviewContent