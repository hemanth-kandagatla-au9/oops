import React, { useState } from 'react'
import { Policy } from '../../../utils/enums'
import '../policies.scss'
import { POLICYOPS_PATH } from '../../../utils/constant'
import { useHistory } from 'react-router-dom'
import { MoreVertical } from 'lucide-react'   
import { Menu, MenuItem, IconButton } from '@mui/material'

import { useDeletePolicyMutation } from '../../../redux/slices/policiesSlice'
import { useRevokeAssignmentMutation } from '../../../redux/slices/assignmentsSlice'
import { toast } from 'react-toastify'

interface AssignmentCardPolicy extends Policy {
  assignmentMeta?: {
    priority?: string
    policyMode?: string
    assignmentType?: string
    isGlobal?: boolean
  }
}

interface Props {
  policy: Policy | AssignmentCardPolicy
  onClick?: () => void
  onDeleteSuccess?: () => void
  onView?: () => void

  type?: 'policy' | 'assignment'   
}

const PRIORITY_COLOR: Record<string, string> = {
  CRITICAL: '#ef4444',
  HIGH: '#f97316',
  MEDIUM: '#2563eb',
  LOW: '#64748b',
}

const PolicyCard: React.FC<Props> = ({ policy, onClick, onDeleteSuccess, type, onView }) => {
  const assignmentPolicy = policy as AssignmentCardPolicy
  const assignmentPriority = assignmentPolicy.assignmentMeta?.priority ?? ''
  const priorityColor = PRIORITY_COLOR[assignmentPriority.toUpperCase()] ?? '#64748b'
  const isGlobalTarget = Boolean(assignmentPolicy.assignmentMeta?.isGlobal)
  const targetsLabel = isGlobalTarget ? 'Global' : String(policy.systems_protected ?? 0)
  const cardTags = (policy.tags ?? []).filter(Boolean)


  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null)
  const [deletePolicy, { isLoading: deletingPolicy }] = useDeletePolicyMutation()
  const [revokeAssignment, { isLoading: deletingAssignment }] = useRevokeAssignmentMutation()
  const deleting = deletingPolicy || deletingAssignment

  const open = Boolean(anchorEl)

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>) => {
    event.stopPropagation() 
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const history = useHistory()

  const handleCardClick = () => {
    if (onClick) {
      onClick()   
    } else {
      history.push(`${POLICYOPS_PATH.POLICIES}/${policy._id}/view`)
    }
  }

  const handleEdit = () => {
    handleClose()

    if (type === 'assignment') {
      history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/${policy._id}/edit`, { editMode: true })
    } else {
      history.push(`${POLICYOPS_PATH.POLICIES}/${policy._id}/edit`)

    }
  }

  const handleView = () => {
    handleClose()

    if (type === 'assignment') {
      if (onView) {
        onView()
      } else {
        history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/${policy._id}/edit`)
      }
    } else {
      history.push(`${POLICYOPS_PATH.POLICIES}/${policy._id}/view`)
    }
  }


  const handleDelete = async () => {
    handleClose()

    try {
      if (type === 'assignment') {
        await revokeAssignment(policy._id).unwrap()
        toast.success('Assignment deleted successfully')
      } else {
        await deletePolicy(policy._id).unwrap()
        toast.success('Policy deleted successfully')
      }

      onDeleteSuccess?.()

    } catch (err: any) {
      toast.error(err?.data?.message || `Failed to delete ${type === 'assignment' ? 'assignment' : 'policy'}`)
    }
  }

  return (
    <div
      className="ps-policy-card"
      onClick={handleCardClick}
      role="button"
      tabIndex={0}
    >
      {/* Header */}
      <div className="ps-policy-card__header">
        <p className="ps-policy-card__name">{policy.name}</p>

        {/* RIGHT SIDE */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>

          {/* Status */}
          <span className={`ps-status-badge ps-status-badge--${policy.status.toLowerCase()}`}>
            {policy.status}
          </span>

          {/* 3 DOT MENU */}
          <IconButton
            size="small"
            onClick={handleMenuClick}
            sx={{ color: '#94a3b8' }}
          >
            <MoreVertical size={16} />
          </IconButton>

          <Menu
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            onClick={(e) => e.stopPropagation()}
            PaperProps={{
              sx: {
                borderRadius: '10px',
                mt: 1,
                minWidth: 140,
                boxShadow: '0px 4px 16px rgba(0,0,0,0.08)',
              },
            }}
          >
            <MenuItem onClick={handleView}>View</MenuItem>
            <MenuItem onClick={handleEdit}>Edit</MenuItem>
            <MenuItem onClick={handleDelete} disabled={deleting} sx={{ color: '#ef4444' }}>
              Delete
            </MenuItem>
          </Menu>
</div>
    </div>

      {/* Meta */}
      {type === 'assignment' ? (
        <>
          <div className="ps-policy-card__meta">
            <div className="ps-policy-card__meta-item">
              <span className="ps-policy-card__meta-label">Priority</span>
              <span className="ps-policy-card__meta-value" style={{ color: priorityColor }}>
                {assignmentPriority || '—'}
              </span>
            </div>

            <div className="ps-policy-card__meta-item ps-policy-card__meta-item--right">
              <span className="ps-policy-card__meta-label">Targets</span>
              <span className="ps-policy-card__meta-value">{targetsLabel}</span>
            </div>
          </div>

          {cardTags.length > 0 && (
            <div className="ps-policy-card__tags" style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {cardTags.map((tag) => (
                <span
                  key={tag}
                  className="ps-policy-card__tag"
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    padding: '2px 8px',
                    borderRadius: '999px',
                    backgroundColor: '#eff6ff',
                    color: '#1d4ed8',
                    border: '1px solid #bfdbfe',
                    fontSize: '0.72rem',
                    fontWeight: 600,
                    lineHeight: 1.4,
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
        </>
      ) : (
        <div className="ps-policy-card__meta">
          <div className="ps-policy-card__meta-item">
            <span className="ps-policy-card__meta-label">Execution type</span>
            <span className="ps-policy-card__meta-value">{policy.executionInfo?.executionMode || '—'}</span>
          </div>

          <div className="ps-policy-card__meta-item ps-policy-card__meta-item--right">
            <span className="ps-policy-card__meta-label">Rules</span>
            <span className="ps-policy-card__meta-value">{policy.rules.length}</span>
          </div>
        </div>
      )}


      {/* Footer */}
  <div className="ps-policy-card__footer">
    <div className="ps-policy-card__user">
      <div className="ps-policy-card__avatar-placeholder">
        {policy.owner?.[0]}
      </div>
      <span className="ps-policy-card__username">{policy.owner}</span>
    </div>

    <div className="ps-policy-card__date">
      {new Date(policy.updated_at || policy.created_at).toLocaleDateString()}
    </div>
  </div>
    </div >
  )
}

export default PolicyCard
