/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable no-undef */
import React, { useCallback, useEffect, useMemo, useState } from 'react'
import {
  Box,
  Typography,
  Button,
  IconButton,
  TextField,
  InputAdornment,
  Tooltip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from '@mui/material'
import { useHistory, useParams } from 'react-router-dom'

import {
  DndContext,
  closestCenter,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core'

import { POLICYOPS_PATH } from '../../utils/constant'
import { Rule, PolicyRule, RuleSeverity } from '../../utils/enums'
import PolicyStepper from './components/PolicyStepper'
import BasicInfoStep from './components/BasicInfoStep'
import { ChevronRight, X, GripVertical, Plus, Search, Edit2, Code, Loader } from 'lucide-react'
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
  arrayMove,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import PolicyReviewContent from './components/PolicyPreviewModal'
import JsonPolicyEditorDialog, { DEFAULT_POLICY_JSON } from './components/JsonPolicyEditorDialog'
import { useCreatePolicyMutation, useGetPolicyByIdQuery, useUpdatePolicyMutation } from '../../redux/slices/policiesSlice'
import { toast } from 'react-toastify'
import { useGetRulesQuery } from '../../redux/slices/rulesSlice'

export interface PolicyFormPageProps {
  policyId?: string
  tags?: string[]
  onSubmit?: (payload: {
    name: string
    description: string
    tags: string[]
    rules: { rule_id: string; rule_version: number; order: number }[]
  }) => Promise<void>

  availableRules?: Rule[]

  initialPolicy?: {
    name: string
    description: string
    tags: string[]
    rules: (PolicyRule & { ruleData?: Rule })[]
  }

  loading?: boolean

  saving?: boolean

  onCancel?: () => void

  onNewRule?: () => void

  onEditRule?: (rule: Rule) => void

  onReview?: (payload: {
    name: string
    description: string
    rules: (PolicyRule & { ruleData?: Rule })[]
  }) => void
  onJsonEditor?: () => void

}
const RULE_TYPES = ['All', 'File', 'Package', 'Service', 'Script'] as const
type RuleTypeFilter = typeof RULE_TYPES[number]

interface TypeTabsProps {
  active: RuleTypeFilter
  onChange: (t: RuleTypeFilter) => void
}

const TypeTabs: React.FC<TypeTabsProps> = ({ active, onChange }) => (
  <Box display="flex" gap={0.5} flexWrap="wrap">
    {RULE_TYPES.map((t) => (
      <Box
        key={t}
        onClick={() => onChange(t)}
        sx={{
          px: 1.25, py: 0.4, borderRadius: 1, cursor: 'pointer',
          fontSize: '0.75rem', fontWeight: active === t ? 600 : 400,
          bgcolor: active === t ? '#dbeafe' : 'transparent',
          color: active === t ? '#1d4ed8' : '#64748b',
          border: '1px solid',
          borderColor: active === t ? '#bfdbfe' : 'transparent',
          transition: 'all 0.1s',
          '&:hover': { bgcolor: active === t ? '#dbeafe' : '#f1f5f9' },
        }}
      >
        {t}
      </Box>
    ))}
  </Box>
)

// ─── Library rule row (left panel) ───────────────────────────────────────────
interface LibraryRuleRowProps {
  rule: Rule
  onAdd: (rule: Rule) => void
  onEdit?: (rule: Rule) => void
}

const SEVERITY_STYLES: Record<string, { color: string }> = {
  Critical: { color: '#dc2626' },
  High: { color: '#ea580c' },
  Medium: { color: '#ca8a04' },
  Low: { color: '#64748b' },
  critical: { color: '#dc2626' },
  high: { color: '#ea580c' },
  medium: { color: '#ca8a04' },
  low: { color: '#64748b' },
}

const SeverityText: React.FC<{ severity: string }> = ({ severity }) => {
  const style = SEVERITY_STYLES[severity] ?? { color: '#64748b' }
  return (
    <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: style.color }}>
      {severity.charAt(0).toUpperCase() + severity.slice(1)}
    </Typography>
  )
}

const RuleIconBubble: React.FC<{ label?: string; size?: number }> = ({ label = 'R', size = 28 }) => (
  <Box
    sx={{
      width: size, height: size, borderRadius: '50%',
      background: 'linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%)',
      border: '1.5px solid #93c5fd',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
    }}
  >
    <Typography sx={{ fontSize: '0.6rem', fontWeight: 700, color: '#1d4ed8' }}>
      {label.slice(0, 1).toUpperCase()}
    </Typography>
  </Box>
)

const LibraryRuleRow: React.FC<LibraryRuleRowProps> = ({ rule, onAdd, onEdit }) => (
  <Box
    sx={{
      display: 'flex', alignItems: 'center', gap: 1.5,
      px: 1.5, py: 1,
      borderRadius: 1.5,
      '&:hover': { bgcolor: '#f8fafc' },
      '&:hover .row-actions': { opacity: 1 },
      cursor: 'default',
    }}
  >
    <RuleIconBubble label={rule.rule_type ?? rule.name} />
    <Box flex={1} minWidth={0}>
      <Typography sx={{ fontSize: '0.8rem', fontWeight: 600, color: '#0f172a' }} noWrap>
        {rule.name}
      </Typography>
      <Typography sx={{ fontSize: '0.7rem', color: '#94a3b8' }} noWrap>
        {rule.description ?? rule.rule_type ?? ''}
      </Typography>
    </Box>
    <Box display="flex" alignItems="center" gap={1} flexShrink={0}>

      <Box
        sx={{
          px: 1,
          py: 0.15,
          borderRadius: '999px',
          backgroundColor: '#eff6ff',
          border: '1px solid #dbeafe',
        }}
      >
        <Typography
          sx={{
            fontSize: '0.65rem',
            fontWeight: 600,
            color: '#2563eb',
          }}
        >
          {rule?.checkType || "--"}
        </Typography>
      </Box>

      <SeverityText severity={rule.severity} />
      <Box className="row-actions" sx={{ display: 'flex', gap: 0.25, opacity: 0, transition: 'opacity 0.12s' }}>
        {onEdit && (
          <Tooltip title="Edit rule">
            <IconButton size="small" sx={{ color: '#94a3b8', p: 0.4 }} >
              <Edit2 size={13} />
            </IconButton>
          </Tooltip>
        )}
        <Tooltip title="Add to policy">
          <IconButton
            size="small"
            sx={{ color: '#2563eb', p: 0.4 }}
            onClick={() => onAdd(rule)}
          >
            <Plus size={13} />
          </IconButton>
        </Tooltip>
      </Box>
    </Box>
  </Box>
)

interface SortableSelectedRuleProps {
  item: PolicyRule & { ruleData?: Rule }
  index: number
  onRemove: (ruleId: string) => void
}

const SortableSelectedRule: React.FC<SortableSelectedRuleProps> = ({ item, index, onRemove }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: String(item.rule_id),
  })

  return (
    <Box
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.45 : 1 }}
      sx={{
        display: 'flex', alignItems: 'center', gap: 1.5,
        px: 1.5, py: 1.25,
        mb: 1,
        bgcolor: '#fff',
        border: '1px solid',
        borderColor: isDragging ? '#93c5fd' : '#e2e8f0',
        borderRadius: 1.5,
        boxShadow: isDragging ? '0 4px 16px rgba(37,99,235,0.12)' : 'none',
        transition: 'box-shadow 0.15s, border-color 0.15s',

      }}
    >
      {/* Drag handle */}

      <Box
        {...attributes}
        {...listeners}
        sx={{ cursor: isDragging ? 'grabbing' : 'grab', color: '#cbd5e1', display: 'flex', flexShrink: 0 }}
      >
        <GripVertical size={15} />
      </Box>


      {/* Order number */}
      <Typography
        sx={{
          fontSize: '0.7rem', fontWeight: 700, color: '#94a3b8',
          width: 20, textAlign: 'center', flexShrink: 0,
        }}
      >
        {String(index + 1).padStart(2, '0')}
      </Typography>

      {/* Rule icon */}
      <RuleIconBubble label={item.ruleData?.rule_type ?? item.ruleData?.name ?? 'R'} />

      {/* Rule info */}
      <Box flex={1} minWidth={0}>
        <Box display="flex" alignItems="center" gap={1} flexWrap="wrap" justifyContent="space-between">
          <Typography sx={{ fontSize: '0.8rem', fontWeight: 600, color: '#0f172a' }} noWrap>
            {item.ruleData?.name ?? item.rule_id}
          </Typography>
           
          {item.ruleData?.severity && <SeverityText severity={item.ruleData.severity} />}
        </Box>
        <Typography sx={{ fontSize: '0.7rem', color: '#94a3b8' }} noWrap>
          {item.ruleData?.description ?? item.ruleData?.rule_type ?? 'Rule Description'}
        </Typography>
      </Box>

      {/* Remove */}
      <IconButton
        size="small"
        sx={{ color: '#cbd5e1', p: 0.4, flexShrink: 0, '&:hover': { color: '#ef4444' } }}
        onClick={() => onRemove(item.rule_id)}
      >
        <X size={14} />
      </IconButton>
    </Box>
  )
}




const PolicyFormPage: React.FC<PolicyFormPageProps> = ({
  policyId,
  availableRules = [],
  initialPolicy,
  loading = false,
  saving = false,
  onCancel,
  onSubmit,
  onNewRule,
  onEditRule,
  onReview,
  onJsonEditor,
}) => {
  const { id } = useParams<{ id: string }>()


  const isEdit = !!id

  const history = useHistory()
  const [selectedRules, setSelectedRules] = useState<(PolicyRule & { ruleData?: Rule })[]>([])


  const {
    data: policyRes,
    isLoading: loadingPolicy,
  } = useGetPolicyByIdQuery(id, {
    skip: !id,
  })

  useEffect(() => {
    if (!policyRes?.data) return

    const p = policyRes.data

    setName(p.name || '')
    setDescription(p.description || '')

    setCategory(p.policyType || '')
    setPolicyType(p.policyType || '')
    setStatus(p.status || 'PUBLISHED')

    setTags(p.tags || [])

    //  executionInfo fix
    setExecutionMode(p.executionInfo?.executionMode || '')
    setFailureHandling(p.executionInfo?.failureHandling || '')

    //  rules mapping
    const mappedRules =
      (p.rules || []).map((r: any, idx: number) => ({
        rule_id: r.ruleId,
        rule_version: 1,
        order: r.sequenceNumber || idx + 1,
        ruleData: {
          name: r.name,
          severity: 'medium',
          version: r.versionNumber,
        },
      })) || []

    setSelectedRules(mappedRules)
  }, [policyRes])

  const handleSubmit = async () => {
    if (!name.trim()) return
    console.log("Submitting with payload:", buildPayload())
    try {
      if (isEdit && id) {
        //  UPDATE API CALL
        await updatePolicy({
          id,
          data: buildPayload(),
        }).unwrap()

        toast.success('Policy updated successfully ')
      } else {
        await createPolicy(buildPayload()).unwrap()

        toast.success('Policy created successfully ')
      }

      setTimeout(() => {
        history.push(POLICYOPS_PATH.POLICIES)
      }, 800)

    } catch (err: any) {
      console.error('Save failed', err)

      toast.error(
        err?.data?.message || 'Failed to save policy. Please try again.'
      )
    }
  }



  // ─────────────────────────────────────────────────────────────
  // Step State
  // ─────────────────────────────────────────────────────────────
  const [step, setStep] = useState(0)

  // ─────────────────────────────────────────────────────────────
  // Form State
  // ─────────────────────────────────────────────────────────────
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState('')
  const [executionMode, setExecutionMode] = useState('')
  const [failureHandling, setFailureHandling] = useState('')
  const [tags, setTags] = useState<string[]>([])
  const [ruleSearch, setRuleSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState<RuleTypeFilter>('All')
  const [policyType, setPolicyType] = useState('')
  const [status, setStatus] = useState('PUBLISHED')
  const [showSuccessModal, setShowSuccessModal] = useState(false)
  const [jsonEditorOpen, setJsonEditorOpen] = useState(false)
  const [jsonEditorValue, setJsonEditorValue] = useState(DEFAULT_POLICY_JSON)

  const [createPolicy, { isLoading: creating }] = useCreatePolicyMutation()
  const [updatePolicy, { isLoading: updating }] = useUpdatePolicyMutation()
  // ─────────────────────────────────────────────────────────────
  // Handlers
  // ─────────────────────────────────────────────────────────────
  const handleBack = () => {
    history.push(POLICYOPS_PATH.POLICIES)
  }

  const handleFieldChange = (
    field: string,
    value: string
  ) => {
    switch (field) {
      case 'name':
        setName(value)
        break

      case 'description':
        setDescription(value)
        break

      case 'category':
        setCategory(value)
        break

      case 'executionMode':
        setExecutionMode(value)
        break

      case 'failureHandling':
        setFailureHandling(value)
        break

      default:
        break
    }
  }


  const handleNext = () => {
    if (step === 0 && !isBasicValid) {
      toast.error('Please fill all required basic info fields')
      return
    }

    if (step === 1 && !isRuleValid) {
      toast.error('Please select at least one rule')
      return
    }

    setStep((prev) => prev + 1)
  }


  const {
    data: rulesRes,
    isLoading: rulesLoading,
  } = useGetRulesQuery({
    page: 1,
    limit: 50,
    search: ruleSearch || undefined,
    checkType: typeFilter !== 'All' ? typeFilter : undefined,
  })

  console.log("Available rules:", rulesRes)

  const filteredLibrary = useMemo(() => {
    const addedIds = new Set(selectedRules.map((r) => r.rule_id))
    const rules = rulesRes?.data || []

    return rules.filter((r: Rule) => {
      const id = r.rule_id || r.id
      return !addedIds.has(id)
    })
  }, [rulesRes, selectedRules])

  const handlePrevious = () => {
    setStep(0)
  }
  console.log("data", selectedRules)
  const buildPayload = () => {
    const basePayload = {
      name: name.trim(),
      description: description.trim(),

      policyType: category,
      status,

      executionInfo: {
        executionMode,
        failureHandling,
      },

      tags,

      rules: selectedRules.map((r, idx) => ({
        ruleId: r.rule_id,
        sequenceNumber: idx + 1,
        versionNumber: r?.ruleData?.version ?? '1.0.0',
        name: r?.ruleData?.name ?? '',
      })),
    }

    //  ADD policyId ONLY for edit
    if (isEdit && id) {
      return {
        ...basePayload,
        policyId: id,
      }
    }

    return basePayload
  }

  const openJsonEditor = () => {
    const payload = buildPayload()
    const hasFormData = Boolean(payload.name || payload.description || payload.rules.length)
    setJsonEditorValue(hasFormData ? JSON.stringify(payload, null, 2) : DEFAULT_POLICY_JSON)
    setJsonEditorOpen(true)
  }

  const handleCreate = async () => {
    if (!name.trim()) return

    try {
      await createPolicy(buildPayload()).unwrap()

      toast.success('Policy created successfully 🎉')

      setTimeout(() => {
        history.push(POLICYOPS_PATH.POLICIES)
      }, 800)

    } catch (err: any) {
      console.error('Create policy failed', err)

      toast.error(
        err?.data?.message || 'Failed to create policy. Please try again.'
      )
    }
  }




  const addRule = useCallback((rule: Rule) => {
    console.log("Adding rule", rule,)
    setSelectedRules((prev) => [
      ...prev,
      {
        rule_id: String(rule.id ??
          rule.rule_id
        ),
        rule_version: rule.version ?? 1,
        order: prev.length + 1,
        ruleData: rule,
      } as PolicyRule & { ruleData?: Rule },
    ])
  }, [])

  const removeRule = useCallback((ruleId: string) => {
    setSelectedRules((prev) => prev.filter((r) => r.rule_id !== ruleId))
  }, [])

  const sensors = useSensors(

    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 5,
      },
    }),

    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  )

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event
    if (over && active.id !== over.id) {
      setSelectedRules((items) => {
        const oldIdx = items.findIndex((i) => i.rule_id === active.id)
        const newIdx = items.findIndex((i) => i.rule_id === over.id)
        return arrayMove(items, oldIdx, newIdx)
      })
    }
  }


  const isBasicValid =
    name.trim() &&
    description.trim() &&
    category.trim() &&
    // executionMode.trim() &&
    failureHandling.trim()

  const isRuleValid = selectedRules.length > 0

const [openNewRuleModal, setOpenNewRuleModal] = useState(false)
  // ─────────────────────────────────────────────────────────────
  // Render
  // ─────────────────────────────────────────────────────────────
  return (
    <Box
      sx={{
        bgcolor: '#FBFCFF',
        // minHeight: '100vh',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      }}
    >
      <Box
        sx={{
          bgcolor: '#FBFCFF',
          borderBottom: '1px solid #f1f5f9',
          px: 3, paddingTop: 2,
          display: 'flex', flexDirection: 'column',
        }}
      >
        {/* Top row: Breadcrumb + Buttons */}
        <Box display="flex" alignItems="center" justifyContent="space-between">
          {/* Breadcrumb */}
          <Box display="flex" alignItems="center" gap={1}>
            <IconButton
              size="small"
              sx={{ color: '#64748b', mr: 0.5 }}
              onClick={handleBack}
            >
              {/* Left chevron */}
              <ChevronRight size={16} style={{ transform: 'rotate(180deg)' }} />
            </IconButton>
            <Typography
              sx={{ fontSize: '0.78rem', color: '#94a3b8', cursor: 'pointer', '&:hover': { color: '#2563eb' } }}
              onClick={handleBack}
            >
              Policy Studio
            </Typography>
            <ChevronRight size={12} color="#cbd5e1" />
            <Typography sx={{ fontSize: '0.78rem', color: '#0f172a', fontWeight: 600 }}>
              Policy
            </Typography>
          </Box>

          <Box display="flex" gap={1.5}>
            <Button
              variant="outlined"
              size="small"
              onClick={handleBack}
              sx={{
                textTransform: 'none',
                borderRadius: 1.5,
                fontSize: '0.82rem',
                borderColor: '#e2e8f0',
                color: '#64748b',
                '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' },
              }}
            >
              Cancel
            </Button>

            <Button
              variant="contained"
              size="small"
              disabled={step !== 2 || creating}
              onClick={handleSubmit}
              sx={{
                textTransform: 'none',
                borderRadius: 1.5,
                fontSize: '0.82rem',
                bgcolor: '#1e40af',
                px: 2,
                '&:hover': { bgcolor: '#1d3ea0' },
                '&.Mui-disabled': {
                  bgcolor: '#93c5fd',
                  color: '#fff',
                },
              }}
            >
              {creating
                ? 'Creating...'
                : isEdit
                  ? 'Save Changes'
                  : 'Create'}
            </Button>
          </Box>

        </Box>

        {/* Bottom row: Page title */}
        <Typography sx={{ fontSize: '1.15rem', fontWeight: 700, color: '#0f172a', paddingLeft: "2.3rem" }}>
          {isEdit ? 'Edit Policy' : 'Create Policy'}
        </Typography>
      </Box>

      {/* ====================================================== */}
      {/* Stepper */}
      {/* ====================================================== */}


      <Box
        display="flex"
        alignItems="center"
        justifyContent="space-between"
        px={3}
      >
        {/* Stepper Center */}
        <Box flex={1} display="flex" justifyContent="center">
          <PolicyStepper
            activeStep={step}
            onStepClick={(clickedStep) => {
              if (clickedStep < step) {
                setStep(clickedStep)
                return
              }

              if (step === 0 && !isBasicValid) {
                toast.error('Please fill all required basic info fields')
                return
              }

              if (step === 1 && !isRuleValid) {
                toast.error('Please select at least one rule')
                return
              }

              setStep(clickedStep)
            }}
          />
        </Box>

        {/* JSON Editor Button */}
        <Box>

          <Button
            variant="outlined"
            size="small"
            startIcon={<Code size={14} />}
            onClick={() => {
              if (onJsonEditor) {
                onJsonEditor()
              } else {
                openJsonEditor()
              }
            }}
            sx={{
              textTransform: 'none',
              borderRadius: '999px',
              fontSize: '0.82rem',
              borderColor: '#e2e8f0',
              color: '#2563eb',
              height: 34,
              px: 2,

              '&:hover': {
                borderColor: '#93c5fd',
                bgcolor: '#eff6ff',
              },
            }}
          >
            JSON Editor
          </Button>
        </Box>
      </Box>


      {/* ====================================================== */}
      {/* Step Content */}
      {/* ====================================================== */}

      <Box sx={{ margin: "0px 24px 16px 24px" }}>
        {step === 0 && (
          <BasicInfoStep
            name={name}
            description={description}
            category={category}
            executionMode={executionMode}
            failureHandling={failureHandling}
            tags={tags}
            onChange={(field, value) => {
              switch (field) {
                case 'tags':
                  setTags(value)
                  break
                default:
                  handleFieldChange(field, value)
              }
            }}
          />

        )}

        {/* STEP 2 PLACEHOLDER */}
        {step === 1 && (
          <>
            {/* Two-column: Rules Library + Selected Rules */}
            <Box display="flex" gap={2} sx={{ height: 'calc(100vh - 307px)', minHeight: 422 }}>

              {/* ── Left: Rules Library ──────────────────────────────────────── */}
              <Box
                sx={{
                  width: '35%', flexShrink: 0,
                  bgcolor: '#fff', border: '1px solid #f1f5f9', borderRadius: 2,
                  display: 'flex', flexDirection: 'column', overflow: 'hidden',
                }}
              >
                {/* Library header */}
                <Box px={2} pt={2} pb={1.5} sx={{ borderBottom: '1px solid #f8fafc' }}>
                  <Box display="flex" alignItems="center" justifyContent="space-between" mb={1.25}>
                    <Box>
                      <Typography sx={{ fontSize: '0.82rem', fontWeight: 700, color: '#0f172a' }}>
                        Rules Library*
                      </Typography>
                      <Typography sx={{ fontSize: '0.7rem', color: '#94a3b8' }}>
                        {availableRules.length} Rules
                      </Typography>
                    </Box>
                    <Box
                      display="flex" alignItems="center" gap={0.5}
                      sx={{ cursor: 'pointer' }}
                     
                    >
                      <Typography sx={{ fontSize: '0.78rem', color: '#2563eb', fontWeight: 600 }} onClick={() => setOpenNewRuleModal(true)}>
                        New Rule
                      </Typography>
                      <Plus size={13} color="#2563eb" />
                    </Box>
                  </Box>

                  {/* Search */}
                  <TextField
                    size="small" fullWidth
                    placeholder="Search Policy"
                    value={ruleSearch}
                    onChange={(e) => setRuleSearch(e.target.value)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Search size={13} color="#94a3b8" />
                        </InputAdornment>
                      ),
                    }}
                    sx={{
                      mb: 1.25,
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 1.5, fontSize: '0.8rem', bgcolor: '#f8fafc',
                        '& fieldset': { borderColor: '#f1f5f9' },
                      },
                    }}
                  />

                  {/* Type filter tabs */}
                  <TypeTabs active={typeFilter} onChange={setTypeFilter} />
                </Box>

                {/* Rules list */}
                <Box sx={{ flex: 1, overflowY: 'auto', py: 1 }}>
                  {rulesLoading ? (
                    <Loader size={24} color="#94a3b8" />
                  ) : filteredLibrary.length === 0 ? (
                    <Box py={4} textAlign="center">
                      <Typography sx={{ fontSize: '0.78rem', color: '#94a3b8' }}>
                        {ruleSearch ? 'No matching rules' : 'No rules available'}
                      </Typography>
                    </Box>
                  ) : (
                    filteredLibrary.map((rule: any) => (
                      <LibraryRuleRow
                        key={rule.id ?? rule.rule_id}
                        rule={rule}
                        onAdd={addRule}
                        onEdit={onEditRule}
                      />
                    ))
                  )}
                </Box>
              </Box>

              {/* ── Right: Selected Rules ────────────────────────────────────── */}
              <Box
                sx={{
                  flex: 1,
                  bgcolor: '#fff', border: '1px solid #f1f5f9', borderRadius: 2,
                  display: 'flex', flexDirection: 'column', overflow: 'hidden',
                }}
              >
                {/* Header */}
                <Box px={2.5} py={2} sx={{ borderBottom: '1px solid #f8fafc' }}>
                  <Box display="flex" sx={{ display: "flex", flexDirection: "column" }}>
                    <Typography sx={{ fontSize: '0.82rem', fontWeight: 700, color: '#0f172a' }}>
                      Selected Rules
                    </Typography>
                    <div className='pfp-drag'>
                      {selectedRules.length > 0 && (
                        <Box
                          sx={{
                            px: 1, py: 0.1, borderRadius: '999px',
                            bgcolor: '#eff6ff', border: '1px solid #dbeafe',
                          }}
                        >
                          <Typography sx={{ fontSize: '0.68rem', fontWeight: 700, color: '#2563eb' }}>
                            {selectedRules.length} Rules
                          </Typography>
                        </Box>
                      )}
                      {selectedRules.length > 0 && (
                        <Typography sx={{ fontSize: '0.72rem', color: '#94a3b8' }}>
                          Drag to reorder
                        </Typography>
                      )}
                    </div>
                  </Box>
                </Box>

                {/* List */}
                <Box sx={{ flex: 1, overflowY: 'auto', px: 2.5, py: 2 }}>
                  {selectedRules.length === 0 ? (
                    <Box
                      sx={{
                        height: '100%', display: 'flex', flexDirection: 'column',
                        alignItems: 'center', justifyContent: 'center',
                        border: '1.5px dashed #e2e8f0', borderRadius: 2,
                        color: '#94a3b8',
                      }}
                    >
                      <Plus size={24} color="#cbd5e1" />
                      <Typography sx={{ fontSize: '0.8rem', mt: 1, color: '#94a3b8' }}>
                        Add rules from the library on the left
                      </Typography>
                    </Box>
                  ) : (
                    <DndContext
                      sensors={sensors}
                      collisionDetection={closestCenter}
                      onDragEnd={handleDragEnd}
                    >
                      <SortableContext
                        items={selectedRules.map((r) => String(r.rule_id))}
                        strategy={verticalListSortingStrategy}
                      >
                        {selectedRules.map((item, idx) => (
                          <SortableSelectedRule
                            key={item.rule_id}
                            item={item}
                            index={idx}
                            onRemove={removeRule}
                          />
                        ))}
                      </SortableContext>
                    </DndContext>
                  )}
                </Box>
              </Box>
            </Box>
          </>
        )}

        {step === 2 && (
          <Box className="pf-review-container">

            <PolicyReviewContent
              name={name}
              description={description}
              category={category}
              executionMode={executionMode}
              failureHandling={failureHandling}
              tags={tags}
              rules={selectedRules}
            />

          </Box>
        )}
      </Box>
      {/*  FOOTER — ONLY SHOW UNTIL STEP 1 */}
      {step < 2 && (
        <Box
          sx={{
            // position: 'fixed',
            bottom: 0,
            left: 0,
            right: 0,
            height: 72,
            bgcolor: '#fff',
            borderTop: '1px solid #ececec',

            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-end',

            px: 4,
            zIndex: 100,
            // marginLeft: '57px',
            gap: '12px',
          }}
        >
          <Button
            size="small"
            onClick={handleBack}
            sx={{
              textTransform: 'none',
              borderRadius: '36px',
              fontSize: '0.82rem',
              color: '#2961F4',
              backgroundColor: '#E3F0FF',
              px: 2,
              '&:hover': { bgcolor: '#f8fafc' },
            }}
          >
            Cancel
          </Button>

          <Button
            variant="contained"
            disabled={
              step === 0
                ? !isBasicValid
                : step === 1
                  ? !isRuleValid
                  : false
            }
            onClick={handleNext}
            sx={{
              borderRadius: '32px',
              textTransform: 'none',
              fontWeight: 600,
              bgcolor: '#2961F4',
              boxShadow: 'none',
              px: 2,

              '&:hover': {
                bgcolor: '#1d4ed8',
                boxShadow: 'none',
              },

              '&.Mui-disabled': {
                bgcolor: '#dbeafe',
                color: '#fff',
              },
            }}
          >
            Next
          </Button>
        </Box>
      )}
      <JsonPolicyEditorDialog
        open={jsonEditorOpen}
        onClose={() => setJsonEditorOpen(false)}
        value={jsonEditorValue}
        onChange={setJsonEditorValue}
      />
      <Dialog
  open={openNewRuleModal}
  onClose={() => setOpenNewRuleModal(false)}
  maxWidth="xs"
  fullWidth
>
  <DialogTitle sx={{ fontSize: '1rem', fontWeight: 600 }}>
    Create New Rule
  </DialogTitle>

  <DialogContent>
    <Typography sx={{ fontSize: '0.85rem', color: '#64748b' }}>
      Are you sure you want to create a new rule? Unsaved changes in this policy will be lost.
    </Typography>
  </DialogContent>

  <DialogActions sx={{ px: 2, pb: 2 }}>
    <Button
      onClick={() => setOpenNewRuleModal(false)}
      variant="outlined"
      size="small"
      sx={{
        textTransform: 'none',
        borderRadius: 1.5,
      }}
    >
      Cancel
    </Button>

    <Button
      onClick={() => {
        setOpenNewRuleModal(false)
        history.push(`${POLICYOPS_PATH.RULES}/new`)
      }}
      variant="contained"
      size="small"
      sx={{
        textTransform: 'none',
        borderRadius: 1.5,
        bgcolor: '#2563eb',
        '&:hover': { bgcolor: '#1d4ed8' },
      }}
    >
      Yes, Create
    </Button>
  </DialogActions>
</Dialog>
    </Box>
  )
}

export default PolicyFormPage