import React from 'react'
import { useParams, useHistory } from 'react-router-dom'
import RuleRow from './components/RuleRow' // reusable rule row
import './policies.scss'
import {
  Box, Typography, Button, TextField, InputAdornment,
  IconButton,
} from '@mui/material'
import { POLICYOPS_PATH } from '../../utils/constant'
import { useGetPolicyByIdQuery } from '../../redux/slices/policiesSlice'
import { ChevronLeft, Pencil } from 'lucide-react'
import PolicyReviewContent from './components/PolicyPreviewModal'

const PolicyDetailPage: React.FC = () => {
  const history = useHistory()





  const { id } = useParams<{ id: string }>()

  const { data, isLoading, isError } = useGetPolicyByIdQuery(id, {
    skip: !id,
  })

  const policy = data?.data

  const assignments = policy?.assignments || []
  console.log('Fetched policy:', policy)


  const rules = (policy?.rules || []).map((r: any) => ({
    name: r?.name,
    description: '',
    severity: 'medium',
    rule_type: 'L',
  }))


  const mappedRules = (policy?.rules || []).map((r: any, idx: number) => ({
    rule_id: r.ruleId || r.rule_id,
    rule_version: 1,
    order: r.sequenceNumber || idx + 1,
    ruleData: {
      name: r.name,
      description: r.description || '',
      severity: r.severity || 'medium',
      rule_type: r.ruleType || 'R',
    },
  }))


  return (
    <div className="pdp">

      {/*  HEADER */}
      <div className="pdp-header">
        <div className="pdp-header__left">
          <button className="pdp-back" onClick={() => history.goBack()}>
           <IconButton size="small" onClick={() => history.goBack()} sx={{ color: '#64748b', border: '1px solid #e2e8f0', borderRadius: '8px', p: '4px', '&:hover': { bgcolor: '#f8fafc', color: '#102459' } }}>
              <ChevronLeft size={16} />
            </IconButton>
          </button>

          <div>
            <p className="pdp-breadcrumb">Policy Studio</p>
            <h2>{policy?.name}</h2>
          </div>
        </div>

        <div className="pdp-header__actions">
          {/* <Button className='ph-rule-btn' sx={{
            border: "1px solid #EAECF0",
            borderRadius: "100px !important",
            backgroundColor: "#FBFCFF !important",
            color: "##667085 !important",
            height: "36px"
          }} >Modify</Button> */}
          <Button variant="contained" onClick={() => history.push(`${POLICYOPS_PATH.POLICIES}/${id}/edit`)} endIcon={<Pencil size={16} />} sx={{ borderRadius: "100px !important", height: "36px", textTransform: 'none', fontWeight: 500, padding: "6px 16px", color: "#667085", bgcolor: '#FFFFFF', border: "1px solid #F2F2F2", boxShadow: 'none', '&:hover': { bgcolor: '#F2F2F2', boxShadow: 'none' } }}>
            Modify
          </Button>
          <Button className="ph-create-btn" sx={{
            border: "1px solid #2961F4",
            borderRadius: "100px !important",
            backgroundColor: "#FBFCFF !important",
            color: "#2961F4 !important",
            height: "36px"
          }}>Assign</Button>
        </div>
      </div>

      <div className="pdp-content">
        <PolicyReviewContent
          name={policy?.name || ''}
          description={policy?.description || ''}
          category={policy?.policyType || ''}
          executionMode={policy?.executionInfo?.executionMode || ''}
          failureHandling={policy?.executionInfo?.failureHandling || ''}
          tags={policy?.tags || []}
          rules={mappedRules}
          type="view"
        />
      </div>
    </div>
  )
}

export default PolicyDetailPage
