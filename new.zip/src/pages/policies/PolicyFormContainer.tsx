import React, { useMemo } from 'react'
import { useHistory, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import PolicyFormPage from './PolicyFormPage'
import { useGetRulesQuery } from '../../redux/slices/rulesSlice'
import {
  useGetPolicyByIdQuery,
  useCreatePolicyMutation,
  useUpdatePolicyMutation,
} from '../../redux/slices/policiesSlice'
import { POLICYOPS_PATH } from '../../utils/constant'
import { Rule, PolicyRule, RuleSeverity } from '../../utils/enums'

// Backend rule shape (camelCase / partial)
interface BackendRule {
  id?: string
  rule_id?: string
  name?: string
  description?: string
  severity?: string
  rule_type?: string
  rulecategory?: string
  checkType: string
  version?: string | number
}

// Backend ordered-rule shape inside a policy
interface BackendOrderedRule {
  ruleId?: string
  rule_id?: string
  name?: string
  sequenceNumber?: number
  order?: number
  versionNumber?: string | number
  rule_version?: string | number
}

// Map a backend rule into the Rule shape the form expects
const mapRule = (r: BackendRule): Rule => {
  const id = r.id ?? r.rule_id ?? ''
  return {
    id: id,
    rule_id: id,
    name: r.name ?? '',
    checkType: r.checkType ?? '',
    description: r.description ?? '',
    severity: String(r.severity ?? '').toLowerCase(),
    rule_type: r.rule_type ?? r.rulecategory ?? '',
    version: Number(r.version) || 1,
  }
}

const PolicyFormContainer: React.FC = () => {
  const history = useHistory()
  const { id } = useParams<{ id?: string }>()
  const isEdit = !!id

  const { data: rulesData, isLoading: rulesLoading } = useGetRulesQuery({
    page: 1, limit: 100,
  })
  const { data: policyData, isLoading: policyLoading } = useGetPolicyByIdQuery(id!, { skip: !isEdit })

  const [createPolicy, { isLoading: creating }] = useCreatePolicyMutation()
  const [updatePolicy, { isLoading: updating }] = useUpdatePolicyMutation()

  const availableRules: Rule[] = useMemo(
    () => (Array.isArray(rulesData?.data) ? rulesData.data.map(mapRule) : []),
    [rulesData],
  )

  const initialPolicy = useMemo(() => {
    const p = policyData?.data
    if (!p) return undefined
    const rules: (PolicyRule & { ruleData?: Rule })[] = Array.isArray(p.rules)
      ? p.rules.map((r: BackendOrderedRule) => {
        const ruleId = r.ruleId ?? r.rule_id ?? ''
        const ruleData = availableRules.find((ar) => ar.id === ruleId || ar.rule_id === ruleId)
        return {
          id: ruleId,
          name: ruleData?.name ?? r.name ?? '',
          description: ruleData?.description ?? '',
          severity: (ruleData?.severity ?? '') as RuleSeverity,
          rule_id: ruleId,
          rule_version: Number(r.versionNumber ?? r.rule_version) || 1,
          order: r.sequenceNumber ?? r.order ?? 0,
          ruleData,
        }
      })
      : []
    return {
      name: p.name ?? '',
      description: p.description ?? '',
      tags: Array.isArray(p.tags) ? p.tags : [],
      rules,
    }
  }, [policyData, availableRules])

  const handleSubmit = async (payload: {
    name: string
    description: string
    tags: string[]
    rules: { rule_id: string; rule_version: number; order: number }[]
  }) => {
    if (payload.name.trim().length < 3) { toast.error('Policy name must be at least 3 characters'); return }
    if (payload.description.trim().length < 10) { toast.error('Description must be at least 10 characters'); return }
    if (payload.rules.length === 0) { toast.error('Add at least one rule'); return }

    const rules = payload.rules.map((r, idx) => {
      const rd = availableRules.find((ar) => ar.id === r.rule_id || ar.rule_id === r.rule_id)
      return {
        ruleId: r.rule_id,
        name: rd?.name ?? '',
        sequenceNumber: idx + 1,
        versionNumber: String(r.rule_version ?? '1.0.0'),
      }
    })

    const body = {
      name: payload.name.trim(),
      description: payload.description.trim(),
      policyType: 'GOVERNANCE',
      tags: payload.tags ?? [],
      metadata: {},
      rules,
    }

    try {
      if (isEdit) {
        await updatePolicy({ id: id!, data: body }).unwrap()
        toast.success('Policy updated')
        history.push(`${POLICYOPS_PATH.POLICIES}/${id}`)
      } else {
        const result = await createPolicy(body).unwrap()
        const newId = result?.data?.policyId ?? result?.data?._id ?? result?.data?.policy_id
        toast.success('Policy created')
        history.push(newId ? `${POLICYOPS_PATH.POLICIES}/${newId}` : POLICYOPS_PATH.POLICIES)
      }
    } catch {
      toast.error('Save failed. Please try again.')
    }
  }

  return (
    
    <PolicyFormPage
      policyId={id}
      availableRules={availableRules}
      initialPolicy={initialPolicy}
      loading={rulesLoading || (isEdit && policyLoading)}
      saving={creating || updating}
      onSubmit={handleSubmit}
      onCancel={() => history.push(POLICYOPS_PATH.POLICIES)}
      onNewRule={() => history.push(`${POLICYOPS_PATH.RULES}/new`)}
      onEditRule={(rule) => history.push(`${POLICYOPS_PATH.RULES}/${rule.id ?? rule.rule_id}/edit`)}
    />
  )
}

export default PolicyFormContainer
