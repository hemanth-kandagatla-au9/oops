import React, { useState } from 'react'
import {
  Box, Grid, Paper, Typography, Button, TextField,
  InputAdornment, Chip, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, LinearProgress
} from '@mui/material'
import {
  Search, Zap, TrendingUp, TrendingDown,
  Activity,
  AlertTriangle,
  CheckCircle,
  Server,
  XCircle,
  Download,
  SlidersHorizontal
} from 'lucide-react'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, BarChart, Bar
} from 'recharts'
import { useHistory } from 'react-router-dom'
import Cookies from 'universal-cookie'
import { useGetAgentsHealthQuery } from '../../redux/slices/agentsSlice'
import { useGetDashboardSummaryQuery } from '../../redux/slices/complianceSlice'
import { useGetRulesQuery } from '../../redux/slices/rulesSlice'
import { formatDisplayName } from '../../utils/uiConstants'
import { POLICYOPS_PATH } from '../../utils/constant'

const tabs = ['Server Compliance', 'Assignment Health', 'Incidents', 'Agent Health']

/* ------------------ COMPONENT ------------------ */

const ResponseGauge: React.FC<{ value: number }> = ({ value }) => (
  <Box display="flex" flexDirection="column" alignItems="center" pt={1}>
    <svg viewBox="0 0 180 110" width={170} height={105}>
      <path d="M20,95 A70,70 0 0,1 160,95" fill="none" stroke="#fee2e2" strokeWidth="14" strokeLinecap="round" />
      <path d="M20,95 A70,70 0 0,1 70,30" fill="none" stroke="#10b981" strokeWidth="14" strokeLinecap="round" />
      <path d="M70,30 A70,70 0 0,1 115,28" fill="none" stroke="#fbbf24" strokeWidth="14" strokeLinecap="round" />
      <path d="M115,28 A70,70 0 0,1 160,95" fill="none" stroke="#f97316" strokeWidth="14" strokeLinecap="round" />
      <line x1="90" y1="95" x2="108" y2="38" stroke="#1a1d2e" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="90" cy="95" r="5" fill="#1a1d2e" />
      <text x="90" y="78" fontSize="22" fontWeight="800" fill="#1a1d2e" textAnchor="middle">{value}</text>
      <text x="90" y="92" fontSize="8.5" fill="#888" textAnchor="middle">Your response time in every millisecond</text>
      <text x="90" y="104" fontSize="8.5" fill="#aaa" textAnchor="middle">Last Check on 21 Apr</text>
    </svg>
  </Box>
)

const DashboardPage = () => {
  const history = useHistory()
  const fullName = formatDisplayName(new Cookies().get('user_fullname') || '')
  const [activeTab, setActiveTab] = useState('Agent Health')

  const { data: dashData } = useGetDashboardSummaryQuery()
  const { data: healthData } = useGetAgentsHealthQuery()

  const summary = dashData?.data
  const health = healthData?.data ?? { online: 0, stale: 0, offline: 0, total: 142 }
  const complianceRate = summary?.compliance_rate ?? 98.7

  const statCards = [
    {
      label: 'Servers Managed', value: health.total || 142, color: '#3b5bdb',
      icon: <Server size={14} />, trend: '+12', up: true,
    },
    {
      label: 'Auto Redemption', value: `${complianceRate.toFixed(1)}%`, color: '#10b981',
      icon: <CheckCircle size={14} />, trend: '+12%', up: true, green: true,
    },
    {
      label: 'Execution (24H)', value: summary?.executions_today ?? 118, color: '#6366f1',
      icon: <Activity size={14} />, trend: '+5', up: true,
    },
    {
      label: 'Drift Events (24h)', value: summary?.drift_events_today ?? 28, color: '#FFA521',
      icon: <AlertTriangle size={14} />, trend: '-8', up: false, warn: true,
    },
    {
      label: 'Failed Execution', value: summary?.failing_servers ?? 14, color: '#ef4444',
      icon: <XCircle size={14} />, trend: '-3', up: false, danger: true,
    },
  ]

  const DEPLOYMENT_TREND = [
    { month: 'Jan', value: 76 },
    { month: 'Feb', value: 80 },
    { month: 'Mar', value: 78 },
    { month: 'Apr', value: 85 },
    { month: 'May', value: 91 },
    { month: 'Jun', value: 95 },
  ]

  const EXECUTION_THROUGHPUT = Array.from({ length: 10 }, (_, i) => ({
    label: `W${i + 1}`,
    light: Math.floor(Math.random() * 400) + 100,
    dark: Math.floor(Math.random() * 600) + 200,
  }))

  const AGENTS = [
    { id: 'cs-agent-prod-001', version: 'V2.2.1', env: 'Production', lastCheckin: '1 min ago', success: 82, status: 'Healthy' },
    { id: 'cs-agent-prod-002', version: 'V2.2.0', env: 'Production', lastCheckin: '3 min ago', success: 95, status: 'Healthy' },
    { id: 'cs-agent-staging-01', version: 'V2.1.9', env: 'Staging', lastCheckin: '12 min ago', success: 67, status: 'Stale' },
    { id: 'cs-agent-dev-003', version: 'V2.1.8', env: 'Development', lastCheckin: '45 min ago', success: 40, status: 'Offline' },
  ]

  const ACTIVITIES = [
    { title: 'Heartbeat', sub: 'cs-agent-prod-001', time: '1 min ago' },
    { title: 'Policy sync', sub: 'cs-agent-prod-002', time: '2 min ago' },
    { title: 'Config drift detected', sub: 'cs-agent-staging-01', time: '8 min ago' },
    { title: 'Auto remediation triggered', sub: 'cs-agent-prod-001', time: '11 min ago' },
  ]

  const statusColor = (s: string) =>
    s === 'Healthy' ? { bg: '#dcfce7', color: '#16a34a' }
      : s === 'Stale' ? { bg: '#fef9c3', color: '#a16207' }
        : { bg: '#fee2e2', color: '#dc2626' }


  return (
    <Box p={2} bgcolor="#FBFCFF">

      {/* HEADER */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Box>
          <Typography fontWeight={700}>Welcome {fullName}</Typography>
          <Typography fontSize="12px" color="#6b7280">
            Real-time visibility into configuration compliance, drift events and autonomous remediation across the estate.
          </Typography>
        </Box>

        <Box display="flex" gap={1} alignItems="center">


          <TextField
            size="small" placeholder="Search"
            InputProps={{
              startAdornment: <InputAdornment position="start"><Search size={13} /></InputAdornment>,
              sx: { fontSize: '0.78rem', height: 32 },
            }}
            sx={{ flex: 1, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e5ef' } }}
          />

          <Button size="small" variant="outlined" sx={{ border: '1px solid #F2F2F2', borderRadius: '100px', color: '#4C5463' }}>
            Last 24 hours
          </Button>

          <Button
            size="small"
            startIcon={<Zap size={14} />}
            onClick={() => history.push(`${POLICYOPS_PATH.CHAT}`)}
            sx={{
              borderRadius: '100px',
              padding: '6px 14px',
              textTransform: 'none',
              fontWeight: 600,

              border: '1px solid transparent',
              background: `
      linear-gradient(#fff, #fff) padding-box,
      linear-gradient(90deg, #2961F4, #EB1700) border-box
    `,

              backgroundImage: 'linear-gradient(90deg, #2961F4, #EB1700)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}
          >
            Ask Assistant
          </Button>
        </Box>
      </Box>

      {/* HERO */}
      <Grid container spacing={2} mb={2}>
        <Grid item xs={8}>
          <Paper sx={{ p: 2, borderRadius: "16px", border: '1px solid #D7E2FF', backgroundColor: '#F3F6FF' }}>


            <Chip
              label="POLICYOPS ENFORCER"
              size="small"
              sx={{
                mb: 1,

                border: '1px solid #D7E2FF',
                backgroundColor: '#FFFFFF',
                padding: "10px",
                height: 'auto',
                color: '#2961F4',
                fontWeight: 500,
              }}
            />
            <Typography fontWeight={700}>
              Configuration State & Self-Healing Operations
            </Typography>
            <Typography fontSize="12px" color="#6b7280" mt={1}>
              PolicyOps ensures active configs remain compliant. Try simulating an out-of-order policy drift to view our real-time correction system in play.
            </Typography>
          </Paper>
        </Grid>

        <Grid item xs={4}>
          <Paper sx={{ p: 2, borderRadius: 3, border: '1px solid #EAECF0', backgroundColor: '#FFFFFF' }}>
            <Typography fontSize="36px" fontWeight={500}>
              98.7%
            </Typography>
            <Typography fontWeight={600}>
              Compliance Posture
            </Typography>
            <Typography fontSize="12px" color="#777">
              Across all managed infrastructure
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      {/* STATS */}
      <Grid container spacing={1.5} mb={2}>
        {statCards.map((c) => (
          <Grid item xs={6} sm={4} md key={c.label}>
            <Paper elevation={0} sx={{ p: 1.5, borderRadius: 2, border: '1px solid #e8eaf0', bgcolor: 'white' }}>
              <Box display="flex" alignItems="center" gap={0.75} mb={0.5}>
                <Box sx={{ color: c.color, display: 'flex' }}>{c.icon}</Box>
                <Typography sx={{ fontSize: '0.7rem', color: '#888', fontWeight: 500 }}>{c.label}</Typography>
              </Box>
              <Typography sx={{
                fontSize: '1.5rem', fontWeight: 700,
                color: c.green ? '#10b981' : c.warn ? '#f97316' : c.danger ? '#ef4444' : '#1a1d2e',
              }}>
                {c.value}
              </Typography>
              <Box display="inline-flex" alignItems="center" gap={0.4}
                sx={{
                  bgcolor: c.up ? '#dcfce7' : '#fee2e2',
                  borderRadius: '20px', px: 0.75, py: 0.25, mt: 0.5,
                }}>
                {c.up ? <TrendingUp size={10} color="#16a34a" /> : <TrendingDown size={10} color="#dc2626" />}
                <Typography sx={{ fontSize: '0.65rem', fontWeight: 700, color: c.up ? '#16a34a' : '#dc2626' }}>
                  {c.trend}
                </Typography>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>

      {/* TABS */}
      <Box
        sx={{
          display: 'inline-flex',
          border: '1px solid #F2F2F2',
          backgroundColor: '#FFFFFF',
          padding: "8px",
          gap: "12px",
          borderRadius: "24px",
          mb: 2
        }}
      >
        {tabs.map((t) => (
          <Box
            key={t}
            onClick={() => setActiveTab(t)}
            sx={{
              px: 2,
              py: 0.7,
              cursor: 'pointer',
              background: activeTab === t ? 'linear-gradient(261deg, #477AFF -0.05%, #6D92F3 99.95%)' : 'transparent',
              borderRadius: '24px',
              fontSize: 12,
              // bgcolor:  '#3b5bdb' : 'transparent',
              color: activeTab === t ? '#fff' : '#667085'
            }}
          >
            {t}
          </Box>
        ))}
      </Box>

      {/* Charts */}
      <Grid container spacing={1.5} mb={2}>
        {/* Deployment Trends */}
        <Grid item xs={12} md={4.5}>
          <Paper elevation={0} sx={{ p: 2, borderRadius: 2, border: '1px solid #e8eaf0', bgcolor: 'white', height: 200 }}>
            <Typography sx={{ fontSize: '0.82rem', fontWeight: 600, mb: 1 }}>Deployment Trends</Typography>
            <ResponsiveContainer width="100%" height={150}>
              <AreaChart data={DEPLOYMENT_TREND} margin={{ top: 0, right: 5, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="dGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#f43f5e" stopOpacity={0.18} />
                    <stop offset="100%" stopColor="#f43f5e" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#bbb' }} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: '#bbb' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ border: '1px solid #e2e8f0', borderRadius: 8, fontSize: 11 }} />
                <Area type="monotone" dataKey="value" stroke="#f43f5e" strokeWidth={2} fill="url(#dGrad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        {/* Execution Throughput */}
        <Grid item xs={12} md={4.5}>
          <Paper elevation={0} sx={{ p: 2, borderRadius: 2, border: '1px solid #e8eaf0', bgcolor: 'white', height: 200 }}>
            <Typography sx={{ fontSize: '0.82rem', fontWeight: 600, mb: 1 }}>Execution Throughput</Typography>
            <ResponsiveContainer width="100%" height={150}>
              <BarChart data={EXECUTION_THROUGHPUT} margin={{ top: 0, right: 5, left: -25, bottom: 0 }} barCategoryGap="20%">
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 10, fill: '#bbb' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: '#bbb' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ border: '1px solid #e2e8f0', borderRadius: 8, fontSize: 11 }} />
                <Bar dataKey="light" fill="#93c5fd" radius={[3, 3, 0, 0]} barSize={6} />
                <Bar dataKey="dark" fill="#3b82f6" radius={[3, 3, 0, 0]} barSize={6} />
              </BarChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        <Grid item xs={12} md={3}>
          <Paper elevation={0} sx={{ p: 2, borderRadius: 2, border: '1px solid #e8eaf0', bgcolor: 'white', height: 200 }}>
            <Typography sx={{ fontSize: '0.82rem', fontWeight: 600, mb: 0.5 }}>Response Time (ms)</Typography>
            <ResponseGauge value={120} />
          </Paper>
        </Grid>
      </Grid>

      {/* Agent Health + Activity */}
      <Grid container spacing={1.5}>
        <Grid item xs={12} md={8}>
          <Paper elevation={0} sx={{ p: 2, borderRadius: 2, border: '1px solid #e8eaf0', bgcolor: 'white' }}>
            <Typography sx={{ fontSize: '0.82rem', fontWeight: 600, mb: 1.5 }}>Agent Health</Typography>
            <Box display="flex" gap={1} mb={1.5}>
              <TextField
                size="small" placeholder="Search"
                InputProps={{
                  startAdornment: <InputAdornment position="start"><Search size={13} /></InputAdornment>,
                  sx: { fontSize: '0.78rem', height: 32 },
                }}
                sx={{ flex: 1, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e5ef' } }}
              />
              <Button variant="outlined" size="small" startIcon={<SlidersHorizontal size={13} />}
                sx={{ borderColor: '#e2e5ef', color: '#555', fontSize: '0.75rem', height: 32 }}>Filter</Button>
              <Button variant="outlined" size="small" startIcon={<Download size={13} />}
                sx={{ borderColor: '#e2e5ef', color: '#555', fontSize: '0.75rem', height: 32 }}>Export</Button>
            </Box>
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell padding="checkbox" />
                    {['Agent', 'Version', 'Environment', 'Last Check-In', 'Success Rate', 'Status'].map((h) => (
                      <TableCell key={h} sx={{ fontSize: '0.7rem', color: '#888', fontWeight: 500 }}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {AGENTS.map((a) => {
                    const sc = statusColor(a.status)
                    const barColor = a.status === 'Healthy' ? '#10b981' : a.status === 'Stale' ? '#fbbf24' : '#ef4444'
                    return (
                      <TableRow key={a.id} hover>
                        <TableCell padding="checkbox"><input type="checkbox" /></TableCell>
                        <TableCell sx={{ fontSize: '0.75rem', fontWeight: 600, color: '#3b5bdb' }}>{a.id}</TableCell>
                        <TableCell sx={{ fontSize: '0.75rem' }}>{a.version}</TableCell>
                        <TableCell sx={{ fontSize: '0.75rem' }}>{a.env}</TableCell>
                        <TableCell sx={{ fontSize: '0.75rem' }}>{a.lastCheckin}</TableCell>
                        <TableCell>
                          <Box display="flex" alignItems="center" gap={0.75}>
                            <LinearProgress variant="determinate" value={a.success}
                              sx={{
                                width: 60, height: 5, borderRadius: 3, bgcolor: '#e8eaf0',
                                '& .MuiLinearProgress-bar': { bgcolor: barColor, borderRadius: 3 },
                              }} />
                            <Typography sx={{ fontSize: '0.72rem' }}>{a.success}%</Typography>
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Chip label={a.status} size="small"
                            sx={{ bgcolor: sc.bg, color: sc.color, fontSize: '0.68rem', height: 20, fontWeight: 600 }} />
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>

        <Grid item xs={12} md={4}>
          <Paper elevation={0} sx={{ p: 2, borderRadius: 2, border: '1px solid #e8eaf0', bgcolor: 'white', height: '100%' }}>
            <Typography sx={{ fontSize: '0.82rem', fontWeight: 600, mb: 1.5 }}>Agent Activity</Typography>
            {ACTIVITIES.map((a, i) => (
              <Box key={i} py={1} borderBottom={i < ACTIVITIES.length - 1 ? '1px solid #f8f8f8' : 'none'}>
                <Box display="flex" justifyContent="space-between" alignItems="flex-start">
                  <Typography sx={{ fontSize: '0.78rem', fontWeight: 600, color: '#1a1d2e' }}>{a.title}</Typography>
                  <Typography sx={{ fontSize: '0.68rem', color: '#bbb', flexShrink: 0, ml: 1 }}>{a.time}</Typography>
                </Box>
                <Typography sx={{ fontSize: '0.72rem', color: '#aaa' }}>{a.sub}</Typography>
              </Box>
            ))}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  )
}

export default DashboardPage