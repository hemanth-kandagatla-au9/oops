import React from 'react'
import { Box, Typography, Button } from '@mui/material'
import { ShieldOff } from 'lucide-react'
import { useMsal } from '@azure/msal-react'
import { POLICYOPS_PATH } from '../../utils/constant'

const UnauthorizedPage: React.FC = () => {
  const { instance } = useMsal()

  return (
    <Box
      display="flex"
      flexDirection="column"
      justifyContent="center"
      alignItems="center"
      height="100vh"
      gap={2}
      sx={{ bgcolor: '#f8fafc' }}
    >
      <Box
        sx={{
          width: 56, height: 56, borderRadius: '50%',
          bgcolor: '#fef2f2', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}
      >
        <ShieldOff size={28} color="#ef4444" />
      </Box>

      <Typography sx={{ fontSize: '1.35rem', fontWeight: 700, color: '#0f172a' }}>
        Access Denied
      </Typography>

      <Typography sx={{ fontSize: '0.9rem', color: '#64748b', textAlign: 'center', maxWidth: 380 }}>
        Your account does not have permission to access this application.
        Please contact your administrator to request access.
      </Typography>

      <Button
        variant="outlined"
        size="small"
        onClick={() => instance.logoutRedirect({ postLogoutRedirectUri: POLICYOPS_PATH.LOGOUT })}
        sx={{ mt: 1, borderColor: '#cbd5e1', color: '#475569', textTransform: 'none', borderRadius: '8px' }}
      >
        Sign out
      </Button>
    </Box>
  )
}

export default UnauthorizedPage
