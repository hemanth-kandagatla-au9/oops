// common
export type Status = "draft" | "published" | "archived"
export type Severity = "critical" | "high" | "medium" | "low"
export type RuleType = "file" | "package" | "service" | "script"
export type EnforcementMode = "audit" | "monitor" | "enforce"
export type AgentStatus = "online" | "stale" | "offline"
export type TargetType = "server" | "environment" | "sid" | "ci" | "global" | "metadata"
export type OnFailure = "continue" | "stop"

export interface PaginatedResponse<T = any> {
  status: boolean
  message: string
  data: T[]
  total: number
  page: number
  limit: number
}

export interface ApiResponse<T = any> {
  status: boolean
  message: string
  data: T
}

export type RuleCategoryFieldType = "text" | "textarea" | "select" | "checkbox" | "number" | "toggle"

export interface RuleCategoryField {
  field: string
  displayName: string
  description?: string
  placeholder: string
  fieldType: RuleCategoryFieldType
  options: string[]
  isMandatory: boolean
  nestedFields: RuleCategoryField[]
}

export interface RuleCategoryMetadata {
  name: string
  categoryCode: string
  description: string
  configFields: RuleCategoryField[]
  driftResponses: RuleCategoryField[]
  isActive: boolean
}

// Rule
export interface RuleDefinition {
  // file type
  path?: string
  checksum?: string
  owner?: string
  group?: string
  permissions?: string
  // package type
  name?: string
  version?: string
  manager?: "yum" | "dnf" | "apt"
  // service type
  state?: "running" | "stopped" | "enabled" | "disabled"
  // script type
  command?: string
  expected_exit_code?: number
  [key: string]: any
}

export interface Rule {
  _id: string
  id?: string
  rule_id: string
  name: string
  description: string
  rule_type: RuleType
  rulecategory?: string
  severity: Severity
  tags: string[]
  version: number
  status: Status
  definition: RuleDefinition
  execution: {
    retry: number
    timeout: number
    on_failure: OnFailure
  }
  created_by: string
  created_at: string
  updated_by: string
  updated_at: string
}

// Policy
export interface PolicyRule {
  rule_id: string
  rule_version: number
  order: number
}

export interface Policy {
  _id: string
  policy_id: string
  name: string
  description: string
  tags: string[]
  version: number
  status: Status
  rules: PolicyRule[]
  created_by: string
  created_at: string
  updated_at: string
  published_by?: string
  published_at?: string
}

// PolicyGroup
export interface PolicyGroupPolicy {
  policy_id: string
  policy_version: number
  order: number
}

export interface PolicyGroup {
  _id: string
  group_id: string
  name: string
  description: string
  tags: string[]
  version: number
  status: Status
  policies: PolicyGroupPolicy[]
  created_by: string
  created_at: string
  updated_at: string
  published_at?: string
}

// Assignment
export interface Assignment {
  _id: string
  assignment_id: string
  name: string
  description: string
  policy_group_id: string
  policy_group_version: number
  target_type: TargetType
  target_value: string | string[] | Record<string, string>
  frequency: number
  mode: EnforcementMode
  version: number
  status: Status
  created_by: string
  created_at: string
  updated_at: string
  published_by?: string
  published_at?: string
}

// Agent
export interface Agent {
  _id: string
  agent_id: string
  hostname: string
  environment: string
  agent_version: string
  status: AgentStatus
  last_heartbeat: string
  last_sync: string
  assignment_ids: string[]
}

export interface ExecutionHistoryEntry {
  execution_id: string
  assignment_id: string
  policy_id: string
  rule_id: string
  rule_version: number
  status: "passed" | "failed" | "timeout"
  start_time: string
  end_time: string
  duration: number
  output: string
  logs: string
}

// Drift
export interface DriftEvent {
  _id: string
  drift_id: string
  assignment_id: string
  policy_group_id: string
  policy_id: string
  rule_id: string
  hostname: string
  severity: Severity
  expected: any
  actual: any
  detected_at: string
  status: "detected" | "remediating" | "fixed" | "failed"
}

export interface RemediationHistory {
  remediation_id: string
  rule_id: string
  action: string
  status: "started" | "completed" | "failed"
  start_time: string
  end_time: string
  duration: number
  logs: string
}

// Audit
export interface AuditLog {
  _id?: string
  audit_id: string
  module: string
  api_endpoint: string
  requested_by: string
  timestamp: string
  request_data: string
  response_data: string
  status_code: number
  request_method: string
}

// Dashboard
export interface DashboardSummary {
  compliance_rate: number
  servers_managed: number
  drift_events_today: number
  failing_servers: number
}

export interface ComplianceSummary {
  compliant: number
  non_compliant: number
  pending: number
  total: number
}

export interface ComplianceByGroup {
  group_name: string
  compliance_rate: number
  total_servers: number
}

export interface ComplianceTrend {
  date: string
  compliance_rate: number
}
