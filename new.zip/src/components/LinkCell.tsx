import React from 'react'
import { Box, Typography } from '@mui/material'

interface LinkCellProps {
  label: string
  onClick: () => void
  secondary?: string
}

const LinkCell: React.FC<LinkCellProps> = ({ label, onClick, secondary }) => (
  <Box sx={{ overflow: 'hidden' }}>
    <Typography
      variant="body2"
      fontWeight={500}
      noWrap
      sx={{
        color: '#102459',
        cursor: 'pointer',
        fontSize: '0.875rem',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        '&:hover': { color: '#1d4ed8' },
      }}
      onClick={onClick}
    >
      {label}
    </Typography>
    {secondary && (
      <Typography
        variant="caption"
        display="block"
        noWrap
        sx={{ color: '#64748b', fontSize: '0.78rem', mt: 0.25, overflow: 'hidden', textOverflow: 'ellipsis' }}
      >
        {secondary}
      </Typography>
    )}
  </Box>
)

export default LinkCell
