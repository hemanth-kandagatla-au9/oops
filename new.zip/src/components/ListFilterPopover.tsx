import React from 'react'
import {
  Box,
  Button,
  Checkbox,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Popover,
  Select,
  TextField,
  Typography,
} from '@mui/material'
import { SEARCH_FIELD_SX } from './SearchFilterBar'

export interface FilterOption {
  value: string
  label: string
}

export interface FilterFieldConfig {
  key: string
  label: string
  type: 'text' | 'select' | 'radio'
  placeholder?: string
  options?: FilterOption[]
  fullWidth?: boolean
}

export interface ListFilterPopoverProps {
  open: boolean
  anchorEl: HTMLElement | null
  onClose: () => void
  fields: FilterFieldConfig[]
  draftValues: Record<string, string>
  onDraftChange: (key: string, value: string) => void
  onApply: () => void
  onClear: () => void
}

const FILTER_FIELD_SX = {
  ...SEARCH_FIELD_SX,
  '& .MuiOutlinedInput-root': {
    ...SEARCH_FIELD_SX['& .MuiOutlinedInput-root'],
    borderRadius: '8px',
  },
}

const RADIO_ITEM_SX = {
  borderRadius: '8px',
  py: 0.5,
  px: 0.75,
  minHeight: 36,
}

const ListFilterPopover: React.FC<ListFilterPopoverProps> = ({
  open,
  anchorEl,
  onClose,
  fields,
  draftValues,
  onDraftChange,
  onApply,
  onClear,
}) => (
  <Popover
    open={open}
    anchorEl={anchorEl}
    onClose={onClose}
    anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
    transformOrigin={{ vertical: 'top', horizontal: 'right' }}
    PaperProps={{
      sx: {
        mt: 1,
        borderRadius: '12px',
        border: '1px solid #e2e8f0',
        boxShadow: '0 8px 24px rgba(15,23,42,0.08)',
        width: 420,
        maxWidth: '92vw',
      },
    }}
  >
    <Box sx={{ p: 2 }}>
      <Typography variant="subtitle2" fontWeight={700} color="#0f172a" mb={2}>
        Filters
      </Typography>

      <Grid container spacing={2}>
        {fields.map((field) => {
          if (field.type === 'text' || field.type === 'select') {
            return (
              <Grid item xs={12} sm={field.fullWidth ? 12 : 6} key={field.key}>
                {field.type === 'text' ? (
                  <TextField
                    fullWidth
                    size="small"
                    label={field.label}
                    placeholder={field.placeholder}
                    value={draftValues[field.key] ?? ''}
                    onChange={(e) => onDraftChange(field.key, e.target.value)}
                    sx={FILTER_FIELD_SX}
                  />
                ) : (
                  <FormControl fullWidth size="small" sx={FILTER_FIELD_SX}>
                    <InputLabel>{field.label}</InputLabel>
                    <Select
                      value={draftValues[field.key] ?? ''}
                      label={field.label}
                      onChange={(e) => onDraftChange(field.key, e.target.value)}
                    >
                      <MenuItem value=""><em>All</em></MenuItem>
                      {(field.options ?? []).map((option) => (
                        <MenuItem key={option.value} value={option.value}>
                          {option.label}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                )}
              </Grid>
            )
          }

          return (
            <Grid item xs={12} key={field.key}>
              <Typography variant="subtitle2" fontWeight={700} color="#0f172a" mb={1}>
                {field.label}
              </Typography>
              <Grid container spacing={1}>
                <Grid item xs={6}>
                  <MenuItem
                    onClick={() => onDraftChange(field.key, '')}
                    sx={RADIO_ITEM_SX}
                  >
                    <Checkbox size="small" checked={(draftValues[field.key] ?? '') === ''} />
                    <Typography variant="body2">All</Typography>
                  </MenuItem>
                </Grid>
                {(field.options ?? []).map((option) => (
                  <Grid item xs={6} key={option.value}>
                    <MenuItem
                      onClick={() => onDraftChange(field.key, option.value)}
                      sx={RADIO_ITEM_SX}
                    >
                      <Checkbox size="small" checked={draftValues[field.key] === option.value} />
                      <Typography variant="body2" noWrap>{option.label}</Typography>
                    </MenuItem>
                  </Grid>
                ))}
              </Grid>
            </Grid>
          )
        })}
      </Grid>

      <Box display="flex" justifyContent="flex-end" gap={1} mt={2}>
        <Button
          size="small"
          onClick={onClear}
          sx={{ textTransform: 'none', color: '#64748b' }}
        >
          Clear
        </Button>
        <Button
          size="small"
          variant="contained"
          onClick={onApply}
          sx={{
            textTransform: 'none',
            bgcolor: '#2563eb',
            boxShadow: 'none',
            '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' },
          }}
        >
          Apply
        </Button>
      </Box>
    </Box>
  </Popover>
)

export default ListFilterPopover
