import React from 'react'
import {
  Alert, Box, Checkbox, IconButton, MenuItem,
  Paper, Select, Skeleton, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Typography,
} from '@mui/material'
import { ChevronLeft, ChevronRight } from 'lucide-react'

// ── Column definition ─────────────────────────────────────────────────────────

export interface TableColumn {
  key: string
  header: string | React.ReactNode
  width?: number | string
  minWidth?: number
  flex?: number
  align?: 'left' | 'center' | 'right'
  render: (row: any) => React.ReactNode
}

// ── Pagination ────────────────────────────────────────────────────────────────

interface PaginationProps {
  total: number
  page: number            // 0-based
  pageSize: number
  rowsPerPageOptions: number[]
  onPageChange: (page: number) => void
  onPageSizeChange?: (size: number) => void
}

const getPageNumbers = (current: number, total: number): (number | '...')[] => {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1)

  const pages: (number | '...')[] = [1]

  if (current > 3) pages.push('...')

  const start = Math.max(2, current - 1)
  const end = Math.min(total - 1, current + 1)
  for (let i = start; i <= end; i++) pages.push(i)

  if (current < total - 2) pages.push('...')

  pages.push(total)
  return pages
}

const TablePagination: React.FC<PaginationProps> = ({
  total, page, pageSize, rowsPerPageOptions, onPageChange, onPageSizeChange,
}) => {
  const totalPages = Math.ceil(total / pageSize)
  const current = page + 1  // 1-based for display
  const pageNums = getPageNumbers(current, totalPages)

  const navBtnSx = (disabled: boolean) => ({
    width: 28, height: 28, p: 0, borderRadius: '4px',
    color: disabled ? '#cbd5e1' : '#64748b',
    '&:hover': { bgcolor: disabled ? 'transparent' : '#f1f5f9', color: disabled ? '#cbd5e1' : '#1e293b' },
  })

  const pageNumSx = (active: boolean) => ({
    minWidth: 28, height: 28, px: 1,
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    borderRadius: '4px',
    cursor: 'pointer', userSelect: 'none' as const,
    bgcolor: active ? '#2563eb' : 'transparent',
    color: active ? 'white' : '#64748b',
    fontSize: '0.8rem', fontWeight: active ? 600 : 400,
    transition: 'background 0.1s',
    '&:hover': { bgcolor: active ? '#2563eb' : '#f1f5f9', color: active ? 'white' : '#1e293b' },
  })

  return (
    <Box
      display="flex"
      justifyContent="space-between"
      alignItems="center"
      px={2}
      py={1.25}
      sx={{ borderTop: '1px solid #f1f5f9' }}
    >
      {/* Page numbers */}
      <Box display="flex" alignItems="center" gap={0.25}>
        <IconButton size="small" disabled={page === 0} onClick={() => onPageChange(page - 1)} sx={navBtnSx(page === 0)}>
          <ChevronLeft size={16} />
        </IconButton>

        {pageNums.map((p, i) =>
          p === '...' ? (
            <Typography key={`ell-${i}`} variant="caption" color="text.secondary" sx={{ px: 0.5 }}>
              …
            </Typography>
          ) : (
            <Box key={p} sx={pageNumSx(current === p)} onClick={() => onPageChange((p as number) - 1)}>
              {p}
            </Box>
          )
        )}

        <IconButton size="small" disabled={page >= totalPages - 1} onClick={() => onPageChange(page + 1)} sx={navBtnSx(page >= totalPages - 1)}>
          <ChevronRight size={16} />
        </IconButton>
      </Box>

      {/* Rows per page + total */}
      <Box display="flex" alignItems="center" gap={0.75}>
        <Typography variant="caption" color="text.secondary">Showing</Typography>
        <Select
          size="small"
          value={pageSize}
          onChange={(e) => onPageSizeChange?.(Number(e.target.value))}
          disabled={!onPageSizeChange}
          sx={{
            minWidth: 52, height: 26, fontSize: '0.75rem',
            '& .MuiSelect-select': { py: '2px !important', px: '8px !important', color: '#374151' },
            '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e8f0' },
          }}
        >
          {rowsPerPageOptions.map((s) => (
            <MenuItem key={s} value={s} sx={{ fontSize: '0.8rem' }}>{s}</MenuItem>
          ))}
        </Select>
        <Typography variant="caption" color="text.secondary">of {total}</Typography>
      </Box>
    </Box>
  )
}

// ── Loading skeleton ──────────────────────────────────────────────────────────

const TableLoadingSkeleton: React.FC<{ columns: number; rows?: number }> = ({
  columns, rows = 8,
}) => (
  <>
    {Array.from({ length: rows }).map((_, ri) => (
      <TableRow key={ri} sx={{ '&:last-child td': { borderBottom: 0 } }}>
        {Array.from({ length: columns }).map((__, ci) => (
          <TableCell key={ci} sx={{ py: 1.75, borderBottom: '1px solid #f1f5f9' }}>
            <Skeleton variant="text" width={ci === 0 ? '75%' : '55%'} height={18} />
            {ci === 0 && <Skeleton variant="text" width="45%" height={14} sx={{ mt: 0.25 }} />}
          </TableCell>
        ))}
      </TableRow>
    ))}
  </>
)

// ── Main component ────────────────────────────────────────────────────────────

export interface PolicyTableProps {
  columns: TableColumn[]
  rows: any[]
  total: number
  page: number               // 0-based
  pageSize?: number
  rowsPerPageOptions?: number[]
  onPageChange: (page: number) => void
  onPageSizeChange?: (size: number) => void
  loading?: boolean
  error?: boolean
  errorMessage?: string
  emptyMessage?: string
  getRowId?: (row: any) => string
  onRowClick?: (row: any) => void
  checkboxSelection?: boolean
  sx?: object
}

const PolicyTable: React.FC<PolicyTableProps> = ({
  columns,
  rows,
  total,
  page,
  pageSize = 10,
  rowsPerPageOptions = [10, 25, 50],
  onPageChange,
  onPageSizeChange,
  loading = false,
  error = false,
  errorMessage = 'Failed to load data',
  emptyMessage = 'No records found',
  getRowId = (row) => row._id,
  onRowClick,
  checkboxSelection = false,
  sx = {},
}) => {
  const [selected, setSelected] = React.useState<Set<string>>(new Set())

  const tableMinWidth = React.useMemo(() => {
    const contentWidth = columns.reduce((sum, col) => {
      if (typeof col.width === 'number') return sum + col.width
      if (typeof col.minWidth === 'number') return sum + col.minWidth
      return sum + 140
    }, 0)

    return checkboxSelection ? contentWidth + 48 : contentWidth
  }, [checkboxSelection, columns])

  const allSelected = rows.length > 0 && rows.every((r) => selected.has(getRowId(r)))
  const someSelected = rows.some((r) => selected.has(getRowId(r))) && !allSelected

  const toggleAll = () => {
    if (allSelected) {
      setSelected(new Set())
    } else {
      setSelected(new Set(rows.map(getRowId)))
    }
  }

  const toggleRow = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  const colCount = columns.length

  if (error) {
    return <Box p={3}><Alert severity="error">{errorMessage}</Alert></Box>
  }

  return (
    <Paper
      elevation={0}
      sx={{
        borderRadius: 2,
        border: '1px solid #e2e8f0',
        overflow: 'hidden',
        bgcolor: 'white',
        display: 'flex',
        flexDirection: 'column',
        ...sx,
      }}
    >
      <TableContainer sx={{ flex: 1, overflowX: 'auto' }}>
        <Table size="small" sx={{ tableLayout: 'fixed', minWidth: tableMinWidth }}>
          {/* ── Header ── */}
          <TableHead>
            <TableRow sx={{ bgcolor: '#f8fafc' }}>
              {columns.map((col, i) => (
                <TableCell
                  key={col.key}
                  align={col.align ?? 'left'}
                  sx={{
                    width: col.width,
                    minWidth: col.minWidth,
                    borderBottom: '1px solid #e2e8f0',
                    py: 1.5,
                    pl: 2,
                    pr: 2,
                    color: '#475569',
                    fontSize: '0.8rem',
                    fontWeight: 600,
                    whiteSpace: 'nowrap',
                  }}
                >
                  {checkboxSelection && i === 0 ? (
                    <Box display="flex" alignItems="center" gap={1}>
                      <Checkbox
                        size="small"
                        checked={allSelected}
                        indeterminate={someSelected}
                        onChange={toggleAll}
                        sx={{ p: '3px', flexShrink: 0, color: '#cbd5e1', '& .MuiSvgIcon-root': { fontSize: 18 }, '&.Mui-checked, &.MuiCheckbox-indeterminate': { color: '#2563eb' } }}
                      />
                      {col.header}
                    </Box>
                  ) : col.header}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>

          {/* ── Body ── */}
          <TableBody>
            {loading ? (
              <TableLoadingSkeleton columns={colCount} rows={pageSize} />
            ) : rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={colCount} sx={{ py: 6, textAlign: 'center', borderBottom: 0 }}>
                  <Typography variant="body2" color="text.secondary">{emptyMessage}</Typography>
                </TableCell>
              </TableRow>
            ) : (
              rows.map((row) => {
                const id = getRowId(row)
                const isSelected = selected.has(id)
                return (
                  <TableRow
                    key={id}
                    hover
                    selected={isSelected}
                    onClick={onRowClick ? () => onRowClick(row) : undefined}
                    sx={{
                      cursor: onRowClick ? 'pointer' : 'default',
                      '&:last-child td': { borderBottom: 0 },
                      '& td': { borderBottom: '1px solid #f1f5f9' },
                      '&:hover': { bgcolor: '#f8fafc' },
                      '&.Mui-selected': { bgcolor: '#eff6ff' },
                      '&.Mui-selected:hover': { bgcolor: '#dbeafe' },
                    }}
                  >
                    {columns.map((col, i) => (
                      <TableCell
                        key={col.key}
                        align={col.align ?? 'left'}
                        sx={{
                          py: 1.5,
                          pl: 2,
                          pr: 2,
                          verticalAlign: 'middle',
                          overflow: 'hidden',
                          maxWidth: 0,
                        }}
                      >
                        {checkboxSelection && i === 0 ? (
                          <Box display="flex" alignItems="center" gap={1} onClick={(e) => e.stopPropagation()}>
                            <Checkbox
                              size="small"
                              checked={isSelected}
                              onChange={() => toggleRow(id)}
                              sx={{ p: '3px', flexShrink: 0, color: '#cbd5e1', '& .MuiSvgIcon-root': { fontSize: 18 }, '&.Mui-checked': { color: '#2563eb' } }}
                            />
                            <Box sx={{ overflow: 'hidden', flex: 1 }}>{col.render(row)}</Box>
                          </Box>
                        ) : col.render(row)}
                      </TableCell>
                    ))}
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* ── Pagination ── */}
      {!loading && total > 0 && (
        <TablePagination
          total={total}
          page={page}
          pageSize={pageSize}
          rowsPerPageOptions={rowsPerPageOptions}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
        />
      )}
    </Paper>
  )
}

export default PolicyTable
