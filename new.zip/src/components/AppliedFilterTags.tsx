import React from 'react'
import { Box, Button, Chip } from '@mui/material'

export interface AppliedFilterTag {
  key: string
  label: string
}

export interface AppliedFilterTagsProps {
  tags: AppliedFilterTag[]
  onRemove: (key: string) => void
  onClearAll: () => void
}

const AppliedFilterTags: React.FC<AppliedFilterTagsProps> = ({
  tags,
  onRemove,
  onClearAll,
}) => {
  if (!tags.length) return null

  return (
    <Box display="flex" alignItems="center" gap={1} flexWrap="wrap" mb={2.5}>
      {tags.map((tag) => (
        <Chip
          key={tag.key}
          label={tag.label}
          size="small"
          onDelete={() => onRemove(tag.key)}
          sx={{
            height: 28,
            fontSize: '0.75rem',
            fontWeight: 500,
            bgcolor: '#eff6ff',
            color: '#1d4ed8',
            border: '1px solid #bfdbfe',
            '& .MuiChip-deleteIcon': {
              color: '#64748b',
              fontSize: 16,
              '&:hover': { color: '#1d4ed8' },
            },
          }}
        />
      ))}
      <Button
        size="small"
        onClick={onClearAll}
        sx={{
          textTransform: 'none',
          fontWeight: 600,
          fontSize: '0.75rem',
          color: '#2563eb',
          minWidth: 'auto',
          px: 1,
        }}
      >
        Clear all
      </Button>
    </Box>
  )
}

export default AppliedFilterTags
