import React from 'react'
import { Box, Button, InputAdornment, TextField } from '@mui/material'
import { Search, SlidersHorizontal } from 'lucide-react'

export const SEARCH_FIELD_SX = {
  '& .MuiOutlinedInput-root': {
    borderRadius: '999px',
    bgcolor: '#ffffff',
    fontSize: '0.875rem',
    '& fieldset': { borderColor: '#e2e8f0' },
    '&:hover fieldset': { borderColor: '#cbd5e1' },
    '&.Mui-focused fieldset': { borderColor: '#2563eb', borderWidth: '1px' },
  },
}

export interface SearchFilterBarProps {
  search: string
  onSearchChange: (value: string) => void
  searchPlaceholder?: string
  onFilterClick?: (event: React.MouseEvent<HTMLElement>) => void
  hasActiveFilters?: boolean
  searchWidth?: number | string
}

const SearchFilterBar: React.FC<SearchFilterBarProps> = ({
  search,
  onSearchChange,
  searchPlaceholder = 'Search',
  onFilterClick,
  hasActiveFilters = false,
  searchWidth = 280,
}) => (
  <Box display="flex" gap={1.5} alignItems="center">
    <TextField
      size="small"
      placeholder={searchPlaceholder}
      value={search}
      onChange={(e) => onSearchChange(e.target.value)}
      sx={{ ...SEARCH_FIELD_SX, width: searchWidth }}
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <Search size={16} color="#94a3b8" />
          </InputAdornment>
        ),
      }}
    />
    {onFilterClick && (
      <Button
        variant="outlined"
        startIcon={<SlidersHorizontal size={15} />}
        onClick={onFilterClick}
        sx={{
          borderRadius: '999px',
          borderColor: hasActiveFilters ? '#93c5fd' : '#e2e8f0',
          color: hasActiveFilters ? '#2563eb' : '#64748b',
          bgcolor: hasActiveFilters ? '#eff6ff' : 'white',
          textTransform: 'none',
          fontWeight: 500,
          px: 2,
          '&:hover': {
            borderColor: hasActiveFilters ? '#93c5fd' : '#cbd5e1',
            bgcolor: hasActiveFilters ? '#eff6ff' : 'white',
          },
        }}
      >
        Filter
      </Button>
    )}
  </Box>
)

export default SearchFilterBar
