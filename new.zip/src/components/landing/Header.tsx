import React, { useState } from 'react';
import {
  AppBar, Avatar, Box, Divider, IconButton,
  ListItemIcon, Menu, MenuItem, Toolbar, Tooltip, Typography,
} from '@mui/material';
import { Bell, HelpCircle, LogOut } from 'lucide-react';
import ConfigSphereLogo from '../../assets/logo/configsphere-logo.svg';
import Cookies from 'universal-cookie';
import { useHistory } from 'react-router-dom';
import { POLICYOPS_PATH } from '../../utils/constant';

const cookies = new Cookies();

const getInitials = (name: string): string =>
  name.trim().split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('');

const Header: React.FC = () => {
  const fullName: string = cookies.get('user_fullname') ?? '';
  const email: string = cookies.get('user_email') ?? '';
  const username: string = cookies.get('username') ?? '';
  const history = useHistory();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  return (
    <AppBar
      position="static"
      elevation={0}
      sx={{ bgcolor: 'white', color: 'text.primary', borderBottom: '1px solid #e2e8f0', zIndex: 1 }}
    >
      <Toolbar sx={{ minHeight: '56px !important', px: 2.5 }}>
        {/* Left — J&J brand */}
        <Box display="flex" alignItems="center" gap={1.5} sx={{ minWidth: 180 }}>
          <Typography sx={{ fontWeight: 700, fontSize: '0.95rem', color: '#cc0000', letterSpacing: '-0.3px' }}>
            Johnson&amp;Johnson
          </Typography>
          <Box sx={{ width: '1px', height: 20, bgcolor: '#d1d5db' }} />
        </Box>

        {/* Center — ConfigSphere logo + name */}
        <Box flexGrow={1} display="flex" justifyContent="center" alignItems="center" gap={1}>
          <img src={ConfigSphereLogo} alt="ConfigSphere" style={{ height: 36 }} />
          <Typography sx={{ fontSize: '1.15rem', fontWeight: 700, letterSpacing: '-0.3px' }}>
            <Box component="span" sx={{ color: '#2563eb' }}>Config</Box>
            <Box component="span" sx={{ color: '#1e293b' }}>Sphere</Box>
          </Typography>
        </Box>

        {/* Right — icons + user */}
        <Box display="flex" alignItems="center" gap={0.5} sx={{ minWidth: 180, justifyContent: 'flex-end' }}>
          <Tooltip title="Notifications">
            <IconButton size="small" sx={{ color: '#64748b' }}>
              <Bell size={20} />
            </IconButton>
          </Tooltip>
          <Tooltip title="Help">
            <IconButton size="small" sx={{ color: '#64748b' }}>
              <HelpCircle size={20} />
            </IconButton>
          </Tooltip>
          {fullName && (
            <Tooltip title={fullName}>
              <IconButton size="small" onClick={(e) => setAnchorEl(e.currentTarget)} sx={{ ml: 1 }}>
                <Avatar sx={{ width: 32, height: 32, bgcolor: '#2563eb', fontSize: 13, fontWeight: 600 }}>
                  {getInitials(fullName)}
                </Avatar>
              </IconButton>
            </Tooltip>
          )}
        </Box>
      </Toolbar>

      {/* User dropdown */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={() => setAnchorEl(null)}
        PaperProps={{
          elevation: 2,
          sx: { mt: 1, minWidth: 220, borderRadius: 2, border: '1px solid #e2e8f0' },
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        <Box px={2} py={1.5}>
          <Box display="flex" alignItems="center" gap={1.5}>
            <Avatar sx={{ width: 38, height: 38, bgcolor: '#2563eb', fontSize: 14, fontWeight: 600 }}>
              {getInitials(fullName)}
            </Avatar>
            <Box overflow="hidden">
              <Typography variant="body2" fontWeight={600} color="#1e293b" noWrap>{fullName || '—'}</Typography>
              <Typography variant="caption" color="text.secondary" noWrap display="block">{email || '—'}</Typography>
              {username && (
                <Typography variant="caption" color="text.secondary" noWrap display="block">@{username}</Typography>
              )}
            </Box>
          </Box>
        </Box>
        <Divider />
        <MenuItem
          onClick={() => { setAnchorEl(null); history.push(POLICYOPS_PATH.LOGOUT); }}
          sx={{ color: '#ef4444', py: 1.25 }}
        >
          <ListItemIcon sx={{ color: '#ef4444', minWidth: 32 }}>
            <LogOut size={16} />
          </ListItemIcon>
          <Typography variant="body2" fontWeight={500}>Sign out</Typography>
        </MenuItem>
      </Menu>
    </AppBar>
  );
};

export default Header;
