import React from 'react'
import { Box, Grid, Skeleton } from '@mui/material'

const CARD_SX = {
  minHeight: 196,
  p: '20px',
  borderRadius: '10px',
  border: '1px solid #e2e8f0',
  bgcolor: '#ffffff',
  boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
  display: 'flex',
  flexDirection: 'column',
  gap: '20px',
}

export const PolicyCardShimmer: React.FC = () => (
  <Box className="ps-policy-card ps-policy-card--shimmer" sx={CARD_SX}>
    <Box className="ps-policy-card__header" display="flex" justifyContent="space-between" alignItems="flex-start" gap={1}>
      <Skeleton variant="text" width="62%" height={22} sx={{ transform: 'none' }} />
      <Skeleton variant="rounded" width={72} height={22} sx={{ borderRadius: '999px', flexShrink: 0 }} />
    </Box>

    <Box className="ps-policy-card__meta" display="flex" justifyContent="space-between" alignItems="flex-start">
      <Box className="ps-policy-card__meta-item">
        <Skeleton variant="text" width={88} height={14} sx={{ transform: 'none', mb: 0.5 }} />
        <Skeleton variant="text" width={56} height={18} sx={{ transform: 'none' }} />
      </Box>
      <Box className="ps-policy-card__meta-item ps-policy-card__meta-item--right" textAlign="right">
        <Skeleton variant="text" width={40} height={14} sx={{ transform: 'none', mb: 0.5, ml: 'auto' }} />
        <Skeleton variant="text" width={24} height={18} sx={{ transform: 'none', ml: 'auto' }} />
      </Box>
    </Box>

    <Box className="ps-policy-card__footer" display="flex" justifyContent="space-between" alignItems="center" mt="auto">
      <Box display="flex" alignItems="center" gap={1}>
        <Skeleton variant="circular" width={28} height={28} />
        <Skeleton variant="text" width={72} height={16} sx={{ transform: 'none' }} />
      </Box>
      <Skeleton variant="text" width={80} height={16} sx={{ transform: 'none' }} />
    </Box>
  </Box>
)

interface CardGridShimmerProps {
  count?: number
  layout?: 'ps-grid' | 'mui-grid'
}

const CardGridShimmer: React.FC<CardGridShimmerProps> = ({ count = 6, layout = 'ps-grid' }) => {
  if (layout === 'mui-grid') {
    return (
      <Grid container spacing={2.5}>
        {Array.from({ length: count }).map((_, index) => (
          <Grid item xs={12} sm={6} lg={4} key={index}>
            <PolicyCardShimmer />
          </Grid>
        ))}
      </Grid>
    )
  }

  return (
    <div className="ps-grid">
      {Array.from({ length: count }).map((_, index) => (
        <PolicyCardShimmer key={index} />
      ))}
    </div>
  )
}

export default CardGridShimmer
