import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface PermissionState {
  permissions: any[] | null;
  isLoading: boolean;
  isError: boolean;
  isSessionExpired: boolean;
}

const initialState: PermissionState = {
  permissions: null,
  isLoading: false,
  isError: false,
  isSessionExpired: false,
};

const permissionSlice = createSlice({
  name: "permissions",
  initialState,
  reducers: {
    setPermissions(state, action: PayloadAction<any[]>) {
      state.permissions = action.payload;
      state.isLoading = false;
      state.isError = false;
    },
    setPermissionsLoading(state, action: PayloadAction<boolean>) {
      state.isLoading = action.payload;
    },
    setPermissionsError(state, action: PayloadAction<boolean>) {
      state.isError = action.payload;
      state.isLoading = false;
    },
    setSessionExpired(state, action: PayloadAction<boolean>) {
      state.isSessionExpired = action.payload;
    },
    clearPermissions(state) {
      state.permissions = null;
      state.isLoading = false;
      state.isError = false;
      state.isSessionExpired = false;
    },
  },
});

export const {
  setPermissions,
  setPermissionsLoading,
  setPermissionsError,
  setSessionExpired,
  clearPermissions,
} = permissionSlice.actions;

export default permissionSlice.reducer;
