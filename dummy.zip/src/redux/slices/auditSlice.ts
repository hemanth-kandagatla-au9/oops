import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const auditSlice = createApi({
  reducerPath: "auditApi",
  baseQuery,
  tagTypes: ["AuditLog"],
  endpoints: (builder) => ({
    getAuditLogs: builder.query<any, { page?: number; limit?: number; module?: string; entity_type?: string; action?: string; performed_by?: string; from_date?: string; to_date?: string }>({
      query: ({ page = 1, limit = 20, module, entity_type, action, performed_by, from_date, to_date }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (module) params.append("module", module);
        if (entity_type) params.append("entity_type", entity_type);
        if (action) params.append("action", action);
        if (performed_by) params.append("performed_by", performed_by);
        if (from_date) params.append("from_date", from_date);
        if (to_date) params.append("to_date", to_date);
        return `/audit?${params.toString()}`;
      },
      providesTags: ["AuditLog"],
    }),
    getAuditById: builder.query<any, string>({
      query: (id) => `/audit/${id}`,
      providesTags: (_result, _error, id) => [{ type: "AuditLog", id }],
    }),
    exportAudit: builder.query<any, { format?: string }>({
      query: ({ format = "json" }) => `/audit/export?format=${format}`,
    }),
  }),
});

export const {
  useGetAuditLogsQuery,
  useGetAuditByIdQuery,
  useExportAuditQuery,
} = auditSlice;
