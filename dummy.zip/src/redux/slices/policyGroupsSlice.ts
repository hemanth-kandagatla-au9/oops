import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const policyGroupsSlice = createApi({
  reducerPath: "policyGroupsApi",
  baseQuery,
  tagTypes: ["PolicyGroup"],
  endpoints: (builder) => ({
    getPolicyGroups: builder.query<any, { page?: number; limit?: number; status?: string; search?: string }>({
      query: ({ page = 1, limit = 10, status, search }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (status) params.append("status", status);
        if (search) params.append("search", search);
        return `/policy-groups?${params.toString()}`;
      },
      providesTags: ["PolicyGroup"],
    }),
    getPolicyGroupById: builder.query<any, string>({
      query: (id) => `/policy-groups/${id}`,
      providesTags: (_result, _error, id) => [{ type: "PolicyGroup", id }],
    }),
    createPolicyGroup: builder.mutation<any, Partial<any>>({
      query: (body) => ({ url: "/policy-groups", method: "POST", body }),
      invalidatesTags: ["PolicyGroup"],
    }),
    updatePolicyGroup: builder.mutation<any, { id: string; data: Partial<any> }>({
      query: ({ id, data }) => ({ url: `/policy-groups/${id}`, method: "PUT", body: data }),
      invalidatesTags: (_result, _error, { id }) => [{ type: "PolicyGroup", id }, "PolicyGroup"],
    }),
    deletePolicyGroup: builder.mutation<any, string>({
      query: (id) => ({ url: `/policy-groups/${id}`, method: "DELETE" }),
      invalidatesTags: ["PolicyGroup"],
    }),
    publishPolicyGroup: builder.mutation<any, string>({
      query: (id) => ({ url: `/policy-groups/${id}/publish`, method: "POST" }),
      invalidatesTags: (_result, _error, id) => [{ type: "PolicyGroup", id }, "PolicyGroup"],
    }),
    archivePolicyGroup: builder.mutation<any, string>({
      query: (id) => ({ url: `/policy-groups/${id}/archive`, method: "POST" }),
      invalidatesTags: (_result, _error, id) => [{ type: "PolicyGroup", id }, "PolicyGroup"],
    }),
    clonePolicyGroup: builder.mutation<any, string>({
      query: (id) => ({ url: `/policy-groups/${id}/clone`, method: "POST" }),
      invalidatesTags: ["PolicyGroup"],
    }),
  }),
});

export const {
  useGetPolicyGroupsQuery,
  useGetPolicyGroupByIdQuery,
  useCreatePolicyGroupMutation,
  useUpdatePolicyGroupMutation,
  useDeletePolicyGroupMutation,
  usePublishPolicyGroupMutation,
  useArchivePolicyGroupMutation,
  useClonePolicyGroupMutation,
} = policyGroupsSlice;
