import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const artifactsSlice = createApi({
  reducerPath: "artifactsApi",
  baseQuery,
  tagTypes: ["Artifact"],
  endpoints: (builder) => ({
    getArtifacts: builder.query<any, { page?: number; limit?: number; artifactType?: string }>({
      query: ({ page = 1, limit = 10, artifactType }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (artifactType) params.append("artifactType", artifactType);
        return `/artifacts?${params.toString()}`;
      },
      providesTags: ["Artifact"],
    }),
    getArtifactById: builder.query<any, string>({
      query: (id) => `/artifacts/${id}`,
    }),
    createArtifact: builder.mutation<any, Partial<any>>({
      query: (body) => ({ url: "/artifacts", method: "POST", body }),
      invalidatesTags: ["Artifact"],
    }),
    updateArtifact: builder.mutation<any, { id: string; data: Partial<any> }>({
      query: ({ id, data }) => ({ url: `/artifacts/${id}`, method: "PUT", body: data }),
      invalidatesTags: ["Artifact"],
    }),
    deleteArtifact: builder.mutation<any, string>({
      query: (id) => ({ url: `/artifacts/${id}`, method: "DELETE" }),
      invalidatesTags: ["Artifact"],
    }),
  }),
});

export const {
  useGetArtifactsQuery,
  useGetArtifactByIdQuery,
  useCreateArtifactMutation,
  useUpdateArtifactMutation,
  useDeleteArtifactMutation,
} = artifactsSlice;
