import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const agentsSlice = createApi({
  reducerPath: "agentsApi",
  baseQuery,
  tagTypes: ["Agent"],
  endpoints: (builder) => ({
    getAgents: builder.query<any, { page?: number; limit?: number; status?: string }>({
      query: ({ page = 1, limit = 10, status }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (status) params.append("status", status);
        return `/agents?${params.toString()}`;
      },
      providesTags: ["Agent"],
    }),
    getAgentById: builder.query<any, string>({
      query: (id) => `/agents/${id}`,
      providesTags: (_result, _error, id) => [{ type: "Agent", id }],
    }),
    syncAgent: builder.mutation<any, string>({
      query: (id) => ({ url: `/agents/${id}/sync-now`, method: "POST" }),
      invalidatesTags: (_result, _error, id) => [{ type: "Agent", id }],
    }),
    getExecutionHistory: builder.query<any, { hostname: string; page?: number; limit?: number }>({
      query: ({ hostname, page = 1, limit = 10 }) =>
        `/hosts/${hostname}/execution-history?page=${page}&limit=${limit}`,
    }),
    getAgentsHealth: builder.query<any, void>({
      query: () => "/agents/health",
    }),
  }),
});

export const {
  useGetAgentsQuery,
  useGetAgentByIdQuery,
  useSyncAgentMutation,
  useGetExecutionHistoryQuery,
  useGetAgentsHealthQuery,
} = agentsSlice;
