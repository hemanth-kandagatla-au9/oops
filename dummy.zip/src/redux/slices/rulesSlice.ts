import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const rulesSlice = createApi({
  reducerPath: "rulesApi",
  baseQuery,
  tagTypes: ["Rule"],
  endpoints: (builder) => ({
    getRules: builder.query<any, { page?: number; limit?: number; status?: string; type?: string; severity?: string; category?: string; search?: string }>({
      query: ({ page = 1, limit = 10, status, type, severity, category, search }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (status) params.append("status", status);
        if (type) params.append("type", type);
        if (severity) params.append("severity", severity);
        if (category) params.append("category", category);
        if (search) params.append("search", search);
        return `/rules?${params.toString()}`;
      },
      providesTags: ["Rule"],
    }),
    getRuleById: builder.query<any, string>({
      query: (id) => `/rules/${id}`,
      providesTags: (_result, _error, id) => [{ type: "Rule", id }],
    }),
    getRuleCategoriesMetadata: builder.query<any, void>({
      query: () => "/rule-categories/metadata",
    }),
    createRule: builder.mutation<any, Partial<any>>({
      query: (body) => ({ url: "/rules", method: "POST", body }),
      invalidatesTags: ["Rule"],
    }),
    updateRule: builder.mutation<any, { id: string; data: Partial<any> }>({
      query: ({ id, data }) => ({ url: `/rules/${id}`, method: "PUT", body: data }),
      invalidatesTags: (_result, _error, { id }) => [{ type: "Rule", id }, "Rule"],
    }),
    deleteRule: builder.mutation<any, string>({
      query: (id) => ({ url: `/rules/${id}`, method: "DELETE" }),
      invalidatesTags: ["Rule"],
    }),
    publishRule: builder.mutation<any, string>({
      query: (id) => ({ url: `/rules/${id}/publish`, method: "POST" }),
      invalidatesTags: (_result, _error, id) => [{ type: "Rule", id }, "Rule"],
    }),
    archiveRule: builder.mutation<any, string>({
      query: (id) => ({ url: `/rules/${id}/archive`, method: "POST" }),
      invalidatesTags: (_result, _error, id) => [{ type: "Rule", id }, "Rule"],
    }),
    cloneRule: builder.mutation<any, string>({
      query: (id) => ({ url: `/rules/${id}/clone`, method: "POST", body: {} }),
      invalidatesTags: ["Rule"],
    }),
    getRuleCategories: builder.query<any, void>({
      query: () => "/category/get_all",
    }),
    getGovernanceTeams: builder.query<any, void>({
      query: () => "/governance/get_all",
    }),
  }),
});

export const {
  useGetRulesQuery,
  useGetRuleByIdQuery,
  useGetRuleCategoriesMetadataQuery,
  useGetRuleCategoriesQuery,
  useGetGovernanceTeamsQuery,
  useCreateRuleMutation,
  useUpdateRuleMutation,
  useDeleteRuleMutation,
  usePublishRuleMutation,
  useArchiveRuleMutation,
  useCloneRuleMutation,
} = rulesSlice;
