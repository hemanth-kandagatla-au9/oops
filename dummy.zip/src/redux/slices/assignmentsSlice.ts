import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const assignmentsSlice = createApi({
  reducerPath: "assignmentsApi",
  baseQuery,
  tagTypes: ["Assignment"],
  endpoints: (builder) => ({
    getAssignments: builder.query<any, { page?: number; limit?: number; policyId?: string; status?: string; target_type?: string; mode?: string; search?: string }>({
      query: ({ page = 1, limit = 10, policyId, status, target_type, mode, search }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (policyId) params.append("policy_id", policyId);
        if (status) params.append("status", status);
        if (target_type) params.append("target_type", target_type);
        if (mode) params.append("mode", mode);
        if (search) params.append("search", search);
        return `/assignments?${params.toString()}`;
      },
      providesTags: ["Assignment"],
    }),
    getAssignmentById: builder.query<any, string>({
      query: (id) => `/assignments/${id}`,
      providesTags: (_result, _error, id) => [{ type: "Assignment", id }],
    }),
    createAssignment: builder.mutation<any, Partial<any>>({
      query: (body) => ({ url: "/assignments", method: "POST", body }),
      invalidatesTags: ["Assignment"],
    }),
    updateAssignment: builder.mutation<any, { id: string; data: Partial<any> }>({
      query: ({ id, data }) => ({ url: `/assignments/${id}`, method: "PUT", body: data }),
      invalidatesTags: (_result, _error, { id }) => [{ type: "Assignment", id }, "Assignment"],
    }),
    revokeAssignment: builder.mutation<any, string>({
      query: (id) => ({ url: `/assignments/${id}`, method: "DELETE" }),
      invalidatesTags: ["Assignment"],
    }),
    publishAssignment: builder.mutation<any, string>({
      query: (id) => ({ url: `/assignments/${id}/publish`, method: "POST" }),
      invalidatesTags: (_result, _error, id) => [{ type: "Assignment", id }, "Assignment"],
    }),
    cloneAssignment: builder.mutation<any, string>({
      query: (id) => ({ url: `/assignments/${id}/clone`, method: "POST" }),
      invalidatesTags: ["Assignment"],
    }),
  }),
});

export const {
  useGetAssignmentsQuery,
  useGetAssignmentByIdQuery,
  useCreateAssignmentMutation,
  useUpdateAssignmentMutation,
  useRevokeAssignmentMutation,
  usePublishAssignmentMutation,
  useCloneAssignmentMutation,
} = assignmentsSlice;
