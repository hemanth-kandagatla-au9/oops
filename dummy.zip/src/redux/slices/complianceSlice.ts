import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const complianceSlice = createApi({
  reducerPath: "complianceApi",
  baseQuery,
  tagTypes: ["Compliance"],
  endpoints: (builder) => ({
    getComplianceRecords: builder.query<any, { page?: number; limit?: number; status?: string }>({
      query: ({ page = 1, limit = 10, status }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (status) params.append("status", status);
        return `/compliance?${params.toString()}`;
      },
      providesTags: ["Compliance"],
    }),
    getComplianceSummary: builder.query<any, void>({
      query: () => "/compliance/summary",
    }),
    getComplianceById: builder.query<any, string>({
      query: (id) => `/compliance/${id}`,
    }),
    createComplianceRecord: builder.mutation<any, Partial<any>>({
      query: (body) => ({ url: "/compliance", method: "POST", body }),
      invalidatesTags: ["Compliance"],
    }),
    getDashboardSummary: builder.query<any, void>({
      query: () => "/dashboard/summary",
    }),
    getComplianceTrend: builder.query<any, void>({
      query: () => "/compliance/trend",
    }),
    getDriftEvents: builder.query<any, { page?: number; limit?: number; status?: string; severity?: string; hostname?: string }>({
      query: ({ page = 1, limit = 10, status, severity, hostname }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (status) params.append("status", status);
        if (severity) params.append("severity", severity);
        if (hostname) params.append("hostname", hostname);
        return `/drift-logs?${params.toString()}`;
      },
    }),
    getRemediationEvents: builder.query<any, { page?: number; limit?: number }>({
      query: ({ page = 1, limit = 10 }) =>
        `/remediation-events?page=${page}&limit=${limit}`,
    }),
  }),
});

export const {
  useGetComplianceRecordsQuery,
  useGetComplianceSummaryQuery,
  useGetComplianceByIdQuery,
  useCreateComplianceRecordMutation,
  useGetDashboardSummaryQuery,
  useGetComplianceTrendQuery,
  useGetDriftEventsQuery,
  useGetRemediationEventsQuery,
} = complianceSlice;
