import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export const targetServersSlice = createApi({
  reducerPath: "targetServersApi",
  baseQuery,
  tagTypes: ["TargetServer"],
  endpoints: (builder) => ({
    getTargetServersMetadata: builder.query<any, void>({
      query: () => "/target-servers/metadata",
    }),
    getTargetServers: builder.query<
      any,
      {
        page?: number;
        limit?: number;
        region?: string;
        os?: string;
        sid?: string;
        owner?: string;
        application?: string;
        environment?: string;
        search?: string;
      }
    >({
      query: ({
        page = 1,
        limit = 100,
        region,
        os,
        sid,
        owner,
        application,
        environment,
        search,
      }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (region) params.append("region", region);
        if (os) params.append("os", os);
        if (sid) params.append("sid", sid);
        if (owner) params.append("owner", owner);
        if (application) params.append("application", application);
        if (environment) params.append("environment", environment);
        if (search) params.append("search", search);
        return `/target-servers?${params.toString()}`;
      },
      providesTags: ["TargetServer"],
    }),
  }),
});

export const {
  useGetTargetServersMetadataQuery,
  useGetTargetServersQuery,
} = targetServersSlice;
