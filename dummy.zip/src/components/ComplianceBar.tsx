import React from 'react'
import { Box, Typography } from '@mui/material'
import { complianceColor } from '../utils/uiConstants'

interface ComplianceBarProps {
  value: number  // 0–100
  barWidth?: number
}

const ComplianceBar: React.FC<ComplianceBarProps> = ({ value, barWidth = 64 }) => {
  const color = complianceColor(value)
  return (
    <Box display="flex" alignItems="center" gap={1}>
      <Typography variant="body2" fontWeight={600} sx={{ color, minWidth: 36 }}>
        {value}%
      </Typography>
      <Box sx={{ width: barWidth, height: 5, bgcolor: '#e2e8f0', borderRadius: 3, overflow: 'hidden', flexShrink: 0 }}>
        <Box sx={{ height: '100%', width: `${Math.min(value, 100)}%`, bgcolor: color, borderRadius: 3 }} />
      </Box>
    </Box>
  )
}

export default ComplianceBar
