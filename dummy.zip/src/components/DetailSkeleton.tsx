import React from 'react'
import { Box, Skeleton, Paper } from '@mui/material'

const DetailSkeleton: React.FC = () => (
  <Box p={3}>
    {/* Breadcrumb */}
    <Box display="flex" alignItems="center" gap={1} mb={2}>
      <Skeleton variant="circular" width={28} height={28} />
      <Skeleton variant="text" width={70} height={20} />
      <Skeleton variant="text" width={16} height={20} />
      <Skeleton variant="text" width={140} height={20} />
    </Box>

    {/* Header card */}
    <Paper elevation={0} variant="outlined" sx={{ p: 3, mb: 3, borderRadius: 2 }}>
      <Box display="flex" justifyContent="space-between" alignItems="flex-start">
        <Box flex={1}>
          <Box display="flex" alignItems="center" gap={1.5} mb={1.5}>
            <Skeleton variant="text" width={220} height={36} />
            <Skeleton variant="rounded" width={72} height={24} />
            <Skeleton variant="rounded" width={56} height={24} />
          </Box>
          <Skeleton variant="text" width="55%" height={20} />
          <Box display="flex" gap={1} mt={1}>
            <Skeleton variant="rounded" width={60} height={20} />
            <Skeleton variant="rounded" width={70} height={20} />
            <Skeleton variant="rounded" width={50} height={20} />
          </Box>
        </Box>
        <Box display="flex" gap={1}>
          <Skeleton variant="rounded" width={80} height={36} />
          <Skeleton variant="rounded" width={80} height={36} />
        </Box>
      </Box>
    </Paper>

    {/* Tabs + content */}
    <Paper elevation={0} variant="outlined" sx={{ borderRadius: 2 }}>
      <Box sx={{ borderBottom: '1px solid', borderColor: 'divider', px: 2, py: 0.5 }}>
        <Box display="flex" gap={3} py={1}>
          <Skeleton variant="text" width={80} height={24} />
          <Skeleton variant="text" width={80} height={24} />
          <Skeleton variant="text" width={100} height={24} />
        </Box>
      </Box>
      <Box p={3}>
        {Array.from({ length: 6 }).map((_, i) => (
          <Box key={i} display="flex" py={1.5} borderBottom="1px solid" borderColor="divider">
            <Skeleton variant="text" width={160} sx={{ mr: 3, flexShrink: 0 }} />
            <Skeleton variant="text" sx={{ flex: 1 }} width={`${50 + (i % 3) * 15}%`} />
          </Box>
        ))}
      </Box>
    </Paper>
  </Box>
)

export default DetailSkeleton
