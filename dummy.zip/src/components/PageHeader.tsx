import React from 'react'
import { Box, Chip, Typography } from '@mui/material'

interface PageHeaderProps {
  title: string
  subtitle?: string
  count?: number
  action?: React.ReactNode
}

const PageHeader: React.FC<PageHeaderProps> = ({ title, subtitle, count, action }) => (
  <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
    <Box>
      <Box display="flex" alignItems="center" gap={1}>
        <Typography variant="h5" fontWeight="bold">{title}</Typography>
        {count !== undefined && (
          <Chip label={count} size="small" sx={{ height: 20, fontSize: '0.7rem' }} />
        )}
      </Box>
      {subtitle && (
        <Typography variant="body2" color="text.secondary">{subtitle}</Typography>
      )}
    </Box>
    {action && <Box>{action}</Box>}
  </Box>
)

export default PageHeader
