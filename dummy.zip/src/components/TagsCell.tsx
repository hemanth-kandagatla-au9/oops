import React from 'react'
import { Box, Chip } from '@mui/material'

interface TagsCellProps {
  tags: string[]
  max?: number
}

const TagsCell: React.FC<TagsCellProps> = ({ tags, max = 2 }) => (
  <Box display="flex" gap={0.5} alignItems="center">
    {tags.slice(0, max).map((t) => (
      <Chip
        key={t}
        label={t}
        size="small"
        variant="outlined"
        sx={{ fontSize: '0.65rem', height: 20 }}
      />
    ))}
    {tags.length > max && (
      <Chip
        label={`+${tags.length - max}`}
        size="small"
        sx={{ fontSize: '0.65rem', height: 20 }}
      />
    )}
  </Box>
)

export default TagsCell
