import React from 'react'
import { Box, Typography } from '@mui/material'
import CustomSwitch from './CustomSwitch'

export type FormToggleRowChangeHandler = (checked: boolean) => void

export interface FormToggleRowProps {
  label: string
  description?: string
  checked: boolean
  onChange: FormToggleRowChangeHandler
  disabled?: boolean
}

const FormToggleRow: React.FC<FormToggleRowProps> = ({
  label,
  description,
  checked,
  onChange,
  disabled = false,
}) => (
  <Box
    sx={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 2,
      px: 2,
      py: 1.75,
      border: '1px solid #e2e8f0',
      borderRadius: '8px',
      bgcolor: '#ffffff',
      height: '100%',
      minHeight: 56,
      boxSizing: 'border-box',
    }}
  >
    <Box sx={{ minWidth: 0, flex: 1 }}>
      <Typography variant="body2" fontWeight={600} color="#0f172a" lineHeight={1.4}>
        {label}
      </Typography>
      {description && (
        <Typography variant="caption" color="text.secondary" display="block" lineHeight={1.4} mt={0.25}>
          {description}
        </Typography>
      )}
    </Box>
    <CustomSwitch
      checked={checked}
      disabled={disabled}
      onChange={(_, value) => onChange(value)}
    />
  </Box>
)

export default FormToggleRow
