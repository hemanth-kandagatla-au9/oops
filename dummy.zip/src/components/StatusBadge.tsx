import React from 'react'
import { Box, Typography } from '@mui/material'

// Design-style soft pill badges — light bg + darker text, matching mockups.
// Use these in table cells instead of MUI Chip for the visual design.

export type BadgeVariant =
  | 'active'
  | 'monitor'
  | 'pending'
  | 'failed'
  | 'draft'
  | 'archived'
  | 'online'
  | 'stale'
  | 'offline'
  | 'enforce'
  | 'audit'
  | 'critical'
  | 'high'
  | 'medium'
  | 'low'
  | 'success'
  | 'warning'
  | 'error'
  | 'info'

const BADGE_STYLES: Record<BadgeVariant, { bg: string; color: string }> = {
  active:   { bg: '#dcfce7', color: '#16a34a' },
  monitor:  { bg: '#fef3c7', color: '#d97706' },
  pending:  { bg: '#f1f5f9', color: '#64748b' },
  failed:   { bg: '#fee2e2', color: '#dc2626' },
  draft:    { bg: '#f1f5f9', color: '#64748b' },
  archived: { bg: '#fee2e2', color: '#dc2626' },
  online:   { bg: '#dcfce7', color: '#16a34a' },
  stale:    { bg: '#fef3c7', color: '#d97706' },
  offline:  { bg: '#fee2e2', color: '#dc2626' },
  enforce:  { bg: '#fee2e2', color: '#dc2626' },
  audit:    { bg: '#dbeafe', color: '#2563eb' },
  critical: { bg: '#fee2e2', color: '#dc2626' },
  high:     { bg: '#fff7ed', color: '#c2410c' },
  medium:   { bg: '#dbeafe', color: '#1d4ed8' },
  low:      { bg: '#f1f5f9', color: '#64748b' },
  success:  { bg: '#dcfce7', color: '#16a34a' },
  warning:  { bg: '#fef3c7', color: '#d97706' },
  error:    { bg: '#fee2e2', color: '#dc2626' },
  info:     { bg: '#dbeafe', color: '#2563eb' },
}

// Map raw API values to badge variants
export const statusToVariant = (status: string): BadgeVariant => {
  const map: Record<string, BadgeVariant> = {
    published: 'active',
    draft: 'draft',
    archived: 'archived',
    online: 'online',
    stale: 'stale',
    offline: 'offline',
    enforce: 'enforce',
    monitor: 'monitor',
    audit: 'audit',
    active: 'active',
    pending: 'pending',
    failed: 'failed',
    detected: 'info',
    remediating: 'monitor',
    fixed: 'success',
    critical: 'critical',
    high: 'high',
    medium: 'medium',
    low: 'low',
  }
  return map[status?.toLowerCase()] ?? 'pending'
}

// Human-readable labels for API status values
export const statusLabel = (status: string): string => {
  const map: Record<string, string> = {
    published: 'Active',
    draft: 'Draft',
    archived: 'Archived',
    enforce: 'Enforce',
    monitor: 'Monitor Only',
    audit: 'Audit Only',
    online: 'Online',
    stale: 'Stale',
    offline: 'Offline',
    active: 'Active',
    pending: 'Pending',
    failed: 'Failed',
    detected: 'Detected',
    remediating: 'Remediating',
    fixed: 'Fixed',
    critical: 'Critical',
    high: 'High',
    medium: 'Medium',
    low: 'Low',
  }
  return map[status?.toLowerCase()] ?? status
}

interface StatusBadgeProps {
  value: string                  // raw API value e.g. "published"
  variant?: BadgeVariant         // override auto-mapping
  label?: string                 // override auto-label
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ value, variant, label }) => {
  const v = variant ?? statusToVariant(value)
  const styles = BADGE_STYLES[v] ?? BADGE_STYLES.pending
  const text = label ?? statusLabel(value)

  return (
    <Box
      component="span"
      sx={{
        display: 'inline-flex',
        alignItems: 'center',
        px: 1.25,
        py: 0.25,
        borderRadius: '999px',
        bgcolor: styles.bg,
        color: styles.color,
        fontSize: '0.72rem',
        fontWeight: 600,
        whiteSpace: 'nowrap',
        lineHeight: 1.6,
      }}
    >
      {text}
    </Box>
  )
}

export default StatusBadge
