import React from 'react'
import { Box, Skeleton, Paper } from '@mui/material'

interface TableSkeletonProps {
  rows?: number
  columns?: number
}

const TableSkeleton: React.FC<TableSkeletonProps> = ({ rows = 8, columns = 6 }) => {
  const colWidths = [2, 1, 1, 1, 1, 1, 1, 1].slice(0, columns)

  return (
    <Paper elevation={0} variant="outlined" sx={{ borderRadius: 2, px: 2, pt: 1.5, pb: 1 }}>
      {/* Header row */}
      <Box display="flex" gap={2} mb={1.5} pb={1.5} borderBottom="1px solid" borderColor="divider">
        {colWidths.map((flex, i) => (
          <Skeleton key={i} variant="text" sx={{ flex }} height={22} />
        ))}
      </Box>
      {/* Data rows */}
      {Array.from({ length: rows }).map((_, i) => (
        <Box key={i} display="flex" gap={2} mb={1.25} alignItems="center">
          {colWidths.map((flex, j) => (
            <Skeleton key={j} variant="text" sx={{ flex }}
              height={j === 0 ? 20 : 18}
              width={j === colWidths.length - 1 ? '60%' : undefined} />
          ))}
        </Box>
      ))}
    </Paper>
  )
}

export default TableSkeleton
