import React from 'react'
import { Box, Typography } from '@mui/material'

interface DetailRowProps {
  label: string
  value: React.ReactNode
  last?: boolean
}

const DetailRow: React.FC<DetailRowProps> = ({ label, value, last = false }) => (
  <Box
    display="flex"
    py={1}
    alignItems="flex-start"
    sx={last ? {} : { borderBottom: '1px solid', borderColor: 'divider' }}
  >
    <Typography
      variant="body2"
      color="text.secondary"
      sx={{ minWidth: 140, fontWeight: 500, flexShrink: 0 }}
    >
      {label}
    </Typography>
    <Box flex={1}>
      {typeof value === 'string' || typeof value === 'number'
        ? <Typography variant="body2" sx={{ wordBreak: 'break-all' }}>{value}</Typography>
        : value}
    </Box>
  </Box>
)

export default DetailRow
