import React from 'react'
import { Box, Paper, Typography } from '@mui/material'

interface StatCardProps {
  label: string
  value: string | number
  icon: React.ReactNode
  color: string
  sub?: string
  onClick?: () => void
  active?: boolean
  /** 'borderLeft' = left accent bar (Dashboard style). Default = icon-right card (Agents/Drift style). */
  variant?: 'default' | 'borderLeft'
}

const StatCard: React.FC<StatCardProps> = ({
  label, value, icon, color, sub, onClick, active, variant = 'default',
}) => {
  const isClickable = Boolean(onClick)

  if (variant === 'borderLeft') {
    return (
      <Paper
        elevation={0}
        variant="outlined"
        onClick={onClick}
        sx={{
          p: 2.5,
          borderRadius: 2,
          borderLeft: `4px solid ${color}`,
          cursor: isClickable ? 'pointer' : 'default',
          transition: 'box-shadow 0.15s',
          '&:hover': isClickable ? { boxShadow: 2 } : {},
        }}
      >
        <Box display="flex" justifyContent="space-between" alignItems="flex-start">
          <Box>
            <Typography variant="body2" color="text.secondary" mb={0.5}>{label}</Typography>
            <Typography variant="h4" fontWeight="bold">{value}</Typography>
            {sub && <Typography variant="caption" color="text.secondary">{sub}</Typography>}
          </Box>
          <Box sx={{ color, opacity: 0.75, mt: 0.5 }}>{icon}</Box>
        </Box>
      </Paper>
    )
  }

  return (
    <Paper
      elevation={0}
      variant="outlined"
      onClick={onClick}
      sx={{
        p: 2.5,
        borderRadius: 2,
        cursor: isClickable ? 'pointer' : 'default',
        borderColor: active ? color : 'divider',
        bgcolor: active ? `${color}10` : 'background.paper',
        transition: 'all 0.15s',
        '&:hover': isClickable ? { borderColor: color, bgcolor: `${color}08` } : {},
      }}
    >
      <Box display="flex" justifyContent="space-between" alignItems="center">
        <Box>
          <Typography variant="body2" color="text.secondary" mb={0.5}>{label}</Typography>
          <Typography variant="h4" fontWeight="bold" color={color}>{value}</Typography>
          {sub && <Typography variant="caption" color="text.secondary">{sub}</Typography>}
        </Box>
        <Box sx={{ color, opacity: 0.7 }}>{icon}</Box>
      </Box>
    </Paper>
  )
}

export default StatCard
