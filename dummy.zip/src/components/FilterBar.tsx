import React from 'react'
import {
  Box, Button, FormControl, InputLabel, MenuItem, Select, TextField,
} from '@mui/material'

export interface FilterSelectItem {
  type: 'select'
  key: string
  label: string
  value: string
  onChange: (v: string) => void
  options: { value: string; label: string }[]
  minWidth?: number
}

export interface FilterSearchItem {
  type: 'search'
  key: string
  placeholder: string
  value: string
  onChange: (v: string) => void
  minWidth?: number
}

export interface FilterDateItem {
  type: 'date'
  key: string
  label: string
  value: string
  onChange: (v: string) => void
  minWidth?: number
}

export type FilterItem = FilterSearchItem | FilterSelectItem | FilterDateItem

interface FilterBarProps {
  filters: FilterItem[]
  hasActive: boolean
  onClear: () => void
}

const FilterBar: React.FC<FilterBarProps> = ({ filters, hasActive, onClear }) => (
  <Box display="flex" gap={2} mb={2} flexWrap="wrap" alignItems="center">
    {filters.map((f) => {
      if (f.type === 'search') {
        return (
          <TextField
            key={f.key}
            size="small"
            placeholder={f.placeholder}
            value={f.value}
            onChange={(e) => f.onChange(e.target.value)}
            sx={{ minWidth: f.minWidth ?? 220 }}
          />
        )
      }
      if (f.type === 'date') {
        return (
          <TextField
            key={f.key}
            size="small"
            label={f.label}
            type="date"
            value={f.value}
            onChange={(e) => f.onChange(e.target.value)}
            InputLabelProps={{ shrink: true }}
            sx={{ minWidth: f.minWidth ?? 150 }}
          />
        )
      }
      return (
        <FormControl key={f.key} size="small" sx={{ minWidth: f.minWidth ?? 130 }}>
          <InputLabel>{f.label}</InputLabel>
          <Select
            value={f.value}
            label={f.label}
            onChange={(e) => f.onChange(e.target.value as string)}
          >
            {f.options.map((o) => (
              <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>
            ))}
          </Select>
        </FormControl>
      )
    })}
    {hasActive && (
      <Button size="small" onClick={onClear}>Clear filters</Button>
    )}
  </Box>
)

export default FilterBar
