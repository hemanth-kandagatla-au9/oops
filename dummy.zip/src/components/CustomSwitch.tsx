import { styled, Switch } from "@mui/material";

const CustomSwitch = styled(Switch)(({ theme }) => ({
  width: 52,
  height: 28,
  padding: 0,
  display: "flex",
  alignItems: "center",

  "& .MuiSwitch-switchBase": {
    padding: 2.5,
    top: "50%",
    transform: "translateY(-50%)",
    position: "absolute",
    "&.Mui-checked": {
      transform: "translate(24px, -50%)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        backgroundColor: "#11AF43",
        opacity: 1,
      },
    },
    "&.Mui-disabled + .MuiSwitch-track": { 
      opacity: 0.5,
    },
    "&.Mui-disabled .MuiSwitch-thumb": {  
      opacity: 0.5,
    },
  },
  "& .MuiSwitch-thumb": {
    backgroundColor: "#fff",
    width: 22,
    height: 22,
    boxShadow: "0 0 2px 0 rgba(0, 0, 0, 0.2)",
  },

  "& .MuiSwitch-track": {
    borderRadius: 14,
    backgroundColor: "#ccc",
    opacity: 1,
    transition: theme.transitions.create(["background-color"], {
      duration: 500,
    }),
    boxSizing: "border-box",
  },
}));

export default CustomSwitch;
