import React from 'react'
import { Box, Alert, Paper } from '@mui/material'
import { DataGrid, GridColDef } from '@mui/x-data-grid'
import TableSkeleton from './TableSkeleton'

interface EntityDataGridProps {
  rows: any[]
  columns: GridColDef[]
  total: number
  page: number
  pageSize?: number
  onPageChange: (page: number) => void
  getRowId?: (row: any) => string
  onRowClick?: (row: any) => void
  loading?: boolean
  error?: boolean
  errorMessage?: string
  rowsPerPageOptions?: number[]
  clickableRows?: boolean
}

const EntityDataGrid: React.FC<EntityDataGridProps> = ({
  rows, columns, total, page, pageSize = 25, onPageChange,
  getRowId = (row) => row._id,
  onRowClick, loading = false, error = false,
  errorMessage = 'Failed to load data',
  rowsPerPageOptions = [25, 50],
  clickableRows = false,
}) => {
  if (loading) return <Box p={3}><TableSkeleton /></Box>
  if (error) return <Box p={3}><Alert severity="error">{errorMessage}</Alert></Box>

  return (
    <Paper elevation={0} variant="outlined" sx={{ borderRadius: 2 }}>
      <DataGrid
        rows={rows}
        columns={columns}
        getRowId={getRowId}
        pageSize={pageSize}
        rowsPerPageOptions={rowsPerPageOptions}
        autoHeight
        disableSelectionOnClick
        paginationMode="server"
        rowCount={total}
        page={page}
        onPageChange={onPageChange}
        onRowClick={onRowClick ? (params) => onRowClick(params.row) : undefined}
        sx={{
          border: 'none',
          ...(clickableRows ? {
            '& .MuiDataGrid-row': { cursor: 'pointer' },
            '& .MuiDataGrid-row:hover': { bgcolor: 'action.hover' },
          } : {}),
        }}
      />
    </Paper>
  )
}

export default EntityDataGrid
