import React, { useEffect } from "react";
import { Switch, Route, Redirect, useHistory, useLocation } from "react-router-dom";
import "./App.scss";
import LogoutPage from "./pages/logout/LogoutPage";
import PrivateRoute from "./utils/PrivateRoute";
import { LandingPageLayout } from "./pages/landing/LandingPage";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer } from "react-toastify";
import { POLICYOPS_PATH } from "./utils/constant";
import { useSelector } from "react-redux";
import { RootState } from "./redux/store";
import UnauthorizedPage from "./pages/unauthorized/UnauthorizedPage";
import SessionExpiredPage from "./pages/sessionExpired/SessionExpired";
import DashboardPage from "./pages/dashboard/DashboardPage";
import RulesPage from "./pages/rules/RulesPage";
import RuleDetailPage from "./pages/rules/RuleDetailPage";
import RuleFormPage from "./pages/rules/RuleFormPage";
import PoliciesPage from "./pages/policies/PoliciesPage";
import PolicyDetailPage from "./pages/policies/PolicyDetailPage";
import PolicyCreateEditPage from "./pages/policies/components/PolicyCreateEditPage";
import PolicyGroupsPage from "./pages/policyGroups/PolicyGroupsPage";
import PolicyGroupDetailPage from "./pages/policyGroups/PolicyGroupDetailPage";
import PolicyGroupFormPage from "./pages/policyGroups/PolicyGroupFormPage";
import AssignmentsPage from "./pages/assignments/AssignmentsPage";
import AssignmentDetailPage from "./pages/assignments/AssignmentDetailPage";
import AssignmentFormPage from "./pages/assignments/AssignmentFormPage";
import ArtifactsPage from "./pages/artifacts/ArtifactsPage";
import AgentsPage from "./pages/agents/AgentsPage";
import AgentDetailPage from "./pages/agents/AgentDetailPage";
import DriftPage from "./pages/drift/DriftPage";
import CompliancePage from "./pages/compliance/CompliancePage";
import AuditPage from "./pages/audit/AuditPage";
import SettingsPage from "./pages/settings/SettingsPage";
import Cookies from "universal-cookie";
import { Box, CircularProgress, Typography } from "@mui/material";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import CreatePolicyPage from "./pages/policies/CreatePolicyPage";
import ConfigSpherePage from "./pages/chat/ConfigSpherePage";

const cookies = new Cookies();

const theme = createTheme({
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: '16px',
          textTransform: 'none',
        },
      },
    },
  },
});
const SKIP_AUTH_PATHS: string[] = [
  POLICYOPS_PATH.UNAUTHORIZED,
  POLICYOPS_PATH.LOGOUT,
  POLICYOPS_PATH.SESSION_EXPIRED,
];

const App: React.FC = () => {
  const permissionState = useSelector((state: RootState) => state.permissions.permissions);
  const isLoading = useSelector((state: RootState) => state.permissions.isLoading);
  const isSessionExpired = useSelector((state: RootState) => state.permissions.isSessionExpired);
  const history = useHistory();
  const location = useLocation();
  const isAuthenticated = !!cookies.get("isAuthenticated");
  const isSkipAuthPage = SKIP_AUTH_PATHS.includes(location.pathname);

  useEffect(() => {
    if (isSessionExpired) {
      history.replace(POLICYOPS_PATH.SESSION_EXPIRED);
    }
  }, [isSessionExpired, history]);

  useEffect(() => {
    if (isLoading || isSkipAuthPage) return;
    if (!isAuthenticated && location.pathname === POLICYOPS_PATH.ROOT) {
      history.replace(POLICYOPS_PATH.DASHBOARD);
    }
  }, [isAuthenticated, isLoading, isSkipAuthPage, history, location.pathname]);

  if (isSkipAuthPage) {
    return (
      <Switch>
        <Route path={POLICYOPS_PATH.LOGOUT} component={LogoutPage} />
        <Route exact path={POLICYOPS_PATH.UNAUTHORIZED} component={UnauthorizedPage} />
        <Route exact path={POLICYOPS_PATH.SESSION_EXPIRED} component={SessionExpiredPage} />
      </Switch>
    );
  }

  if (isLoading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh" flexDirection="column">
        <CircularProgress />
        <Typography variant="body2" sx={{ mt: 2 }}>Loading PolicyOps...</Typography>
      </Box>
    );
  }

  return (
    <ThemeProvider theme={theme}>
      <ToastContainer position="top-right" autoClose={3000} />
      <LandingPageLayout>
        <Switch>
          <Route exact path="/" render={() => <Redirect to={POLICYOPS_PATH.DASHBOARD} />} />
          <PrivateRoute
            path={POLICYOPS_PATH.DASHBOARD}
            component={DashboardPage}
            permissions={permissionState}
            module="policyops"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.RULES}/new`}
            component={RuleFormPage}
            permissions={permissionState}
            module="rules"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.RULES}/:id/edit`}
            component={RuleFormPage}
            permissions={permissionState}
            module="rules"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.RULES}/:id`}
            component={RuleDetailPage}
            permissions={permissionState}
            module="rules"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.RULES}
            component={RulesPage}
            permissions={permissionState}
            module="rules"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.POLICIES}/new`}
            component={CreatePolicyPage}
            permissions={permissionState}
            module="policies"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.POLICIES}/:id/edit`}
            component={PolicyCreateEditPage}
            permissions={permissionState}
            module="policies"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.CHAT}`}
            component={ConfigSpherePage}
            permissions={permissionState}
            module="chat"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.POLICIES}/:id/view`}
            component={PolicyDetailPage}
            permissions={permissionState}
            module="policies"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.POLICIES}/:id`}
            component={PolicyDetailPage}
            permissions={permissionState}
            module="policies"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.POLICIES}
            component={PoliciesPage}
            permissions={permissionState}
            module="policies"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.POLICY_GROUPS}/new`}
            component={PolicyGroupFormPage}
            permissions={permissionState}
            module="policy_groups"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.POLICY_GROUPS}/:id/edit`}
            component={PolicyGroupFormPage}
            permissions={permissionState}
            module="policy_groups"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.POLICY_GROUPS}/:id`}
            component={PolicyGroupDetailPage}
            permissions={permissionState}
            module="policy_groups"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.POLICY_GROUPS}
            component={PolicyGroupsPage}
            permissions={permissionState}
            module="policy_groups"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.ASSIGNMENTS}/new`}
            component={AssignmentFormPage}
            permissions={permissionState}
            module="assignments"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.ASSIGNMENTS}/:id/edit`}
            component={AssignmentFormPage}
            permissions={permissionState}
            module="assignments"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.ASSIGNMENTS}/:id`}
            component={AssignmentDetailPage}
            permissions={permissionState}
            module="assignments"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.ASSIGNMENTS}
            component={AssignmentsPage}
            permissions={permissionState}
            module="assignments"
          />
          <PrivateRoute
            path={`${POLICYOPS_PATH.AGENTS}/:hostname`}
            component={AgentDetailPage}
            permissions={permissionState}
            module="dashboard"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.AGENTS}
            component={AgentsPage}
            permissions={permissionState}
            module="dashboard"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.ARTIFACTS}
            component={ArtifactsPage}
            permissions={permissionState}
            module="artifacts"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.DRIFT}
            component={DriftPage}
            permissions={permissionState}
            module="compliance"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.COMPLIANCE}
            component={CompliancePage}
            permissions={permissionState}
            module="compliance"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.AUDIT}
            component={AuditPage}
            permissions={permissionState}
            module="audit"
          />
          <PrivateRoute
            path={POLICYOPS_PATH.SETTINGS}
            component={SettingsPage}
            permissions={permissionState}
            module="policyops"
          />
        </Switch>
      </LandingPageLayout>
    </ThemeProvider>
  );
};

export default App;
