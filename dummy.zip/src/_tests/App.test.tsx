import React from "react";
import { render } from "@testing-library/react";
import { Provider } from "react-redux";
import { MemoryRouter } from "react-router-dom";
import { store } from "../redux/store";
import App from "../App";

jest.mock("../utils/tokenService", () => ({
  getAccessToken: jest.fn().mockResolvedValue("mock-token"),
}));

jest.mock("../utils/msalConfig", () => ({
  msalConfig: {},
  loginRequest: {},
}));

describe("App", () => {
  it("renders without crashing", () => {
    const { container } = render(
      <Provider store={store}>
        <MemoryRouter>
          <App />
        </MemoryRouter>
      </Provider>
    );
    expect(container).toBeTruthy();
  });
});
