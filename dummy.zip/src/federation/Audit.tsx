import React from "react";
import AuditPage from "../pages/audit/AuditPage";
import LandingPageLayout from "../pages/landing/LandingPage";

const Audit: React.FC = () => (
  <LandingPageLayout>
    <AuditPage />
  </LandingPageLayout>
);

export default Audit;
