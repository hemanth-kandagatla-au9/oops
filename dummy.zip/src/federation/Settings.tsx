import React from "react";
import SettingsPage from "../pages/settings/SettingsPage";
import LandingPageLayout from "../pages/landing/LandingPage";

const Settings: React.FC = () => (
  <LandingPageLayout>
    <SettingsPage />
  </LandingPageLayout>
);

export default Settings;
