import React from "react";
import PoliciesPage from "../pages/policies/PoliciesPage";
import LandingPageLayout from "../pages/landing/LandingPage";

const Policies: React.FC = () => (
  <LandingPageLayout>
    <PoliciesPage />
  </LandingPageLayout>
);

export default Policies;
