import React from "react";
import CompliancePage from "../pages/compliance/CompliancePage";
import LandingPageLayout from "../pages/landing/LandingPage";

const Compliance: React.FC = () => (
  <LandingPageLayout>
    <CompliancePage />
  </LandingPageLayout>
);

export default Compliance;
