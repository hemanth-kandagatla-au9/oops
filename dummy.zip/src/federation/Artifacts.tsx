import React from "react";
import ArtifactsPage from "../pages/artifacts/ArtifactsPage";
import LandingPageLayout from "../pages/landing/LandingPage";

const Artifacts: React.FC = () => (
  <LandingPageLayout>
    <ArtifactsPage />
  </LandingPageLayout>
);

export default Artifacts;
