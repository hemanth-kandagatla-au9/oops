import React from "react";
import PolicyGroupsPage from "../pages/policyGroups/PolicyGroupsPage";
import LandingPageLayout from "../pages/landing/LandingPage";

const PolicyGroups: React.FC = () => (
  <LandingPageLayout>
    <PolicyGroupsPage />
  </LandingPageLayout>
);

export default PolicyGroups;
