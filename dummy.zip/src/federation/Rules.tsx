import React from "react";
import RulesPage from "../pages/rules/RulesPage";
import LandingPageLayout from "../pages/landing/LandingPage";

const Rules: React.FC = () => (
  <LandingPageLayout>
    <RulesPage />
  </LandingPageLayout>
);

export default Rules;
