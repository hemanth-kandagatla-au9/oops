import React from "react";
import DashboardPage from "../pages/dashboard/DashboardPage";
import LandingPageLayout from "../pages/landing/LandingPage";

const Dashboard: React.FC = () => (
  <LandingPageLayout>
    <DashboardPage />
  </LandingPageLayout>
);

export default Dashboard;
