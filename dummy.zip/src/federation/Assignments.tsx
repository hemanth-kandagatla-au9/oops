import React from "react";
import AssignmentsPage from "../pages/assignments/AssignmentsPage";
import LandingPageLayout from "../pages/landing/LandingPage";

const Assignments: React.FC = () => (
  <LandingPageLayout>
    <AssignmentsPage />
  </LandingPageLayout>
);

export default Assignments;
