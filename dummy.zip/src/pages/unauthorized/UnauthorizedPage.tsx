import React from "react";
import { Box, Typography, Button } from "@mui/material";
import { useHistory } from "react-router-dom";
import { POLICYOPS_PATH } from "../../utils/constant";

const UnauthorizedPage: React.FC = () => {
  const history = useHistory();

  return (
    <Box display="flex" flexDirection="column" justifyContent="center" alignItems="center" height="100vh">
      <Typography variant="h4" color="error" gutterBottom>
        Access Denied
      </Typography>
      <Typography variant="body1" color="text.secondary" mb={3}>
        You do not have permission to access this module.
      </Typography>
      <Button variant="contained" onClick={() => history.push(POLICYOPS_PATH.DASHBOARD)}>
        Go to Dashboard
      </Button>
    </Box>
  );
};

export default UnauthorizedPage;
