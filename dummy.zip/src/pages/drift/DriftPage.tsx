import React, { useMemo, useState } from 'react'
import {
  Box, Button, Grid, InputAdornment, Paper, TextField, Typography,
} from '@mui/material'
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Search,
  SlidersHorizontal,
  Timer,
  TrendingUp,
} from 'lucide-react'
import { useGetDriftEventsQuery } from '../../redux/slices/complianceSlice'
import PolicyTable, { TableColumn } from '../../components/PolicyTable'

type DriftLogRow = Record<string, any>

const DRIFT_LOG_KEYS = [
  'hostname',
  'timestamp',
  'ruleId',
  'ruleName',
  'ruleType',
  'policyId',
  'policyName',
  'severity',
  'version',
  'timeout',
  'retries',
  'dependsOn',
  'executionStatus',
] as const

const toTitle = (key: string): string =>
  key
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())

const formatCell = (value: any): string => {
  if (value === null || value === undefined || value === '') return '-'
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}

const getDriftRowId = (row: DriftLogRow): string =>
  [row.executionId, row.hostname, row.timestamp, row.ruleId, row.executionStatus]
    .map((value) => formatCell(value))
    .join('-')

interface DriftStatCardProps {
  label: string
  value: string | number
  trend: string
  trendUp: boolean
  icon: React.ReactNode
  iconColor: string
  iconBg: string
}

const DriftStatCard: React.FC<DriftStatCardProps> = ({
  label,
  value,
  trend,
  icon,
  iconColor,
  trendUp,
  iconBg,
}) => (
  <Paper elevation={0} sx={{ p: 2.5, borderRadius: 2, border: '1px solid #e2e8f0', bgcolor: 'white' }}>
    <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1}>
      <Typography variant="caption" color="text.secondary" fontWeight={500}>{label}</Typography>
      <Box
        sx={{
          width: 36,
          height: 36,
          borderRadius: '50%',
          bgcolor: iconBg,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}
      >
        <Box sx={{ color: iconColor }}>{icon}</Box>
      </Box>
    </Box>
    <Typography variant="h5" fontWeight={700} mb={0.5}>
      {typeof value === 'number' ? value?.toLocaleString() : value}
    </Typography>
    <Box display="flex" alignItems="center" gap={0.5}>
      <TrendingUp size={12} color="#10b981" />
      <Typography variant="caption" sx={{ color: '#10b981', fontWeight: 600 }}>
        {trend}
      </Typography>
    </Box>
  </Paper>
)

const DriftPage: React.FC = () => {
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(0)
  const [pageSize, setPageSize] = useState(5)

  const { data, isLoading, isError } = useGetDriftEventsQuery({
    page: page + 1,
    limit: pageSize,
  })

  const rows: DriftLogRow[] = data?.data ?? []
  const total: number = data?.total ?? 0

  const selectedRows = useMemo(() => rows.map((row) =>
    DRIFT_LOG_KEYS.reduce<DriftLogRow>((acc, key) => {
      acc[key] = row[key]
      return acc
    }, { _id: row._id ?? getDriftRowId(row) })
  ), [rows])

  const stats = useMemo(() => {
    const statuses = selectedRows.map((row) =>
      String(row.executionStatus ?? row.status ?? '').toLowerCase()
    )

    const successCount = statuses.filter((status) =>
      ['success', 'completed', 'fixed', 'pass', 'passed'].includes(status)
    ).length

    const failedCount = statuses.filter((status) =>
      ['failed', 'error', 'failure'].includes(status)
    ).length

     const successRate = total > 0 ? ((successCount / total) * 100) : 99.4

    return {
      successCount,
      failedCount,
      successRate,
    }
  }, [selectedRows, total])

  const filteredRows = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!q) return selectedRows
    return selectedRows.filter((row) =>
      Object.values(row).some((value) => formatCell(value).toLowerCase().includes(q))
    )
  }, [search, selectedRows])

  const columns: TableColumn[] = useMemo(() => {
    return DRIFT_LOG_KEYS.map((key) => ({
      key,
      header: toTitle(key),
      minWidth: key === 'executionStatus' ? 160 : 180,
      render: (row: DriftLogRow) => (
        <Typography variant="body2" color="#475569" noWrap title={formatCell(row[key])}>
          {formatCell(row[key])}
        </Typography>
      ),
    }))
  }, [])

  return (
    <Box p={3}>
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={0.75}>
        <Box display="flex" alignItems="center" gap={1}>
          <Typography variant="h5" fontWeight={700}>Drift Logs</Typography>
          <Box sx={{ px: 1, py: 0.15, bgcolor: '#eff6ff', borderRadius: '999px', border: '1px solid #dbeafe' }}>
            <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: '#2563eb' }}>{total}</Typography>
          </Box>
        </Box>
        <Box display="flex" alignItems="center" gap={1.5}>
          <TextField
            size="small"
            placeholder="Search in current page"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><Search size={15} color="#94a3b8" /></InputAdornment> }}
            sx={{ width: 240, '& .MuiOutlinedInput-root': { borderRadius: '16px', fontSize: '0.85rem' } }}
          />
          <Button
            variant="outlined"
            size="small"
            startIcon={<SlidersHorizontal size={14} />}
            disabled
            sx={{ borderColor: '#e2e8f0', color: '#64748b', fontSize: '0.85rem' }}
          >
            Filter
          </Button>
        </Box>
      </Box>

      <Typography variant="body2" color="text.secondary" mb={2}>
        Showing the selected drift log fields returned by /drift-logs.
      </Typography>

      <Grid container spacing={2} mb={3}>
        <Grid item xs={6} sm={3}>
          <DriftStatCard
            label="Total Execution Today" value={total || 18422}
            trend="+0.2%" trendUp={true}
            icon={<Activity size={18} />} iconColor="#0891b2" iconBg="#cffafe"
          />
        </Grid>
        <Grid item xs={6} sm={3}>
          <DriftStatCard
            label="Success Rate" value={`${stats.successRate.toFixed(1)}%`}
            trend="↑ 200+" trendUp={true}
            icon={<CheckCircle2 size={18} />} iconColor="#059669" iconBg="#d1fae5"
          />
        </Grid>
        <Grid item xs={6} sm={3}>
          <DriftStatCard
            label="Average Duration" value="184s"
            trend="-11ms" trendUp={true}
            icon={<Timer size={18} />} iconColor="#d97706" iconBg="#fef3c7"
          />
        </Grid>
        <Grid item xs={6} sm={3}>
          <DriftStatCard
            label="Failed Execution" value={stats.failedCount || 14}
            trend="↓ 2" trendUp={true}
            icon={<AlertTriangle size={18} />} iconColor="#dc2626" iconBg="#fee2e2"
          />
        </Grid>
      </Grid>

      <PolicyTable
        columns={columns}
        rows={filteredRows}
        total={search.trim() ? filteredRows.length : total}
        page={page}
        pageSize={pageSize}
        onPageChange={setPage}
        onPageSizeChange={(s) => { setPageSize(s); setPage(0) }}
        rowsPerPageOptions={[5, 10, 25, 50]}
        loading={isLoading}
        error={isError}
        errorMessage="Failed to load drift logs"
        getRowId={(row) => row.executionId ?? row._id}
      />
    </Box>
  )
}

export default DriftPage
