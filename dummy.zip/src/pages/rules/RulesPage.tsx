import React, { useState } from 'react'
import {
  Box, Button, IconButton, InputAdornment, TextField, Tooltip, Typography,
} from '@mui/material'
import { Plus, Search, SlidersHorizontal, Shield, Copy } from 'lucide-react'
import { useHistory } from 'react-router-dom'
import { toast } from 'react-toastify'
import dayjs from 'dayjs'
import {
  useGetRulesQuery,
  useCloneRuleMutation,
} from '../../redux/slices/rulesSlice'
import { POLICYOPS_PATH } from '../../utils/constant'
import PolicyTable, { TableColumn } from '../../components/PolicyTable'
import LinkCell from '../../components/LinkCell'

// ── Status pill — handles both uppercase and lowercase from API ───────────────
const STATUS_PILL: Record<string, { bg: string; color: string; border: string; label: string }> = {
  published: { bg: '#f0fdf4', color: '#16a34a', border: '#bbf7d0', label: 'Published' },
  draft:     { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0', label: 'Draft'     },
  archived:  { bg: '#fff7ed', color: '#d97706', border: '#fed7aa', label: 'Archived'  },
}

const RuleStatusPill: React.FC<{ status: string }> = ({ status }) => {
  const key = (status ?? '').toLowerCase()
  const s = STATUS_PILL[key] ?? STATUS_PILL.draft
  return (
    <Box sx={{
      px: 1.5, py: 0.35,
      borderRadius: '999px',
      bgcolor: s.bg,
      color: s.color,
      border: `1px solid ${s.border}`,
      fontSize: '0.72rem',
      fontWeight: 600,
      display: 'inline-block',
      whiteSpace: 'nowrap',
    }}>
      {s.label}
    </Box>
  )
}

const getRuleId = (row: any) => row.id ?? row._id ?? row.rule_id ?? ''

// ── Page ──────────────────────────────────────────────────────────────────────
const RulesPage: React.FC = () => {
  const history = useHistory()
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(0)
  const [pageSize, setPageSize] = useState(10)

  const { data, isLoading, isError } = useGetRulesQuery({
    page: page + 1,
    limit: pageSize,
    search: search || undefined,
  })

  const [cloneRule] = useCloneRuleMutation()

  const rules: any[] = data?.data ?? []
  const total: number = data?.total ?? 0

  const handleClone = async (row: any) => {
    const id = getRuleId(row)
    try { await cloneRule(id).unwrap(); toast.success(`"${row.name}" cloned as draft`) }
    catch { toast.error('Clone failed.') }
  }

  const columns: TableColumn[] = [
    {
      key: 'name',
      header: 'Configuration Name',
      width: '22%',
      render: (row: any) => (
        <LinkCell
          label={row.name}
          secondary={row.description}
          onClick={() => history.push(`${POLICYOPS_PATH.RULES}/${getRuleId(row)}`)}
        />
      ),
    },
    {
      key: 'rulecategory',
      header: 'Type',
      width: '16%',
      render: (row: any) => (
        <Typography variant="body2" noWrap sx={{ color: '#102459', fontWeight: 500, fontSize: '0.875rem' }}>
          {row.rulecategory || row.rule_type || '-'}
        </Typography>
      ),
    },
    {
      key: 'severity',
      header: 'Severity',
      width: '10%',
      render: (row: any) => {
        const key = (row.severity ?? '').toLowerCase()
        const SEV: Record<string, { bg: string; color: string; border: string }> = {
          critical: { bg: '#fef2f2', color: '#dc2626', border: '#fecaca' },
          high:     { bg: '#fffbeb', color: '#d97706', border: '#fde68a' },
          medium:   { bg: '#eff6ff', color: '#2563eb', border: '#bfdbfe' },
          low:      { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' },
        }
        const s = SEV[key] ?? SEV.low
        return (
          <Box sx={{ px: 1.25, py: 0.3, borderRadius: '999px', bgcolor: s.bg, color: s.color, border: `1px solid ${s.border}`, fontSize: '0.72rem', fontWeight: 600, display: 'inline-block', whiteSpace: 'nowrap' }}>
            {key.charAt(0).toUpperCase() + key.slice(1) || '-'}
          </Box>
        )
      },
    },
    {
      key: 'version',
      header: 'Version',
      width: '10%',
      render: (row: any) => (
        <Box sx={{
          px: 1.5, py: 0.4,
          borderRadius: 1.5,
          border: '1px solid #cbd5e1',
          bgcolor: '#f1f5f9',
          fontSize: '0.78rem',
          fontWeight: 600,
          color: '#102459',
          display: 'inline-block',
          whiteSpace: 'nowrap',
        }}>
          V{row.version}
        </Box>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      width: '10%',
      render: (row: any) => <RuleStatusPill status={row.status} />,
    },
    {
      key: 'createdAt',
      header: 'Created At',
      width: '14%',
      render: (row: any) => (
        <Typography variant="body2" sx={{ color: '#64748b', fontSize: '0.8125rem' }}>
          {row.createdAt || row.created_at
            ? dayjs(row.createdAt ?? row.created_at).format('MMM D, YYYY')
            : '-'}
        </Typography>
      ),
    },
    {
      key: 'actions',
      header: 'Action',
      width: '8%',
      align: 'right',
      render: (row: any) => {
        const id = getRuleId(row)
        return (
          <Box display="flex" gap={0.5} justifyContent="flex-end">
            <Tooltip title="View / Edit">
              <IconButton
                size="small"
                sx={{ color: '#94a3b8', '&:hover': { color: '#2563eb' } }}
                onClick={(e) => { e.stopPropagation(); history.push(`${POLICYOPS_PATH.RULES}/${id}`) }}
              >
                <Shield size={15} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Clone">
              <IconButton
                size="small"
                sx={{ color: '#94a3b8', '&:hover': { color: '#2563eb' } }}
                onClick={(e) => { e.stopPropagation(); handleClone(row) }}
              >
                <Copy size={15} />
              </IconButton>
            </Tooltip>
          </Box>
        )
      },
    },
  ]

  return (
    <Box p={2.5} sx={{ height: '100%', display: 'flex', flexDirection: 'column', boxSizing: 'border-box' }}>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1.5}>
        <Box>
          <Box display="flex" alignItems="center" gap={1}>
            <Typography variant="h5" fontWeight={700}>Rules Repository</Typography>
            <Box sx={{ px: 1, py: 0.15, bgcolor: '#eff6ff', borderRadius: '999px', border: '1px solid #dbeafe' }}>
              <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: '#2563eb' }}>{total}</Typography>
            </Box>
          </Box>
          <Typography variant="body2" color="text.secondary" mt={0.25}>
            A descriptive body text comes here
          </Typography>
        </Box>

        <Box display="flex" alignItems="center" gap={1.5}>
          <TextField
            size="small"
            placeholder="Search"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(0) }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search size={15} color="#94a3b8" />
                </InputAdornment>
              ),
            }}
            sx={{
              width: 220,
              '& .MuiOutlinedInput-root': {
                borderRadius: '999px',
                fontSize: '0.85rem',
                bgcolor: 'white',
                '& fieldset': { borderColor: '#e2e8f0' },
              },
            }}
          />
          <Button
            variant="outlined"
            size="small"
            startIcon={<SlidersHorizontal size={14} />}
            sx={{ borderColor: '#e2e8f0', color: '#374151', fontSize: '0.85rem', bgcolor: 'white', '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' } }}
          >
            Filter
          </Button>
          <Button
            variant="contained"
            size="small"
            endIcon={<Plus size={14} />}
            onClick={() => history.push(`${POLICYOPS_PATH.RULES}/new`)}
            sx={{ bgcolor: '#2563eb', fontSize: '0.85rem', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}
          >
            Configure Rule
          </Button>
        </Box>
      </Box>

      {/* Table */}
      <Box sx={{ flex: 1, minHeight: 0 }}>
        <PolicyTable
          columns={columns}
          rows={rules}
          total={total}
          page={page}
          pageSize={pageSize}
          onPageChange={setPage}
          onPageSizeChange={(s) => { setPageSize(s); setPage(0) }}
          loading={isLoading}
          error={isError}
          errorMessage="Failed to load rules"
          checkboxSelection
          sx={{ height: '100%' }}
        />
      </Box>
    </Box>
  )
}

export default RulesPage
