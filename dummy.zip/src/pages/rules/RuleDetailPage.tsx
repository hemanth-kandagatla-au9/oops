import React, { useState } from 'react'
import {
  Box, Typography, Button, Chip, CircularProgress, Alert, Paper,
  Divider, IconButton, Dialog, DialogTitle, DialogContent,
  DialogContentText, DialogActions, Grid,
} from '@mui/material'
import { ChevronLeft, Edit2, Copy, CheckCircle, Archive } from 'lucide-react'
import { useHistory, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import dayjs from 'dayjs'
import Editor from '@monaco-editor/react'
import {
  useGetRuleByIdQuery,
  usePublishRuleMutation,
  useArchiveRuleMutation,
  useCloneRuleMutation,
} from '../../redux/slices/rulesSlice'
import { POLICYOPS_PATH } from '../../utils/constant'

// ── Pill helpers ──────────────────────────────────────────────────────────────
const STATUS_PILL: Record<string, { bg: string; color: string; border: string }> = {
  published: { bg: '#f0fdf4', color: '#16a34a', border: '#bbf7d0' },
  draft:     { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' },
  archived:  { bg: '#fff7ed', color: '#d97706', border: '#fed7aa' },
}
const SEVERITY_PILL: Record<string, { bg: string; color: string; border: string }> = {
  critical: { bg: '#fef2f2', color: '#dc2626', border: '#fecaca' },
  high:     { bg: '#fffbeb', color: '#d97706', border: '#fde68a' },
  medium:   { bg: '#eff6ff', color: '#2563eb', border: '#bfdbfe' },
  low:      { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' },
}

const Pill: React.FC<{ label: string; map: Record<string, { bg: string; color: string; border: string }> }> = ({ label, map }) => {
  const key = (label ?? '').toLowerCase()
  const s = map[key] ?? map.low ?? { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' }
  return (
    <Box sx={{
      px: 1.5, py: 0.3, borderRadius: '999px',
      bgcolor: s.bg, color: s.color, border: `1px solid ${s.border}`,
      fontSize: '0.72rem', fontWeight: 600, display: 'inline-block', whiteSpace: 'nowrap',
    }}>
      {key.charAt(0).toUpperCase() + key.slice(1)}
    </Box>
  )
}

// ── Card section ──────────────────────────────────────────────────────────────
const Card: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <Paper elevation={0} variant="outlined" sx={{ borderRadius: '10px', overflow: 'hidden', mb: 2 }}>
    <Box sx={{ px: 3, py: 1.75, borderBottom: '1px solid #f1f5f9' }}>
      <Typography sx={{ fontSize: '0.75rem', fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
        {title}
      </Typography>
    </Box>
    <Box sx={{ px: 3, py: 2 }}>{children}</Box>
  </Paper>
)

// ── Info row (for main content) ───────────────────────────────────────────────
const InfoRow: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <Box display="flex" alignItems="flex-start" py={1} sx={{ '&:not(:last-child)': { borderBottom: '1px solid #f8fafc' } }}>
    <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', minWidth: 160, flexShrink: 0 }}>{label}</Typography>
    <Box flex={1}>
      {typeof value === 'string'
        ? <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#102459' }}>{value}</Typography>
        : value}
    </Box>
  </Box>
)

// ── Meta item (for sidebar — stacked label + value) ───────────────────────────
const MetaItem: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <Box mb={2}>
    <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', mb: 0.75 }}>
      {label}
    </Typography>
    {children}
  </Box>
)

// ── JSON viewer ───────────────────────────────────────────────────────────────
const JsonViewer: React.FC<{ data: any }> = ({ data }) => {
  const empty = !data || Object.keys(data).length === 0
  if (empty) return (
    <Typography sx={{ fontSize: '0.8125rem', color: '#94a3b8', fontStyle: 'italic' }}>No data configured</Typography>
  )
  return (
    <Box sx={{ border: '1px solid #e2e8f0', borderRadius: '8px', overflow: 'hidden' }}>
      <Editor
        height="180px"
        language="json"
        value={JSON.stringify(data, null, 2)}
        options={{ readOnly: true, minimap: { enabled: false }, scrollBeyondLastLine: false, fontSize: 12, lineNumbers: 'off', wordWrap: 'on', folding: false }}
      />
    </Box>
  )
}

// ── Main page ─────────────────────────────────────────────────────────────────
const RuleDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>()
  const history = useHistory()
  const [confirmAction, setConfirmAction] = useState<'publish' | 'archive' | null>(null)

  const { data, isLoading, isError } = useGetRuleByIdQuery(id)
  const [publishRule, { isLoading: publishing }] = usePublishRuleMutation()
  const [archiveRule, { isLoading: archiving }] = useArchiveRuleMutation()
  const [cloneRule] = useCloneRuleMutation()

  const rule: any = data?.data

  const handlePublish = async () => {
    setConfirmAction(null)
    try { await publishRule(id).unwrap(); toast.success(`"${rule.name}" published`) }
    catch { toast.error('Publish failed.') }
  }
  const handleArchive = async () => {
    setConfirmAction(null)
    try { await archiveRule(id).unwrap(); toast.success(`"${rule.name}" archived`) }
    catch { toast.error('Archive failed.') }
  }
  const handleClone = async () => {
    try { await cloneRule(id).unwrap(); toast.success(`"${rule.name}" cloned as draft`) }
    catch { toast.error('Clone failed.') }
  }

  if (isLoading) return <Box sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><CircularProgress /></Box>
  if (isError || !rule) return <Box p={3}><Alert severity="error">Rule not found</Alert></Box>

  const statusKey  = (rule.status ?? '').toLowerCase()
  const createdAt  = rule.createdAt  ?? rule.created_at
  const updatedAt  = rule.updatedAt  ?? rule.updated_at
  const createdBy  = rule.createdBy  ?? rule.created_by  ?? '-'
  const updatedBy  = rule.updatedBy  ?? rule.updated_by  ?? '-'
  const tags: string[] = rule.tags ?? []

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', bgcolor: '#ffffff' }}>

      {/* ── Top bar ── */}
      <Box sx={{ bgcolor: '#ffffff', borderBottom: '1px solid #e2e8f0', px: 3, pt: 2, pb: 0 }}>
        <Box display="flex" alignItems="center" gap={0.5} mb={1.5}>
          <IconButton size="small" onClick={() => history.push(POLICYOPS_PATH.RULES)}>
            <ChevronLeft size={18} />
          </IconButton>
          <Typography
            sx={{ fontSize: '0.8125rem', color: '#2563eb', cursor: 'pointer', fontWeight: 500, '&:hover': { textDecoration: 'underline' } }}
            onClick={() => history.push(POLICYOPS_PATH.RULES)}
          >Rules</Typography>
          <Typography sx={{ fontSize: '0.8125rem', color: '#94a3b8', mx: 0.25 }}>›</Typography>
          <Typography sx={{ fontSize: '0.8125rem', color: '#64748b' }}>{rule.name}</Typography>
        </Box>

        <Box display="flex" justifyContent="space-between" alignItems="flex-start" pb={2}>
          <Box>
            <Box display="flex" alignItems="center" gap={1.5} mb={0.5}>
              <Typography sx={{ fontSize: '1.2rem', fontWeight: 700, color: '#102459' }}>{rule.name}</Typography>
              <Pill label={rule.status} map={STATUS_PILL} />
              <Pill label={rule.severity} map={SEVERITY_PILL} />
              <Box sx={{ px: 1.25, py: 0.2, border: '1px solid #cbd5e1', bgcolor: '#f1f5f9', borderRadius: '999px', fontSize: '0.72rem', fontWeight: 600, color: '#475569' }}>
                V{rule.version}
              </Box>
            </Box>
            {rule.description && (
              <Typography sx={{ fontSize: '0.875rem', color: '#64748b', maxWidth: 560 }}>{rule.description}</Typography>
            )}
          </Box>

          <Box display="flex" gap={1} flexShrink={0} ml={3}>
            {statusKey === 'draft' && (
              <Button size="small" variant="outlined" startIcon={<Edit2 size={14} />}
                sx={{ borderColor: '#e2e8f0', color: '#374151' }}
                onClick={() => history.push(`${POLICYOPS_PATH.RULES}/${id}/edit`)}>
                Edit
              </Button>
            )}
            <Button size="small" variant="outlined" startIcon={<Copy size={14} />}
              sx={{ borderColor: '#e2e8f0', color: '#374151' }}
              onClick={handleClone}>Clone</Button>
            {statusKey === 'draft' && (
              <Button size="small" variant="contained" startIcon={<CheckCircle size={14} />}
                sx={{ bgcolor: '#16a34a', boxShadow: 'none', '&:hover': { bgcolor: '#15803d', boxShadow: 'none' } }}
                onClick={() => setConfirmAction('publish')}>Publish</Button>
            )}
            {statusKey === 'published' && (
              <Button size="small" variant="outlined" startIcon={<Archive size={14} />}
                sx={{ borderColor: '#fed7aa', color: '#d97706', '&:hover': { bgcolor: '#fffbeb' } }}
                onClick={() => setConfirmAction('archive')}>Archive</Button>
            )}
          </Box>
        </Box>
      </Box>

      {/* ── Body ── */}
      <Box sx={{ flex: 1, overflowY: 'auto', bgcolor: '#f8fafc', p: 3 }}>
        <Grid container spacing={2.5} alignItems="flex-start">

          {/* Left — main content */}
          <Grid item xs={12} md={8}>
            <Card title="Details">
              <InfoRow label="Configuration Name" value={rule.name || '-'} />
              <InfoRow label="Description"        value={rule.description || '-'} />
              <InfoRow label="Category / Type"    value={rule.rulecategory || rule.rule_type || '-'} />
            </Card>

            <Card title="Configuration">
              <JsonViewer data={rule.configuration ?? rule.definition} />
            </Card>

            <Card title="Drift Response">
              <JsonViewer data={rule.driftresponse} />
            </Card>

            {rule.governance && Object.keys(rule.governance).length > 0 && (
              <Card title="Governance">
                {Object.entries(rule.governance).map(([k, v]) => (
                  <InfoRow key={k} label={k} value={typeof v === 'object' ? JSON.stringify(v) : String(v ?? '-')} />
                ))}
              </Card>
            )}
          </Grid>

          {/* Right — metadata sidebar */}
          <Grid item xs={12} md={4}>
            <Paper elevation={0} variant="outlined" sx={{ borderRadius: '10px', overflow: 'hidden' }}>
              <Box sx={{ px: 3, py: 1.75, borderBottom: '1px solid #f1f5f9' }}>
                <Typography sx={{ fontSize: '0.75rem', fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  Properties
                </Typography>
              </Box>
              <Box sx={{ px: 3, py: 2.5 }}>

                <MetaItem label="Status">
                  <Pill label={rule.status} map={STATUS_PILL} />
                </MetaItem>

                <MetaItem label="Severity">
                  <Pill label={rule.severity} map={SEVERITY_PILL} />
                </MetaItem>

                <MetaItem label="Version">
                  <Box sx={{ px: 1.25, py: 0.25, border: '1px solid #cbd5e1', bgcolor: '#f1f5f9', borderRadius: '999px', fontSize: '0.75rem', fontWeight: 600, color: '#475569', display: 'inline-block' }}>
                    V{rule.version}
                  </Box>
                </MetaItem>

                {tags.length > 0 && (
                  <MetaItem label="Tags">
                    <Box display="flex" gap={0.5} flexWrap="wrap">
                      {tags.map((t: string) => (
                        <Chip key={t} label={t} size="small" variant="outlined" sx={{ fontSize: '0.7rem', height: 22 }} />
                      ))}
                    </Box>
                  </MetaItem>
                )}

                <Divider sx={{ my: 2 }} />

                <MetaItem label="Created by">
                  <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#102459' }}>{createdBy}</Typography>
                </MetaItem>

                <MetaItem label="Created at">
                  <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#102459' }}>
                    {createdAt ? dayjs(createdAt).format('MMM D, YYYY · HH:mm') : '-'}
                  </Typography>
                </MetaItem>

                <MetaItem label="Updated by">
                  <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#102459' }}>{updatedBy}</Typography>
                </MetaItem>

                <MetaItem label="Updated at">
                  <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#102459' }}>
                    {updatedAt ? dayjs(updatedAt).format('MMM D, YYYY · HH:mm') : '-'}
                  </Typography>
                </MetaItem>

              </Box>
            </Paper>
          </Grid>

        </Grid>
      </Box>

      {/* Confirm publish */}
      <Dialog open={confirmAction === 'publish'} onClose={() => setConfirmAction(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: '12px' } }}>
        <DialogTitle sx={{ fontSize: '1rem', fontWeight: 600, color: '#102459' }}>Publish Rule</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ fontSize: '0.875rem' }}>
            Publish "{rule.name}"? This locks the rule (v{rule.version}) and makes it available for policies.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
          <Button size="small" onClick={() => setConfirmAction(null)} sx={{ color: '#64748b' }}>Cancel</Button>
          <Button size="small" variant="contained" onClick={handlePublish} disabled={publishing}
            sx={{ bgcolor: '#16a34a', boxShadow: 'none', '&:hover': { bgcolor: '#15803d', boxShadow: 'none' } }}>
            Publish
          </Button>
        </DialogActions>
      </Dialog>

      {/* Confirm archive */}
      <Dialog open={confirmAction === 'archive'} onClose={() => setConfirmAction(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: '12px' } }}>
        <DialogTitle sx={{ fontSize: '1rem', fontWeight: 600, color: '#102459' }}>Archive Rule</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ fontSize: '0.875rem' }}>
            Archive "{rule.name}"? It will be retired and can no longer be added to new policies.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
          <Button size="small" onClick={() => setConfirmAction(null)} sx={{ color: '#64748b' }}>Cancel</Button>
          <Button size="small" variant="outlined" onClick={handleArchive} disabled={archiving}
            sx={{ borderColor: '#fed7aa', color: '#d97706', '&:hover': { bgcolor: '#fffbeb' } }}>
            Archive
          </Button>
        </DialogActions>
      </Dialog>

    </Box>
  )
}

export default RuleDetailPage
