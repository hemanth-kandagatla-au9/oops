import React, { useState } from 'react'
import {
  Box, Typography, Button, CircularProgress, Alert, Paper,
  Divider, IconButton, Dialog, DialogTitle, DialogContent,
  DialogContentText, DialogActions, Grid,
} from '@mui/material'
import { ChevronLeft, Edit2, Copy, CheckCircle, Archive } from 'lucide-react'
import { useHistory, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import {
  useGetRuleByIdQuery,
  useUpdateRuleMutation,
  useCloneRuleMutation,
} from '../../redux/slices/rulesSlice'
import { POLICYOPS_PATH } from '../../utils/constant'

const STATUS_PILL: Record<string, { bg: string; color: string; border: string }> = {
  published: { bg: '#f0fdf4', color: '#16a34a', border: '#bbf7d0' },
  draft:     { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' },
  archived:  { bg: '#fff7ed', color: '#d97706', border: '#fed7aa' },
}
const SEVERITY_PILL: Record<string, { bg: string; color: string; border: string }> = {
  critical: { bg: '#fef2f2', color: '#dc2626', border: '#fecaca' },
  high:     { bg: '#fffbeb', color: '#d97706', border: '#fde68a' },
  medium:   { bg: '#eff6ff', color: '#2563eb', border: '#bfdbfe' },
  low:      { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' },
}

const Pill: React.FC<{ label: string; map: Record<string, { bg: string; color: string; border: string }> }> = ({ label, map }) => {
  const key = (label ?? '').toLowerCase()
  const s = map[key] ?? { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' }
  return (
    <Box sx={{
      px: 1.5, py: 0.3, borderRadius: '999px',
      bgcolor: s.bg, color: s.color, border: `1px solid ${s.border}`,
      fontSize: '0.72rem', fontWeight: 600, display: 'inline-block', whiteSpace: 'nowrap',
    }}>
      {key.charAt(0).toUpperCase() + key.slice(1)}
    </Box>
  )
}

const formatKey = (key: string) =>
  key
    .replace(/([a-z\d])([A-Z])/g, '$1 $2')
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2')
    .replace(/^[a-z]/, (c) => c.toUpperCase())

const InfoRow: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <Box display="flex" alignItems="flex-start" py={1} sx={{ '&:not(:last-child)': { borderBottom: '1px solid #f8fafc' } }}>
    <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', minWidth: 200, flexShrink: 0 }}>{label}</Typography>
    <Box flex={1}>
      {typeof value === 'string'
        ? <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#102459', wordBreak: 'break-word' }}>{value}</Typography>
        : value}
    </Box>
  </Box>
)

const RuleDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>()
  const history = useHistory()
  const [confirmAction, setConfirmAction] = useState<'publish' | 'archive' | null>(null)

  const { data, isLoading, isError } = useGetRuleByIdQuery(id)
  const [updateRule, { isLoading: statusUpdating }] = useUpdateRuleMutation()
  const [cloneRule] = useCloneRuleMutation()

  const rule: any = data?.data

  const handlePublish = async () => {
    setConfirmAction(null)
    try {
      await updateRule({ id, data: { ...rule, status: 'PUBLISHED' } }).unwrap()
      toast.success(`"${rule.name}" published`)
    }
    catch { toast.error('Publish failed.') }
  }
  const handleArchive = async () => {
    setConfirmAction(null)
    try {
      await updateRule({ id, data: { ...rule, status: 'ARCHIVED' } }).unwrap()
      toast.success(`"${rule.name}" archived`)
    }
    catch { toast.error('Archive failed.') }
  }
  const handleClone = async () => {
    try { await cloneRule(id).unwrap(); toast.success(`"${rule.name}" cloned as draft`) }
    catch { toast.error('Clone failed.') }
  }

  if (isLoading) return <Box sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><CircularProgress /></Box>
  if (isError || !rule) return <Box p={3}><Alert severity="error">Rule not found</Alert></Box>

  const statusKey = (rule.status ?? '').toLowerCase()

  const configEntries = Object.entries(rule.configuration ?? rule.definition ?? {})
    .filter(([, v]) => v !== '' && v !== null && v !== undefined && v !== false)

  const driftEntries = Object.entries(rule.driftresponse ?? {})
    .filter(([, v]) => v !== '' && v !== null && v !== undefined && v !== false)

  const gov = rule.governance ?? {}

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', bgcolor: '#ffffff' }}>

      {/* ── Top bar ── */}
      <Box sx={{ bgcolor: '#ffffff', borderBottom: '1px solid #e2e8f0', px: 3, pt: 1.5, pb: 1.5 }}>
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Box display="flex" alignItems="center" gap={1}>
            <IconButton
              size="small"
              onClick={() => history.push(POLICYOPS_PATH.RULES)}
              sx={{ color: '#64748b', border: '1px solid #e2e8f0', borderRadius: '8px', p: '4px', '&:hover': { bgcolor: '#f8fafc', color: '#102459' } }}
            >
              <ChevronLeft size={16} />
            </IconButton>
            <Box>
              <Typography
                variant="caption"
                sx={{ color: '#2563eb', cursor: 'pointer', fontWeight: 500, display: 'block', lineHeight: 1.4, '&:hover': { textDecoration: 'underline' } }}
                onClick={() => history.push(POLICYOPS_PATH.RULES)}
              >
                Rule
              </Typography>
              <Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: '#102459', lineHeight: 1.2 }}>{rule.name}</Typography>
            </Box>
          </Box>

          <Box display="flex" gap={1} alignItems="center">
            {statusKey !== 'archived' && (
              <Button
                size="small"
                variant="outlined"
                endIcon={<Edit2 size={14} />}
                sx={{ borderColor: '#e2e8f0', color: '#374151', fontWeight: 500, fontSize: '0.875rem', textTransform: 'none', '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' } }}
                onClick={() => history.push(`${POLICYOPS_PATH.RULES}/${id}/edit`)}
              >
                Modify
              </Button>
            )}
            <Button size="small" variant="outlined" startIcon={<Copy size={14} />}
              sx={{ borderColor: '#e2e8f0', color: '#374151', textTransform: 'none' }}
              onClick={handleClone}>Clone</Button>
            {statusKey === 'draft' && (
              <Button size="small" variant="contained" startIcon={<CheckCircle size={14} />}
                sx={{ bgcolor: '#16a34a', boxShadow: 'none', textTransform: 'none', '&:hover': { bgcolor: '#15803d', boxShadow: 'none' } }}
                onClick={() => setConfirmAction('publish')}>Publish</Button>
            )}
            {statusKey === 'published' && (
              <Button size="small" variant="outlined" startIcon={<Archive size={14} />}
                sx={{ borderColor: '#fed7aa', color: '#d97706', textTransform: 'none', '&:hover': { bgcolor: '#fffbeb' } }}
                onClick={() => setConfirmAction('archive')}>Archive</Button>
            )}
          </Box>
        </Box>
      </Box>

      {/* ── Body ── */}
      <Box sx={{ flex: 1, overflowY: 'auto', bgcolor: '#f8fafc', p: 3 }}>
        <Paper elevation={0} sx={{ borderRadius: '12px', border: '1px solid #e2e8f0', bgcolor: 'white', overflow: 'hidden' }}>

          {/* Basic Information */}
          <Box sx={{ px: 3.5, pt: 3, pb: 2.5 }}>
            <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#102459', mb: 1.75 }}>Basic Information</Typography>
            <InfoRow label="Configuration Name" value={rule.name || '-'} />
            <InfoRow label="Rule Category" value={rule.rulecategory || rule.rule_type || '-'} />
            <InfoRow label="Severity" value={<Pill label={rule.severity} map={SEVERITY_PILL} />} />
            <InfoRow label="Description" value={rule.description || '-'} />
          </Box>

          <Divider sx={{ borderColor: '#f1f5f9' }} />

          {/* Configuration + Response & Governance */}
          <Grid container>
            <Grid item xs={12} md={6} sx={{ px: 3.5, pt: 3, pb: 3.5, borderRight: { md: '1px solid #f1f5f9' } }}>
              <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#102459', mb: 1.75 }}>Configuration</Typography>
              {configEntries.length > 0
                ? configEntries.map(([key, value]) => (
                    <InfoRow key={key} label={formatKey(key)} value={String(value)} />
                  ))
                : <Typography sx={{ fontSize: '0.8125rem', color: '#94a3b8', fontStyle: 'italic' }}>No configuration data</Typography>
              }
            </Grid>
            <Grid item xs={12} md={6} sx={{ px: 3.5, pt: 3, pb: 3.5 }}>
              <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#102459', mb: 1.75 }}>Response and Governance</Typography>
              {driftEntries.map(([key, value]) => (
                <InfoRow key={key} label={formatKey(key)} value={String(value)} />
              ))}
              {driftEntries.length > 0 && (gov.ownerTeam || gov.associatedChangeTicket) && (
                <Divider sx={{ my: 1.5, borderColor: '#f1f5f9' }} />
              )}
              {gov.ownerTeam && <InfoRow label="Owner Team" value={String(gov.ownerTeam)} />}
              {gov.associatedChangeTicket && <InfoRow label="Associated Change Ticket" value={String(gov.associatedChangeTicket)} />}
              {!driftEntries.length && !gov.ownerTeam && !gov.associatedChangeTicket && (
                <Typography sx={{ fontSize: '0.8125rem', color: '#94a3b8', fontStyle: 'italic' }}>No response data</Typography>
              )}
            </Grid>
          </Grid>

        </Paper>
      </Box>

      {/* Confirm publish */}
      <Dialog open={confirmAction === 'publish'} onClose={() => setConfirmAction(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: '12px' } }}>
        <DialogTitle sx={{ fontSize: '1rem', fontWeight: 600, color: '#102459' }}>Publish Rule</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ fontSize: '0.875rem' }}>
            Publish "{rule.name}"? This locks the rule (v{rule.version}) and makes it available for policies.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
          <Button size="small" onClick={() => setConfirmAction(null)} sx={{ color: '#64748b' }}>Cancel</Button>
          <Button size="small" variant="contained" onClick={handlePublish} disabled={statusUpdating}
            sx={{ bgcolor: '#16a34a', boxShadow: 'none', '&:hover': { bgcolor: '#15803d', boxShadow: 'none' } }}>
            Publish
          </Button>
        </DialogActions>
      </Dialog>

      {/* Confirm archive */}
      <Dialog open={confirmAction === 'archive'} onClose={() => setConfirmAction(null)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: '12px' } }}>
        <DialogTitle sx={{ fontSize: '1rem', fontWeight: 600, color: '#102459' }}>Archive Rule</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ fontSize: '0.875rem' }}>
            Archive "{rule.name}"? It will be retired and can no longer be added to new policies.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
          <Button size="small" onClick={() => setConfirmAction(null)} sx={{ color: '#64748b' }}>Cancel</Button>
          <Button size="small" variant="outlined" onClick={handleArchive} disabled={statusUpdating}
            sx={{ borderColor: '#fed7aa', color: '#d97706', '&:hover': { bgcolor: '#fffbeb' } }}>
            Archive
          </Button>
        </DialogActions>
      </Dialog>

    </Box>
  )
}

export default RuleDetailPage
