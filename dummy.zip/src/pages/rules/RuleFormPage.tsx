import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react'
import {
  Alert,
  Box,
  Button,
  Checkbox,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  Divider,
  FormControl,
  Grid,
  IconButton,
  InputLabel,
  ListItemText,
  MenuItem,
  Paper,
  Select,
  Step,
  StepButton,
  StepConnector,
  StepLabel,
  Stepper,
  TextField,
  Typography,
} from '@mui/material'
import { styled } from '@mui/material/styles'
import { stepConnectorClasses } from '@mui/material/StepConnector'
import { CheckCircle2, Lock, X, Maximize2, Minimize2, ChevronLeft } from 'lucide-react'
import { useHistory, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import Editor from '@monaco-editor/react'
import {
  useGetRuleByIdQuery,
  useGetRuleCategoriesMetadataQuery,
  useGetRuleCategoriesQuery,
  useGetGovernanceTeamsQuery,
  useCreateRuleMutation,
  useUpdateRuleMutation,
} from '../../redux/slices/rulesSlice'
import { POLICYOPS_PATH } from '../../utils/constant'
import { Severity, OnFailure, RuleCategoryField, RuleCategoryMetadata } from '../../types'

const SEVERITIES: Severity[] = ['critical', 'high', 'medium', 'low']
const STEPS = ['Basic Info', 'Configuration', 'Actions', 'Governance']
const DEFAULT_CATEGORY = 'FILE_VALIDATION'

const RuleStepConnector = styled(StepConnector)(() => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 16,
    left: 'calc(-50% + 16px)',
    right: 'calc(50% + 16px)',
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 2,
    border: 0,
    backgroundColor: '#e2e8f0',
    borderRadius: 1,
  },
  [`&.${stepConnectorClasses.active} .${stepConnectorClasses.line}`]: {
    backgroundColor: '#2563eb',
  },
  [`&.${stepConnectorClasses.completed} .${stepConnectorClasses.line}`]: {
    backgroundColor: '#22c55e',
  },
}))

const FORM_FIELD_SX = {
  '& .MuiOutlinedInput-root': {
    borderRadius: '8px', fontSize: '0.875rem', color: '#102459',
    '& fieldset': { borderColor: '#e2e8f0' },
    '&:hover fieldset': { borderColor: '#94a3b8' },
    '&.Mui-focused fieldset': { borderColor: '#2563eb', borderWidth: '1px' },
  },
  '& .MuiInputLabel-root': { color: '#94a3b8', fontSize: '0.875rem' },
  '& .MuiInputLabel-root.Mui-focused': { color: '#2563eb' },
  '& .MuiInputBase-input': { fontSize: '0.875rem', color: '#102459' },
}

const CHECKBOX_SX = {
  color: '#cbd5e1',
  p: '0 8px 0 2px',
  '&.Mui-checked': { color: '#2563eb' },
  '& .MuiSvgIcon-root': { width: 20, height: 20 },
}


const CARD_SX = {
  borderRadius: '10px',
  border: '1px solid #e2e8f0',
  bgcolor: 'white',
  p: 3.5,
  height: '100%',
}

const BASIC_INFO_SUBTITLE = 'Define the high-level identity and target of this configuration rule.'
const SECTION_SUBTITLE = 'Define the exact desired state. You can enable multiple validation checks simultaneously.'
const DRIFT_SECTION_SUBTITLE = 'Select what should happen if this rule detects configuration drift. You can enable multiple response actions simultaneously.'
const GOVERNANCE_SUBTITLE = 'Assign ownership and enforce change management approvals.'


const buildInitialValues = (fields: RuleCategoryField[]): Record<string, any> => {
  const values: Record<string, any> = {}

  const walk = (list: RuleCategoryField[]) => {
    list.forEach((field) => {
      if (field.fieldType === 'checkbox') values[field.field] = false
      else if (field.fieldType === 'select' && field.field === 'primaryAction') values[field.field] = []
      else values[field.field] = ''
      if (field.nestedFields?.length) walk(field.nestedFields)
    })
  }

  walk(fields)
  return values
}

const collectFieldKeys = (fields: RuleCategoryField[]): string[] => {
  const keys: string[] = []

  const walk = (list: RuleCategoryField[]) => {
    list.forEach((field) => {
      keys.push(field.field)
      if (field.nestedFields?.length) walk(field.nestedFields)
    })
  }

  walk(fields)
  return keys
}

const clearNestedValues = (
  nestedFields: RuleCategoryField[],
  values: Record<string, any>,
): Record<string, any> => {
  const next = { ...values }

  const walk = (list: RuleCategoryField[]) => {
    list.forEach((field) => {
      delete next[field.field]
      if (field.nestedFields?.length) walk(field.nestedFields)
    })
  }

  walk(nestedFields)
  return next
}

const FIELD_ALIASES: Record<string, string> = {
  systemName: 'serviceName',
  absoluteFilePath: 'filePath',
  permissionsOctal: 'permissions',
}

const CONFIG_KEY_ALIASES: Record<string, string> = {
  checkExistence: 'validateFileExistence',
  existenceState: 'fileExistenceValue',
  checkPerms: 'validateOwnershipPermissions',
  checkContent: 'validateChecksumContent',
  checkState: 'validateInstallationState',
  state: 'runningStateValue',
  checkVersion: 'validateSpecificVersion',
  runningState: 'runningStateValue',
  checkRunning: 'validateRunningState',
  path: 'filePath',
  owner: 'expectedOwner',
  mode: 'permissions',
}

const DRIFT_KEY_ALIASES: Record<string, string> = {
  remediate: 'agentRemediation',
  remediationAction: 'primaryAction',
  sendEmail: 'sendEmailAlert',
  createIncident: 'createITSMIncident',
}

const normalizeParsedKeys = (parsed: Record<string, any>): Record<string, any> => {
  const normalized = { ...parsed }
  Object.entries(FIELD_ALIASES).forEach(([alias, canonical]) => {
    if (Object.prototype.hasOwnProperty.call(normalized, alias)
      && !Object.prototype.hasOwnProperty.call(normalized, canonical)) {
      normalized[canonical] = normalized[alias]
    }
  })
  return normalized
}

const normalizeAliasKeys = (
  parsed: Record<string, any>,
  aliasMap: Record<string, string>,
): Record<string, any> => {
  const normalized = { ...parsed }
  Object.entries(aliasMap).forEach(([alias, canonical]) => {
    if (Object.prototype.hasOwnProperty.call(normalized, alias)
      && !Object.prototype.hasOwnProperty.call(normalized, canonical)) {
      normalized[canonical] = normalized[alias]
    }
  })
  return normalized
}

const mergeKnownFields = (
  knownKeys: string[],
  source: Record<string, any>,
  target: Record<string, any>,
): Record<string, any> => {
  const next = { ...target }
  knownKeys.forEach((key) => {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      next[key] = source[key]
    }
  })
  return next
}

const buildFieldDisplayMap = (
  fields: RuleCategoryField[],
  map: Record<string, string> = {},
): Record<string, string> => {
  fields.forEach((field) => {
    map[field.field] = field.displayName
    if (field.nestedFields?.length) buildFieldDisplayMap(field.nestedFields, map)
  })
  return map
}

const enableParentCheckboxes = (
  fields: RuleCategoryField[],
  values: Record<string, any>,
  source: Record<string, any>,
): Record<string, any> => {
  let next = { ...values }

  fields.forEach((field) => {
    if (field.fieldType !== 'checkbox' || !field.nestedFields?.length) return

    if (Object.prototype.hasOwnProperty.call(source, field.field)) {
      next[field.field] = Boolean(source[field.field])
      if (!next[field.field]) {
        next = clearNestedValues(field.nestedFields, next)
      }
      return
    }

    const nestedKeys = collectFieldKeys(field.nestedFields)
    const hasNestedValue = nestedKeys.some((key) => {
      const nestedValue = next[key]
      return nestedValue !== '' && nestedValue !== false && nestedValue !== null && nestedValue !== undefined
    })

    if (hasNestedValue) {
      next[field.field] = true
    }
  })

  return next
}

const syncFieldValues = (
  fields: RuleCategoryField[],
  parsed: Record<string, any>,
  prev: Record<string, any>,
): Record<string, any> => {
  const keys = collectFieldKeys(fields)
  const merged = mergeKnownFields(keys, parsed, prev)
  return enableParentCheckboxes(fields, merged, parsed)
}

const getTopLevelGridSize = (field: RuleCategoryField): number => {
  if (field.fieldType === 'checkbox' || field.fieldType === 'textarea') return 12
  if (field.isMandatory) return 12
  return 6
}

const getConfigSectionTitle = (categoryCode: string): string => {
  if (categoryCode.includes('FILE')) return 'Configure File State'
  if (categoryCode.includes('SCRIPT')) return 'Configure Script State'
  if (categoryCode.includes('PACKAGE')) return 'Configure Package State'
  if (categoryCode.includes('SERVICE')) return 'Configure Service State'
  return 'Configure State'
}

const resolveCategoryCode = (
  value: string,
  categories: RuleCategoryMetadata[],
): string | null => {
  if (!value) return null
  const direct = categories.find((category) => category.categoryCode === value)
  if (direct) return direct.categoryCode
  const byName = categories.find((category) => category.name.toLowerCase() === value.toLowerCase())
  if (byName) return byName.categoryCode
  const partial = categories.find((category) => {
    const normalized = value.toLowerCase()
    return category.name.toLowerCase().includes(normalized)
      || normalized.includes(category.name.toLowerCase().split(' ')[0])
  })
  return partial?.categoryCode ?? null
}

const getNestedGridSx = (parentField: RuleCategoryField, nestedFields: RuleCategoryField[]) => {
  if (parentField.field === 'validateChecksumContent' && nestedFields.length >= 2) {
    return {
      display: 'grid',
      gap: 2,
      alignItems: 'center',
      gridTemplateColumns: { xs: '1fr', sm: '5fr auto 5fr' },
    }
  }
  if (nestedFields.length === 1) {
    return { display: 'grid', gap: 2, gridTemplateColumns: '1fr' }
  }
  if (nestedFields.length === 2) {
    return { display: 'grid', gap: 2, gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' } }
  }
  return { display: 'grid', gap: 2, gridTemplateColumns: { xs: '1fr', sm: 'repeat(3, 1fr)' } }
}

interface DynamicFieldsProps {
  fields: RuleCategoryField[]
  values: Record<string, any>
  onValuesChange: (updater: (prev: Record<string, any>) => Record<string, any>) => void
}

const DynamicFields: React.FC<DynamicFieldsProps> = ({ fields, values, onValuesChange }) => {
  const [expandedSection, setExpandedSection] = React.useState<string | null>(null)

  const getLabel = (field: RuleCategoryField) => (
    field.isMandatory ? `${field.displayName} *` : field.displayName
  )

  const renderInput = (field: RuleCategoryField): React.ReactNode => {
    const value = values[field.field]

    if (field.fieldType === 'select') {
      const isMulti = field.field === 'primaryAction'

      if (isMulti) {
        const selected: string[] = Array.isArray(value) ? value : (value ? [String(value)] : [])
        return (
          <FormControl fullWidth size="small" key={field.field} sx={FORM_FIELD_SX}>
            <InputLabel required={field.isMandatory}>{field.displayName}</InputLabel>
            <Select
              multiple
              value={selected}
              label={getLabel(field)}
              onChange={(event) => {
                onValuesChange((prev) => ({ ...prev, [field.field]: event.target.value as string[] }))
              }}
              renderValue={(sel) => (
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, py: 0.25 }}>
                  {(sel as string[]).map((v) => (
                    <Chip key={v} label={v} size="small" sx={{ height: 22, fontSize: '0.72rem', bgcolor: '#eff6ff', color: '#2563eb', border: '1px solid #bfdbfe' }} />
                  ))}
                </Box>
              )}
            >
              {field.options?.map((option) => (
                <MenuItem key={option} value={option} dense>
                  <Checkbox size="small" checked={selected.indexOf(option) > -1} sx={{ p: '2px', mr: 1, color: '#cbd5e1', '&.Mui-checked': { color: '#2563eb' } }} />
                  <ListItemText primary={option} primaryTypographyProps={{ fontSize: '0.875rem' }} />
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        )
      }

      return (
        <FormControl fullWidth size="small" key={field.field} sx={FORM_FIELD_SX}>
          <InputLabel required={field.isMandatory}>{field.displayName}</InputLabel>
          <Select
            value={value ?? ''}
            label={getLabel(field)}
            onChange={(event) => {
              onValuesChange((prev) => ({ ...prev, [field.field]: event.target.value }))
            }}
          >
            {field.options?.map((option) => (
              <MenuItem key={option} value={option}>{option}</MenuItem>
            ))}
          </Select>
        </FormControl>
      )
    }

    return (
      <TextField
        fullWidth
        size="small"
        key={field.field}
        sx={FORM_FIELD_SX}
        type={field.fieldType === 'number' ? 'number' : 'text'}
        label={getLabel(field)}
        placeholder={field.placeholder || field.displayName}
        required={field.isMandatory}
        value={value ?? ''}
        multiline={field.fieldType === 'textarea'}
        rows={field.fieldType === 'textarea' ? 4 : undefined}
        onChange={(event) => {
          const nextValue = field.fieldType === 'number'
            ? Number(event.target.value)
            : event.target.value
          onValuesChange((prev) => ({ ...prev, [field.field]: nextValue }))
        }}
      />
    )
  }

  const renderNestedContent = (parentField: RuleCategoryField, nestedFields: RuleCategoryField[]) => {
    const gridSx = getNestedGridSx(parentField, nestedFields)

    if (parentField.field === 'validateChecksumContent' && nestedFields.length >= 2) {
      const [checksumField, contentField] = nestedFields
      return (
        <Box sx={gridSx}>
          <Box>{renderInput(checksumField)}</Box>
          <Typography variant="body2" color="text.secondary" fontWeight={600} sx={{ textAlign: 'center', px: { sm: 1 } }}>
            OR
          </Typography>
          <Box>{renderInput(contentField)}</Box>
        </Box>
      )
    }

    return (
      <Box sx={gridSx}>
        {nestedFields.map((nestedField) => (
          <Box key={nestedField.field}>{renderInput(nestedField)}</Box>
        ))}
      </Box>
    )
  }

  const renderField = (field: RuleCategoryField): React.ReactNode => {
    if (field.fieldType === 'checkbox') {
      const checked = Boolean(values[field.field])
      const nestedFields = field.nestedFields ?? []
      const isExpanded = expandedSection === field.field && checked

      return (
        <Box
          key={field.field}
          sx={{
            mb: 1.5, width: '100%',
            border: '1px solid', borderColor: checked ? '#bfdbfe' : '#f1f5f9',
            borderRadius: '10px',
            bgcolor: checked ? '#fafcff' : 'white',
            overflow: 'hidden',
            transition: 'border-color 0.15s, background 0.15s',
          }}
        >
          {/* Card header row */}
          <Box
            sx={{
              display: 'flex', alignItems: 'flex-start', gap: 1.25,
              px: 2, py: 1.75,
              cursor: checked && nestedFields.length > 0 ? 'pointer' : 'default',
            }}
            onClick={() => {
              if (checked && nestedFields.length > 0) {
                setExpandedSection(isExpanded ? null : field.field)
              }
            }}
          >
            <Checkbox
              size="small"
              checked={checked}
              disableRipple
              sx={{ ...CHECKBOX_SX, mt: '1px' }}
              onClick={(e) => e.stopPropagation()}
              onChange={(event) => {
                const isChecked = event.target.checked
                if (isChecked) {
                  setExpandedSection(field.field)
                } else if (expandedSection === field.field) {
                  setExpandedSection(null)
                }
                onValuesChange((prev) => {
                  const updated = { ...prev, [field.field]: isChecked }
                  return isChecked ? updated : clearNestedValues(nestedFields, updated)
                })
              }}
            />
            <Box sx={{ flex: 1 }}>
              <Typography variant="body2" sx={{ color: '#102459', fontSize: '0.875rem', fontWeight: checked ? 600 : 500, userSelect: 'none' }}>
                {field.displayName}
              </Typography>
              {field.description && (
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.78rem', mt: 0.25, display: 'block' }}>
                  {field.description}
                </Typography>
              )}
            </Box>
          </Box>

          {/* Expanded nested fields */}
          {isExpanded && nestedFields.length > 0 && (
            <Box sx={{ px: 2, pb: 2, pt: 0.5, borderTop: '1px solid #f1f5f9' }}>
              {renderNestedContent(field, nestedFields)}
            </Box>
          )}
        </Box>
      )
    }

    return renderInput(field)
  }

  return (
    <Grid container spacing={2.5}>
      {fields.map((field) => (
        <Grid item xs={12} sm={getTopLevelGridSize(field)} key={field.field}>
          {renderField(field)}
        </Grid>
      ))}
    </Grid>
  )
}

interface LiveJsonEditorProps {
  value: string
  syncStatus: 'synced' | 'saved' | 'error'
  onChange: (value: string) => void
}

const LiveJsonEditor: React.FC<LiveJsonEditorProps> = ({ value, syncStatus, onChange }) => {
  const [isFullscreen, setIsFullscreen] = useState(false)

  const header = (
    <Box sx={{ px: 2, py: 1.5, display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #334155', bgcolor: '#252526' }}>
      <Typography variant="body2" fontWeight={600} color="#f1f5f9" sx={{ fontSize: '0.8125rem' }}>
        Live Json States Editor
      </Typography>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <Box sx={{
          px: 1.25,
          py: 0.35,
          borderRadius: '6px',
          bgcolor: syncStatus === 'error' ? '#7f1d1d' : '#166534',
          color: syncStatus === 'error' ? '#fecaca' : '#bbf7d0',
          fontSize: '0.6875rem',
          fontWeight: 600,
          textTransform: 'capitalize',
        }}
        >
          {syncStatus === 'error' ? 'Invalid JSON' : syncStatus}
        </Box>
        <IconButton
          size="small"
          onClick={() => setIsFullscreen((prev) => !prev)}
          sx={{ color: '#cbd5e1', '&:hover': { color: '#f1f5f9', bgcolor: 'rgba(255,255,255,0.08)' } }}
          aria-label={isFullscreen ? 'Exit full screen' : 'Expand to full screen'}
        >
          {isFullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
        </IconButton>
      </Box>
    </Box>
  )

  const editor = (
    <Box sx={{ flex: 1, minHeight: 0 }}>
      <Editor
        height="100%"
        defaultLanguage="json"
        theme="vs-dark"
        value={value}
        onChange={(nextValue) => onChange(nextValue ?? '')}
        options={{
          minimap: { enabled: false },
          fontSize: 13,
          lineNumbers: 'on',
          scrollBeyondLastLine: false,
          wordWrap: 'on',
          tabSize: 2,
          automaticLayout: true,
        }}
      />
    </Box>
  )

  if (isFullscreen) {
    return (
      <Dialog
        open
        fullScreen
        onClose={() => setIsFullscreen(false)}
        PaperProps={{ sx: { bgcolor: '#1e1e1e', display: 'flex', flexDirection: 'column' } }}
      >
        {header}
        {editor}
      </Dialog>
    )
  }

  return (
    <Paper
      elevation={0}
      sx={{
        height: '100%',
        minHeight: 480,
        display: 'flex',
        flexDirection: 'column',
        borderRadius: '10px',
        border: '1px solid #334155',
        bgcolor: '#1e1e1e',
        overflow: 'hidden',
        boxShadow: '0 1px 3px rgba(0,0,0,0.12)',
      }}
    >
      {header}
      {editor}
    </Paper>
  )
}

const StepIcon: React.FC<{ index: number; active: boolean; completed: boolean }> = ({
  index,
  active,
  completed,
}) => {
  const bg = completed ? '#22c55e' : active ? '#2563eb' : '#e2e8f0'
  const color = completed || active ? 'white' : '#64748b'

  return (
    <Box sx={{
      width: 32,
      height: 32,
      borderRadius: '50%',
      bgcolor: bg,
      color,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontWeight: 600,
      fontSize: '0.8rem',
      boxShadow: active ? '0 0 0 3px rgba(37, 99, 235, 0.15)' : 'none',
      transition: 'all 0.2s ease',
    }}
    >
      {completed ? <CheckCircle2 size={16} /> : active ? <Lock size={14} /> : index + 1}
    </Box>
  )
}

const RuleFormPage: React.FC = () => {
  const { id } = useParams<{ id?: string }>()
  const isEdit = !!id
  const history = useHistory()

  const [activeStep, setActiveStep] = useState(0)
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [selectedCategoryCode, setSelectedCategoryCode] = useState('')
  const [severity, setSeverity] = useState<Severity | ''>('')
  const [configValues, setConfigValues] = useState<Record<string, any>>({})
  const [driftValues, setDriftValues] = useState<Record<string, any>>({})
  const [ruleCategory, setRuleCategory] = useState('')
  const [ownerTeam, setOwnerTeam] = useState('')
  const [changeTicket, setChangeTicket] = useState('')
  const [requireManualApproval, setRequireManualApproval] = useState(false)

  const [retry] = useState(2)
  const [timeoutSec] = useState(30)
  const [onFailure] = useState<OnFailure>('continue')
  const [tags] = useState<string[]>([])

  const [jsonText, setJsonText] = useState('{}')
  const [jsonSyncStatus, setJsonSyncStatus] = useState<'synced' | 'saved' | 'error'>('synced')
  const [showPreviewModal, setShowPreviewModal] = useState(false)

  const isUpdatingFromJson = useRef(false)
  const jsonDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const { data: existingData, isLoading: loadingExisting } = useGetRuleByIdQuery(id!, { skip: !isEdit })
  const { data: categoriesData, isLoading: loadingCategories } = useGetRuleCategoriesMetadataQuery()
  const { data: ruleCategoriesData } = useGetRuleCategoriesQuery()
  const { data: governanceData } = useGetGovernanceTeamsQuery()
  const [createRule, { isLoading: creating }] = useCreateRuleMutation()
  const [updateRule, { isLoading: updating }] = useUpdateRuleMutation()

  const ruleCategoryOptions: string[] = (ruleCategoriesData?.data ?? []).map((c: any) => c.name ?? c)
  const governanceTeams: string[] = (governanceData?.data ?? []).map((g: any) => g.name ?? g)

  const categories: RuleCategoryMetadata[] = (categoriesData?.data ?? []).filter(
    (category: RuleCategoryMetadata) => category.isActive !== false,
  )
  const selectedCategory = categories.find((category) => category.categoryCode === selectedCategoryCode)

  const buildFullState = useCallback(() => {
    const state: Record<string, any> = {
      name,
      version: '1.0.0',
      description,
      severity: String(severity || '').toUpperCase(),
      checkType: selectedCategory?.name ?? '',
      rulecategory: ruleCategory,
      configuration: {
        ...configValues,
        checkExistence: Boolean(configValues.validateFileExistence),
        existenceState: configValues.fileExistenceValue ?? '',
        checkPerms: Boolean(configValues.validateOwnershipPermissions),
        checkContent: Boolean(configValues.validateChecksumContent),
        checkState: Boolean(configValues.validateInstallationState),
        state: configValues.runningStateValue ?? '',
        checkVersion: Boolean(configValues.validateSpecificVersion),
        runningState: configValues.runningStateValue ?? '',
        checkRunning: Boolean(configValues.validateRunningState),
        path: configValues.filePath ?? '',
        owner: configValues.expectedOwner ?? '',
        mode: configValues.permissions ?? '',
      },
      driftresponse: {
        ...driftValues,
        remediate: Boolean(driftValues.agentRemediation),
        remediationAction: driftValues.primaryAction ?? '',
        sendEmail: Boolean(driftValues.sendEmailAlert),
        emailRecipients: driftValues.emailRecipients ?? '',
        createIncident: Boolean(driftValues.createITSMIncident),
      },
      tags,
      governance: {
        ownerTeam,
        associatedChangeTicket: changeTicket,
        requireManualApprovalBeforeEnforcement: requireManualApproval,
      },
    }

    return state
  }, [
    name,
    description,
    severity,
    ruleCategory,
    configValues,
    driftValues,
    ownerTeam,
    changeTicket,
    requireManualApproval,
    selectedCategory,
    tags,
  ])

  const applyJsonToForm = useCallback((parsed: Record<string, any>) => {
    const source = normalizeParsedKeys(parsed)

    if ('name' in source || 'ruleName' in source) {
      setName(String(source.name ?? source.ruleName ?? ''))
    }
    if ('description' in source) {
      setDescription(String(source.description ?? ''))
    }
    if ('severity' in source) {
      const normalizedSeverity = String(source.severity || '').toLowerCase()
      if (SEVERITIES.includes(normalizedSeverity as Severity)) {
        setSeverity(normalizedSeverity as Severity)
      }
    }
    if ('ownerTeam' in source || 'governance' in source) {
      setOwnerTeam(String(source.ownerTeam ?? source.governance?.ownerTeam ?? ''))
    }
    if ('associatedChangeTicket' in source || 'changeTicket' in source || 'governance' in source) {
      setChangeTicket(String(
        source.associatedChangeTicket
        ?? source.changeTicket
        ?? source.governance?.associatedChangeTicket
        ?? '',
      ))
    }
    if ('requireManualApprovalBeforeEnforcement' in source || 'governance' in source) {
      setRequireManualApproval(Boolean(
        source.requireManualApprovalBeforeEnforcement
        ?? source.governance?.requireManualApprovalBeforeEnforcement,
      ))
    }

    const categoryValue = source.ruleCategory ?? source.rulecategory ?? source.categoryCode ?? source.rule_type
    const configSource = normalizeAliasKeys(source.configuration ?? {}, CONFIG_KEY_ALIASES)
    const driftSource = normalizeAliasKeys(source.driftresponse ?? source.driftResponse ?? {}, DRIFT_KEY_ALIASES)

    const mergedSource = {
      ...source,
      ...configSource,
      ...driftSource,
    }

    if (categoryValue) {
      const resolved = resolveCategoryCode(String(categoryValue), categories)
      if (resolved && resolved !== selectedCategoryCode) {
        const category = categories.find((item) => item.categoryCode === resolved)
        if (category) {
          setSelectedCategoryCode(resolved)
          setConfigValues(syncFieldValues(
            category.configFields ?? [],
            mergedSource,
            buildInitialValues(category.configFields ?? []),
          ))
          setDriftValues(syncFieldValues(
            category.driftResponses ?? [],
            mergedSource,
            buildInitialValues(category.driftResponses ?? []),
          ))
          return
        }
      }
    }

    if (selectedCategory?.configFields?.length) {
      setConfigValues((prev) => syncFieldValues(selectedCategory.configFields ?? [], mergedSource, prev))
    }
    if (selectedCategory?.driftResponses?.length) {
      setDriftValues((prev) => syncFieldValues(selectedCategory.driftResponses ?? [], mergedSource, prev))
    }
  }, [categories, selectedCategory, selectedCategoryCode])

  useEffect(() => {
    if (isEdit) return
    if (!categories.length) return
    if (selectedCategoryCode) return

    const defaultCategory = categories.find((category) => category.categoryCode === DEFAULT_CATEGORY) ?? categories[0]
    setSelectedCategoryCode(defaultCategory.categoryCode)
    setConfigValues(buildInitialValues(defaultCategory.configFields ?? []))
    setDriftValues(buildInitialValues(defaultCategory.driftResponses ?? []))
  }, [isEdit, categories, selectedCategoryCode])

  useEffect(() => {
    const rule = existingData?.data
    if (!rule) return
    if (!categories.length) return

    setName(rule.name ?? '')
    setDescription(rule.description ?? '')

    const sev = String(rule.severity ?? '').toLowerCase()
    if (SEVERITIES.includes(sev as Severity)) setSeverity(sev as Severity)

    const categoryValue = rule.rulecategory ?? rule.ruleCategory ?? rule.definition?.categoryCode ?? rule.rule_type ?? ''
    const resolved = resolveCategoryCode(String(categoryValue), categories)
    const category = categories.find((c) => c.categoryCode === resolved)
    if (category) {
      setSelectedCategoryCode(category.categoryCode)
      setConfigValues(syncFieldValues(
        category.configFields ?? [],
        rule.configuration ?? rule.definition ?? {},
        buildInitialValues(category.configFields ?? []),
      ))
      setDriftValues(syncFieldValues(
        category.driftResponses ?? [],
        rule.driftresponse ?? rule.driftResponse ?? {},
        buildInitialValues(category.driftResponses ?? []),
      ))
    }

    const gov = rule.governance ?? {}
    setOwnerTeam(gov.ownerTeam ?? '')
    setChangeTicket(gov.associatedChangeTicket ?? '')
    setRequireManualApproval(Boolean(gov.requireManualApprovalBeforeEnforcement))
  }, [existingData, categoriesData])

  useEffect(() => {
    if (isUpdatingFromJson.current) return
    const nextJson = JSON.stringify(buildFullState(), null, 2)
    setJsonText(nextJson)
    setJsonSyncStatus('synced')
  }, [buildFullState])

  const handleJsonChange = useCallback((value: string) => {
    setJsonText(value)

    if (jsonDebounceRef.current) clearTimeout(jsonDebounceRef.current)
    jsonDebounceRef.current = setTimeout(() => {
      try {
        const parsed = JSON.parse(value)
        if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
          setJsonSyncStatus('error')
          return
        }
        isUpdatingFromJson.current = true
        applyJsonToForm(parsed)
        setJsonSyncStatus('synced')
        requestAnimationFrame(() => {
          isUpdatingFromJson.current = false
        })
      } catch {
        setJsonSyncStatus('error')
      }
    }, 200)
  }, [applyJsonToForm])

  useEffect(() => () => {
    if (jsonDebounceRef.current) clearTimeout(jsonDebounceRef.current)
  }, [])

  const handleCategoryChange = (categoryCode: string) => {
    const category = categories.find((item) => item.categoryCode === categoryCode)
    if (!category) return
    setSelectedCategoryCode(categoryCode)
    setConfigValues(buildInitialValues(category.configFields ?? []))
    setDriftValues(buildInitialValues(category.driftResponses ?? []))
  }

  const canReview = Boolean(
    name.trim()
    && selectedCategoryCode
    && severity
    && ownerTeam.trim()
    && jsonSyncStatus !== 'error',
  )

  const buildPayload = () => ({
    name: name.trim(),
    version: '1.0.0',
    description: description.trim(),
    severity: String(severity || '').toUpperCase(),
    checkType: selectedCategory?.name ?? '',
    rulecategory: ruleCategory,
    configuration: {
      ...configValues,
      checkExistence: Boolean(configValues.validateFileExistence),
      existenceState: configValues.fileExistenceValue ?? '',
      checkPerms: Boolean(configValues.validateOwnershipPermissions),
      checkContent: Boolean(configValues.validateChecksumContent),
      checkState: Boolean(configValues.validateInstallationState),
      state: configValues.runningStateValue ?? '',
      checkVersion: Boolean(configValues.validateSpecificVersion),
      runningState: configValues.runningStateValue ?? '',
      checkRunning: Boolean(configValues.validateRunningState),
      path: configValues.filePath ?? '',
      owner: configValues.expectedOwner ?? '',
      mode: configValues.permissions ?? '',
    },
    driftresponse: {
      ...driftValues,
      remediate: Boolean(driftValues.agentRemediation),
      remediationAction: driftValues.primaryAction ?? '',
      sendEmail: Boolean(driftValues.sendEmailAlert),
      emailRecipients: driftValues.emailRecipients ?? '',
      createIncident: Boolean(driftValues.createITSMIncident),
    },
    status: 'PUBLISHED',
    tags,
    governance: {
      ownerTeam,
      associatedChangeTicket: changeTicket,
      requireManualApprovalBeforeEnforcement: requireManualApproval,
    },
    createdBy: '',
    updatedBy: '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    execution: { retry, timeout: timeoutSec, on_failure: onFailure },
  })

  const handleCreate = async () => {
    if (!name.trim()) {
      toast.error('Rule name is required')
      return
    }
    if (!selectedCategoryCode) {
      toast.error('Rule category is required')
      return
    }
    if (!severity) {
      toast.error('Severity is required')
      return
    }
    if (!ownerTeam.trim()) {
      toast.error('Owner team is required')
      return
    }

    const payload = buildPayload()

    try {
      if (isEdit) {
        await updateRule({ id: id!, data: payload }).unwrap()
        toast.success('Rule updated')
        setShowPreviewModal(false)
        setJsonSyncStatus('saved')
        history.push(`${POLICYOPS_PATH.RULES}/${id}`)
      } else {
        const result = await createRule(payload).unwrap()
        const newId = result.data?._id ?? result.data?.id
        toast.success('Rule created')
        setShowPreviewModal(false)
        setJsonSyncStatus('saved')
        history.push(`${POLICYOPS_PATH.RULES}/${newId}`)
      }
    } catch {
      toast.error('Create failed. Please try again.')
    }
  }

  const handleOpenPreview = () => {
    if (!name.trim()) {
      toast.error('Rule name is required')
      return
    }
    if (!selectedCategoryCode) {
      toast.error('Rule category is required')
      return
    }
    if (!severity) {
      toast.error('Severity is required')
      return
    }
    if (!ownerTeam.trim()) {
      toast.error('Owner team is required')
      return
    }
    if (jsonSyncStatus === 'error') {
      toast.error('Fix invalid JSON before review')
      return
    }
    setShowPreviewModal(true)
  }

  const validateStep = (step: number): boolean => {
    if (step === 0) {
      if (!name.trim()) {
        toast.error('Rule name is required')
        return false
      }
      if (!selectedCategoryCode) {
        toast.error('Rule category is required')
        return false
      }
    }
    return true
  }

  const handleStepClick = (targetStep: number) => {
    if (targetStep <= activeStep) {
      setActiveStep(targetStep)
      return
    }

    if (!validateStep(activeStep)) return
    setActiveStep(targetStep)
  }

  const handleNext = () => {
    if (!validateStep(activeStep)) return
    setActiveStep((prev) => Math.min(prev + 1, STEPS.length - 1))
  }

  const handlePrevious = () => {
    setActiveStep((prev) => Math.max(prev - 1, 0))
  }

  const fieldDisplayMap = useMemo(() => {
    if (!selectedCategory) return {}
    const map = buildFieldDisplayMap(selectedCategory.configFields ?? [])
    return buildFieldDisplayMap(selectedCategory.driftResponses ?? [], map)
  }, [selectedCategory])

  const mapRows = useCallback((values: Record<string, any>) => (
    Object.entries(values)
      .filter(([, value]) => value !== '' && value !== null && value !== undefined && value !== false)
      .map(([key, value]) => ({
        label: fieldDisplayMap[key] ?? key,
        value: typeof value === 'boolean' ? 'Yes' : String(value),
      }))
  ), [fieldDisplayMap])

  if ((isEdit && loadingExisting) || loadingCategories) return <Box sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><CircularProgress /></Box>
  if (isEdit && !existingData?.data) return <Box p={3}><Alert severity="error">Rule not found</Alert></Box>
  if (!categories.length) return <Box p={3}><Alert severity="warning">No active rule categories available.</Alert></Box>

  const isSaving = creating || updating

  const configRows = mapRows(configValues)

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <Box sx={{ maxWidth: 900, mx: 'auto', width: '100%' }}>
            <Paper elevation={0} sx={{ ...CARD_SX, p: 0, overflow: 'hidden' }}>
              {/* Card header */}
              <Box sx={{ px: 3.5, pt: 3, pb: 2.5 }}>
                <Typography variant="subtitle1" fontWeight={700} color="#102459">Basic Information</Typography>
                <Typography variant="body2" color="text.secondary" mt={0.5}>{BASIC_INFO_SUBTITLE}</Typography>
              </Box>

              {/* Rule Name row */}
              <Box sx={{ px: 3.5, py: 1.75, borderTop: '1px solid #f1f5f9' }}>
                <TextField
                  fullWidth
                  size="small"
                  placeholder="Rule Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      borderRadius: '8px', fontSize: '0.875rem', color: '#102459',
                      '& fieldset': { borderColor: '#e2e8f0' },
                      '&:hover fieldset': { borderColor: '#94a3b8' },
                      '&.Mui-focused fieldset': { borderColor: '#2563eb', borderWidth: '1px' },
                    },
                    '& .MuiInputBase-input::placeholder': { color: '#94a3b8', opacity: 1 },
                  }}
                />
              </Box>

              {/* Description row */}
              <Box sx={{ px: 3.5, py: 1.75, borderTop: '1px solid #f1f5f9' }}>
                <TextField
                  fullWidth
                  size="small"
                  placeholder="Description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      borderRadius: '8px', fontSize: '0.875rem', color: '#102459',
                      '& fieldset': { borderColor: '#e2e8f0' },
                      '&:hover fieldset': { borderColor: '#94a3b8' },
                      '&.Mui-focused fieldset': { borderColor: '#2563eb', borderWidth: '1px' },
                    },
                    '& .MuiInputBase-input::placeholder': { color: '#94a3b8', opacity: 1 },
                  }}
                />
              </Box>

              {/* Check Type + Rule Category + Severity row */}
              <Box sx={{ px: 3.5, py: 1.75, borderTop: '1px solid #f1f5f9' }}>
                <Grid container spacing={2}>
                  {/* Check Type */}
                  <Grid item xs={12} sm={4}>
                    <FormControl fullWidth size="small" required sx={FORM_FIELD_SX}>
                      <InputLabel>Check Type</InputLabel>
                      <Select
                        value={selectedCategoryCode}
                        label="Check Type *"
                        disabled={isEdit}
                        onChange={(e) => handleCategoryChange(e.target.value)}
                      >
                        {categories.map((cat) => (
                          <MenuItem key={cat.categoryCode} value={cat.categoryCode}>{cat.name}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                  {/* Rule Category */}
                  <Grid item xs={12} sm={4}>
                    <FormControl fullWidth size="small" required sx={FORM_FIELD_SX}>
                      <InputLabel>Rule Category</InputLabel>
                      <Select
                        value={ruleCategory}
                        label="Rule Category *"
                        onChange={(e) => setRuleCategory(e.target.value)}
                      >
                        {ruleCategoryOptions.map((opt) => (
                          <MenuItem key={opt} value={opt}>{opt}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                  {/* Severity */}
                  <Grid item xs={12} sm={4}>
                    <FormControl fullWidth size="small" required sx={FORM_FIELD_SX}>
                      <InputLabel>Severity</InputLabel>
                      <Select
                        value={severity}
                        label="Severity *"
                        onChange={(e) => setSeverity(e.target.value as Severity)}
                      >
                        {SEVERITIES.map((opt) => (
                          <MenuItem key={opt} value={opt}>
                            {opt.charAt(0).toUpperCase() + opt.slice(1)}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                </Grid>
              </Box>
            </Paper>
          </Box>
        )

      case 1:
        return (
          <Grid container spacing={3} sx={{ height: '100%', alignItems: 'stretch' }}>
            <Grid item xs={12} lg={7}>
              <Paper elevation={0} sx={CARD_SX}>
                <Typography variant="subtitle1" fontWeight={700} mb={0.5} color="#102459">{getConfigSectionTitle(selectedCategoryCode)}</Typography>
                <Typography variant="body2" color="text.secondary" mb={2}>{SECTION_SUBTITLE}</Typography>
                <Divider sx={{ mb: 3, borderColor: '#f1f5f9' }} />
                <DynamicFields fields={selectedCategory?.configFields ?? []} values={configValues} onValuesChange={(updater) => setConfigValues((prev) => updater(prev))} />
              </Paper>
            </Grid>
            <Grid item xs={12} lg={5}>
              <LiveJsonEditor value={jsonText} syncStatus={jsonSyncStatus} onChange={handleJsonChange} />
            </Grid>
          </Grid>
        )

      case 2:
        return (
          <Grid container spacing={3} sx={{ height: '100%', alignItems: 'stretch' }}>
            <Grid item xs={12} lg={7}>
              <Paper elevation={0} sx={CARD_SX}>
                <Typography variant="subtitle1" fontWeight={700} mb={0.5} color="#102459">Drift Actions</Typography>
                <Typography variant="body2" color="text.secondary" mb={2}>{DRIFT_SECTION_SUBTITLE}</Typography>
                <Divider sx={{ mb: 3, borderColor: '#f1f5f9' }} />
                <DynamicFields fields={selectedCategory?.driftResponses ?? []} values={driftValues} onValuesChange={(updater) => setDriftValues((prev) => updater(prev))} />
              </Paper>
            </Grid>
            <Grid item xs={12} lg={5}>
              <LiveJsonEditor value={jsonText} syncStatus={jsonSyncStatus} onChange={handleJsonChange} />
            </Grid>
          </Grid>
        )

      case 3:
        return (
          <Grid container spacing={3} sx={{ height: '100%', alignItems: 'stretch' }}>
            <Grid item xs={12} lg={7}>
              <Paper elevation={0} sx={CARD_SX}>
                <Typography variant="subtitle1" fontWeight={700} mb={0.5} color="#102459">Governance & Ownership</Typography>
                <Typography variant="body2" color="text.secondary" mb={2}>{GOVERNANCE_SUBTITLE}</Typography>
                <Divider sx={{ mb: 3, borderColor: '#f1f5f9' }} />
                <Grid container spacing={2.5}>
                  <Grid item xs={12} sm={6}>
                    <FormControl fullWidth size="small" required sx={FORM_FIELD_SX}>
                      <InputLabel>Owner Team</InputLabel>
                      <Select value={ownerTeam} label="Owner Team *" onChange={(e) => setOwnerTeam(e.target.value)}>
                        {governanceTeams.map((team) => (<MenuItem key={team} value={team}>{team}</MenuItem>))}
                      </Select>
                    </FormControl>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField fullWidth size="small" sx={FORM_FIELD_SX} label="Associated Change Ticket (Optional)" placeholder="e.g. CHG-123456" value={changeTicket} onChange={(e) => setChangeTicket(e.target.value)} />
                  </Grid>
                </Grid>
              </Paper>
            </Grid>
            <Grid item xs={12} lg={5}>
              <LiveJsonEditor value={jsonText} syncStatus={jsonSyncStatus} onChange={handleJsonChange} />
            </Grid>
          </Grid>
        )

      default:
        return null
    }
  }

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', bgcolor: '#ffffff' }}>
      <Box sx={{ bgcolor: 'white', borderBottom: '1px solid #e2e8f0', px: 3, pt: 1.5, pb: 0 }}>
        {/* Title row */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25 }}>
            <IconButton size="small" onClick={() => history.goBack()} sx={{ color: '#64748b', border: '1px solid #e2e8f0', borderRadius: '8px', p: '4px', '&:hover': { bgcolor: '#f8fafc', color: '#102459' } }}>
              <ChevronLeft size={16} />
            </IconButton>
            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 0.15 }}>
                <Typography variant="caption" sx={{ color: '#2563eb', cursor: 'pointer', fontWeight: 500, '&:hover': { textDecoration: 'underline' } }} onClick={() => history.push(POLICYOPS_PATH.RULES)}>Rules</Typography>
                <Typography variant="caption" sx={{ color: '#94a3b8' }}>›</Typography>
                <Typography variant="caption" sx={{ color: '#64748b' }}>{isEdit ? 'Edit' : 'Create'}</Typography>
              </Box>
              <Typography variant="subtitle1" fontWeight={700} lineHeight={1.2} color="#102459">{isEdit ? 'Edit Rule' : 'Create Rule'}</Typography>
            </Box>
          </Box>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button variant="outlined" size="small" onClick={() => history.goBack()} sx={{ borderColor: '#bfdbfe', color: '#2563eb', bgcolor: '#eff6ff', px: 2, '&:hover': { borderColor: '#93c5fd', bgcolor: '#dbeafe' } }}>Cancel</Button>
            <Button variant="contained" size="small" onClick={handleOpenPreview} disabled={!canReview || isSaving} sx={{ px: 2, bgcolor: canReview && !isSaving ? '#2563eb' : '#e2e8f0', color: canReview && !isSaving ? '#fff' : '#94a3b8', boxShadow: 'none', '&:hover': { bgcolor: canReview && !isSaving ? '#1d4ed8' : '#e2e8f0', boxShadow: 'none' } }}>
              Review & Create
            </Button>
          </Box>
        </Box>

        {/* Stepper */}
        <Stepper nonLinear activeStep={activeStep} alternativeLabel connector={<RuleStepConnector />} sx={{ maxWidth: 700, mx: 'auto', pb: 1.5, '& .MuiStepLabel-label': { mt: 0.75, fontSize: '0.78rem' }, '& .MuiStepLabel-labelContainer': { maxWidth: 'none' } }}>
          {STEPS.map((label, index) => (
            <Step key={label} completed={index < activeStep}>
              <StepButton disableRipple onClick={() => handleStepClick(index)}>
                <StepLabel StepIconComponent={() => (<StepIcon index={index} active={index === activeStep} completed={index < activeStep} />)}>
                  <Typography fontWeight={index === activeStep ? 700 : 400} color={index <= activeStep ? '#1e293b' : '#94a3b8'} sx={{ fontSize: '0.78rem' }}>
                    {label}
                  </Typography>
                </StepLabel>
              </StepButton>
            </Step>
          ))}
        </Stepper>
      </Box>

      <Box sx={{ flex: 1, overflow: 'auto', px: 4, py: 3, bgcolor: '#eef2f9' }}>
        {renderStepContent()}
      </Box>

      <Box sx={{ bgcolor: 'white', borderTop: '1px solid #e2e8f0', px: 3, py: 2, display: 'flex', justifyContent: 'flex-end', gap: 1.5 }}>
        {activeStep > 0 && (
          <Button variant="outlined" size="medium" onClick={handlePrevious} sx={{ borderColor: '#e2e8f0', color: '#64748b', textTransform: 'none', fontWeight: 500, px: 2.5, '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' } }}>
            Previous
          </Button>
        )}
        {activeStep < STEPS.length - 1 ? (
          <Button variant="contained" size="medium" onClick={handleNext} sx={{ textTransform: 'none', fontWeight: 500, px: 2.5, bgcolor: '#2563eb', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}>
            Next
          </Button>
        ) : (
          <Button variant="contained" size="medium" onClick={handleOpenPreview} disabled={!canReview || isSaving} sx={{ textTransform: 'none', fontWeight: 500, px: 2.5, bgcolor: canReview && !isSaving ? '#2563eb' : '#e2e8f0', color: canReview && !isSaving ? '#fff' : '#94a3b8', boxShadow: 'none', '&:hover': { bgcolor: canReview && !isSaving ? '#1d4ed8' : '#e2e8f0', boxShadow: 'none' } }}>
            Review & Create
          </Button>
        )}
      </Box>

      <Dialog open={showPreviewModal} onClose={() => setShowPreviewModal(false)} maxWidth="md" fullWidth PaperProps={{ sx: { borderRadius: '16px', overflow: 'hidden' } }}>
        <DialogContent sx={{ p: 0 }}>
          {/* Header */}
          <Box display="flex" alignItems="center" justifyContent="space-between" px={3.5} pt={3} pb={2} borderBottom="1px solid #e2e8f0">
            <Typography sx={{ fontSize: '1.125rem', fontWeight: 600, color: '#101828' }}>Rule Preview</Typography>
            <IconButton size="small" onClick={() => setShowPreviewModal(false)} sx={{ color: '#94a3b8', '&:hover': { color: '#475569', bgcolor: '#f1f5f9' } }}>
              <X size={18} />
            </IconButton>
          </Box>

          <Box sx={{ p: 3, display: 'flex', flexDirection: 'column', gap: 2 }}>
            {/* Basic Information */}
            <Box sx={{ bgcolor: '#eef2f9', borderRadius: '12px', p: 2.5 }}>
              <Typography sx={{ fontSize: '0.9375rem', fontWeight: 500, color: '#101828', mb: 1.5 }}>Basic Information</Typography>
              {[
                { label: 'Configuration Name', value: name || '-' },
                { label: 'Type', value: selectedCategory?.name || '-' },
                { label: 'Description', value: description || '-' },
              ].map(({ label, value }) => (
                <Box key={label} display="flex" alignItems="flex-start" py={0.6}>
                  <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', minWidth: 200, flexShrink: 0 }}>{label}</Typography>
                  <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#101828' }}>{value}</Typography>
                </Box>
              ))}
            </Box>

            {/* Target Settings */}
            {configRows.length > 0 && (
              <Box sx={{ bgcolor: '#eef2f9', borderRadius: '12px', p: 2.5 }}>
                <Typography sx={{ fontSize: '0.9375rem', fontWeight: 500, color: '#101828', mb: 1.5 }}>Target Settings</Typography>
                {configRows.map(({ label, value }) => (
                  <Box key={label} display="flex" alignItems="flex-start" py={0.6}>
                    <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', minWidth: 200, flexShrink: 0 }}>{label}</Typography>
                    <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#101828', wordBreak: 'break-word', flex: 1 }}>{value}</Typography>
                  </Box>
                ))}
              </Box>
            )}

            {/* Enforcement & Version Details */}
            <Box sx={{ bgcolor: '#eef2f9', borderRadius: '12px', p: 2.5 }}>
              <Typography sx={{ fontSize: '0.9375rem', fontWeight: 500, color: '#101828', mb: 1.5 }}>Enforcement & Version Details</Typography>
              <Box display="flex" alignItems="center" py={0.6}>
                <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', minWidth: 200, flexShrink: 0 }}>Severity</Typography>
                <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#101828' }}>{String(severity || '-').charAt(0).toUpperCase() + String(severity || '').slice(1)}</Typography>
              </Box>
              <Box display="flex" alignItems="center" py={0.6}>
                <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', minWidth: 200, flexShrink: 0 }}>Version</Typography>
                <Box sx={{ px: 1.25, py: 0.2, border: '1px solid #cbd5e1', bgcolor: '#f1f5f9', borderRadius: '999px', fontSize: '0.75rem', fontWeight: 500, color: '#475569' }}>
                  V1.0.0
                </Box>
              </Box>
              {ownerTeam && (
                <Box display="flex" alignItems="flex-start" py={0.6}>
                  <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', minWidth: 200, flexShrink: 0 }}>Owner Team</Typography>
                  <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#101828' }}>{ownerTeam}</Typography>
                </Box>
              )}
              {changeTicket && (
                <Box display="flex" alignItems="flex-start" py={0.6}>
                  <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', minWidth: 200, flexShrink: 0 }}>Commit Message (Optional)</Typography>
                  <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#101828' }}>{changeTicket}</Typography>
                </Box>
              )}
            </Box>
          </Box>
        </DialogContent>

        <DialogActions sx={{ px: 3, py: 2, gap: 1, borderTop: '1px solid #e2e8f0' }}>
          <Button size="small" variant="outlined" onClick={() => setShowPreviewModal(false)} sx={{ borderColor: '#e2e8f0', color: '#64748b', fontSize: '0.8125rem', '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' } }}>
            Cancel
          </Button>
          <Button size="small" variant="outlined" onClick={() => setShowPreviewModal(false)} sx={{ borderColor: '#2563eb', color: '#2563eb', fontSize: '0.8125rem', '&:hover': { bgcolor: '#eff6ff' } }}>
            Modify
          </Button>
          <Button size="small" variant="contained" onClick={handleCreate} disabled={isSaving} sx={{ bgcolor: '#2563eb', px: 2.5, fontSize: '0.8125rem', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}>
            {isSaving ? 'Creating…' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default RuleFormPage
