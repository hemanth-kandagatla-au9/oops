import React from 'react'
import { Box, Paper, Typography, Chip, List, ListItem, ListItemIcon, ListItemText } from '@mui/material'
import { Package, Upload, FileArchive, Hash, Clock } from 'lucide-react'

const planned = [
  { icon: <Upload size={18} />, title: 'Upload RPMs & scripts', desc: 'Push binary artifacts to MinIO S3 backing store' },
  { icon: <Hash size={18} />, title: 'Checksum management', desc: 'SHA-256 verification for all uploaded files' },
  { icon: <FileArchive size={18} />, title: 'Version history', desc: 'Immutable versioned artifact registry' },
  { icon: <Clock size={18} />, title: 'Usage tracking', desc: 'Which rules reference each artifact' },
]

const ArtifactsPage: React.FC = () => (
  <Box p={3}>
    <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
      <Box>
        <Typography variant="h5" fontWeight="bold">Artifacts</Typography>
        <Typography variant="body2" color="text.secondary">
          Binary file registry — RPMs, scripts, config files used by rules
        </Typography>
      </Box>
      <Chip label="Out of POC scope" size="small" color="default" variant="outlined" />
    </Box>

    <Paper elevation={0} variant="outlined" sx={{ p: 4, borderRadius: 2, textAlign: 'center' }}>
      <Box sx={{ color: 'text.disabled', mb: 2 }}><Package size={48} /></Box>
      <Typography variant="h6" fontWeight="bold" mb={1}>Not implemented in this POC</Typography>
      <Typography variant="body2" color="text.secondary" mb={3} maxWidth={480} mx="auto">
        The Artifacts module is out of scope for this frontend POC. It will be implemented when the
        MinIO S3 backend is ready. The following features are planned:
      </Typography>
      <List dense sx={{ maxWidth: 400, mx: 'auto', textAlign: 'left' }}>
        {planned.map(({ icon, title, desc }) => (
          <ListItem key={title} sx={{ py: 0.75 }}>
            <ListItemIcon sx={{ minWidth: 36, color: 'text.secondary' }}>{icon}</ListItemIcon>
            <ListItemText
              primary={<Typography variant="body2" fontWeight={500}>{title}</Typography>}
              secondary={<Typography variant="caption" color="text.secondary">{desc}</Typography>}
            />
          </ListItem>
        ))}
      </List>
    </Paper>
  </Box>
)

export default ArtifactsPage
