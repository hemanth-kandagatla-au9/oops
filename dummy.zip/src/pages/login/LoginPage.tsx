import React, { useEffect, useState } from "react";
import { Box, Button, CircularProgress, Typography } from "@mui/material";
import { useMsal } from "@azure/msal-react";

const TOKEN_SCOPES = ["User.Read", "profile", "email"];

const LoginPage: React.FC = () => {
  const { instance } = useMsal();
  const [loading, setLoading] = useState(false);

  const doLogin = async () => {
    try {
      setLoading(true);
      const accounts = instance.getAllAccounts();
      if (accounts.length > 0) {
        window.location.href = "/dashboard";
        return;
      }
      const currentUrl = window.location.pathname + window.location.search;
      const isDefault = ['/', '/login', '/dashboard'].includes(currentUrl);
      if (!isDefault && !sessionStorage.getItem("postLoginRedirect")) {
        sessionStorage.setItem("postLoginRedirect", currentUrl);
      }
      await instance.loginRedirect({ scopes: TOKEN_SCOPES });
    } catch (err) {
      console.error("Login error:", err);
      setLoading(false);
    }
  };

  // Auto-redirect on mount — same as platform's Login.tsx
  useEffect(() => {
    doLogin();
  }, []);

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      height="100vh"
      sx={{ background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)" }}
    >
      {loading ? (
        <CircularProgress sx={{ color: "white" }} size={48} />
      ) : (
        <>
          <Typography variant="h3" color="white" fontWeight="bold" mb={2}>
            IASphere PolicyOps
          </Typography>
          <Typography variant="subtitle1" color="rgba(255,255,255,0.8)" mb={4}>
            Configuration Management Platform
          </Typography>
          <Button
            variant="contained"
            size="large"
            onClick={doLogin}
            sx={{ bgcolor: "white", color: "#667eea", "&:hover": { bgcolor: "rgba(255,255,255,0.9)" } }}
          >
            Sign in with Microsoft
          </Button>
        </>
      )}
    </Box>
  );
};

export default LoginPage;
