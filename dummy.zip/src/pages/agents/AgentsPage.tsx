import React, { useState } from 'react'
import { Box, Button, Chip, Grid, IconButton, Tooltip, Typography } from '@mui/material'
import { RefreshCw, Eye, Wifi, WifiOff, Clock, SlidersHorizontal } from 'lucide-react'
import { useHistory } from 'react-router-dom'
import { toast } from 'react-toastify'
import {
  useGetAgentsQuery,
  useGetAgentsHealthQuery,
  useSyncAgentMutation,
} from '../../redux/slices/agentsSlice'
import { POLICYOPS_PATH } from '../../utils/constant'
import { AGENT_STATUS_COLORS } from '../../utils/uiConstants'
import { formatRelative, formatTime } from '../../utils/dateUtils'
import PolicyTable, { TableColumn } from '../../components/PolicyTable'
import LinkCell from '../../components/LinkCell'
import StatCard from '../../components/StatCard'
import StatusBadge from '../../components/StatusBadge'
import { Agent } from '../../types'

const AgentsPage: React.FC = () => {
  const history = useHistory()
  const [statusFilter, setStatusFilter] = useState('')
  const [page, setPage] = useState(0)
  const [pageSize, setPageSize] = useState(10)

  const { data, isLoading, isError, refetch } = useGetAgentsQuery({ page: page + 1, limit: pageSize, status: statusFilter || undefined })
  const { data: healthData } = useGetAgentsHealthQuery()
  const [syncAgent] = useSyncAgentMutation()

  const agents: Agent[] = data?.data ?? []
  const total: number = data?.total ?? 0
  const health = healthData?.data ?? { online: 0, stale: 0, offline: 0, total: 0 }

  const handleSync = async (agent: Agent, e: React.MouseEvent) => {
    e.stopPropagation()
    try { await syncAgent(agent._id).unwrap(); toast.success(`Sync initiated for ${agent.hostname}`); refetch() }
    catch { toast.error(`Sync failed for ${agent.hostname}`) }
  }

  const toggleFilter = (status: string) => { setStatusFilter((prev) => (prev === status ? '' : status)); setPage(0) }


  const columns: TableColumn[] = [
    {
      key: 'hostname', header: 'Hostname', minWidth: 160,
      render: (row: Agent) => (
        <LinkCell label={row.hostname} onClick={() => history.push(`${POLICYOPS_PATH.AGENTS}/${row.hostname}`)} />
      ),
    },
    {
      key: 'environment', header: 'Environment', width: 130,
      render: (row: Agent) => <Chip label={row.environment} size="small" variant="outlined" sx={{ fontSize: '0.72rem' }} />,
    },
    {
      key: 'agent_version', header: 'Version', width: 100,
      render: (row: Agent) => <Typography variant="body2" color="text.secondary">v{row.agent_version}</Typography>,
    },
    {
      key: 'status', header: 'Status', width: 110,
      render: (row: Agent) => <StatusBadge value={row.status} />,
    },
    {
      key: 'last_heartbeat', header: 'Last Heartbeat', width: 170,
      render: (row: Agent) => (
        <Box>
          <Typography variant="body2">{formatRelative(row.last_heartbeat)}</Typography>
          <Typography variant="caption" color="text.secondary">{formatTime(row.last_heartbeat)}</Typography>
        </Box>
      ),
    },
    {
      key: 'last_sync', header: 'Last Sync', width: 170,
      render: (row: Agent) => (
        <Box>
          <Typography variant="body2">{formatRelative(row.last_sync)}</Typography>
          <Typography variant="caption" color="text.secondary">{formatTime(row.last_sync)}</Typography>
        </Box>
      ),
    },
    {
      key: 'assignment_ids', header: 'Assignments', width: 120,
      render: (row: Agent) => {
        const ids: string[] = row.assignment_ids ?? []
        return ids.length > 0
          ? <Chip label={`${ids.length} active`} size="small" variant="outlined" color="primary" sx={{ fontSize: '0.72rem' }} />
          : <Typography variant="body2" color="text.disabled">None</Typography>
      },
    },
    {
      key: 'actions', header: 'Actions', width: 100, align: 'right',
      render: (row: Agent) => (
        <Box display="flex" gap={0.5} justifyContent="flex-end">
          <Tooltip title="View detail">
            <IconButton size="small" onClick={(e) => { e.stopPropagation(); history.push(`${POLICYOPS_PATH.AGENTS}/${row.hostname}`) }}>
              <Eye size={15} />
            </IconButton>
          </Tooltip>
          <Tooltip title="Sync now">
            <IconButton size="small" sx={{ color: '#2563eb' }} onClick={(e) => handleSync(row, e)} disabled={row.status === 'offline'}>
              <RefreshCw size={15} />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    },
  ]

  return (
    <Box p={3}>
      {/* ── Header row ── */}
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={0.75}>
        <Box>
          <Box display="flex" alignItems="center" gap={1}>
            <Typography variant="h5" fontWeight={700}>Agent Inventory</Typography>
            <Box sx={{ px: 1, py: 0.15, bgcolor: '#eff6ff', borderRadius: '999px', border: '1px solid #dbeafe' }}>
              <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: '#2563eb' }}>{total}</Typography>
            </Box>
          </Box>
        </Box>
        <Box display="flex" alignItems="center" gap={1.5}>
          <Button
            variant="outlined" size="small"
            startIcon={<SlidersHorizontal size={14} />}
            sx={{ borderColor: '#e2e8f0', color: '#64748b', fontSize: '0.85rem' }}
          >
            Filter
          </Button>
          <Button
            variant="outlined" size="small"
            startIcon={<RefreshCw size={14} />}
            onClick={() => refetch()}
            sx={{ borderColor: '#e2e8f0', color: '#64748b', fontSize: '0.85rem' }}
          >
            Refresh
          </Button>
        </Box>
      </Box>
      <Typography variant="body2" color="text.secondary" mb={3}>
        Monitor and manage Rust agents on your server fleet
      </Typography>

      <Grid container spacing={2} mb={3}>
        <Grid item xs={6} sm={3}>
          <StatCard label="Online" value={health.online} icon={<Wifi size={24} />} color="#16a34a"
            onClick={() => toggleFilter('online')} active={statusFilter === 'online'} />
        </Grid>
        <Grid item xs={6} sm={3}>
          <StatCard label="Stale" value={health.stale} icon={<Clock size={24} />} color="#d97706"
            onClick={() => toggleFilter('stale')} active={statusFilter === 'stale'} />
        </Grid>
        <Grid item xs={6} sm={3}>
          <StatCard label="Offline" value={health.offline} icon={<WifiOff size={24} />} color="#dc2626"
            onClick={() => toggleFilter('offline')} active={statusFilter === 'offline'} />
        </Grid>
        <Grid item xs={6} sm={3}>
          <StatCard label="Total" value={health.total} icon={<Wifi size={24} />} color="#2563eb" />
        </Grid>
      </Grid>

      <PolicyTable
        columns={columns} rows={agents} total={total}
        page={page} pageSize={pageSize}
        onPageChange={setPage} onPageSizeChange={(s) => { setPageSize(s); setPage(0) }}
        loading={isLoading} error={isError} errorMessage="Failed to load agents"
      />
    </Box>
  )
}

export default AgentsPage
