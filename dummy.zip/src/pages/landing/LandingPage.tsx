import React from "react";
import "../../styles/pages/landing/Landingpage.scss";
import Sidebar from "../../components/landing/Sidebar";
import Header from "../../components/landing/Header";

interface LandingPageLayoutProps {
  children: React.ReactNode;
}

export const LandingPageLayout: React.FC<LandingPageLayoutProps> = ({ children }) => {
  return (
    <div className="landing-page">
      <Header />
      <div className="landing-body">
        <Sidebar />
        <div className="page-content">{children}</div>
      </div>
    </div>
  );
};

export default LandingPageLayout;
