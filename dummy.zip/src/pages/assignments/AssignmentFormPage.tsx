import React, { useState, useEffect } from 'react'
import {
  Alert,
  Box,
  Button,
  Checkbox,
  Chip,
  CircularProgress,
  FormControl,
  Grid,
  IconButton,
  InputAdornment,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Step,
  StepButton,
  StepConnector,
  StepLabel,
  Stepper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material'
import { styled } from '@mui/material/styles'
import { stepConnectorClasses } from '@mui/material/StepConnector'
import {
  ArrowLeft, CheckCircle2, ChevronDown, FileText, GripVertical,
  LayoutGrid, List, Lock, Pencil, Plus, Search, X,
} from 'lucide-react'
import { useHistory, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import {
  useGetAssignmentByIdQuery,
  useCreateAssignmentMutation,
  useUpdateAssignmentMutation,
} from '../../redux/slices/assignmentsSlice'
import { useGetPoliciesQuery } from '../../redux/slices/policiesSlice'
import {
  useGetTargetServersMetadataQuery,
  useGetTargetServersQuery,
} from '../../redux/slices/targetServersSlice'
import { POLICYOPS_PATH } from '../../utils/constant'
import FormToggleRow from '../../components/FormToggleRow'

const STEPS = ['Basic Info', 'Policy Selection', 'Target Selection', 'Execution Info', 'Summary']

const AssignmentStepConnector = styled(StepConnector)(() => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 20,
    left: 'calc(-50% + 20px)',
    right: 'calc(50% + 20px)',
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 2,
    border: 0,
    backgroundColor: '#e2e8f0',
    borderRadius: 1,
  },
  [`&.${stepConnectorClasses.active} .${stepConnectorClasses.line}`]: {
    backgroundColor: '#2563eb',
  },
  [`&.${stepConnectorClasses.completed} .${stepConnectorClasses.line}`]: {
    backgroundColor: '#22c55e',
  },
}))

const FORM_FIELD_SX = {
  '& .MuiOutlinedInput-root': {
    borderRadius: '8px',
    bgcolor: '#ffffff',
    fontSize: '0.875rem',
    '& fieldset': { borderColor: '#e2e8f0' },
    '&:hover fieldset': { borderColor: '#cbd5e1' },
    '&.Mui-focused fieldset': { borderColor: '#2563eb', borderWidth: '1px' },
  },
  '& .MuiInputLabel-root': { color: '#64748b', fontSize: '0.875rem' },
  '& .MuiInputLabel-root.Mui-focused': { color: '#2563eb' },
}

const CARD_SX = {
  borderRadius: '10px',
  border: '1px solid #e2e8f0',
  bgcolor: 'white',
  p: 3.5,
  height: '100%',
}

const ASSIGNMENT_TYPES = ['Policy']
const PRIORITIES = ['Critical', 'High', 'Medium', 'Low']
const POLICY_SELECTION_MODES = ['Single Policy', 'Multiple Policies']
const TARGET_TYPES = ['Server']
const EXECUTION_MODES = ['Use Policy', 'Audit', 'Enforce']
const EXECUTION_STRATEGIES = ['Sequential', 'Parallel']
const ROLLOUT_STRATEGIES = ['All Servers', 'Batch', 'Percentage']
const SCHEDULE_TYPES = ['Manual', 'Hourly', 'Daily', 'Weekly', 'Monthly', 'Cron']
const TIMEZONES = ['UTC', 'EST', 'PST', 'CET', 'IST']
interface TargetServerMetadata {
  region: string[]
  os: string[]
  sid: string[]
  owner: string[]
  application: string[]
  environment: string[]
}

interface TargetServerItem {
  hostname: string
  environment: string
  region: string
  service: string
  sid: string
  application: string
  businessService: string
  owner: string
  serverType: string
  os: string
  status: string
  createdDate?: string
  lastUpdated?: string
}

interface PolicyItem {
  id: string
  policyId?: string
  name: string
  versionNumber?: string
  env: string
  envBg: string
  envColor: string
  rules: number
  compliance: number
  status: string
}

const MOCK_POLICIES: PolicyItem[] = [
  { id: 'p1', name: 'Linux Security Policy', env: 'Prod', envBg: '#dcfce7', envColor: '#15803d', rules: 4, compliance: 99.2, status: 'Active' },
  { id: 'p2', name: 'Payment Gateway Policy', env: 'Staging', envBg: '#dbeafe', envColor: '#2563eb', rules: 6, compliance: 99.2, status: 'Active' },
  { id: 'p3', name: 'Database Hardening Policy', env: 'Prod', envBg: '#dcfce7', envColor: '#15803d', rules: 8, compliance: 99.2, status: 'Active' },
  { id: 'p4', name: 'Web Server Baseline', env: 'Staging', envBg: '#dbeafe', envColor: '#2563eb', rules: 5, compliance: 99.2, status: 'Active' },
  { id: 'p5', name: 'Container Security Policy', env: 'Prod', envBg: '#dcfce7', envColor: '#15803d', rules: 3, compliance: 99.2, status: 'Active' },
]

type FieldErrors = Record<string, string>

const validateStep0 = (name: string, assignmentType: string, priority: string): FieldErrors => {
  const errors: FieldErrors = {}
  if (!name.trim()) errors.name = 'Assignment name is required'
  if (!assignmentType) errors.assignmentType = 'Assignment type is required'
  if (!priority) errors.priority = 'Priority is required'
  return errors
}

const validateStep1 = (selectedCount: number): FieldErrors => {
  const errors: FieldErrors = {}
  if (!selectedCount) errors.selectedPolicies = 'Select at least one policy'
  return errors
}

const validateStep2 = (targetType: string, selectedServerCount: number): FieldErrors => {
  const errors: FieldErrors = {}
  if (!targetType) errors.targetType = 'Target type is required'
  if (!selectedServerCount) errors.selectedServers = 'Select at least one server'
  return errors
}

const StepIcon: React.FC<{ index: number; active: boolean; completed: boolean }> = ({
  index, active, completed,
}) => {
  const icons = [
    <LayoutGrid size={16} key="basic" />,
    <Lock size={16} key="policy" />,
    <Lock size={16} key="exec" />,
    <List size={16} key="review" />,
  ]
  const bg = completed ? '#22c55e' : active ? '#2563eb' : '#e2e8f0'
  const color = completed || active ? 'white' : '#64748b'

  return (
    <Box sx={{
      width: 40, height: 40, borderRadius: '50%', bgcolor: bg, color,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontWeight: 600, fontSize: '0.875rem',
      boxShadow: active ? '0 0 0 4px rgba(37,99,235,0.12)' : 'none',
    }}
    >
      {completed ? <CheckCircle2 size={20} /> : active ? icons[index] : index + 1}
    </Box>
  )
}

const PolicyRow: React.FC<{
  policy: PolicyItem
  action?: 'add' | 'remove'
  onAction?: () => void
  showDrag?: boolean
}> = ({ policy, action, onAction, showDrag }) => (
  <Box sx={{
    display: 'flex', alignItems: 'center', gap: 1.5, p: 1.5,
    border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', mb: 1,
  }}
  >
    {showDrag && <GripVertical size={16} color="#94a3b8" style={{ flexShrink: 0 }} />}
    {!showDrag && <ChevronDown size={16} color="#94a3b8" style={{ flexShrink: 0 }} />}
    <FileText size={18} color="#2563eb" style={{ flexShrink: 0 }} />
    <Box flex={1} minWidth={0}>
      <Typography variant="body2" fontWeight={600} color="#0f172a" noWrap>{policy.name}</Typography>
      <Box display="flex" alignItems="center" gap={1} mt={0.25}>
        <Box sx={{ px: 0.75, py: 0.1, borderRadius: '4px', bgcolor: policy.envBg, color: policy.envColor, fontSize: '0.65rem', fontWeight: 600 }}>
          {policy.env}
        </Box>
        <Typography variant="caption" color="text.secondary">{policy.rules} Rule</Typography>
      </Box>
    </Box>
    <Box textAlign="right" mr={0.5}>
      <Typography variant="body2" fontWeight={700}>{policy.compliance}%</Typography>
      <Typography variant="caption" sx={{ color: '#15803d', fontWeight: 600 }}>{policy.status}</Typography>
    </Box>
    {action === 'add' && (
      <IconButton size="small" onClick={onAction} sx={{ color: '#2563eb' }}><Plus size={18} /></IconButton>
    )}
    {action === 'remove' && (
      <IconButton size="small" onClick={onAction} sx={{ color: '#94a3b8' }}><X size={16} /></IconButton>
    )}
  </Box>
)

interface ReviewCardProps {
  title: string
  onEdit?: () => void
  rows: { label: string; value: string }[]
}

const ReviewCard: React.FC<ReviewCardProps> = ({ title, onEdit, rows }) => (
  <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto', mb: 2.5, p: 3 }}>
    <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
      <Typography variant="subtitle1" fontWeight={700} color="#0f172a">{title}</Typography>
      {onEdit && (
        <IconButton size="small" onClick={onEdit} sx={{ color: '#64748b' }}><Pencil size={15} /></IconButton>
      )}
    </Box>
    {rows.map(({ label, value }) => (
      <Box key={label} display="flex" justifyContent="space-between" py={0.75} borderBottom="1px solid #f1f5f9">
        <Typography variant="body2" color="text.secondary">{label}</Typography>
        <Typography variant="body2" fontWeight={500} color="#0f172a">{value || '—'}</Typography>
      </Box>
    ))}
  </Paper>
)

const AssignmentFormPage: React.FC = () => {
  const { id } = useParams<{ id?: string }>()
  const isEdit = !!id
  const history = useHistory()

  const [viewMode, setViewMode] = useState(isEdit)
  const [activeStep, setActiveStep] = useState(0)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})
  const [name, setName] = useState('')
  const [assignmentType, setAssignmentType] = useState('')
  const [priority, setPriority] = useState('')
  const [description, setDescription] = useState('')
  const [selectedPolicies, setSelectedPolicies] = useState<PolicyItem[]>([])
  const [policySearch, setPolicySearch] = useState('')
  const [targetType, setTargetType] = useState('Server')
  const [selectedTargetHosts, setSelectedTargetHosts] = useState<string[]>([])
  const [targetFilters, setTargetFilters] = useState({
    region: '',
    os: '',
    sid: '',
    owner: '',
    application: '',
    environment: '',
  })
  const [executionMode, setExecutionMode] = useState('Use Policy')
  const [executionStrategy, setExecutionStrategy] = useState('Sequential')
  const [rolloutStrategy, setRolloutStrategy] = useState('Batch')
  const [batchSize, setBatchSize] = useState('34')
  const [rolloutPercentage, setRolloutPercentage] = useState('10')
  const [rollbackEnabled, setRollbackEnabled] = useState(true)
  const [scheduleType, setScheduleType] = useState('Manual')
  const [cronExpression, setCronExpression] = useState('')
  const [timezone, setTimezone] = useState('UTC')
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [exclusionEnabled, setExclusionEnabled] = useState(false)
  const [excludedFromTime, setExcludedFromTime] = useState('')
  const [excludedToTime, setExcludedToTime] = useState('')

  const { data: assignmentData, isLoading: loadingAssignment } = useGetAssignmentByIdQuery(id!, { skip: !isEdit })
  const [createAssignment, { isLoading: creating }] = useCreateAssignmentMutation()
  const [updateAssignment, { isLoading: updating }] = useUpdateAssignmentMutation()
  const { data: targetMetadataData } = useGetTargetServersMetadataQuery()
  
  const isSaving = creating || updating
  const isReviewStep = activeStep === STEPS.length - 1

  const targetServersQueryArgs = {
    page: 1,
    limit: 100,
    region: targetFilters.region || undefined,
    os: targetFilters.os || undefined,
    sid: targetFilters.sid || undefined,
    owner: targetFilters.owner || undefined,
    application: targetFilters.application || undefined,
    environment: targetFilters.environment || undefined,
  }
  const { data: targetServersData, isLoading: loadingTargetServers } = useGetTargetServersQuery(targetServersQueryArgs)

  const usePoliciesFromApi = true
  const { data: policiesData, isLoading: policiesLoading } = useGetPoliciesQuery(
    { page: 1, limit: 100, status: 'PUBLISHED' },
    { skip: !usePoliciesFromApi },
  )

  const apiPolicies: PolicyItem[] = (policiesData?.data ?? []).map((p: any) => ({
    id: p._id ?? p.id,
    policyId: p.policyId ?? p.policy_id ?? p._id ?? p.id,
    name: p.name,
    versionNumber: p.versionNumber ?? p.version ?? '1.0.0',
    env: 'Prod',
    envBg: '#dcfce7',
    envColor: '#15803d',
    rules: Array.isArray(p.rules) ? p.rules.length : (p.rulesCount ?? 0),
    compliance: p.complianceScore ?? 99.2,
    status: p.status ?? 'Active',
  }))

  const policySource = usePoliciesFromApi ? apiPolicies : MOCK_POLICIES

  const availablePolicies = policySource.filter(
    (p) => !policySearch.trim() || p.name.toLowerCase().includes(policySearch.toLowerCase()),
  )

  const targetMetadata: TargetServerMetadata = {
    region: targetMetadataData?.data?.region ?? [],
    os: targetMetadataData?.data?.os ?? [],
    sid: targetMetadataData?.data?.sid ?? [],
    owner: targetMetadataData?.data?.owner ?? [],
    application: targetMetadataData?.data?.application ?? [],
    environment: targetMetadataData?.data?.environment ?? [],
  }

  const targetServers: TargetServerItem[] = targetServersData?.data ?? []
  const filteredTargetServers = targetServers
  const selectedTargets = targetServers.filter((server) => selectedTargetHosts.includes(server.hostname))

  const setTargetFilter = (key: keyof typeof targetFilters, value: string) => {
    setTargetFilters((prev) => ({ ...prev, [key]: value }))
    setSelectedTargetHosts([])
  }

  useEffect(() => {
    const a = assignmentData?.data
    if (!a) return
    setName(a.name)
    setDescription(a.description ?? '')
    setAssignmentType('Policy')
    setPriority('Critical')
    if (a.policies?.length) {
      const mapped: PolicyItem[] = a.policies.map((p: any) => ({
        id: p.policyId ?? p.id,
        policyId: p.policyId ?? p.id,
        name: p.name,
        versionNumber: p.versionNumber ?? '1.0.0',
        env: 'Prod',
        envBg: '#dcfce7',
        envColor: '#15803d',
        rules: 0,
        compliance: 0,
        status: 'Active',
      }))
      setSelectedPolicies(mapped)
    }
  }, [assignmentData])

  const isStep0Valid = Boolean(name.trim() && assignmentType && priority)
  const isStep1Valid = Boolean(selectedPolicies.length > 0)
  const isStep2Valid = Boolean(targetType && selectedTargetHosts.length > 0)
  const canReview = isStep0Valid && isStep1Valid && isStep2Valid

  const handleAddPolicy = (policy: PolicyItem) => {
    setSelectedPolicies((prev) => [...prev, policy])
  }

  const handleRemovePolicy = (policyId: string) => {
    setSelectedPolicies((prev) => prev.filter((p) => p.id !== policyId))
  }

  const movePolicy = (index: number, direction: 'up' | 'down') => {
    setSelectedPolicies((prev) => {
      const next = [...prev]
      const swapIndex = direction === 'up' ? index - 1 : index + 1
      if (swapIndex < 0 || swapIndex >= next.length) return prev
      ;[next[index], next[swapIndex]] = [next[swapIndex], next[index]]
      return next
    })
  }

  const toggleServer = (hostname: string) => {
    setSelectedTargetHosts((prev) => (
      prev.includes(hostname) ? prev.filter((item) => item !== hostname) : [...prev, hostname]
    ))
  }

  const toggleAllServers = () => {
    setSelectedTargetHosts((prev) => (
      prev.length === filteredTargetServers.length ? [] : filteredTargetServers.map((server) => server.hostname)
    ))
  }

  const validateStep = (step: number): boolean => {
    let errors: FieldErrors = {}
    if (step === 0) errors = validateStep0(name, assignmentType, priority)
    if (step === 1) errors = validateStep1(selectedPolicies.length)
    if (step === 2) errors = validateStep2(targetType, selectedTargetHosts.length)

    setFieldErrors(errors)
    if (Object.keys(errors).length) {
      toast.error(Object.values(errors)[0])
      return false
    }
    return true
  }

  const handleStepClick = (targetStep: number) => {
    if (targetStep <= activeStep) {
      setFieldErrors({})
      setActiveStep(targetStep)
      return
    }

    if (!validateStep(activeStep)) return
    setFieldErrors({})
    setActiveStep(targetStep)
  }

  const handleNext = () => {
    if (!validateStep(activeStep)) return
    setFieldErrors({})
    setActiveStep((s) => Math.min(s + 1, STEPS.length - 1))
  }

  const handlePrevious = () => setActiveStep((s) => Math.max(s - 1, 0))

  const handleSubmit = async () => {
    const allErrors = {
      ...validateStep0(name, assignmentType, priority),
      ...validateStep1(selectedPolicies.length),
      ...validateStep2(targetType, selectedTargetHosts.length),
    }
    if (Object.keys(allErrors).length) {
      setFieldErrors(allErrors)
      toast.error(Object.values(allErrors)[0])
      return
    }

    const payload = {
      name: name.trim(),
      assignmentType: assignmentType.toUpperCase(),
      priority: priority.toUpperCase(),
      description: description.trim(),
      policyMode: selectedPolicies.length > 1 ? 'Multiple Policies' : 'Single Policy',
      policies: selectedPolicies.map((p, index) => ({
        policyId: p.policyId ?? p.id,
        name: p.name,
        versionNumber: p.versionNumber ?? '1.0.0',
        sequenceNumber: index + 1,
      })),
      targets: selectedTargets.map((server) => ({ hostname: server.hostname })),
      targetType: 'SERVER',
      status: 'ACTIVE',
      executionConfig: {},
      scheduleConfig: {},
      excludeExecutionWindowConfig: {},
    }

    try {
      if (isEdit) {
        await updateAssignment({ id: id!, data: payload }).unwrap()
        toast.success('Assignment updated')
        history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/${id}`)
      } else {
        const result = await createAssignment(payload).unwrap()
        toast.success('Assignment created')
        history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/${result?.data?._id ?? ''}`)
      }
    } catch {
      toast.error('Save failed. Please try again.')
    }
  }

  if (isEdit && loadingAssignment) return <Box p={3}><CircularProgress /></Box>
  if (isEdit && !assignmentData?.data) return <Box p={3}><Alert severity="error">Assignment not found</Alert></Box>

  const handleEditClick = () => {
    setViewMode(false)
    setActiveStep(0)
  }

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <Box sx={{ maxWidth: 960, mx: 'auto', width: '100%' }}>
            <Paper elevation={0} sx={CARD_SX}>
              <Typography variant="subtitle1" fontWeight={600} mb={0.5} color="#0f172a">Basic Information</Typography>
              <Typography variant="body2" color="text.secondary" mb={3}>
                Give your assignment a clear name and purpose. You can edit this later.
              </Typography>
              <Grid container spacing={2.5}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    required
                    size="small"
                    sx={FORM_FIELD_SX}
                    label="Assignment Name"
                    placeholder="Assignment Name"
                    value={name}
                    error={Boolean(fieldErrors.name)}
                    helperText={fieldErrors.name}
                    onChange={(e) => { setName(e.target.value); setFieldErrors((prev) => ({ ...prev, name: '' })) }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControl fullWidth required size="small" sx={FORM_FIELD_SX} error={Boolean(fieldErrors.assignmentType)}>
                    <InputLabel>Assignment Type</InputLabel>
                    <Select
                      value={assignmentType}
                      label="Assignment Type"
                      onChange={(e) => { setAssignmentType(e.target.value); setFieldErrors((prev) => ({ ...prev, assignmentType: '' })) }}
                    >
                      {ASSIGNMENT_TYPES.map((t) => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                    </Select>
                    {fieldErrors.assignmentType && (
                      <Typography variant="caption" color="error" sx={{ mt: 0.5, ml: 1.75 }}>{fieldErrors.assignmentType}</Typography>
                    )}
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControl fullWidth required size="small" sx={FORM_FIELD_SX} error={Boolean(fieldErrors.priority)}>
                    <InputLabel>Priority</InputLabel>
                    <Select
                      value={priority}
                      label="Priority"
                      onChange={(e) => { setPriority(e.target.value); setFieldErrors((prev) => ({ ...prev, priority: '' })) }}
                    >
                      {PRIORITIES.map((p) => <MenuItem key={p} value={p}>{p}</MenuItem>)}
                    </Select>
                    {fieldErrors.priority && (
                      <Typography variant="caption" color="error" sx={{ mt: 0.5, ml: 1.75 }}>{fieldErrors.priority}</Typography>
                    )}
                  </FormControl>
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    size="small"
                    sx={FORM_FIELD_SX}
                    label="Description"
                    placeholder="Description"
                    value={description}
                    multiline
                    rows={3}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </Grid>
              </Grid>
            </Paper>
          </Box>
        )

      case 1:
        return (
          <Box sx={{ maxWidth: 1200, mx: 'auto', width: '100%' }}>
            <Grid container spacing={3} sx={{ alignItems: 'stretch' }}>
              <Grid item xs={12} lg={6}>
                <Paper elevation={0} sx={CARD_SX}>
                  <Typography variant="subtitle1" fontWeight={700} color="#0f172a">
                    Policy Library <Typography component="span" color="error">*</Typography>
                  </Typography>
                  <Typography variant="caption" color="text.secondary" display="block" mb={2}>
                    {policiesLoading ? 'Loading…' : `${policySource.length} policies · ${policySource.reduce((s, p) => s + p.rules, 0)} rules`}
                  </Typography>
                  <TextField
                    fullWidth size="small" placeholder="Search Policy" value={policySearch}
                    onChange={(e) => setPolicySearch(e.target.value)}
                    sx={{ ...FORM_FIELD_SX, mb: 2 }}
                    InputProps={{ startAdornment: <InputAdornment position="start"><Search size={16} color="#94a3b8" /></InputAdornment> }}
                  />
                  <Box sx={{ maxHeight: 420, overflowY: 'auto' }}>
                    {availablePolicies.map((policy) => (
                      <PolicyRow key={policy.id} policy={policy} action="add" onAction={() => handleAddPolicy(policy)} />
                    ))}
                    {!availablePolicies.length && (
                      <Typography variant="body2" color="text.secondary" textAlign="center" py={3}>No policies available</Typography>
                    )}
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={12} lg={6}>
                <Paper elevation={0} sx={{ ...CARD_SX, bgcolor: '#fafbfc', backgroundImage: 'radial-gradient(#e2e8f0 1px, transparent 1px)', backgroundSize: '16px 16px' }}>
                  <Typography variant="subtitle1" fontWeight={700} color="#0f172a">
                    Selected Policies <Typography component="span" color="error">*</Typography>
                  </Typography>
                  <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                    Policy Execution Order · Drag to reorder
                  </Typography>
                  {fieldErrors.selectedPolicies && (
                    <Typography variant="caption" color="error" display="block" mb={1}>{fieldErrors.selectedPolicies}</Typography>
                  )}
                  <Box sx={{ maxHeight: 420, overflowY: 'auto' }}>
                    {selectedPolicies.map((policy, index) => (
                      <Box key={policy.id} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                          <IconButton size="small" disabled={index === 0} onClick={() => movePolicy(index, 'up')} sx={{ p: 0.25 }}>▲</IconButton>
                          <IconButton size="small" disabled={index === selectedPolicies.length - 1} onClick={() => movePolicy(index, 'down')} sx={{ p: 0.25 }}>▼</IconButton>
                        </Box>
                        <Box flex={1}>
                          <PolicyRow policy={policy} action="remove" showDrag onAction={() => handleRemovePolicy(policy.id)} />
                        </Box>
                      </Box>
                    ))}
                    {!selectedPolicies.length && (
                      <Box sx={{ border: fieldErrors.selectedPolicies ? '2px dashed #ef4444' : '2px dashed #cbd5e1', borderRadius: '8px', p: 4, textAlign: 'center' }}>
                        <Typography variant="body2" color="text.secondary">Add policies from the library</Typography>
                      </Box>
                    )}
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          </Box>
        )

      case 2:
        return (
          <Box sx={{ maxWidth: 1100, mx: 'auto', width: '100%' }}>
            <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto', mb: 3 }}>
              <Typography variant="subtitle1" fontWeight={700} color="#0f172a" mb={2.5}>Target Selection</Typography>
              <Grid container spacing={2.5} mb={2.5}>
                <Grid item xs={12} sm={4} md={2}>
                  <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                    <InputLabel>Region</InputLabel>
                    <Select value={targetFilters.region} label="Region" onChange={(e) => setTargetFilter('region', e.target.value)}>
                      <MenuItem value=""><em>All</em></MenuItem>
                      {targetMetadata.region.map((option) => <MenuItem key={option} value={option}>{option}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4} md={2}>
                  <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                    <InputLabel>OS</InputLabel>
                    <Select value={targetFilters.os} label="OS" onChange={(e) => setTargetFilter('os', e.target.value)}>
                      <MenuItem value=""><em>All</em></MenuItem>
                      {targetMetadata.os.map((option) => <MenuItem key={option} value={option}>{option}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4} md={2}>
                  <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                    <InputLabel>SID</InputLabel>
                    <Select value={targetFilters.sid} label="SID" onChange={(e) => setTargetFilter('sid', e.target.value)}>
                      <MenuItem value=""><em>All</em></MenuItem>
                      {targetMetadata.sid.map((option) => <MenuItem key={option} value={option}>{option}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4} md={2}>
                  <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                    <InputLabel>Owner</InputLabel>
                    <Select value={targetFilters.owner} label="Owner" onChange={(e) => setTargetFilter('owner', e.target.value)}>
                      <MenuItem value=""><em>All</em></MenuItem>
                      {targetMetadata.owner.map((option) => <MenuItem key={option} value={option}>{option}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4} md={2}>
                  <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                    <InputLabel>Application</InputLabel>
                    <Select value={targetFilters.application} label="Application" onChange={(e) => setTargetFilter('application', e.target.value)}>
                      <MenuItem value=""><em>All</em></MenuItem>
                      {targetMetadata.application.map((option) => <MenuItem key={option} value={option}>{option}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4} md={2}>
                  <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                    <InputLabel>Environment</InputLabel>
                    <Select value={targetFilters.environment} label="Environment" onChange={(e) => setTargetFilter('environment', e.target.value)}>
                      <MenuItem value=""><em>All</em></MenuItem>
                      {targetMetadata.environment.map((option) => <MenuItem key={option} value={option}>{option}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
              </Grid>

              <Box display="flex" justifyContent="space-between" alignItems="center" gap={2} flexWrap="wrap" mb={1.5}>
                <Box>
                  <Typography variant="body2" fontWeight={600} color="#0f172a">
                    Selected Targets
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {selectedTargets.length} target(s) selected
                  </Typography>
                </Box>
                <Button
                  variant="outlined"
                  size="small"
                  onClick={() => setSelectedTargetHosts([])}
                  disabled={!selectedTargetHosts.length}
                  sx={{ textTransform: 'none', borderRadius: '999px' }}
                >
                  Clear Selection
                </Button>
              </Box>
              {selectedTargets.length > 0 && (
                <Box display="flex" gap={1} flexWrap="wrap" mb={2}>
                  {selectedTargets.map((server) => (
                    <Chip
                      key={server.hostname}
                      label={server.hostname}
                      onDelete={() => toggleServer(server.hostname)}
                      sx={{ bgcolor: '#eff6ff' }}
                    />
                  ))}
                </Box>
              )}

              <Typography variant="body2" fontWeight={600} color="#0f172a" mt={2} mb={1}>
                Target Servers <Typography component="span" color="error">*</Typography>
              </Typography>
              {fieldErrors.selectedServers && (
                <Typography variant="caption" color="error" display="block" mb={1}>{fieldErrors.selectedServers}</Typography>
              )}
              <TableContainer sx={{ border: fieldErrors.selectedServers ? '1px solid #ef4444' : '1px solid #e2e8f0', borderRadius: '8px', overflowX: 'auto' }}>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow sx={{ bgcolor: '#f8fafc' }}>
                      <TableCell padding="checkbox">
                        <Checkbox
                          size="small"
                          indeterminate={selectedTargetHosts.length > 0 && selectedTargetHosts.length < filteredTargetServers.length}
                          checked={filteredTargetServers.length > 0 && selectedTargetHosts.length === filteredTargetServers.length}
                          onChange={toggleAllServers}
                        />
                      </TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Hostname</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Region</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Environment</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Service</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>SID</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Application</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Business Service</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Owner</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Server Type</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>OS</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {loadingTargetServers ? (
                      <TableRow>
                        <TableCell colSpan={12}>
                          <Box display="flex" justifyContent="center" py={3}>
                            <CircularProgress size={24} />
                          </Box>
                        </TableCell>
                      </TableRow>
                    ) : filteredTargetServers.length ? (
                      filteredTargetServers.map((server) => (
                        <TableRow key={server.hostname} hover selected={selectedTargetHosts.includes(server.hostname)}>
                          <TableCell padding="checkbox">
                            <Checkbox
                              size="small"
                              checked={selectedTargetHosts.includes(server.hostname)}
                              onChange={() => {
                                toggleServer(server.hostname)
                                setFieldErrors((prev) => ({ ...prev, selectedServers: '' }))
                              }}
                            />
                          </TableCell>
                          <TableCell>{server.hostname}</TableCell>
                          <TableCell>{server.region}</TableCell>
                          <TableCell>{server.environment}</TableCell>
                          <TableCell>{server.service}</TableCell>
                          <TableCell>{server.sid}</TableCell>
                          <TableCell>{server.application}</TableCell>
                          <TableCell>{server.businessService}</TableCell>
                          <TableCell>{server.owner}</TableCell>
                          <TableCell>{server.serverType}</TableCell>
                          <TableCell>{server.os}</TableCell>
                          <TableCell>{server.status}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={12}>
                          <Typography variant="body2" color="text.secondary" textAlign="center" py={3}>
                            No target servers match the selected filters.
                          </Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
            </Paper>
          </Box>
        )

      case 3:
        return (
          <Box sx={{ maxWidth: 1100, mx: 'auto', width: '100%' }}>
            <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto', mb: 3 }}>
              <Typography variant="subtitle1" fontWeight={700} color="#0f172a" mb={2.5}>Execution Configuration</Typography>
              <Grid container spacing={2.5} alignItems="center">
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                    <InputLabel>Execution Mode Override</InputLabel>
                    <Select value={executionMode} label="Execution Mode Override" onChange={(e) => setExecutionMode(e.target.value)}>
                      {EXECUTION_MODES.map((m) => <MenuItem key={m} value={m}>{m}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                    <InputLabel>Execution Strategy</InputLabel>
                    <Select value={executionStrategy} label="Execution Strategy" onChange={(e) => setExecutionStrategy(e.target.value)}>
                      {EXECUTION_STRATEGIES.map((m) => <MenuItem key={m} value={m}>{m}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                    <InputLabel>Rollout Strategy</InputLabel>
                    <Select value={rolloutStrategy} label="Rollout Strategy" onChange={(e) => setRolloutStrategy(e.target.value)}>
                      {ROLLOUT_STRATEGIES.map((m) => <MenuItem key={m} value={m}>{m}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField
                    fullWidth
                    size="small"
                    sx={FORM_FIELD_SX}
                    label="Batch Size"
                    type="number"
                    value={batchSize}
                    disabled={rolloutStrategy !== 'Batch'}
                    onChange={(e) => setBatchSize(e.target.value)}
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField
                    fullWidth
                    size="small"
                    sx={FORM_FIELD_SX}
                    label="Rollout Percentage"
                    type="number"
                    value={rolloutPercentage}
                    disabled={rolloutStrategy !== 'Percentage'}
                    onChange={(e) => setRolloutPercentage(e.target.value)}
                    InputProps={{ endAdornment: <InputAdornment position="end">%</InputAdornment> }}
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormToggleRow
                    label="RollBack Enable"
                    description="Enables advanced rollback features"
                    checked={rollbackEnabled}
                    onChange={(checked) => setRollbackEnabled(checked)}
                  />
                </Grid>
              </Grid>
            </Paper>

            <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto', mb: 3 }}>
              <Typography variant="subtitle1" fontWeight={700} color="#0f172a" mb={2.5}>Schedule</Typography>
              <Grid container spacing={2.5}>
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                    <InputLabel>Schedule Type</InputLabel>
                    <Select value={scheduleType} label="Schedule Type" onChange={(e) => setScheduleType(e.target.value)}>
                      {SCHEDULE_TYPES.map((m) => <MenuItem key={m} value={m}>{m}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                {scheduleType === 'Cron' && (
                  <Grid item xs={12} sm={4}>
                    <TextField
                      fullWidth size="small" sx={FORM_FIELD_SX} label="Cron Expression"
                      placeholder="0 */30 * * * *" value={cronExpression} onChange={(e) => setCronExpression(e.target.value)}
                    />
                  </Grid>
                )}
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                    <InputLabel>Timezone</InputLabel>
                    <Select value={timezone} label="Timezone" onChange={(e) => setTimezone(e.target.value)}>
                      {TIMEZONES.map((m) => <MenuItem key={m} value={m}>{m}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth size="small" sx={FORM_FIELD_SX} label="Start Date" type="datetime-local"
                    value={startDate} onChange={(e) => setStartDate(e.target.value)}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth size="small" sx={FORM_FIELD_SX} label="End Date" type="datetime-local"
                    value={endDate} onChange={(e) => setEndDate(e.target.value)}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
              </Grid>
            </Paper>

            <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto' }}>
              <Typography variant="subtitle1" fontWeight={700} color="#0f172a" mb={2.5}>Excluded Execution Window</Typography>
              <Grid container spacing={2.5} alignItems="center">
                <Grid item xs={12}>
                  <FormToggleRow
                    label="Enable Exclusion Window"
                    checked={exclusionEnabled}
                    onChange={(checked) => setExclusionEnabled(checked)}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    size="small"
                    sx={FORM_FIELD_SX}
                    label="Excluded From Time"
                    type="time"
                    value={excludedFromTime}
                    disabled={!exclusionEnabled}
                    onChange={(e) => setExcludedFromTime(e.target.value)}
                    InputLabelProps={{ shrink: true }}
                    inputProps={{ step: 60 }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    size="small"
                    sx={FORM_FIELD_SX}
                    label="Excluded To Time"
                    type="time"
                    value={excludedToTime}
                    disabled={!exclusionEnabled}
                    onChange={(e) => setExcludedToTime(e.target.value)}
                    InputLabelProps={{ shrink: true }}
                    inputProps={{ step: 60 }}
                  />
                </Grid>
              </Grid>
            </Paper>
          </Box>
        )

      case 4:
        return (
          <Grid container spacing={3}>
            <Grid item xs={12} lg={7}>
              <ReviewCard
                title="Basic Information"
                onEdit={() => setActiveStep(0)}
                rows={[
                  { label: 'Assignment Name', value: name || '—' },
                  { label: 'Assignment Type', value: assignmentType || '—' },
                  { label: 'Priority', value: priority || '—' },
                  { label: 'Description', value: description || '—' },
                ]}
              />
              <ReviewCard
                title="Policy Selection"
                onEdit={() => setActiveStep(1)}
                rows={[
                  { label: 'Selected Policies', value: selectedPolicies.map((p) => p.name).join(', ') || '—' },
                ]}
              />
              <ReviewCard
                title="Target Selection"
                onEdit={() => setActiveStep(2)}
                rows={[
                  { label: 'Target Type', value: targetType || '—' },
                  { label: 'Selected Targets', value: selectedTargets.length ? `${selectedTargets.length} server(s)` : '—' },
                ]}
              />
              <ReviewCard
                title="Execution Configuration"
                onEdit={() => { setViewMode(false); setActiveStep(3) }}
                rows={[
                  { label: 'Execution Mode Override', value: executionMode },
                  { label: 'Execution Strategy', value: executionStrategy },
                  { label: 'Rollout Strategy', value: rolloutStrategy },
                  { label: 'Batch Size', value: rolloutStrategy === 'Batch' ? batchSize : '—' },
                  { label: 'Rollout Percentage', value: rolloutStrategy === 'Percentage' ? `${rolloutPercentage}%` : '—' },
                  { label: 'Rollback Enabled', value: rollbackEnabled ? 'Yes' : 'No' },
                ]}
              />
              <ReviewCard
                title="Schedule"
                onEdit={() => { setViewMode(false); setActiveStep(3) }}
                rows={[
                  { label: 'Schedule Type', value: scheduleType },
                  ...(scheduleType === 'Cron' ? [{ label: 'Cron Expression', value: cronExpression || '—' }] : []),
                  { label: 'Timezone', value: timezone },
                  { label: 'Start Date', value: startDate || '—' },
                  { label: 'End Date', value: endDate || '—' },
                ]}
              />
              <ReviewCard
                title="Excluded Execution Window"
                onEdit={() => { setViewMode(false); setActiveStep(3) }}
                rows={[
                  { label: 'Enable Exclusion Window', value: exclusionEnabled ? 'Yes' : 'No' },
                  { label: 'Excluded From Time', value: exclusionEnabled && excludedFromTime ? excludedFromTime : '—' },
                  { label: 'Excluded To Time', value: exclusionEnabled && excludedToTime ? excludedToTime : '—' },
                ]}
              />
            </Grid>
            <Grid item xs={12} lg={5}>
              <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto' }}>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                  <Typography variant="subtitle1" fontWeight={700} color="#0f172a">Policy</Typography>
                  <IconButton size="small" onClick={() => setActiveStep(1)} sx={{ color: '#64748b' }}><Pencil size={15} /></IconButton>
                </Box>
                {selectedPolicies.map((policy) => (
                  <Box key={policy.id} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, p: 1.5, bgcolor: '#f8fafc', borderRadius: '8px', mb: 1 }}>
                    <FileText size={18} color="#2563eb" />
                    <Box flex={1}>
                      <Typography variant="body2" fontWeight={600}>{policy.name}</Typography>
                      <Box display="flex" gap={1} alignItems="center">
                        <Typography variant="caption" sx={{ color: policy.envColor, fontWeight: 600 }}>{policy.env}</Typography>
                        <Typography variant="caption" color="text.secondary">{policy.rules} Rule</Typography>
                      </Box>
                    </Box>
                    <Box textAlign="right">
                      <Typography variant="body2" fontWeight={700}>{policy.compliance}%</Typography>
                      <Typography variant="caption" sx={{ color: '#15803d', fontWeight: 600 }}>{policy.status}</Typography>
                    </Box>
                  </Box>
                ))}
              </Paper>
            </Grid>
          </Grid>
        )

      default:
        return null
    }
  }

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', bgcolor: '#f1f5f9' }}>
      <Box sx={{ px: 3, py: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Box display="flex" alignItems="center" gap={1.5}>
          <IconButton size="small" onClick={() => history.goBack()} sx={{ color: '#64748b' }}>
            <ArrowLeft size={18} />
          </IconButton>
          <Box>
            <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.8125rem', cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }} onClick={() => history.push(POLICYOPS_PATH.ASSIGNMENTS)}>
              Assignment Center
            </Typography>
            <Typography variant="h5" fontWeight={700} lineHeight={1.2} color="#0f172a">
              {viewMode ? 'View Assignment' : (isEdit ? 'Edit Assignment' : 'Create Assignment')}
            </Typography>
          </Box>
        </Box>

        <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'center' }}>
          {viewMode && isEdit && (
            <Button variant="contained" onClick={handleEditClick} startIcon={<Pencil size={16} />} sx={{ textTransform: 'none', fontWeight: 500, px: 2.5, bgcolor: '#2563eb', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}>
              Edit
            </Button>
          )}
          {!viewMode && isReviewStep && (
            <Button variant="text" onClick={handlePrevious} sx={{ textTransform: 'none', color: '#2563eb', fontWeight: 500 }}>
              Previous
            </Button>
          )}
          <Button variant="outlined" onClick={() => history.goBack()} sx={{ borderColor: '#bfdbfe', color: '#2563eb', bgcolor: '#eff6ff', textTransform: 'none', fontWeight: 500, px: 2.5 }}>
            Cancel
          </Button>
          {!viewMode && isReviewStep ? (
            <Button variant="contained" onClick={handleSubmit} disabled={!canReview || isSaving} sx={{ textTransform: 'none', fontWeight: 500, px: 2.5, bgcolor: '#2563eb', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}>
              {isSaving ? (isEdit ? 'Updating…' : 'Creating…') : (isEdit ? 'Update' : 'Create')}
            </Button>
          ) : !viewMode ? (
            <Button
              variant="contained"
              disabled={!canReview || isSaving}
              onClick={() => canReview && setActiveStep(STEPS.length - 1)}
              sx={{ textTransform: 'none', fontWeight: 500, px: 2.5, bgcolor: canReview ? '#2563eb' : '#e2e8f0', color: canReview ? '#fff' : '#94a3b8', boxShadow: 'none', '&:hover': { bgcolor: canReview ? '#1d4ed8' : '#e2e8f0', boxShadow: 'none' } }}
            >
              {isEdit ? 'Review & Update' : 'Review & Create'}
            </Button>
          ) : null}
        </Box>
      </Box>

      {!viewMode && (
        <Box sx={{ px: 3, py: 3 }}>
          <Stepper
            nonLinear
            activeStep={activeStep}
            alternativeLabel
            connector={<AssignmentStepConnector />}
            sx={{
              maxWidth: 820,
              mx: 'auto',
              pb: 1.5,
              '& .MuiStepLabel-label': { mt: 0.75, fontSize: '0.78rem' },
              '& .MuiStepLabel-labelContainer': { maxWidth: 'none' },
            }}
          >
            {STEPS.map((label, index) => (
              <Step key={label} completed={index < activeStep}>
                <StepButton disableRipple onClick={() => handleStepClick(index)}>
                  <StepLabel StepIconComponent={() => (<StepIcon index={index} active={index === activeStep} completed={index < activeStep} />)}>
                    <Typography fontWeight={index === activeStep ? 700 : 400} color={index <= activeStep ? '#1e293b' : '#94a3b8'} sx={{ fontSize: '0.78rem' }}>
                      {label}
                    </Typography>
                  </StepLabel>
                </StepButton>
              </Step>
            ))}
          </Stepper>
        </Box>
      )}

      <Box sx={{ flex: 1, overflow: 'auto', px: 3, py: 3 }}>
        {viewMode ? (
          <Grid container spacing={3}>
            <Grid item xs={12} lg={7}>
              <ReviewCard
                title="Basic Information"
                onEdit={() => { setViewMode(false); setActiveStep(0) }}
                rows={[
                  { label: 'Assignment Name', value: name || '—' },
                  { label: 'Assignment Type', value: assignmentType || '—' },
                  { label: 'Priority', value: priority || '—' },
                  { label: 'Description', value: description || '—' },
                ]}
              />
              <ReviewCard
                title="Policy Selection"
                onEdit={() => { setViewMode(false); setActiveStep(1) }}
                rows={[
                  { label: 'Selected Policies', value: selectedPolicies.map((p) => p.name).join(', ') || '—' },
                ]}
              />
              <ReviewCard
                title="Target Selection"
                onEdit={() => { setViewMode(false); setActiveStep(2) }}
                rows={[
                  { label: 'Target Type', value: targetType || '—' },
                  { label: 'Selected Targets', value: selectedTargets.length ? `${selectedTargets.length} server(s)` : '—' },
                ]}
              />
              <ReviewCard
                title="Execution Configuration"
                onEdit={() => { setViewMode(false); setActiveStep(3) }}
                rows={[
                  { label: 'Execution Mode Override', value: executionMode },
                  { label: 'Execution Strategy', value: executionStrategy },
                  { label: 'Rollout Strategy', value: rolloutStrategy },
                  { label: 'Batch Size', value: rolloutStrategy === 'Batch' ? batchSize : '—' },
                  { label: 'Rollout Percentage', value: rolloutStrategy === 'Percentage' ? `${rolloutPercentage}%` : '—' },
                  { label: 'Rollback Enabled', value: rollbackEnabled ? 'Yes' : 'No' },
                ]}
              />
              <ReviewCard
                title="Schedule"
                onEdit={() => { setViewMode(false); setActiveStep(3) }}
                rows={[
                  { label: 'Schedule Type', value: scheduleType },
                  ...(scheduleType === 'Cron' ? [{ label: 'Cron Expression', value: cronExpression || '—' }] : []),
                  { label: 'Timezone', value: timezone },
                  { label: 'Start Date', value: startDate || '—' },
                  { label: 'End Date', value: endDate || '—' },
                ]}
              />
              <ReviewCard
                title="Excluded Execution Window"
                onEdit={() => { setViewMode(false); setActiveStep(3) }}
                rows={[
                  { label: 'Enable Exclusion Window', value: exclusionEnabled ? 'Yes' : 'No' },
                  { label: 'Excluded From Time', value: exclusionEnabled && excludedFromTime ? excludedFromTime : '—' },
                  { label: 'Excluded To Time', value: exclusionEnabled && excludedToTime ? excludedToTime : '—' },
                ]}
              />
            </Grid>
            <Grid item xs={12} lg={5}>
              <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto' }}>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                  <Typography variant="subtitle1" fontWeight={700} color="#0f172a">Policy</Typography>
                  <IconButton size="small" onClick={() => { setViewMode(false); setActiveStep(1) }} sx={{ color: '#64748b' }}><Pencil size={15} /></IconButton>
                </Box>
                {selectedPolicies.map((policy) => (
                  <Box key={policy.id} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, p: 1.5, bgcolor: '#f8fafc', borderRadius: '8px', mb: 1 }}>
                    <FileText size={18} color="#2563eb" />
                    <Box flex={1}>
                      <Typography variant="body2" fontWeight={600}>{policy.name}</Typography>
                      <Box display="flex" gap={1} alignItems="center">
                        <Typography variant="caption" sx={{ color: policy.envColor, fontWeight: 600 }}>{policy.env}</Typography>
                        <Typography variant="caption" color="text.secondary">{policy.rules} Rule</Typography>
                      </Box>
                    </Box>
                    <Box textAlign="right">
                      <Typography variant="body2" fontWeight={700}>{policy.compliance}%</Typography>
                      <Typography variant="caption" sx={{ color: '#15803d', fontWeight: 600 }}>{policy.status}</Typography>
                    </Box>
                  </Box>
                ))}
              </Paper>
            </Grid>
          </Grid>
        ) : renderStepContent()}
      </Box>

      {!viewMode && !isReviewStep && (
        <Box sx={{ bgcolor: 'white', borderTop: '1px solid #e2e8f0', px: 3, py: 2, display: 'flex', justifyContent: 'flex-end', gap: 1.5 }}>
          {activeStep > 0 && (
            <Button variant="outlined" onClick={handlePrevious} sx={{ borderColor: '#e2e8f0', color: '#64748b', textTransform: 'none', fontWeight: 500, px: 2.5 }}>
              Previous
            </Button>
          )}
          <Button variant="contained" onClick={handleNext} sx={{ textTransform: 'none', fontWeight: 500, px: 2.5, bgcolor: '#2563eb', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}>
            Next
          </Button>
        </Box>
      )}
    </Box>
  )
}

export default AssignmentFormPage
