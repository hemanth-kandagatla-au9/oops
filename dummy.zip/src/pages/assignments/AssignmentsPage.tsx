import React, { useMemo, useState } from 'react'
import {
  Box, Button, Grid, InputAdornment, Paper, TextField, Typography,
} from '@mui/material'
import { FileText, Plus, Search, SlidersHorizontal } from 'lucide-react'
import { useHistory } from 'react-router-dom'
import { useGetAssignmentsQuery } from '../../redux/slices/assignmentsSlice'
import { POLICYOPS_PATH } from '../../utils/constant'

interface ApiTarget {
  hostname: string
}

interface ApiPolicy {
  policyId: string
  name: string
  sequenceNumber: number
  versionNumber: string
}

interface AssignmentCardData {
  id: string
  name: string
  description?: string
  versionNumber?: string
  assignmentType?: string
  priority?: string
  policyMode?: string
  policies?: ApiPolicy[]
  policyCount?: number
  targets?: ApiTarget[]
  targetType?: string
  status: string
  isActive?: boolean
  createdAt?: string
  updatedAt?: string
}

const getAssignmentRouteId = (assignment: AssignmentCardData): string => assignment.id || ''

const FORM_FIELD_SX = {
  '& .MuiOutlinedInput-root': {
    borderRadius: '999px',
    bgcolor: '#ffffff',
    fontSize: '0.875rem',
    '& fieldset': { borderColor: '#e2e8f0' },
    '&:hover fieldset': { borderColor: '#cbd5e1' },
    '&.Mui-focused fieldset': { borderColor: '#2563eb', borderWidth: '1px' },
  },
}

const STATUS_STYLE: Record<string, { bg: string; color: string; label: string }> = {
  ACTIVE:   { bg: '#dcfce7', color: '#15803d', label: 'Active' },
  INACTIVE: { bg: '#f1f5f9', color: '#64748b', label: 'Inactive' },
  DRAFT:    { bg: '#f1f5f9', color: '#64748b', label: 'Draft' },
  ARCHIVED: { bg: '#fef9c3', color: '#a16207', label: 'Archived' },
}

const PRIORITY_COLOR: Record<string, string> = {
  CRITICAL: '#ef4444',
  HIGH:     '#f97316',
  MEDIUM:   '#2563eb',
  LOW:      '#64748b',
}

interface StatCardProps {
  label: string
  value: string | number
}

const StatCard: React.FC<StatCardProps> = ({ label, value }) => (
  <Paper elevation={0} sx={{ p: 2.5, borderRadius: '10px', border: '1px solid #e2e8f0', bgcolor: 'white', boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
    <Typography variant="caption" color="text.secondary" display="block" mb={0.75}>{label}</Typography>
    <Typography variant="h5" fontWeight={700} color="#0f172a">{value}</Typography>
  </Paper>
)

interface AssignmentCardProps {
  assignment: AssignmentCardData
  onClick: () => void
}

const AssignmentCard: React.FC<AssignmentCardProps> = ({ assignment, onClick }) => {
  const status = STATUS_STYLE[assignment.status] ?? { bg: '#f1f5f9', color: '#64748b', label: assignment.status }
  const targetCount = assignment.targets?.length ?? 0
  const firstPolicy = assignment.policies?.[0]

  return (
    <Paper
      elevation={0}
      onClick={onClick}
      sx={{
        p: 2.5,
        borderRadius: '10px',
        border: '1px solid #e2e8f0',
        bgcolor: 'white',
        boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
        cursor: 'pointer',
        transition: 'all 0.15s',
        '&:hover': { borderColor: '#93c5fd', boxShadow: '0 4px 12px rgba(37,99,235,0.08)' },
      }}
    >
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={2}>
        <Typography variant="subtitle2" fontWeight={700} color="#0f172a" sx={{ pr: 1 }}>{assignment.name}</Typography>
        <Box sx={{ px: 1.25, py: 0.35, borderRadius: '999px', bgcolor: status.bg, color: status.color, fontSize: '0.72rem', fontWeight: 600, whiteSpace: 'nowrap', flexShrink: 0 }}>
          {status.label}
        </Box>
      </Box>

      {firstPolicy && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, bgcolor: '#f8fafc', borderRadius: '8px', px: 1.5, py: 1, mb: 2.5 }}>
          <FileText size={16} color="#2563eb" />
          <Typography variant="body2" color="#64748b" noWrap>{firstPolicy.name}</Typography>
        </Box>
      )}

      <Grid container spacing={2} mb={2.5}>
        <Grid item xs={6}>
          <Typography variant="caption" color="text.secondary" display="block" mb={0.25}>Priority</Typography>
          <Typography variant="body2" fontWeight={700} color={PRIORITY_COLOR[assignment.priority ?? ''] ?? '#64748b'}>
            {assignment.priority || '—'}
          </Typography>
        </Grid>
        <Grid item xs={6}>
          <Typography variant="caption" color="text.secondary" display="block" mb={0.25}>Targets</Typography>
          <Typography variant="body2" fontWeight={700} color="#0f172a">{targetCount}</Typography>
        </Grid>
        <Grid item xs={6}>
          <Typography variant="caption" color="text.secondary" display="block" mb={0.25}>Type</Typography>
          <Typography variant="body2" fontWeight={600} color="#0f172a">{assignment.assignmentType || '—'}</Typography>
        </Grid>
        <Grid item xs={6}>
          <Typography variant="caption" color="text.secondary" display="block" mb={0.25}>Policies</Typography>
          <Typography variant="body2" fontWeight={700} color="#0f172a">{assignment.policyCount ?? assignment.policies?.length ?? 0}</Typography>
        </Grid>
      </Grid>

      <Typography variant="caption" color="text.secondary">{assignment.policyMode || '—'}</Typography>
    </Paper>
  )
}

const AssignmentsPage: React.FC = () => {
  const history = useHistory()
  const [search, setSearch] = useState('')

  const { data, isLoading } = useGetAssignmentsQuery({ page: 1, limit: 50 })
  const assignments: AssignmentCardData[] = data?.data ?? []

  const filtered = useMemo(() => {
    if (!search.trim()) return assignments
    const q = search.toLowerCase()
    return assignments.filter((a) => a.name.toLowerCase().includes(q))
  }, [assignments, search])

  const totalServers = assignments.reduce((sum, a) => sum + (a.targets?.length ?? 0), 0)
  const activeCount = assignments.filter((a) => a.status === 'ACTIVE').length
  const pendingApproval = assignments.filter((a) => a.status !== 'ACTIVE').length

  return (
    <Box sx={{ p: 3, bgcolor: '#f1f5f9', minHeight: '100%' }}>
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={0.5}>
        <Typography variant="h5" fontWeight={700} color="#0f172a">Assignment Center</Typography>
        <Button
          variant="contained"
          endIcon={<Plus size={16} />}
          onClick={() => history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/new`)}
          sx={{ bgcolor: '#2563eb', textTransform: 'none', fontWeight: 500, borderRadius: '100px', px: 2.5, boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}
        >
          New Assignment
        </Button>
      </Box>

      <Typography variant="body2" color="text.secondary" mb={3}>
        Deploy and manage policies across global, environment, region or server group scopes
      </Typography>

      <Grid container spacing={2} mb={3}>
        <Grid item xs={6} sm={3}><StatCard label="Total Assignments" value={assignments.length} /></Grid>
        <Grid item xs={6} sm={3}><StatCard label="Assigned Targets" value={totalServers} /></Grid>
        <Grid item xs={6} sm={3}><StatCard label="Active" value={activeCount} /></Grid>
        <Grid item xs={6} sm={3}><StatCard label="Inactive / Draft" value={pendingApproval} /></Grid>
      </Grid>

      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2.5} flexWrap="wrap" gap={2}>
        <Box display="flex" alignItems="center" gap={1}>
          <Typography variant="subtitle1" fontWeight={600} color="#0f172a">Active Assignments</Typography>
          <Box sx={{ px: 1, py: 0.2, bgcolor: '#dbeafe', borderRadius: '999px', minWidth: 28, textAlign: 'center' }}>
            <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: '#2563eb' }}>
              {String(filtered.length).padStart(2, '0')}
            </Typography>
          </Box>
        </Box>
        <Box display="flex" gap={1.5} alignItems="center">
          <TextField
            size="small"
            placeholder="Search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            sx={{ ...FORM_FIELD_SX, width: 280 }}
            InputProps={{ startAdornment: <InputAdornment position="start"><Search size={16} color="#94a3b8" /></InputAdornment> }}
          />
          <Button
            variant="outlined"
            startIcon={<SlidersHorizontal size={15} />}
            sx={{ borderRadius: '999px', borderColor: '#e2e8f0', color: '#64748b', textTransform: 'none', fontWeight: 500, px: 2, background: 'white', '&:hover': { borderColor: '#cbd5e1', background: 'white' } }}
          >
            Filter
          </Button>
        </Box>
      </Box>

      {isLoading ? (
        <Typography variant="body2" color="text.secondary">Loading assignments…</Typography>
      ) : !filtered.length ? (
        <Paper elevation={0} sx={{ p: 3, borderRadius: '10px', border: '1px dashed #cbd5e1', bgcolor: 'white' }}>
          <Typography variant="body2" color="text.secondary">No assignments found.</Typography>
        </Paper>
      ) : (
        <Grid container spacing={2.5}>
          {filtered.map((assignment) => (
            <Grid item xs={12} sm={6} lg={4} key={getAssignmentRouteId(assignment) || assignment.name}>
              <AssignmentCard
                assignment={assignment}
                onClick={() => {
                  const assignmentId = getAssignmentRouteId(assignment)
                  if (!assignmentId) return
                  history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/${assignmentId}/edit`)
                }}
              />
            </Grid>
          ))}
        </Grid>
      )}
    </Box>
  )
}

export default AssignmentsPage
