import React, { useEffect } from "react";
import { Box, Typography } from "@mui/material";
import { loginInsights, clearUserInfoCookies, getMsalInstance } from "../../utils/authService";
import { getAccessToken } from "../../utils/tokenService";

const LogoutPage: React.FC = () => {
  useEffect(() => {
    const doLogout = async () => {
      // TODO: re-enable when auth backend is reachable from this environment
      // try {
      //   const token = await getAccessToken();
      //   if (token) {
      //     await loginInsights({ action: "logout", accessToken: token });
      //   }
      // } catch (e) {
      //   console.error("logout loginInsights error:", e);
      // }
      {
        clearUserInfoCookies();
        const msalInst = getMsalInstance();
        const hasSession = msalInst && msalInst.getAllAccounts().length > 0;
        if (hasSession) {
          // Active MSAL session — do full Azure AD logout
          await msalInst.logoutRedirect({ postLogoutRedirectUri: "/" });
        } else {
          // Already logged out from MSAL (e.g. post-redirect second load) — go home
          window.location.href = "/";
        }
      }
    };

    doLogout();
  }, []);

  return (
    <Box display="flex" justifyContent="center" alignItems="center" height="100vh" flexDirection="column">
      <Typography variant="h5">Logging out...</Typography>
      <Typography variant="body2" mt={1} color="text.secondary">
        Please wait while we securely sign you out.
      </Typography>
    </Box>
  );
};

export default LogoutPage;
