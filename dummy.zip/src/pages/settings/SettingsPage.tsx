import React from 'react'
import { Box, Paper, Typography, Chip, List, ListItem, ListItemIcon, ListItemText } from '@mui/material'
import { Settings, Bell, Shield, Users, Database, Clock } from 'lucide-react'

const planned = [
  { icon: <Bell size={18} />, title: 'Alert thresholds', desc: 'Configure drift alert severity and notification channels' },
  { icon: <Shield size={18} />, title: 'RBAC configuration', desc: 'Manage roles, permissions and module access' },
  { icon: <Users size={18} />, title: 'User management', desc: 'Invite team members and assign roles' },
  { icon: <Database size={18} />, title: 'Data retention', desc: 'Configure audit log retention (default 13 months)' },
  { icon: <Clock size={18} />, title: 'Schedule overrides', desc: 'Global frequency caps and maintenance windows' },
]

const SettingsPage: React.FC = () => (
  <Box p={3}>
    <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
      <Box>
        <Typography variant="h5" fontWeight="bold">Settings</Typography>
        <Typography variant="body2" color="text.secondary">
          Platform configuration and administration
        </Typography>
      </Box>
      <Chip label="Out of POC scope" size="small" color="default" variant="outlined" />
    </Box>

    <Paper elevation={0} variant="outlined" sx={{ p: 4, borderRadius: 2, textAlign: 'center' }}>
      <Box sx={{ color: 'text.disabled', mb: 2 }}><Settings size={48} /></Box>
      <Typography variant="h6" fontWeight="bold" mb={1}>Not implemented in this POC</Typography>
      <Typography variant="body2" color="text.secondary" mb={3} maxWidth={480} mx="auto">
        Platform settings are out of scope for this frontend POC. They will be built once the
        core configuration management workflow is validated. Planned settings:
      </Typography>
      <List dense sx={{ maxWidth: 400, mx: 'auto', textAlign: 'left' }}>
        {planned.map(({ icon, title, desc }) => (
          <ListItem key={title} sx={{ py: 0.75 }}>
            <ListItemIcon sx={{ minWidth: 36, color: 'text.secondary' }}>{icon}</ListItemIcon>
            <ListItemText
              primary={<Typography variant="body2" fontWeight={500}>{title}</Typography>}
              secondary={<Typography variant="caption" color="text.secondary">{desc}</Typography>}
            />
          </ListItem>
        ))}
      </List>
    </Paper>
  </Box>
)

export default SettingsPage
