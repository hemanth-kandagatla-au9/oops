import React, { useState } from 'react'
import {
  Box, Button, Chip, CircularProgress, Alert, Divider,
  Drawer, Grid, IconButton, Menu, MenuItem, Paper, Tooltip, Typography,
} from '@mui/material'
import { Download, X, Eye, ChevronDown } from 'lucide-react'
import Editor from '@monaco-editor/react'
import {
  useGetAuditLogsQuery,
  useGetAuditByIdQuery,
} from '../../redux/slices/auditSlice'
import { ACTION_COLORS, ENTITY_COLORS } from '../../utils/uiConstants'
import { formatDate, formatDateTime, formatRelative, formatExportDate } from '../../utils/dateUtils'
import { MONACO_READONLY_OPTIONS } from '../../utils/monacoConfig'
import FilterBar, { FilterItem } from '../../components/FilterBar'
import PolicyTable, { TableColumn } from '../../components/PolicyTable'
import StatusBadge from '../../components/StatusBadge'
import DetailRow from '../../components/DetailRow'
import { AuditLog } from '../../types'

// ── Detail Drawer ─────────────────────────────────────────────────────────────
interface AuditDrawerProps { logId: string | null; onClose: () => void }

const AuditDrawer: React.FC<AuditDrawerProps> = ({ logId, onClose }) => {
  const { data, isLoading } = useGetAuditByIdQuery(logId!, { skip: !logId })
  const log: AuditLog | undefined = data?.data

  return (
    <Box sx={{ width: 580, p: 3, height: '100%', overflowY: 'auto' }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="subtitle1" fontWeight="bold">Audit Entry Detail</Typography>
        <IconButton size="small" onClick={onClose}><X size={18} /></IconButton>
      </Box>

      {isLoading && <CircularProgress size={24} />}
      {!isLoading && !log && <Alert severity="error">Entry not found</Alert>}

      {log && (
        <>
          <Box sx={{ p: 2, bgcolor: 'action.hover', borderRadius: 1.5, mb: 2 }}>
            <Box display="flex" gap={1} flexWrap="wrap" mb={1.5}>
              <StatusBadge value={log.action} />
              <Chip label={log.entity_type.replace('_', ' ')} size="small"
                sx={{ bgcolor: ENTITY_COLORS[log.entity_type] ?? '#666', color: 'white', fontSize: '0.7rem' }} />
              {log.hostname && <Chip label={log.hostname} size="small" variant="outlined" />}
            </Box>
            <Typography variant="body2" fontWeight={500}>{log.entity_name}</Typography>
            <Typography variant="caption" color="text.secondary">{log.event_type} · v{log.entity_version}</Typography>
          </Box>

          <Typography variant="subtitle2" fontWeight={700} mb={1.5} color="text.secondary" textTransform="uppercase" letterSpacing={0.5} fontSize="0.65rem">
            Details
          </Typography>
          <DetailRow label="Audit ID" value={log.audit_id} />
          <DetailRow label="Event Type" value={log.event_type} />
          <DetailRow label="Entity Type" value={log.entity_type} />
          <DetailRow label="Entity ID" value={log.entity_id} />
          <DetailRow label="Entity Name" value={log.entity_name} />
          <DetailRow label="Entity Version" value={`v${log.entity_version}`} />
          <DetailRow label="Action" value={log.action} />
          <DetailRow label="Performed By" value={log.performed_by} />
          <DetailRow label="Timestamp" value={formatDateTime(log.timestamp)} last />

          {(log.old_value || log.new_value) && (
            <>
              <Divider sx={{ my: 2 }} />
              <Typography variant="subtitle2" fontWeight={700} mb={1.5} color="text.secondary" textTransform="uppercase" letterSpacing={0.5} fontSize="0.65rem">
                Change Details
              </Typography>
              <Grid container spacing={1.5}>
                <Grid item xs={6}>
                  <Typography variant="caption" color="error.main" fontWeight={600} mb={0.5} display="block">Before</Typography>
                  <Box border="1px solid" borderColor={log.old_value ? 'error.light' : 'divider'} borderRadius={1} overflow="hidden">
                    <Editor height="200px" language="json"
                      value={log.old_value ? JSON.stringify(log.old_value, null, 2) : '// no previous value'}
                      options={MONACO_READONLY_OPTIONS} />
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="caption" color="success.main" fontWeight={600} mb={0.5} display="block">After</Typography>
                  <Box border="1px solid" borderColor={log.new_value ? 'success.light' : 'divider'} borderRadius={1} overflow="hidden">
                    <Editor height="200px" language="json"
                      value={log.new_value ? JSON.stringify(log.new_value, null, 2) : '// no new value'}
                      options={MONACO_READONLY_OPTIONS} />
                  </Box>
                </Grid>
              </Grid>
            </>
          )}
        </>
      )}
    </Box>
  )
}

// ── Main Page ─────────────────────────────────────────────────────────────────
const AuditPage: React.FC = () => {
  const [entityTypeFilter, setEntityTypeFilter] = useState('')
  const [actionFilter, setActionFilter] = useState('')
  const [performedBy, setPerformedBy] = useState('')
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [page, setPage] = useState(0)
  const [pageSize, setPageSize] = useState(10)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [exportAnchor, setExportAnchor] = useState<HTMLElement | null>(null)
  const [exporting, setExporting] = useState(false)

  const { data, isLoading, isError } = useGetAuditLogsQuery({
    page: page + 1, limit: pageSize,
    entity_type: entityTypeFilter || undefined,
    action: actionFilter || undefined,
    performed_by: performedBy || undefined,
    from_date: fromDate || undefined,
    to_date: toDate || undefined,
  })

  const logs: AuditLog[] = data?.data ?? []
  const total: number = data?.total ?? 0
  const hasFilters = !!(entityTypeFilter || actionFilter || performedBy || fromDate || toDate)
  const resetPage = () => setPage(0)

  const handleExport = async (format: 'csv' | 'json') => {
    setExportAnchor(null); setExporting(true)
    try {
      const params = new URLSearchParams({ format })
      if (entityTypeFilter) params.append('entity_type', entityTypeFilter)
      if (actionFilter) params.append('action', actionFilter)
      if (performedBy) params.append('performed_by', performedBy)
      if (fromDate) params.append('from_date', fromDate)
      if (toDate) params.append('to_date', toDate)
      const response = await fetch(`${process.env.POLICYOPS_API}/audit/export?${params.toString()}`)
      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url; a.download = `audit-export-${formatExportDate()}.${format}`
      document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url)
    } catch { } finally { setExporting(false) }
  }

  const filters: FilterItem[] = [
    {
      type: 'select', key: 'entity_type', label: 'Entity Type', value: entityTypeFilter, onChange: (v) => { setEntityTypeFilter(v); resetPage() }, minWidth: 150,
      options: [{ value: '', label: 'All types' }, { value: 'rule', label: 'Rule' }, { value: 'policy', label: 'Policy' }, { value: 'policy_group', label: 'Policy Group' }, { value: 'assignment', label: 'Assignment' }, { value: 'agent', label: 'Agent' }],
    },
    {
      type: 'select', key: 'action', label: 'Action', value: actionFilter, onChange: (v) => { setActionFilter(v); resetPage() },
      options: [{ value: '', label: 'All actions' }, { value: 'created', label: 'Created' }, { value: 'updated', label: 'Updated' }, { value: 'published', label: 'Published' }, { value: 'archived', label: 'Archived' }, { value: 'cloned', label: 'Cloned' }],
    },
    { type: 'search', key: 'performed_by', placeholder: 'Performed by...', value: performedBy, onChange: (v) => { setPerformedBy(v); resetPage() }, minWidth: 180 },
    { type: 'date', key: 'from_date', label: 'From date', value: fromDate, onChange: (v) => { setFromDate(v); resetPage() } },
    { type: 'date', key: 'to_date', label: 'To date', value: toDate, onChange: (v) => { setToDate(v); resetPage() } },
  ]

  const activeChips = [
    entityTypeFilter && { label: `Type: ${entityTypeFilter}`, onDelete: () => setEntityTypeFilter('') },
    actionFilter && { label: `Action: ${actionFilter}`, onDelete: () => setActionFilter('') },
    performedBy && { label: `By: ${performedBy}`, onDelete: () => setPerformedBy('') },
    fromDate && { label: `From: ${fromDate}`, onDelete: () => setFromDate('') },
    toDate && { label: `To: ${toDate}`, onDelete: () => setToDate('') },
  ].filter(Boolean) as { label: string; onDelete: () => void }[]

  const columns: TableColumn[] = [
    {
      key: 'timestamp', header: 'Timestamp', width: 165,
      render: (row: AuditLog) => (
        <Box>
          <Typography variant="body2">{formatDate(row.timestamp)}</Typography>
          <Typography variant="caption" color="text.secondary">{formatRelative(row.timestamp)}</Typography>
        </Box>
      ),
    },
    {
      key: 'performed_by', header: 'Performed By', width: 160,
      render: (row: AuditLog) => <Typography variant="body2" fontWeight={500} noWrap>{row.performed_by}</Typography>,
    },
    {
      key: 'action', header: 'Action', width: 110,
      render: (row: AuditLog) => <StatusBadge value={row.action} />,
    },
    {
      key: 'entity_type', header: 'Entity Type', width: 130,
      render: (row: AuditLog) => (
        <Chip label={row.entity_type.replace('_', ' ')} size="small"
          sx={{ bgcolor: ENTITY_COLORS[row.entity_type] ?? '#666', color: 'white', fontSize: '0.7rem' }} />
      ),
    },
    {
      key: 'entity_name', header: 'Entity', minWidth: 160,
      render: (row: AuditLog) => <Typography variant="body2" noWrap fontWeight={500}>{row.entity_name}</Typography>,
    },
    {
      key: 'entity_version', header: 'Version', width: 80,
      render: (row: AuditLog) => <Typography variant="body2" color="text.secondary">v{row.entity_version}</Typography>,
    },
    {
      key: 'event_type', header: 'Event', minWidth: 160,
      render: (row: AuditLog) => <Typography variant="body2" color="text.secondary" noWrap>{row.event_type}</Typography>,
    },
    {
      key: '_id', header: '', width: 48, align: 'right',
      render: (row: AuditLog) => (
        <Tooltip title="View details">
          <IconButton size="small" onClick={(e) => { e.stopPropagation(); setSelectedId(row._id) }}>
            <Eye size={14} />
          </IconButton>
        </Tooltip>
      ),
    },
  ]

  return (
    <Box p={3}>
      {/* ── Header row ── */}
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={0.75}>
        <Box>
          <Box display="flex" alignItems="center" gap={1}>
            <Typography variant="h5" fontWeight={700}>Audit History</Typography>
            <Box sx={{ px: 1, py: 0.15, bgcolor: '#eff6ff', borderRadius: '999px', border: '1px solid #dbeafe' }}>
              <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: '#2563eb' }}>{total}</Typography>
            </Box>
          </Box>
        </Box>
        <Box display="flex" alignItems="center" gap={1.5}>
          <Button
            variant="outlined" size="small"
            startIcon={<Download size={14} />}
            endIcon={<ChevronDown size={14} />}
            disabled={exporting}
            onClick={(e) => setExportAnchor(e.currentTarget)}
            sx={{ borderColor: '#e2e8f0', color: '#64748b', fontSize: '0.85rem' }}
          >
            {exporting ? 'Exporting...' : 'Export'}
          </Button>
          <Menu anchorEl={exportAnchor} open={!!exportAnchor} onClose={() => setExportAnchor(null)}>
            <MenuItem onClick={() => handleExport('json')}>Export as JSON</MenuItem>
            <MenuItem onClick={() => handleExport('csv')}>Export as CSV</MenuItem>
          </Menu>
        </Box>
      </Box>
      <Typography variant="body2" color="text.secondary" mb={2.5}>
        Immutable record of all configuration changes
      </Typography>

      <Paper elevation={0} variant="outlined" sx={{ p: 2, mb: 2, borderRadius: 2 }}>
        <FilterBar filters={filters} hasActive={hasFilters}
          onClear={() => { setEntityTypeFilter(''); setActionFilter(''); setPerformedBy(''); setFromDate(''); setToDate(''); setPage(0) }} />
        {activeChips.length > 0 && (
          <Box display="flex" gap={1} mt={0.5} flexWrap="wrap">
            {activeChips.map((c) => <Chip key={c.label} label={c.label} size="small" onDelete={c.onDelete} />)}
          </Box>
        )}
      </Paper>

      <Typography variant="caption" color="text.secondary" mb={1} display="block">
        Click any row to view change details
      </Typography>
      <PolicyTable
        columns={columns} rows={logs} total={total}
        page={page} pageSize={pageSize} rowsPerPageOptions={[10, 20, 50]}
        onPageChange={setPage} onPageSizeChange={(s) => { setPageSize(s); setPage(0) }}
        loading={isLoading} error={isError} errorMessage="Failed to load audit logs"
        onRowClick={(row) => setSelectedId(row._id)}
      />

      <Drawer anchor="right" open={!!selectedId} onClose={() => setSelectedId(null)} PaperProps={{ sx: { width: 580 } }}>
        <AuditDrawer logId={selectedId} onClose={() => setSelectedId(null)} />
      </Drawer>
    </Box>
  )
}

export default AuditPage
