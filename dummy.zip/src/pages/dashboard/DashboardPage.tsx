import React, { useState } from 'react'
import Cookies from 'universal-cookie'
import { formatDisplayName } from '../../utils/uiConstants'
import {
  Box, Button, Grid, MenuItem, Paper, Select, Typography,
} from '@mui/material'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell,
} from 'recharts'
import {
  FileText, Settings, Server, AlertTriangle,
  TrendingUp, TrendingDown, Zap, Plus, CalendarDays,
} from 'lucide-react'
import { useHistory } from 'react-router-dom'
import { useGetDashboardSummaryQuery } from '../../redux/slices/complianceSlice'
import { useGetRulesQuery } from '../../redux/slices/rulesSlice'
import { useGetAgentsHealthQuery } from '../../redux/slices/agentsSlice'
import { POLICYOPS_PATH } from '../../utils/constant'

const MONTHLY_TREND = [
  { month: 'Jan', value: 76 },
  { month: 'Feb', value: 80 },
  { month: 'Mar', value: 78 },
  { month: 'Apr', value: 85 },
  { month: 'May', value: 91 },
  { month: 'Jun', value: 95 },
]

const RULE_DISTRIBUTION = [
  { name: 'File',     value: 38, color: '#3b82f6' },
  { name: 'Package',  value: 27, color: '#10b981' },
  { name: 'Service',  value: 22, color: '#f97316' },
  { name: 'Security', value: 13, color: '#8b5cf6' },
]

// ── Sub-components ────────────────────────────────────────────────────────────

interface HeroKpiCardProps {
  title: string
  value: string
  subtitle: string
  icon: React.ReactNode
}

const HeroKpiCard: React.FC<HeroKpiCardProps> = ({ title, value, subtitle, icon }) => (
  <Box sx={{
    bgcolor: 'rgba(255,255,255,0.12)',
    backdropFilter: 'blur(8px)',
    borderRadius: 2.5,
    px: 3, py: 2.5,
    minWidth: 180,
    border: '1px solid rgba(255,255,255,0.25)',
  }}>
    <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
      <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.8)', fontWeight: 500 }}>{title}</Typography>
      {icon}
    </Box>
    <Typography sx={{ fontSize: '2.4rem', fontWeight: 800, color: 'white', lineHeight: 1.1, mb: 0.75 }}>
      {value}
    </Typography>
    <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.55)' }}>{subtitle}</Typography>
  </Box>
)

interface DashStatCardProps {
  label: string
  value: string | number
  trend?: string
  trendUp?: boolean
  icon: React.ReactNode
  iconColor: string
  colorValue?: boolean
}

const DashStatCard: React.FC<DashStatCardProps> = ({ label, value, trend, trendUp, icon, iconColor, colorValue }) => {
  const trendColor = trendUp === undefined ? '#94a3b8' : trendUp ? '#10b981' : '#ef4444'
  const trendBg   = trendUp === undefined ? '#f1f5f9'  : trendUp ? '#dcfce7'  : '#fee2e2'

  return (
    <Paper elevation={0} sx={{ p: 1.75, borderRadius: 2, border: '1px solid #e2e8f0', bgcolor: 'white', height: '100%' }}>
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1}>
        <Typography variant="caption" color="text.secondary" fontWeight={500} sx={{ fontSize: '0.72rem' }}>{label}</Typography>
        <Box sx={{
          width: 28, height: 28, borderRadius: 1.5,
          bgcolor: `${iconColor}15`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: iconColor, flexShrink: 0,
        }}>
          {icon}
        </Box>
      </Box>
      <Typography variant="h6" fontWeight={700} mb={0.75} sx={{ color: colorValue ? iconColor : 'text.primary' }}>{value}</Typography>
      {trend && (
        <Box display="inline-flex" alignItems="center" gap={0.4}
          sx={{ bgcolor: trendBg, borderRadius: '20px', px: 0.75, py: 0.25 }}>
          {trendUp !== undefined && (
            trendUp ? <TrendingUp size={11} color={trendColor} /> : <TrendingDown size={11} color={trendColor} />
          )}
          <Typography sx={{ fontSize: '0.68rem', color: trendColor, fontWeight: 600, lineHeight: 1 }}>
            {trend}
          </Typography>
        </Box>
      )}
    </Paper>
  )
}

interface BottomMetricProps {
  label: string
  value: string | number
  sub?: string
}

const BottomMetric: React.FC<BottomMetricProps> = ({ label, value, sub }) => (
  <Paper elevation={0} sx={{ px: 2.5, py: 1.75, borderRadius: 2, border: '1px solid #e2e8f0', bgcolor: 'white' }}>
    <Typography variant="caption" color="text.secondary" display="block" mb={0.25}>{label}</Typography>
    <Typography variant="h6" fontWeight={700}>{typeof value === 'number' ? value?.toLocaleString() : value}</Typography>
    {sub && <Typography variant="caption" color="text.secondary">{sub}</Typography>}
  </Paper>
)

const PieLegend: React.FC<{ data: typeof RULE_DISTRIBUTION }> = ({ data }) => (
  <Box display="flex" flexDirection="column" gap={1} justifyContent="center">
    {data.map((d) => (
      <Box key={d.name} display="flex" alignItems="center" gap={1}>
        <Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: d.color, flexShrink: 0 }} />
        <Typography variant="caption" color="text.secondary">{d.name}</Typography>
        <Typography variant="caption" fontWeight={600} ml="auto" pl={1}>{d.value}%</Typography>
      </Box>
    ))}
  </Box>
)

// ── Main page ─────────────────────────────────────────────────────────────────

const DashboardPage: React.FC = () => {
  const history = useHistory()
  const fullName = formatDisplayName(new Cookies().get('user_fullname') || '')
  const [trendPeriod, setTrendPeriod] = useState('previous_year')

  const { data: dashData } = useGetDashboardSummaryQuery()
  const { data: healthData } = useGetAgentsHealthQuery()
  const { data: rulesData } = useGetRulesQuery({ page: 1, limit: 1 })

  const summary = dashData?.data
  const health = healthData?.data ?? { online: 0, stale: 0, offline: 0, total: 0 }
  const complianceRate = summary?.compliance_rate ?? 94.2
  const totalConfigs = rulesData?.total ?? 142
  const activeConfigs = Math.round(totalConfigs * 0.83)

  return (
    <Box p={3}>

      {/* Welcome row */}
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={3}>
        <Box>
          <Typography variant="h5" fontWeight={700}>Welcome {fullName}</Typography>
          <Typography variant="body2" color="text.secondary" noWrap>
            Real-time visibility into configuration compliance, drift events and autonomous remediation across the estate.
          </Typography>
        </Box>
        <Box display="flex" gap={1.5} alignItems="center">
          <Button
            variant="outlined" size="small" startIcon={<CalendarDays size={14} />}
            sx={{ borderColor: '#e2e8f0', color: '#64748b', fontSize: '0.85rem' }}
          >
            Sort by Date
          </Button>
          <Button
            variant="contained" size="small" endIcon={<Plus size={14} />}
            onClick={() => history.push(`${POLICYOPS_PATH.RULES}/new`)}
            sx={{ bgcolor: '#2563eb', fontSize: '0.85rem', '&:hover': { bgcolor: '#1d4ed8' } }}
          >
            Configure Rule
          </Button>
        </Box>
      </Box>

      {/* Hero banner */}
      <Box sx={{
        borderRadius: 3,
        background: 'linear-gradient(to left, #0c1a5e 0%, #1e3a8a 40%, #2563eb 80%, #3b82f6 100%)',
        p: 3, mb: 3, color: 'white',
      }}>
        <Grid container spacing={3} alignItems="center">
          <Grid item xs={12} md={6}>
            <Typography variant="h5" fontWeight={700} mb={1} sx={{ color: 'white' }}>
              Configuration State &amp; Self-Healing Operations
            </Typography>
            <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.75)', lineHeight: 1.6 }}>
              PolicyOps ensures active configs remain compliant. Try simulating an out-of-order policy drift to view our real-time correction system in play.
            </Typography>
          </Grid>
          <Grid item xs={12} md={6}>
            <Box display="flex" gap={2} justifyContent={{ xs: 'flex-start', md: 'flex-end' }}>
              <HeroKpiCard
                title="Compliance Posture"
                value={`${complianceRate.toFixed(1)}%`}
                subtitle="Across all managed infrastructure"
                icon={<Zap size={18} color="rgba(255,255,255,0.9)" />}
              />
              <HeroKpiCard
                title="Automation Success Rate"
                value="92%"
                subtitle="Issues resolved without human intervention"
                icon={<Plus size={18} color="rgba(255,255,255,0.9)" />}
              />
            </Box>
          </Grid>
        </Grid>
      </Box>

      {/* Stat cards */}
      <Grid container spacing={2} mb={3}>
        {[
          { label: 'Total Configs',    value: totalConfigs,                       trend: '+8%',  trendUp: true,  icon: <FileText size={18} />,     iconColor: '#2563eb' },
          { label: 'Active Configs',   value: activeConfigs,                      trend: '+5',   trendUp: true,  icon: <Settings size={18} />,     iconColor: '#10b981' },
          { label: 'Managed Servers',  value: health.total || 2845,               trend: '+5',   trendUp: true,  icon: <Server size={18} />,       iconColor: '#6366f1' },
          { label: 'Compliance Score', value: `${complianceRate.toFixed(1)}%`,    trend: '+12%', trendUp: true,  icon: <TrendingUp size={18} />,   iconColor: '#10b981', colorValue: true },
          { label: 'Drift Events/24h', value: summary?.drift_events_today ?? 54,  trend: '-8',   trendUp: false, icon: <AlertTriangle size={18} />,iconColor: '#f97316', colorValue: true },
          { label: 'Failed Execution', value: summary?.failing_servers ?? 14,     trend: '-3',   trendUp: false, icon: <AlertTriangle size={18} />,iconColor: '#ef4444', colorValue: true },
        ].map((card) => (
          <Grid item xs={6} sm={4} md={2} key={card.label}>
            <DashStatCard {...card} />
          </Grid>
        ))}
      </Grid>

      {/* Charts */}
      <Grid container spacing={2.5} mb={3}>
        <Grid item xs={12} md={6}>
          <Paper elevation={0} sx={{ p: 2.5, borderRadius: 2, border: '1px solid #e2e8f0', bgcolor: 'white', height: 280 }}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="subtitle1" fontWeight={600}>Compliance Trends</Typography>
              <Select
                size="small" value={trendPeriod} onChange={(e) => setTrendPeriod(e.target.value)}
                sx={{ fontSize: '0.8rem', height: 30, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e8f0' } }}
              >
                <MenuItem value="previous_year">Previous Year</MenuItem>
                <MenuItem value="last_6_months">Last 6 Months</MenuItem>
                <MenuItem value="last_30_days">Last 30 Days</MenuItem>
              </Select>
            </Box>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={MONTHLY_TREND} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="compGradient" x1="0" y1="1" x2="0" y2="0">
                    <stop offset="0%" stopColor="#f43f5e" stopOpacity={0} />
                    <stop offset="100%" stopColor="#f43f5e" stopOpacity={0.2} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ border: '1px solid #e2e8f0', borderRadius: 8, fontSize: 12 }}
                  formatter={(v: any) => [`${Number(v).toFixed(1)}%`, 'Compliance']}
                />
                <Area type="monotone" dataKey="value" stroke="#f43f5e" strokeWidth={2}
                  fill="url(#compGradient)" dot={false} activeDot={{ r: 4, fill: '#f43f5e' }} />
              </AreaChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper elevation={0} sx={{ p: 2.5, borderRadius: 2, border: '1px solid #e2e8f0', bgcolor: 'white', height: 280 }}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="subtitle1" fontWeight={600}>Configuration Distribution</Typography>
              <Typography
                variant="caption" color="primary" fontWeight={600}
                sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}
                onClick={() => history.push(POLICYOPS_PATH.RULES)}
              >
                Know More
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" height={200}>
              <ResponsiveContainer width="55%" height="100%">
                <PieChart>
                  <Pie data={RULE_DISTRIBUTION} cx="50%" cy="50%" outerRadius={85} paddingAngle={2} dataKey="value">
                    {RULE_DISTRIBUTION.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ border: '1px solid #e2e8f0', borderRadius: 8, fontSize: 12 }}
                    formatter={(v: any) => [`${v}%`, '']}
                  />
                </PieChart>
              </ResponsiveContainer>
              <Box width="45%">
                <PieLegend data={RULE_DISTRIBUTION} />
              </Box>
            </Box>
          </Paper>
        </Grid>
      </Grid>

      {/* Bottom metrics */}
      <Grid container spacing={2}>
        {[
          { label: 'Files Restarted',      value: 8412,   sub: '+100 today' },
          { label: 'Packages Installed',   value: 1096,   sub: '+100 today' },
          { label: 'Services Restarted',   value: 2873,   sub: '+107 today' },
          { label: 'Security Corrections', value: 664 },
          { label: 'Auto Remediations',    value: 12941 },
          { label: 'Agent Success Rate',   value: '99.4%' },
        ].map((m) => (
          <Grid item xs={6} sm={4} md={2} key={m.label}>
            <BottomMetric {...m} />
          </Grid>
        ))}
      </Grid>

    </Box>
  )
}

export default DashboardPage
