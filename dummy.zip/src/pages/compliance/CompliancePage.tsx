import React, { useEffect, useState } from 'react'
import {
  Box, Typography, Paper, Grid, Chip, CircularProgress, Alert,
  Button, Divider,
} from '@mui/material'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer as ResponsiveContainerBase, BarChart, Bar, Cell as CellBase, Legend,
} from 'recharts'

// React 17 + Recharts 2.x type incompatibility: Recharts types return ReactNode which React 17
// JSX does not accept (it requires ReactElement | null). Cast to bypass the false positive.
const ResponsiveContainer = ResponsiveContainerBase as React.FC<any>
const Cell = CellBase as React.FC<any>
import { RefreshCw, TrendingUp, Server, AlertTriangle, CheckCircle, XCircle, Clock } from 'lucide-react'
import { useHistory } from 'react-router-dom'
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'
import {
  useGetDashboardSummaryQuery,
  useGetComplianceSummaryQuery,
  useGetComplianceTrendQuery,
  useGetDriftEventsQuery,
} from '../../redux/slices/complianceSlice'
import { useGetAgentsHealthQuery } from '../../redux/slices/agentsSlice'
import { POLICYOPS_PATH } from '../../utils/constant'

dayjs.extend(relativeTime)

const SEVERITY_COLORS: Record<string, string> = {
  critical: '#ef4444', high: '#f59e0b', medium: '#0288d1', low: '#78909c',
}

const DRIFT_STATUS_COLORS: Record<string, any> = {
  detected: 'info', remediating: 'warning', fixed: 'success', failed: 'error',
}

// ── Stat card ────────────────────────────────────────────────────────────────
interface MetricCardProps {
  label: string; value: string | number; sub?: string
  icon: React.ReactNode; color: string; borderColor?: string
}
const MetricCard: React.FC<MetricCardProps> = ({ label, value, sub, icon, color, borderColor }) => (
  <Paper elevation={0} variant="outlined"
    sx={{ p: 2.5, borderRadius: 2, borderLeft: `4px solid ${borderColor ?? color}` }}>
    <Box display="flex" justifyContent="space-between" alignItems="flex-start">
      <Box>
        <Typography variant="body2" color="text.secondary" mb={0.5}>{label}</Typography>
        <Typography variant="h4" fontWeight="bold" color={color}>{value}</Typography>
        {sub && <Typography variant="caption" color="text.secondary">{sub}</Typography>}
      </Box>
      <Box sx={{ color, opacity: 0.7, mt: 0.5 }}>{icon}</Box>
    </Box>
  </Paper>
)

// ── Custom tooltip for trend chart ──────────────────────────────────────────
const TrendTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  return (
    <Paper elevation={3} sx={{ p: 1.5, borderRadius: 1 }}>
      <Typography variant="caption" color="text.secondary" display="block">{label}</Typography>
      <Typography variant="body2" fontWeight="bold" color="primary">
        {Number(payload[0].value).toFixed(1)}% compliant
      </Typography>
    </Paper>
  )
}

// ── Main page ────────────────────────────────────────────────────────────────
const CompliancePage: React.FC = () => {
  const history = useHistory()
  const [lastRefresh, setLastRefresh] = useState(dayjs())

  const { data: summaryData, isLoading: loadingSummary, refetch: refetchSummary } = useGetDashboardSummaryQuery()
  const { data: compData, refetch: refetchComp } = useGetComplianceSummaryQuery()
  const { data: trendData, refetch: refetchTrend } = useGetComplianceTrendQuery()
  const { data: driftData } = useGetDriftEventsQuery({ page: 1, limit: 8 })
  const { data: healthData } = useGetAgentsHealthQuery()

  const summary = summaryData?.data
  const comp = compData?.data
  const trend = (trendData?.data ?? []).map((d: any) => ({
    ...d,
    compliance_rate: parseFloat(Math.min(100, Math.max(0, Number(d.compliance_rate))).toFixed(1)),
    date: dayjs(d.date).format('MMM D'),
  }))
  const driftEvents = driftData?.data ?? []
  const health = healthData?.data ?? { online: 0, stale: 0, offline: 0, total: 0 }

  // Auto-refresh every 30s
  useEffect(() => {
    const interval = setInterval(() => {
      refetchSummary(); refetchComp(); refetchTrend()
      setLastRefresh(dayjs())
    }, 30000)
    return () => clearInterval(interval)
  }, [refetchSummary, refetchComp, refetchTrend])

  const handleRefresh = () => {
    refetchSummary(); refetchComp(); refetchTrend()
    setLastRefresh(dayjs())
  }

  const complianceRate = summary?.compliance_rate ?? 0
  const rateColor = complianceRate >= 90 ? '#10b981' : complianceRate >= 70 ? '#f59e0b' : '#ef4444'

  const agentBarData = [
    { name: 'Online', value: health.online, color: '#10b981' },
    { name: 'Stale', value: health.stale, color: '#f59e0b' },
    { name: 'Offline', value: health.offline, color: '#ef4444' },
  ]

  if (loadingSummary) return <Box p={3}><CircularProgress /></Box>

  return (
    <Box p={3}>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h5" fontWeight="bold">Compliance Dashboard</Typography>
          <Typography variant="body2" color="text.secondary">
            Real-time compliance posture across your infrastructure
          </Typography>
        </Box>
        <Box display="flex" alignItems="center" gap={2}>
          <Typography variant="caption" color="text.secondary">
            Updated {lastRefresh.fromNow()} · auto-refreshes every 30s
          </Typography>
          <Button variant="outlined" size="small" startIcon={<RefreshCw size={14} />} onClick={handleRefresh}>
            Refresh
          </Button>
        </Box>
      </Box>

      {/* Top metric cards */}
      <Grid container spacing={2} mb={3}>
        <Grid item xs={6} md={3}>
          <MetricCard label="Compliance Rate" value={`${complianceRate.toFixed(1)}%`}
            sub={complianceRate >= 90 ? 'Healthy' : complianceRate >= 70 ? 'Needs attention' : 'Critical'}
            icon={<TrendingUp size={28} />} color={rateColor} />
        </Grid>
        <Grid item xs={6} md={3}>
          <MetricCard label="Servers Managed" value={summary?.servers_managed ?? 0}
            sub={`${health.online} online`}
            icon={<Server size={28} />} color="#6366f1" />
        </Grid>
        <Grid item xs={6} md={3}>
          <MetricCard label="Drift Events Today" value={summary?.drift_events_today ?? 0}
            sub="Detected in last 24h"
            icon={<AlertTriangle size={28} />} color="#f59e0b" />
        </Grid>
        <Grid item xs={6} md={3}>
          <MetricCard label="Failing Servers" value={summary?.failing_servers ?? 0}
            sub="Stale or offline"
            icon={<XCircle size={28} />} color="#ef4444" />
        </Grid>
      </Grid>

      {/* Second row — compliance breakdown + agent health */}
      <Grid container spacing={2} mb={3}>
        <Grid item xs={6} md={3}>
          <Paper elevation={0} variant="outlined" sx={{ p: 2.5, borderRadius: 2, textAlign: 'center', height: '100%' }}>
            <CheckCircle size={32} color="#10b981" style={{ marginBottom: 8 }} />
            <Typography variant="h4" fontWeight="bold" color="#10b981">{comp?.compliant ?? 0}</Typography>
            <Typography variant="body2" color="text.secondary">Compliant servers</Typography>
          </Paper>
        </Grid>
        <Grid item xs={6} md={3}>
          <Paper elevation={0} variant="outlined" sx={{ p: 2.5, borderRadius: 2, textAlign: 'center', height: '100%' }}>
            <XCircle size={32} color="#ef4444" style={{ marginBottom: 8 }} />
            <Typography variant="h4" fontWeight="bold" color="#ef4444">{comp?.non_compliant ?? 0}</Typography>
            <Typography variant="body2" color="text.secondary">Non-compliant servers</Typography>
          </Paper>
        </Grid>
        <Grid item xs={6} md={3}>
          <Paper elevation={0} variant="outlined" sx={{ p: 2.5, borderRadius: 2, textAlign: 'center', height: '100%' }}>
            <Clock size={32} color="#f59e0b" style={{ marginBottom: 8 }} />
            <Typography variant="h4" fontWeight="bold" color="#f59e0b">{comp?.pending ?? 0}</Typography>
            <Typography variant="body2" color="text.secondary">Pending evaluation</Typography>
          </Paper>
        </Grid>
        <Grid item xs={6} md={3}>
          <Paper elevation={0} variant="outlined" sx={{ p: 2.5, borderRadius: 2, textAlign: 'center', height: '100%' }}>
            <Server size={32} color="#6366f1" style={{ marginBottom: 8 }} />
            <Typography variant="h4" fontWeight="bold" color="#6366f1">{comp?.total ?? 0}</Typography>
            <Typography variant="body2" color="text.secondary">Total evaluated</Typography>
          </Paper>
        </Grid>
      </Grid>

      {/* Charts row */}
      <Grid container spacing={3} mb={3}>
        {/* Compliance trend */}
        <Grid item xs={12} md={8}>
          <Paper elevation={0} variant="outlined" sx={{ p: 3, borderRadius: 2 }}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Box>
                <Typography variant="subtitle1" fontWeight="bold">30-Day Compliance Trend</Typography>
                <Typography variant="caption" color="text.secondary">Percentage of servers passing all checks</Typography>
              </Box>
            </Box>
            {trend.length === 0 ? (
              <Box py={4} textAlign="center"><Typography variant="body2" color="text.secondary">No trend data</Typography></Box>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={trend} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                  <defs>
                    <linearGradient id="complianceGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={rateColor} stopOpacity={0.2} />
                      <stop offset="95%" stopColor={rateColor} stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} tickLine={false}
                    interval={Math.floor(trend.length / 6)} />
                  <YAxis domain={[60, 100]} tick={{ fontSize: 11 }} tickLine={false}
                    tickFormatter={(v) => `${v}%`} />
                  <Tooltip content={<TrendTooltip />} />
                  <Area type="monotone" dataKey="compliance_rate" stroke={rateColor} strokeWidth={2}
                    fill="url(#complianceGradient)" dot={false} activeDot={{ r: 4 }} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </Paper>
        </Grid>

        {/* Agent health */}
        <Grid item xs={12} md={4}>
          <Paper elevation={0} variant="outlined" sx={{ p: 3, borderRadius: 2, height: '100%' }}>
            <Typography variant="subtitle1" fontWeight="bold" mb={0.5}>Agent Fleet Health</Typography>
            <Typography variant="caption" color="text.secondary" display="block" mb={2}>
              {health.total} total agents
            </Typography>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={agentBarData} layout="vertical" margin={{ left: 10, right: 20 }}>
                <XAxis type="number" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} width={55} />
                <Tooltip formatter={(v: any) => [v, 'Agents']} />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  {agentBarData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <Divider sx={{ my: 2 }} />
            <Box display="flex" justifyContent="space-around">
              {agentBarData.map((d) => (
                <Box key={d.name} textAlign="center">
                  <Typography variant="h6" fontWeight="bold" color={d.color}>{d.value}</Typography>
                  <Typography variant="caption" color="text.secondary">{d.name}</Typography>
                </Box>
              ))}
            </Box>
          </Paper>
        </Grid>
      </Grid>

      {/* Recent drift events */}
      <Paper elevation={0} variant="outlined" sx={{ p: 3, borderRadius: 2 }}>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
          <Box>
            <Typography variant="subtitle1" fontWeight="bold">Recent Drift Events</Typography>
            <Typography variant="caption" color="text.secondary">Latest configuration deviations across your fleet</Typography>
          </Box>
          <Button size="small" variant="outlined" onClick={() => history.push(POLICYOPS_PATH.DRIFT)}>
            View All Drift
          </Button>
        </Box>

        {driftEvents.length === 0 ? (
          <Box py={3} textAlign="center">
            <CheckCircle size={32} color="#10b981" />
            <Typography variant="body2" color="text.secondary" mt={1}>No drift events — fleet is compliant</Typography>
          </Box>
        ) : (
          <Box>
            {/* Severity breakdown */}
            {(() => {
              const bySeverity = driftEvents.reduce((acc: any, e: any) => {
                acc[e.severity] = (acc[e.severity] ?? 0) + 1; return acc
              }, {})
              return (
                <Box display="flex" gap={1.5} mb={2} flexWrap="wrap">
                  {['critical', 'high', 'medium', 'low'].map((sev) =>
                    bySeverity[sev] ? (
                      <Box key={sev} display="flex" alignItems="center" gap={0.5}>
                        <Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: SEVERITY_COLORS[sev] }} />
                        <Typography variant="body2" color="text.secondary">
                          {bySeverity[sev]} {sev}
                        </Typography>
                      </Box>
                    ) : null
                  )}
                </Box>
              )
            })()}

            {driftEvents.slice(0, 6).map((event: any) => (
              <Box key={event._id} display="flex" alignItems="center" gap={2} py={1.25}
                borderBottom="1px solid" borderColor="divider"
                sx={{ cursor: 'pointer', '&:hover': { bgcolor: 'action.hover' }, borderRadius: 0.5 }}
                onClick={() => history.push(POLICYOPS_PATH.DRIFT)}>
                <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: SEVERITY_COLORS[event.severity], flexShrink: 0 }} />
                <Box flex={1} minWidth={0}>
                  <Box display="flex" alignItems="center" gap={1}>
                    <Typography variant="body2" fontWeight={500} noWrap>{event.rule_id}</Typography>
                    <Typography variant="body2" color="text.secondary">on</Typography>
                    <Typography variant="body2" fontWeight={500} color="primary" noWrap>{event.hostname}</Typography>
                  </Box>
                </Box>
                <Box display="flex" gap={1} alignItems="center" flexShrink={0}>
                  <Chip label={event.status} size="small" color={DRIFT_STATUS_COLORS[event.status] ?? 'default'}
                    sx={{ height: 20, fontSize: '0.65rem' }} />
                  <Typography variant="caption" color="text.secondary" sx={{ minWidth: 80, textAlign: 'right' }}>
                    {dayjs(event.detected_at).fromNow()}
                  </Typography>
                </Box>
              </Box>
            ))}
          </Box>
        )}
      </Paper>
    </Box>
  )
}

export default CompliancePage
