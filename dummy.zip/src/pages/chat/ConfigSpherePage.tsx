import React, { useState } from "react";
import "./ConfigSpherePage.scss";
import Cookies from "universal-cookie";

/* ✅ TYPES */
interface Message {
    type: "text" | "html";
    role: "user" | "assistant";
    content: string;
}

interface Chat {
    id: string;
    title: string;
    messages: Message[];
}

/* ✅ AI CARD HTML */
const aiInsightHTML = `
<div class="ai-insight-card">
  <h3>📊 Non-Compliance Trend (Last 30 Days)</h3>

  <p>
    Non-compliance has decreased by
    <b style="color:#16a34a;">18%</b>
    over the last 30 days.
  </p>

  <div class="stats-row">
    <div class="stat">
      <div class="value">127</div>
      <div class="label">Servers</div>
    </div>
    <div class="stat">
      <div class="value">341</div>
      <div class="label">Drifts</div>
    </div>
    <div class="stat">
      <div class="value">92.4%</div>
      <div class="label">Score</div>
    </div>
  </div>

  <h4>⚠️ Major Contributors</h4>
  <ul style="padding: 16px;">
    <li><b>SSH Hardening Policy</b> - 84 violations</li>
    <li><b>Audit Logging Policy</b> - 62 violations</li>
    <li><b>Certificate Management</b> - 39 violations</li>
  </ul>

  <h4>💡 Recommendations</h4>
  <ul style="padding: 16px;">
    <li>Review SSH Hardening assignments in SAP Production.</li>
    <li>Trigger remediation for drifted servers.</li>
    <li>Renew certificates expiring within 15 days.</li>
  </ul>

  <div class="actions">
    <button class="btn-secondary">View Violations</button>
    <button class="btn-primary">Run Remediation</button>
    <button class="btn-secondary">Export Report</button>
  </div>
</div>
`;

const aiRemediationHTML = `
<div class="ai-card">
  <h3>
    ⚙️ Remediation Triggered
    <span class="status-badge">In Progress</span>
  </h3>

  <p>
    Dispatching the SSH configuration update across all target nodes.
  </p>

  <ul class="execution-details">
    <li><span class="label">Target:</span> SAP Production (84 servers)</li>
    <li><span class="label">Policy:</span> SSH_Hardening_v2.1</li>
    <li><span class="label">Mechanism:</span> Framework Agent</li>
  </ul>

  <div class="terminal-block">
    <div>[19:41:26] Initiating deployment...</div>
    <div>[19:41:27] Dispatching agents...</div>
    <div>[19:41:28] Applying config... (12/84)</div>
  </div>
</div>
`;

const initialChats: Chat[] = [
  {
    id: "1",
    title: "New Chat",
    messages: [] 
  },
  {
    id: "2",
    title: "Non‑Compliance Trend Analysis",
    messages: [
      {
        type: "text",
        role: "user",
        content:
          "Show me the non-compliance trend for the last 30 days and identify the major contributors."
      },
      {
        type: "html",
        role: "assistant",
        content: aiInsightHTML
      },
      {
        type: "text",
        role: "user",
        content:
          "Run remediation for the SSH Hardening Policy on the 84 drifted SAP Production servers."
      },
      {
        type: "html",
        role: "assistant",
        content: aiRemediationHTML
      }
    ]
  }
];



// ─── Icons (inline SVGs, no external icon lib needed) ───────────────────────

const IconGrid = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="7" height="7" rx="1" />
        <rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" />
        <rect x="14" y="14" width="7" height="7" rx="1" />
    </svg>
);

const IconChart = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
    </svg>
);

const IconMonitor = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="3" width="20" height="14" rx="2" />
        <line x1="8" y1="21" x2="16" y2="21" />
        <line x1="12" y1="17" x2="12" y2="21" />
    </svg>
);

const IconChat = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
);

const IconFile = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
        <polyline points="14 2 14 8 20 8" />
    </svg>
);

const IconHistory = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <polyline points="1 4 1 10 7 10" />
        <path d="M3.51 15a9 9 0 1 0 .49-4.95" />
        <line x1="12" y1="7" x2="12" y2="12" />
        <line x1="12" y1="12" x2="15" y2="14" />
    </svg>
);

const IconUser = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
);

const IconBell = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
        <path d="M13.73 21a2 2 0 0 1-3.46 0" />
    </svg>
);

const IconHelp = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" />
        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
        <line x1="12" y1="17" x2="12.01" y2="17" />
    </svg>
);

const IconPlus = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
        <line x1="12" y1="5" x2="12" y2="19" />
        <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
);

const IconMic = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
        <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
        <line x1="12" y1="19" x2="12" y2="23" />
        <line x1="8" y1="23" x2="16" y2="23" />
    </svg>
);

const IconSend = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
        <line x1="22" y1="2" x2="11" y2="13" />
        <polygon points="22 2 15 22 11 13 2 9 22 2" />
    </svg>
);

const IconChevronsRight = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
        <polyline points="13 17 18 12 13 7" />
        <polyline points="6 17 11 12 6 7" />
    </svg>
);

// Suggestion card icon variants
const IconShield = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
);

const IconSearch = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <circle cx="11" cy="11" r="8" />
        <line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
);

const IconSettings = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
);

const IconTag = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" />
        <line x1="7" y1="7" x2="7.01" y2="7" />
    </svg>
);

const IconAlertCircle = () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" />
        <line x1="12" y1="8" x2="12" y2="12" />
        <line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
);

// ─── Types ────────────────────────────────────────────────────────────────────

interface SuggestionItem {
    id: string;
    label: string;
    icon: React.ReactNode;
}

interface SidebarNavItem {
    id: string;
    icon: React.ReactNode;
    active?: boolean;
}

// ─── Static Data ─────────────────────────────────────────────────────────────

const sidebarNavItems: SidebarNavItem[] = [
    { id: "dashboard", icon: <IconGrid /> },
    { id: "analytics", icon: <IconChart /> },
    { id: "monitor", icon: <IconMonitor /> },
    { id: "chat", icon: <IconChat />, active: true },
    { id: "reports", icon: <IconFile /> },
    { id: "history", icon: <IconHistory /> },
    { id: "users", icon: <IconUser /> },
];

const suggestions: SuggestionItem[][] = [
    [
        { id: "non-compliant", label: "Show non-compliant systems", icon: <IconShield /> },
        { id: "drift-events", label: "Investigate recent drift events", icon: <IconSearch /> },
        { id: "auto-remediation", label: "Show auto-remediation activity", icon: <IconSettings /> },
    ],
    [
        { id: "policies-prod", label: "Find policies assigned to production", icon: <IconTag /> },
        { id: "failed-exec", label: "Analyze failed executions", icon: <IconAlertCircle /> },
    ],
];
interface SuggestionCardProps {
    item: SuggestionItem;
    onClick: (label: string) => void;
}

const SuggestionCard: React.FC<SuggestionCardProps> = ({ item, onClick }) => (
    <button
        className="cs-suggestion-card"
        onClick={() => onClick(item.label)}
        aria-label={item.label}
    >
        <span className="cs-suggestion-card__icon">{item.icon}</span>
        <span className="cs-suggestion-card__label">{item.label}</span>
    </button>
);

const InputBar: React.FC<{
    value: string;
    onChange: (v: string) => void;
    onSend: () => void;
}> = ({ value, onChange, onSend }) => (
    <div className="cs-input-bar">
        <div className="cs-input-bar__inner">
            <button className="cs-input-bar__plus-btn" aria-label="Attach">
                <IconPlus />
            </button>
            <input
                className="cs-input-bar__input"
                type="text"
                placeholder="Ask about anything..."
                value={value}
                onChange={(e) => onChange(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && onSend()}
            />
            <button className="cs-input-bar__mic-btn" aria-label="Voice input">
                <IconMic />
            </button>
            <button className="cs-input-bar__send-btn" aria-label="Send" onClick={onSend}>
                <IconSend />
            </button>
        </div>
    </div>
);

// ─── Main Component ───────────────────────────────────────────────────────────

const ConfigSphere: React.FC = () => {
    const cookies = new Cookies();

    const [inputValue, setInputValue] = useState("");
    const [chats, setChats] = useState(initialChats);
    const [activeChatId, setActiveChatId] = useState("1");

    const activeChat = chats.find(c => c.id === activeChatId);
    const fullName: string = cookies.get('user_fullname') ?? '';

    const handleSuggestionClick = (label: string) => {
        setInputValue(label);
    };

    const handleSend = () => {
        if (!inputValue.trim()) return;

        const userMessage: Message = {
            type: "text",
            role: "user",
            content: inputValue
        };

        let botResponse: Message = {
            type: "text",
            role: "assistant",
            content: "Let me check that for you..."
        };

        if (inputValue.toLowerCase().includes("non-compliance trend")) {
            botResponse = {
                type: "html",
                role: "assistant",
                content: aiInsightHTML
            };
        }

        setChats(prev =>
            prev.map(chat =>
                chat.id === activeChatId
                    ? {
                        ...chat,
                        messages: [...chat.messages, userMessage, botResponse]
                    }
                    : chat
            )
        );

        setInputValue("");
    };



    return (
        <div className="cs-root">

            <div className="cs-body">

                {/* ✅ NEW CHAT SIDEBAR */}
                <aside className="cs-chat-sidebar">
                    <div className="cs-chat-sidebar__header">
                        <h3>ConfigSphere Assistant</h3>
                    </div>

                    <div className="cs-chat-sidebar__section">
                        <div className="cs-chat-sidebar__section-title">
                            Recent Chats
                        </div>

                        <ul className="cs-chat-sidebar__list">
                            {chats.map(chat => (
                                <li
                                    key={chat.id}
                                    className={chat.id === activeChatId ? "active" : ""}
                                    onClick={() => setActiveChatId(chat.id)}
                                >
                                    <span className="dot"></span>
                                    {chat.title}
                                </li>
                            ))}
                        </ul>

                    </div>
                </aside>

                {/* ✅ MAIN */}
                <main className="cs-main">

                    <div className="cs-chat">

                        {/* ✅ IF EMPTY CHAT → SHOW WELCOME */}
                        {activeChat?.messages.length === 0 ? (
                            <>
                                <div className="cs-welcome">
                                    <h1 className="cs-welcome__greeting">Hi {fullName}</h1>
                                    <h2 className="cs-welcome__headline">
                                        How can I help you today?
                                    </h2>
                                    <p className="cs-welcome__subtext">
                                        Ask about compliance, infrastructure health, and policy
                                        operations — or pick a quick suggestion below to get started.
                                    </p>
                                </div>

                                <div className="cs-suggestions">
                                    {suggestions.map((row, rowIndex) => (
                                        <div
                                            key={rowIndex}
                                            className={`cs-suggestions__row ${rowIndex === 1 ? "cs-suggestions__row--center" : ""
                                                }`}
                                        >
                                            {row.map(item => (
                                                <SuggestionCard
                                                    key={item.id}
                                                    item={item}
                                                    onClick={handleSuggestionClick}
                                                />
                                            ))}
                                        </div>
                                    ))}
                                </div>
                            </>
                        ) : activeChat ? (
                            /* ✅ IF CHAT EXISTS → SHOW CHAT UI */
                            <div className="cs-conversation">
                                {activeChat.messages.map((msg, i) => (
                                    <div
                                        key={i}
                                        className={`cs-message ${msg.role === "user"
                                                ? "cs-message--right"
                                                : "cs-message--left"
                                            }`}
                                    >
                                        {msg.type === "html" ? (
                                            <div
                                                className="cs-html-card"
                                                dangerouslySetInnerHTML={{ __html: msg.content }}
                                            />
                                        ) : (
                                            <div className="cs-message__bubble">
                                                {msg.content}
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>

                        ) : null}

                    </div>

                    <InputBar
                        value={inputValue}
                        onChange={setInputValue}
                        onSend={handleSend}
                    />
                </main>
            </div>
        </div>
    );
};

export default ConfigSphere;