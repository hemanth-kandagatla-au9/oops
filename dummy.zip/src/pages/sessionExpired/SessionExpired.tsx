import React from "react";
import { Box, Typography, Button } from "@mui/material";
import { useHistory } from "react-router-dom";
import { POLICYOPS_PATH } from "../../utils/constant";

const SessionExpiredPage: React.FC = () => {
  const history = useHistory();

  return (
    <Box display="flex" flexDirection="column" justifyContent="center" alignItems="center" height="100vh">
      <Typography variant="h4" gutterBottom>
        Session Expired
      </Typography>
      <Typography variant="body1" color="text.secondary" mb={3}>
        Your session has expired. Please log in again.
      </Typography>
      <Button variant="contained" onClick={() => history.push(POLICYOPS_PATH.ROOT)}>
        Log In Again
      </Button>
    </Box>
  );
};

export default SessionExpiredPage;
