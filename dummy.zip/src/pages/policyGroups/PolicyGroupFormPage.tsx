import React, { useState, useEffect, useMemo, useCallback } from 'react'
import {
  Box, Typography, Button, TextField, Chip, CircularProgress, Alert,
  Paper, Grid, Autocomplete, IconButton, InputAdornment,
  List, ListItemButton, ListItemText, ListItemSecondaryAction,
} from '@mui/material'
import { ArrowLeft, Save, GripVertical, X, Plus, Search, Eye } from 'lucide-react'
import { useHistory, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import {
  DndContext, closestCenter, PointerSensor, KeyboardSensor,
  useSensor, useSensors, DragEndEvent,
} from '@dnd-kit/core'
import {
  SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy,
  useSortable, arrayMove,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import {
  useGetPolicyGroupByIdQuery,
  useCreatePolicyGroupMutation,
  useUpdatePolicyGroupMutation,
} from '../../redux/slices/policyGroupsSlice'
import { useGetPoliciesQuery } from '../../redux/slices/policiesSlice'
import { POLICYOPS_PATH } from '../../utils/constant'
import { Policy, PolicyGroupPolicy } from '../../types'

const STATUS_COLORS: Record<string, any> = { draft: 'default', published: 'success', archived: 'error' }

// ── Sortable policy row ──────────────────────────────────────────────────────
interface SortablePolicyRowProps {
  item: PolicyGroupPolicy & { policyData?: Policy }
  index: number
  onRemove: (policyId: string) => void
  onNavigate: (policyId: string) => void
}

const SortablePolicyRow: React.FC<SortablePolicyRowProps> = ({ item, index, onRemove, onNavigate }) => {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: item.policy_id })
  const style = { transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1 }

  return (
    <Paper ref={setNodeRef} style={style} elevation={isDragging ? 4 : 0}
      variant={isDragging ? 'elevation' : 'outlined'} sx={{ mb: 1, borderRadius: 1.5 }}>
      <Box display="flex" alignItems="center" gap={1.5} p={1.5}>
        <Box {...attributes} {...listeners} sx={{ cursor: 'grab', color: 'text.disabled', display: 'flex', alignItems: 'center', flexShrink: 0 }}>
          <GripVertical size={18} />
        </Box>
        <Box sx={{ width: 24, height: 24, borderRadius: '50%', bgcolor: 'secondary.main', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Typography variant="caption" color="white" fontWeight="bold" lineHeight={1}>{index + 1}</Typography>
        </Box>
        <Box flex={1} minWidth={0}>
          <Box display="flex" alignItems="center" gap={1} flexWrap="wrap">
            <Typography variant="body2" fontWeight={500} noWrap>{item.policyData?.name ?? item.policy_id}</Typography>
            <Chip label={`v${item.policy_version}`} size="small" variant="outlined" sx={{ height: 18, fontSize: '0.65rem', flexShrink: 0 }} />
            {item.policyData && (
              <Chip label={item.policyData.status} size="small" color={STATUS_COLORS[item.policyData.status]} sx={{ height: 18, fontSize: '0.65rem', flexShrink: 0 }} />
            )}
            {item.policyData && (
              <Chip label={`${item.policyData.rules?.length ?? 0} rules`} size="small" variant="outlined" sx={{ height: 18, fontSize: '0.65rem', flexShrink: 0 }} />
            )}
          </Box>
        </Box>
        <Box display="flex" gap={0.5} flexShrink={0}>
          <IconButton size="small" onClick={() => onNavigate(item.policyData?._id ?? item.policy_id)}><Eye size={14} /></IconButton>
          <IconButton size="small" color="error" onClick={() => onRemove(item.policy_id)}><X size={14} /></IconButton>
        </Box>
      </Box>
    </Paper>
  )
}

// ── Main form ────────────────────────────────────────────────────────────────
const PolicyGroupFormPage: React.FC = () => {
  const { id } = useParams<{ id?: string }>()
  const isEdit = !!id
  const history = useHistory()

  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [tags, setTags] = useState<string[]>([])
  const [selectedPolicies, setSelectedPolicies] = useState<(PolicyGroupPolicy & { policyData?: Policy })[]>([])
  const [policySearch, setPolicySearch] = useState('')

  const { data: groupData, isLoading: loadingGroup } = useGetPolicyGroupByIdQuery(id!, { skip: !isEdit })
  const { data: policiesData } = useGetPoliciesQuery({ page: 1, limit: 100, status: 'published' })
  const [createGroup, { isLoading: creating }] = useCreatePolicyGroupMutation()
  const [updateGroup, { isLoading: updating }] = useUpdatePolicyGroupMutation()

  const publishedPolicies: Policy[] = policiesData?.data ?? []

  useEffect(() => {
    const group = groupData?.data
    if (!group) return
    setName(group.name)
    setDescription(group.description)
    setTags(group.tags ?? [])
    const sorted = [...(group.policies ?? [])].sort((a: any, b: any) => a.order - b.order)
    setSelectedPolicies(sorted.map((gp: PolicyGroupPolicy) => ({
      ...gp,
      policyData: publishedPolicies.find((p) => p.policy_id === gp.policy_id || p._id === gp.policy_id),
    })))
  }, [groupData, publishedPolicies])

  useEffect(() => {
    if (publishedPolicies.length === 0) return
    setSelectedPolicies((prev) =>
      prev.map((gp) => ({
        ...gp,
        policyData: publishedPolicies.find((p) => p.policy_id === gp.policy_id || p._id === gp.policy_id) ?? gp.policyData,
      }))
    )
  }, [publishedPolicies])

  const filteredAvailable = useMemo(() => {
    const addedIds = new Set(selectedPolicies.map((p) => p.policy_id))
    return publishedPolicies.filter((p) => {
      if (addedIds.has(p.policy_id) || addedIds.has(p._id)) return false
      if (policySearch && !p.name.toLowerCase().includes(policySearch.toLowerCase())) return false
      return true
    })
  }, [publishedPolicies, selectedPolicies, policySearch])

  const addPolicy = useCallback((policy: Policy) => {
    setSelectedPolicies((prev) => [
      ...prev,
      { policy_id: policy.policy_id, policy_version: policy.version, order: prev.length + 1, policyData: policy },
    ])
  }, [])

  const removePolicy = useCallback((policyId: string) => {
    setSelectedPolicies((prev) => prev.filter((p) => p.policy_id !== policyId))
  }, [])

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  )

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event
    if (over && active.id !== over.id) {
      setSelectedPolicies((items) => {
        const oldIdx = items.findIndex((i) => i.policy_id === active.id)
        const newIdx = items.findIndex((i) => i.policy_id === over.id)
        return arrayMove(items, oldIdx, newIdx)
      })
    }
  }

  const handleSubmit = async () => {
    if (!name.trim()) { toast.error('Group name is required'); return }

    const payload = {
      name: name.trim(),
      description: description.trim(),
      tags,
      policies: selectedPolicies.map((p, idx) => ({
        policy_id: p.policy_id,
        policy_version: p.policy_version,
        order: idx + 1,
      })),
    }

    try {
      if (isEdit) {
        await updateGroup({ id: id!, data: payload }).unwrap()
        toast.success('Policy group updated')
        history.push(`${POLICYOPS_PATH.POLICY_GROUPS}/${id}`)
      } else {
        const result = await createGroup(payload).unwrap()
        toast.success('Policy group created as draft')
        history.push(`${POLICYOPS_PATH.POLICY_GROUPS}/${result.data._id}`)
      }
    } catch {
      toast.error('Save failed. Please try again.')
    }
  }

  if (isEdit && loadingGroup) return <Box p={3}><CircularProgress /></Box>
  if (isEdit && !groupData?.data) return <Box p={3}><Alert severity="error">Policy group not found</Alert></Box>

  const isSaving = creating || updating

  return (
    <Box p={3}>
      {/* Breadcrumb */}
      <Box display="flex" alignItems="center" gap={1} mb={3}>
        <IconButton size="small" onClick={() => history.goBack()}><ArrowLeft size={18} /></IconButton>
        <Typography variant="body2" color="text.secondary" sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}
          onClick={() => history.push(POLICYOPS_PATH.POLICY_GROUPS)}>Policy Groups</Typography>
        <Typography variant="body2" color="text.secondary">/</Typography>
        <Typography variant="body2">{isEdit ? 'Edit Group' : 'Create Group'}</Typography>
      </Box>

      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h5" fontWeight="bold">{isEdit ? 'Edit Policy Group' : 'Create Policy Group'}</Typography>
          <Typography variant="body2" color="text.secondary">Bundle published policies into an ordered group for assignment</Typography>
        </Box>
        <Box display="flex" gap={1.5}>
          <Button variant="outlined" onClick={() => history.goBack()}>Cancel</Button>
          <Button variant="contained" startIcon={<Save size={16} />} onClick={handleSubmit} disabled={isSaving}>
            {isSaving ? 'Saving...' : isEdit ? 'Save Changes' : 'Save as Draft'}
          </Button>
        </Box>
      </Box>

      <Grid container spacing={3}>
        {/* Left — basic info + policy picker */}
        <Grid item xs={12} md={4}>
          <Paper elevation={0} variant="outlined" sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="subtitle2" fontWeight="bold" mb={2} color="text.secondary" textTransform="uppercase" letterSpacing={0.5}>
              Basic Info
            </Typography>
            <TextField fullWidth size="small" label="Name *" value={name} onChange={(e) => setName(e.target.value)} sx={{ mb: 2 }} />
            <TextField fullWidth size="small" label="Description" value={description}
              onChange={(e) => setDescription(e.target.value)} multiline rows={3} sx={{ mb: 2 }} />
            <Autocomplete multiple freeSolo options={[]} value={tags}
              onChange={(_, v) => setTags(v as string[])}
              renderTags={(value, getTagProps) =>
                value.map((option, index) => (
                  <Chip variant="outlined" label={option} size="small" {...getTagProps({ index })} key={option} />
                ))
              }
              renderInput={(params) => <TextField {...params} size="small" label="Tags" placeholder="Type and press Enter" />}
            />
          </Paper>

          <Paper elevation={0} variant="outlined" sx={{ p: 3, borderRadius: 2, mt: 2 }}>
            <Typography variant="subtitle2" fontWeight="bold" mb={1.5} color="text.secondary" textTransform="uppercase" letterSpacing={0.5}>
              Available Published Policies
            </Typography>
            <TextField fullWidth size="small" placeholder="Search policies..."
              value={policySearch} onChange={(e) => setPolicySearch(e.target.value)}
              InputProps={{ startAdornment: <InputAdornment position="start"><Search size={14} /></InputAdornment> }}
              sx={{ mb: 1 }}
            />
            <Box sx={{ maxHeight: 300, overflowY: 'auto' }}>
              {filteredAvailable.length === 0 ? (
                <Typography variant="body2" color="text.secondary" py={2} textAlign="center">
                  {policySearch ? 'No matching policies' : 'All published policies added'}
                </Typography>
              ) : (
                <List dense disablePadding>
                  {filteredAvailable.map((policy) => (
                    <ListItemButton key={policy._id} onClick={() => addPolicy(policy)}
                      sx={{ borderRadius: 1, mb: 0.5, border: '1px solid', borderColor: 'divider' }}>
                      <ListItemText
                        primary={<Typography variant="body2" fontWeight={500}>{policy.name}</Typography>}
                        secondary={
                          <Box display="flex" gap={0.5} mt={0.25}>
                            <Chip label={`v${policy.version}`} size="small" variant="outlined" sx={{ height: 16, fontSize: '0.6rem' }} />
                            <Chip label={`${policy.rules?.length ?? 0} rules`} size="small" variant="outlined" sx={{ height: 16, fontSize: '0.6rem' }} />
                          </Box>
                        }
                      />
                      <ListItemSecondaryAction>
                        <IconButton size="small" color="primary" onClick={() => addPolicy(policy)}><Plus size={14} /></IconButton>
                      </ListItemSecondaryAction>
                    </ListItemButton>
                  ))}
                </List>
              )}
            </Box>
          </Paper>
        </Grid>

        {/* Right — policy order */}
        <Grid item xs={12} md={8}>
          <Paper elevation={0} variant="outlined" sx={{ p: 3, borderRadius: 2, minHeight: 400 }}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="subtitle2" fontWeight="bold" color="text.secondary" textTransform="uppercase" letterSpacing={0.5}>
                Group Policies ({selectedPolicies.length})
              </Typography>
              {selectedPolicies.length > 0 && (
                <Typography variant="caption" color="text.secondary">Drag to reorder</Typography>
              )}
            </Box>

            {selectedPolicies.length === 0 ? (
              <Box py={6} textAlign="center" border="2px dashed" borderColor="divider" borderRadius={2}>
                <Typography variant="body2" color="text.secondary">
                  Add policies from the panel on the left
                </Typography>
              </Box>
            ) : (
              <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                <SortableContext items={selectedPolicies.map((p) => p.policy_id)} strategy={verticalListSortingStrategy}>
                  {selectedPolicies.map((item, idx) => (
                    <SortablePolicyRow
                      key={item.policy_id}
                      item={item}
                      index={idx}
                      onRemove={removePolicy}
                      onNavigate={(polId) => history.push(`${POLICYOPS_PATH.POLICIES}/${polId}`)}
                    />
                  ))}
                </SortableContext>
              </DndContext>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  )
}

export default PolicyGroupFormPage
