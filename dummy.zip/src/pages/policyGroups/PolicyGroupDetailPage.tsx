import React, { useState, useMemo } from 'react'
import {
  Box, Typography, Button, Chip, CircularProgress, Alert, Paper,
  Grid, Tab, Tabs, IconButton, Dialog, DialogTitle,
  DialogContent, DialogContentText, DialogActions,
} from '@mui/material'
import { ArrowLeft, Edit2, Copy, CheckCircle, Archive } from 'lucide-react'
import { useHistory, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import dayjs from 'dayjs'
import Editor from '@monaco-editor/react'
import {
  useGetPolicyGroupByIdQuery,
  usePublishPolicyGroupMutation,
  useArchivePolicyGroupMutation,
  useClonePolicyGroupMutation,
} from '../../redux/slices/policyGroupsSlice'
import { useGetPoliciesQuery } from '../../redux/slices/policiesSlice'
import { useGetRulesQuery } from '../../redux/slices/rulesSlice'
import DetailSkeleton from '../../components/DetailSkeleton'
import { POLICYOPS_PATH } from '../../utils/constant'
import { Policy, Rule } from '../../types'

const STATUS_COLORS: Record<string, any> = { draft: 'default', published: 'success', archived: 'error' }

interface TabPanelProps { children?: React.ReactNode; value: number; index: number }
const TabPanel: React.FC<TabPanelProps> = ({ children, value, index }) => (
  <Box hidden={value !== index} pt={3}>{value === index && children}</Box>
)

const PolicyGroupDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>()
  const history = useHistory()
  const [tab, setTab] = useState(0)
  const [confirmAction, setConfirmAction] = useState<'publish' | 'archive' | null>(null)

  const { data, isLoading, isError } = useGetPolicyGroupByIdQuery(id)
  const { data: policiesData } = useGetPoliciesQuery({ page: 1, limit: 100 })
  const { data: rulesData } = useGetRulesQuery({ page: 1, limit: 100 })
  const [publishGroup, { isLoading: publishing }] = usePublishPolicyGroupMutation()
  const [archiveGroup, { isLoading: archiving }] = useArchivePolicyGroupMutation()
  const [cloneGroup] = useClonePolicyGroupMutation()

  const group = data?.data
  const allPolicies: Policy[] = policiesData?.data ?? []
  const allRules: Rule[] = rulesData?.data ?? []

  const resolvedPolicies = useMemo(() => {
    if (!group?.policies) return []
    return [...group.policies]
      .sort((a: any, b: any) => a.order - b.order)
      .map((gp: any) => ({
        ...gp,
        policyData: allPolicies.find((p) => p.policy_id === gp.policy_id || p._id === gp.policy_id),
      }))
  }, [group, allPolicies])

  const compiledPreview = useMemo(() => {
    if (!group) return null
    return {
      group_id: group.group_id,
      group_version: group.version,
      name: group.name,
      description: group.description,
      compiled_at: new Date().toISOString(),
      policies: resolvedPolicies.map((gp: any, idx: number) => {
        const policy: Policy | undefined = gp.policyData
        const policyRules = (policy?.rules ?? [])
          .slice()
          .sort((a: any, b: any) => a.order - b.order)
          .map((pr: any) => {
            const ruleData = allRules.find((r) => r.rule_id === pr.rule_id || r._id === pr.rule_id)
            return {
              order: pr.order,
              rule_id: pr.rule_id,
              rule_version: pr.rule_version,
              name: ruleData?.name ?? pr.rule_id,
              rule_type: ruleData?.rule_type,
              severity: ruleData?.severity,
              definition: ruleData?.definition ?? {},
              execution: ruleData?.execution ?? {},
            }
          })
        return {
          order: idx + 1,
          policy_id: gp.policy_id,
          policy_version: gp.policy_version,
          name: policy?.name ?? gp.policy_id,
          rules: policyRules,
        }
      }),
    }
  }, [group, resolvedPolicies, allRules])

  const handlePublish = async () => {
    setConfirmAction(null)
    try { await publishGroup(id).unwrap(); toast.success(`"${group.name}" published`) }
    catch { toast.error('Publish failed.') }
  }

  const handleArchive = async () => {
    setConfirmAction(null)
    try { await archiveGroup(id).unwrap(); toast.success(`"${group.name}" archived`) }
    catch { toast.error('Archive failed.') }
  }

  const handleClone = async () => {
    try { await cloneGroup(id).unwrap(); toast.success(`"${group.name}" cloned as draft`) }
    catch { toast.error('Clone failed.') }
  }

  if (isLoading) return <DetailSkeleton />
  if (isError || !group) return <Box p={3}><Alert severity="error">Policy group not found</Alert></Box>

  const totalRules = resolvedPolicies.reduce((sum: number, gp: any) => sum + (gp.policyData?.rules?.length ?? 0), 0)

  return (
    <Box p={3}>
      {/* Breadcrumb */}
      <Box display="flex" alignItems="center" gap={1} mb={2}>
        <IconButton size="small" onClick={() => history.push(POLICYOPS_PATH.POLICY_GROUPS)}><ArrowLeft size={18} /></IconButton>
        <Typography variant="body2" color="text.secondary" sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}
          onClick={() => history.push(POLICYOPS_PATH.POLICY_GROUPS)}>Policy Groups</Typography>
        <Typography variant="body2" color="text.secondary">/</Typography>
        <Typography variant="body2">{group.name}</Typography>
      </Box>

      {/* Header */}
      <Paper elevation={0} variant="outlined" sx={{ p: 3, mb: 3, borderRadius: 2 }}>
        <Box display="flex" justifyContent="space-between" alignItems="flex-start" flexWrap="wrap" gap={2}>
          <Box>
            <Box display="flex" alignItems="center" gap={1.5} mb={1} flexWrap="wrap">
              <Typography variant="h5" fontWeight="bold">{group.name}</Typography>
              <Chip label={group.status} size="small" color={STATUS_COLORS[group.status] ?? 'default'} />
              <Chip label={`v${group.version}`} size="small" variant="outlined" />
              <Chip label={`${group.policies?.length ?? 0} policies`} size="small" variant="outlined" />
              <Chip label={`${totalRules} rules`} size="small" variant="outlined" />
            </Box>
            <Typography variant="body2" color="text.secondary" mb={1}>{group.description}</Typography>
            <Box display="flex" gap={0.5} flexWrap="wrap">
              {(group.tags ?? []).map((tag: string) => (
                <Chip key={tag} label={tag} size="small" variant="outlined" sx={{ fontSize: '0.7rem' }} />
              ))}
            </Box>
          </Box>
          <Box display="flex" gap={1} flexWrap="wrap">
            {group.status === 'draft' && (
              <Button variant="outlined" startIcon={<Edit2 size={15} />}
                onClick={() => history.push(`${POLICYOPS_PATH.POLICY_GROUPS}/${id}/edit`)}>Edit</Button>
            )}
            <Button variant="outlined" startIcon={<Copy size={15} />} onClick={handleClone}>Clone</Button>
            {group.status === 'draft' && (
              <Button variant="contained" color="success" startIcon={<CheckCircle size={15} />}
                onClick={() => setConfirmAction('publish')}>Publish</Button>
            )}
            {group.status === 'published' && (
              <Button variant="outlined" color="warning" startIcon={<Archive size={15} />}
                onClick={() => setConfirmAction('archive')}>Archive</Button>
            )}
          </Box>
        </Box>
      </Paper>

      {/* Tabs */}
      <Paper elevation={0} variant="outlined" sx={{ borderRadius: 2 }}>
        <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ px: 2, borderBottom: '1px solid', borderColor: 'divider' }}>
          <Tab label="Overview" />
          <Tab label={`Policies (${group.policies?.length ?? 0})`} />
          <Tab label="Compile Preview" />
        </Tabs>

        <Box px={3} pb={3}>
          {/* Overview */}
          <TabPanel value={tab} index={0}>
            <Grid container spacing={4}>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" fontWeight="bold" mb={1.5} color="text.secondary" textTransform="uppercase" letterSpacing={0.5}>General</Typography>
                {[
                  ['Group ID', group.group_id],
                  ['Version', `v${group.version}`],
                  ['Status', group.status],
                  ['Policies', group.policies?.length ?? 0],
                  ['Total rules', totalRules],
                ].map(([label, value]) => (
                  <Box key={label as string} display="flex" py={1.5} borderBottom="1px solid" borderColor="divider">
                    <Typography variant="body2" color="text.secondary" sx={{ minWidth: 150, fontWeight: 500 }}>{label}</Typography>
                    <Typography variant="body2">{String(value)}</Typography>
                  </Box>
                ))}
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" fontWeight="bold" mb={1.5} color="text.secondary" textTransform="uppercase" letterSpacing={0.5}>Audit</Typography>
                {[
                  ['Created By', group.created_by],
                  ['Created At', dayjs(group.created_at).format('MMM D, YYYY HH:mm')],
                  ['Updated At', dayjs(group.updated_at).format('MMM D, YYYY HH:mm')],
                  ['Published At', group.published_at ? dayjs(group.published_at).format('MMM D, YYYY HH:mm') : '—'],
                ].map(([label, value]) => (
                  <Box key={label as string} display="flex" py={1.5} borderBottom="1px solid" borderColor="divider">
                    <Typography variant="body2" color="text.secondary" sx={{ minWidth: 150, fontWeight: 500 }}>{label}</Typography>
                    <Typography variant="body2">{String(value)}</Typography>
                  </Box>
                ))}
              </Grid>
            </Grid>
          </TabPanel>

          {/* Policies list */}
          <TabPanel value={tab} index={1}>
            {resolvedPolicies.length === 0 ? (
              <Typography variant="body2" color="text.secondary">No policies in this group.</Typography>
            ) : (
              <Box display="flex" flexDirection="column" gap={1.5}>
                {resolvedPolicies.map((gp: any, idx: number) => {
                  const policy: Policy | undefined = gp.policyData
                  return (
                    <Paper key={gp.policy_id} elevation={0} variant="outlined" sx={{ p: 2, borderRadius: 1.5 }}>
                      <Box display="flex" alignItems="flex-start" gap={2}>
                        <Box sx={{ width: 28, height: 28, borderRadius: '50%', bgcolor: 'secondary.main', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                          <Typography variant="caption" color="white" fontWeight="bold">{idx + 1}</Typography>
                        </Box>
                        <Box flex={1}>
                          <Box display="flex" alignItems="center" gap={1} mb={0.5} flexWrap="wrap">
                            <Typography variant="body2" fontWeight={500} color="primary"
                              sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}
                              onClick={() => history.push(`${POLICYOPS_PATH.POLICIES}/${policy?._id ?? gp.policy_id}`)}>
                              {policy?.name ?? gp.policy_id}
                            </Typography>
                            <Chip label={`v${gp.policy_version}`} size="small" variant="outlined" sx={{ height: 18, fontSize: '0.65rem' }} />
                            {policy && <Chip label={policy.status} size="small" color={STATUS_COLORS[policy.status]} sx={{ height: 18, fontSize: '0.65rem' }} />}
                            {policy && <Chip label={`${policy.rules?.length ?? 0} rules`} size="small" variant="outlined" sx={{ height: 18, fontSize: '0.65rem' }} />}
                          </Box>
                          {policy?.description && (
                            <Typography variant="caption" color="text.secondary">{policy.description}</Typography>
                          )}
                        </Box>
                      </Box>
                    </Paper>
                  )
                })}
              </Box>
            )}
          </TabPanel>

          {/* Compile Preview */}
          <TabPanel value={tab} index={2}>
            <Typography variant="body2" color="text.secondary" mb={2}>
              Fully resolved payload — policies with all rules and definitions inlined. This is what agents receive.
            </Typography>
            <Box border="1px solid" borderColor="divider" borderRadius={1} overflow="hidden">
              <Editor
                height="460px"
                language="json"
                value={JSON.stringify(compiledPreview, null, 2)}
                options={{ readOnly: true, minimap: { enabled: false }, scrollBeyondLastLine: false, fontSize: 13, wordWrap: 'on' }}
              />
            </Box>
          </TabPanel>
        </Box>
      </Paper>

      <Dialog open={confirmAction === 'publish'} onClose={() => setConfirmAction(null)} maxWidth="xs" fullWidth>
        <DialogTitle>Publish Policy Group</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Publish "{group.name}" (v{group.version})? All attached policies must be published. The group will be locked.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmAction(null)}>Cancel</Button>
          <Button onClick={handlePublish} variant="contained" color="success" disabled={publishing}>Publish</Button>
        </DialogActions>
      </Dialog>

      <Dialog open={confirmAction === 'archive'} onClose={() => setConfirmAction(null)} maxWidth="xs" fullWidth>
        <DialogTitle>Archive Policy Group</DialogTitle>
        <DialogContent>
          <DialogContentText>Archive "{group.name}"? It will be retired and unavailable for new assignments.</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmAction(null)}>Cancel</Button>
          <Button onClick={handleArchive} variant="outlined" color="warning" disabled={archiving}>Archive</Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default PolicyGroupDetailPage
