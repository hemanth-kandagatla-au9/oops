﻿import React from 'react'
import { useHistory } from 'react-router-dom'
import {
  Box, Typography, Button, TextField, InputAdornment,
} from '@mui/material'
import { Code, Plus, Search, SlidersHorizontal } from 'lucide-react'
import { Tooltip } from '@mui/material'
import { POLICYOPS_PATH } from '../../../utils/constant'
import '../policies.scss'

interface PageHeaderProps {
  title: string
  subtitle: string
  onCreateRule?: () => void
  onCreatePolicy?: () => void
  onJsonEditor?: () => void
  search: string
  onSearch: (val: string) => void
}

const PageHeader: React.FC<PageHeaderProps> = ({
  title, subtitle, onCreateRule, onCreatePolicy, onJsonEditor, search, onSearch,
}) => {
  const history = useHistory()

  return (
    <Box marginBottom="12px">
      <Box display="flex" alignItems="center" justifyContent="space-between">
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 700, color: '#0f172a', fontSize: '1.15rem' }}>
            {title}
          </Typography>
          <Typography sx={{ fontSize: '0.8rem', color: '#94a3b8', mt: 0.4 }}>
            {subtitle}
          </Typography>
        </Box>

        <Box display="flex" alignItems="center" gap={1.5}>
          
          <Button
            variant="outlined"
            size="small"
            endIcon={<Plus size={13} />}
            onClick={() => history.push(`${POLICYOPS_PATH.RULES}/new`)}
            className='ph-rule-btn'

          >
            Create Rule
          </Button>
          <Button
            variant="contained"
            size="small"
            endIcon={<Plus size={13} />}
            onClick={() => history.push(`${POLICYOPS_PATH.POLICIES}/new`)}
            className='ph-create-btn'
          >
            Create Policy
          </Button>
          {onJsonEditor && (
            <Tooltip title="Advanced Mode: Create or edit the complete policy definition using JSON." arrow placement="bottom-end">
              <Button
                variant="outlined"
                size="small"
                startIcon={<Code size={14} />}
                onClick={onJsonEditor}
                sx={{ fontSize: '0.85rem', borderColor: '#e2e8f0', color: '#2563eb', '&:hover': { borderColor: '#93c5fd', bgcolor: '#eff6ff' } }}
              >
                JSON Editor
              </Button>
            </Tooltip>
          )}
        </Box>
      </Box>
    </Box>
  )
}

export default PageHeader