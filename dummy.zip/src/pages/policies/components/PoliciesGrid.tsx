import React from 'react'
import PolicyCard from './PolicyCard'
import { Policy } from '../../../utils/enums'
import '../policies.scss'


interface Props {
  policies: Policy[]
}

const PoliciesGrid: React.FC<Props> = ({ policies }) => {
  
  if (!policies.length) {
    return (
      <div className="ps-empty">
        <p>No policies found</p>
      </div>
    )
  }

  return (
    <div className="ps-grid">
      {policies.map((p) => (
        <PolicyCard key={p._id} policy={p} />
      ))}
    </div>
  )
}

export default PoliciesGrid