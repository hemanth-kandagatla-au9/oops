/* eslint-disable no-undef */
import { Box, Typography } from '@mui/material'
import blueStepper from '../../../assets/policyStepper/policy1ststepper.svg'
import completedStepper from '../../../assets/policyStepper/completedStepper.svg'
import defaultStepper from '../../../assets/policyStepper/defaultStepper.svg'


interface Props {
    activeStep: number
    onStepClick?: (step: number) => void
}


const steps = [
    {
        label: 'Basic Info',

        blueIcon: blueStepper,

        greenIcon: completedStepper,

        greyIcon: defaultStepper,
    },

    {
        label: 'Rule Selection',

        blueIcon: blueStepper,

        greenIcon: completedStepper,

        greyIcon: defaultStepper,
    },
    {
        label: 'Review',

        blueIcon: blueStepper,

        greenIcon: completedStepper,

        greyIcon: defaultStepper,
    },
]

const PolicyStepper: React.FC<Props> = ({
    activeStep,
    onStepClick,
}) => {
    const getIcon = (
        index: number,
        step: any
    ) => {
        // COMPLETED STEP
        if (index < activeStep) {
            return step.greenIcon
        }

        // ACTIVE STEP
        if (index === activeStep) {
            return step.blueIcon
        }

        // FUTURE STEP
        return step.greyIcon
    }

    return (
        <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            padding="8px 24px 24px"
        >
            {steps.map((step, index) => {
                const completed = index < activeStep

                return (
                    <Box
                        key={step.label}
                        display="flex"
                        alignItems="center"

                        sx={{
                            cursor: 'pointer',
                        }}
                        onClick={() => onStepClick?.(index)}

                    >
                        {/* STEP */}
                        <Box textAlign="center">
                            <Box
                                component="img"
                                src={getIcon(index, step)}
                                alt={step.label}
                                sx={{
                                    width: 32,
                                    height: 32,
                                    objectFit: 'contain',
                                }}
                            />

                            <Typography
                                sx={{
                                    mt: 0.75,
                                    fontSize: 13,
                                    fontWeight:
                                        index === activeStep
                                            ? 600
                                            : 500,

                                    color:
                                        index === activeStep
                                            ? '#0f172a'
                                            : '#475569',
                                }}
                            >
                                {step.label}
                            </Typography>
                        </Box>

                        {/* CONNECTOR */}
                        {index !== steps.length - 1 && (
                            <Box
                                sx={{
                                    width: 160,
                                    height: 2,
                                    mx: 1.5,

                                    bgcolor: completed
                                        ? '#5AC782'
                                        : '#2563eb',

                                    borderRadius: 999,
                                }}
                            />
                        )}
                    </Box>
                )
            })}
        </Box>
    )
}

export default PolicyStepper