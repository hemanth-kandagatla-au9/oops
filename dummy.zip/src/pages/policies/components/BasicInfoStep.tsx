/* eslint-disable no-undef */

import {
  Box,
  TextField,
  Typography,
  MenuItem,
  Chip,
  Stack,
} from '@mui/material'
import React from 'react'

interface Props {
  name: string
  description: string
  category: string
  executionMode: string
  failureHandling: string
  tags: string[]
  onChange: (field: string, value: any) => void
}

const sectionCard = {
  background: '#ffffff',
  border: '1px solid #ececec',
  borderRadius: '12px',
  padding: '16px',
}

const inputStyle = {
  '& .MuiOutlinedInput-root': {
    borderRadius: '10px',
    background: '#f9fafb',
    '& fieldset': {
      borderColor: '#e5e7eb',
    },
    '&:hover fieldset': {
      borderColor: '#cbd5e1',
    },
    '&.Mui-focused fieldset': {
      borderColor: '#2961f4',
    },
  },
}

const BasicInfoStep: React.FC<Props> = ({
  name,
  description,
  category,
  executionMode,
  failureHandling,
  tags,
  onChange,
}) => {
  const [tagInput, setTagInput] = React.useState('')

  return (
    <Box display="flex" flexDirection="column" gap={2}>
      {/* ───────── Policy Info ───────── */}
      <Box sx={sectionCard}>
        <Typography fontWeight={600} fontSize={14}>
          Policy Information
        </Typography>

        <Typography fontSize={12} color="#94a3b8" mb={2}>
          Give your policy a clear name and purpose. You can edit this later.
        </Typography>

        <Box display="grid" gridTemplateColumns="1fr 1fr" gap={2}>
          {/* Policy Name */}
          <TextField
            label="Policy Name*"
            helperText={!name.trim() ? 'Required' : ''}
            value={name}
            onChange={(e) => onChange('name', e.target.value)}
            fullWidth
            size="small"
            sx={inputStyle}
          />

          {/* Category Dropdown */}
          <TextField
            select
            label="Policy Category*"
            helperText={!category.trim() ? 'Required' : ''}
            value={category}
            onChange={(e) => onChange('category', e.target.value)}
            fullWidth
            size="small"
            sx={inputStyle}
            SelectProps={{
              displayEmpty: true,
            }}
          >
            
            <MenuItem value="Security">Security</MenuItem>
            <MenuItem value="Compliance">Compliance</MenuItem>
          </TextField>
        </Box>

        {/* Description */}
        <TextField
          label="Description*"
          helperText={!description.trim() ? 'Required' : ''}
          value={description}
          onChange={(e) => onChange('description', e.target.value)}
          fullWidth
          size="small"
          sx={{ ...inputStyle, mt: 2 }}
        />
      </Box>

      {/* ───────── Execution Info ───────── */}
      <Box sx={sectionCard}>
        <Typography fontWeight={600} fontSize={14}>
          Execution Information
        </Typography>

        <Typography fontSize={12} color="#94a3b8" mb={2}>
          Define your policy execution information
        </Typography>

        <Box display="grid" gridTemplateColumns="1fr 1fr" gap={2}>
          {/* Execution Mode */}
          <TextField
            select
            label="Execution Mode*"
            helperText={!executionMode.trim() ? 'Required' : ''}
            value={executionMode}
            onChange={(e) =>
              onChange('executionMode', e.target.value)
            }
            fullWidth
            size="small"
            sx={inputStyle}
            SelectProps={{
              displayEmpty: true,

            }}
          >
            <MenuItem value="Auto">Auto</MenuItem>
            <MenuItem value="Manual">Enforce</MenuItem>
          </TextField>

          {/* Failure Handling */}
          <TextField
            select
            label="Failure Handling*"
            helperText={!failureHandling.trim() ? 'Required' : ''}
            value={failureHandling}
            onChange={(e) =>
              onChange('failureHandling', e.target.value)
            }
            fullWidth
            size="small"
            sx={inputStyle}
            SelectProps={{
              displayEmpty: true,

            }}
          >
            <MenuItem value="Rollback">Rollback</MenuItem>
            <MenuItem value="Continue">Continue</MenuItem>
            <MenuItem value="Continue">Stop</MenuItem>
          </TextField>
        </Box>

        {/* ✅ Tag Input */}
        <TextField
          placeholder="Tag"
          value={tagInput}
          onChange={(e) => setTagInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && tagInput.trim()) {
              e.preventDefault()

              if (!tags.includes(tagInput.trim())) {
                onChange('tags', [...tags, tagInput.trim()])
              }

              setTagInput('')
            }
          }}
          fullWidth
          size="small"
          sx={{ ...inputStyle, mt: 2 }}
        />

        {/* ✅ Selected Tags */}
        <Box mt={1}>
          <Typography fontSize={12} color="#667085" mb={0.5}>
            Selected: {tags.length}
          </Typography>

          <Stack direction="row" spacing={1} flexWrap="wrap">
            {tags.map((tag, index) => (
              <Chip
                key={index}
                label={tag}
                size="small"
                onDelete={() =>
                  onChange(
                    'tags',
                    tags.filter((_, i) => i !== index)
                  )
                }
                sx={{
                  borderRadius: '16px',
                  background: '#eef2ff',
                  color: '#4f46e5',
                  fontSize: '12px',
                  fontWeight: 500,
                }}
              />
            ))}
          </Stack>
        </Box>
      </Box>
    </Box>
  )
}

export default BasicInfoStep

