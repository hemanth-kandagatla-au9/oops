import React from 'react'
import { Rule } from '../../../utils/enums'
import '../policies.scss'

const severityClass = (severity = '') => {
  const s = severity?.toLowerCase()
  if (s === 'critical') return 'policy-preview-modal__rule-severity--critical'
  if (s === 'high') return 'policy-preview-modal__rule-severity--high'
  if (s === 'medium') return 'policy-preview-modal__rule-severity--medium'
  return 'policy-preview-modal__rule-severity--low'
}

const capitalize = (s = '') =>
  s.charAt(0).toUpperCase() + s.slice(1)

const RuleIcon = ({ label = 'R' }: { label?: string }) => (
  <div className="policy-preview-modal__rule-icon">
    <span>{label.slice(0, 1).toUpperCase()}</span>
  </div>
)

interface Props {
  rule: Rule
  index: number
}

const RuleRow: React.FC<Props> = ({ rule, index }) => {
  const severity = rule?.severity ?? ''

  return (
    <div className="policy-preview-modal__rule-row">
      <div className="policy-preview-modal__rule-left">

        <span className="policy-preview-modal__rule-order">
          {String(index + 1).padStart(2, '0')}
        </span>

        <RuleIcon label={rule.rule_type || rule.name} />

        <div className="policy-preview-modal__rule-info">
          <div className="policy-preview-modal__rule-name">
            {rule.name}
          </div>
          <div className="policy-preview-modal__rule-desc">
            {rule.description}
          </div>
        </div>
      </div>

      <span
        className={[
          'policy-preview-modal__rule-severity',
          severityClass(severity),
        ].join(' ')}
      >
        {capitalize(severity)}
      </span>
    </div>
  )
}

export default RuleRow
