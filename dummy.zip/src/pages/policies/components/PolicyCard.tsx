import React from 'react'
import { Policy } from '../../../utils/enums'
import '../policies.scss'
import { POLICYOPS_PATH } from '../../../utils/constant'
import { useHistory } from 'react-router-dom'

interface Props {
  policy: Policy
}

const PolicyCard: React.FC<Props> = ({ policy }) => {
  const coverage = policy.compliance_coverage ?? 0

  

   
const history = useHistory()

const handleCardClick = (id: string) => {
  console.log("id", id)
  history.push(`${POLICYOPS_PATH.POLICIES}/${id}/view`)
}


  return (
    <div className="ps-policy-card"  onClick={() => handleCardClick(policy._id)}
      role="button"
      tabIndex={0}
      >
      {/* Header */}
      <div className="ps-policy-card__header">
        <p className="ps-policy-card__name">{policy.name}</p>

        <span className={`ps-status-badge ps-status-badge--${policy.status.toLowerCase()}`}>
          {policy.status}
        </span>
      </div>

      {/* Meta */}
      <div className="ps-policy-card__meta">
        <div className="ps-policy-card__meta-item">
          <span className="ps-policy-card__meta-label">Execution type</span>
          <span className="ps-policy-card__meta-value">Audit</span>
        </div>

        <div className="ps-policy-card__meta-item ps-policy-card__meta-item--right">
          <span className="ps-policy-card__meta-label">Rules</span>
          <span className="ps-policy-card__meta-value">{policy.rules.length}</span>
        </div>
      </div>

      {/* Compliance */}
      <div className="ps-policy-card__compliance">
        <div className="ps-policy-card__compliance-row">
          <span className="ps-policy-card__compliance-label">Compliance Index</span>
          <span className="ps-policy-card__compliance-value">
            {coverage}%
          </span>
        </div>

        <div className="ps-policy-card__progress-track">
          <div
            className="ps-policy-card__progress-fill"
            style={{ width: `${coverage}%` }}
          />
        </div>
      </div>

      {/* Footer */}
      <div className="ps-policy-card__footer">
        <div className="ps-policy-card__user">
          <div className="ps-policy-card__avatar-placeholder">
            {policy.owner?.[0]}
          </div>
          <span className="ps-policy-card__username">{policy.owner}</span>
        </div>

        <div className="ps-policy-card__date">
          {new Date(policy.updated_at || policy.created_at).toLocaleDateString()}
        </div>
      </div>
    </div>
  )
}

export default PolicyCard
