import React from 'react'
import '../policies.scss'

interface Props {
  count: number
  search: string
  onSearch: (v: string) => void
}

const PoliciesToolbar: React.FC<Props> = ({ count, search, onSearch }) => {
  return (
    <div className="ps-toolbar">
      <div className="ps-toolbar__left">
        <span className="ps-toolbar__title">Policies</span>
        <span className="ps-toolbar__count">{count}</span>
      </div>

      <div className="ps-toolbar__right">
        <input
          className="ps-toolbar__search"
          placeholder="Search"
          value={search}
          onChange={(e) => onSearch(e.target.value)}
        />

        <button className="ps-btn ps-btn--outline">Filter</button>

        <button className="ps-btn ps-btn--ghost-sm">☰</button>
        <button className="ps-btn ps-btn--ghost-sm">◻</button>
      </div>
    </div>
  )
}

export default PoliciesToolbar
