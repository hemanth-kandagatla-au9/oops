/* eslint-disable no-undef */
import React, { useState } from 'react'
import { useHistory, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import {
  useGetPolicyByIdQuery,
  useCreatePolicyMutation,
  useUpdatePolicyMutation,
} from '../../../redux/slices/policiesSlice'
import { useGetRulesQuery } from '../../../redux/slices/rulesSlice'
import { POLICYOPS_PATH } from '../../../utils/constant'
import { Rule, PolicyRule } from '../../../utils/enums'
import PolicyFormPage from '../PolicyFormPage'
import PolicyPreviewModal from './PolicyPreviewModal'

interface PreviewPayload {
  name: string
  description: string
  rules: (PolicyRule & { ruleData?: Rule })[]
}

const PolicyCreateEditPage: React.FC = () => {
  const { id } = useParams<{ id?: string }>()
  const isEdit = !!id && id !== 'new'
  const history = useHistory()

  const [preview, setPreview] = useState<PreviewPayload | null>(null)

  // ── Data fetching ─────────────────────────────────────────────────────────
  const { data: policyData, isLoading: loadingPolicy } = useGetPolicyByIdQuery(id!, { skip: !isEdit })
  const { data: rulesData } = useGetRulesQuery({ page: 1, limit: 100, status: 'published' })

  const [createPolicy, { isLoading: creating }] = useCreatePolicyMutation()
  const [updatePolicy, { isLoading: updating }]  = useUpdatePolicyMutation()

  const publishedRules: Rule[] = rulesData?.data ?? []

  // ── Build initialPolicy for edit mode ────────────────────────────────────
  const initialPolicy = React.useMemo(() => {
    const policy = policyData?.data
    if (!policy) return undefined
    const sorted = [...(policy.rules ?? [])].sort((a: any, b: any) => (a.order ?? 0) - (b.order ?? 0))
    return {
      name:        policy.name,
      description: policy.description,
      tags:        policy.tags ?? [],
      rules: sorted.map((pr: PolicyRule) => ({
        ...pr,
        ruleData: publishedRules.find((r) => r.rule_id === pr.rule_id || r._id === pr.rule_id),
      })),
    }
  }, [policyData, publishedRules])

  // ── "Review & Create Policy" clicked — open modal ─────────────────────────
  const handleReview = (payload: PreviewPayload) => {
    setPreview(payload)
  }

  // ── "Create" inside modal — call API, toast, navigate ─────────────────────
 const handleConfirmCreate = async () => {
  if (!preview) return

  const apiPayload = {
    name: preview.name.trim(),

    description: preview.description.trim(),

    rules: preview.rules.map((r, idx) => ({
      ruleId: r.rule_id,

      name: r.ruleData?.name ?? '',

      versionNumber:
        r.ruleData?.versionNumber ??
        r.ruleData?.version ??
        '1.0.0',

      sequenceNumber: idx + 1,
    })),
  }

  try {
    if (isEdit) {
      await updatePolicy({
        id: id!,
        data: apiPayload,
      }).unwrap()

      toast.success(`"${preview.name}" updated successfully`, {
        position: 'top-right',
        autoClose: 3500,
      })

      history.push(POLICYOPS_PATH.POLICIES)
    } else {
      await createPolicy(apiPayload).unwrap()

      toast.success(`"${preview.name}" policy created successfully`, {
        position: 'top-right',
        autoClose: 3500,
      })

      history.push(POLICYOPS_PATH.POLICIES)
    }
  } catch (error) {
    console.error(error)

    toast.error('Failed to save policy. Please try again.', {
      position: 'top-right',
    })
  }
}

  return (
    <>
      <PolicyFormPage
        policyId={isEdit ? id : undefined}
        availableRules={publishedRules}
        initialPolicy={initialPolicy}
        loading={isEdit && loadingPolicy}
        saving={creating || updating}
        onCancel={() => history.goBack()}
        onReview={handleReview}
        onNewRule={() => history.push(POLICYOPS_PATH.RULES + '/new')}
        onEditRule={(rule) => history.push(`${POLICYOPS_PATH.RULES}/${rule._id ?? rule.rule_id}/edit`)} tags={[]}      />

      
    </>
  )
}

export default PolicyCreateEditPage