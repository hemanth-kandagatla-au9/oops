import React, { useState } from 'react'
import { useHistory } from 'react-router-dom'
import { toast } from 'react-toastify'
import PolicyFormPage from './PolicyFormPage'
import { useGetRulesQuery } from '../../redux/slices/rulesSlice'
import { useCreatePolicyMutation } from '../../redux/slices/policiesSlice'
import { POLICYOPS_PATH } from '../../utils/constant'
import { Rule, PolicyRule } from '../../utils/enums'
import PolicyPreviewModal from './components/PolicyPreviewModal'

interface PreviewPayload {
  name: string
  description: string
  rules: (PolicyRule & { ruleData?: Rule })[]
}

const CreatePolicyPage: React.FC = () => {
  const history = useHistory()
  const [preview, setPreview] = useState<PreviewPayload | null>(null)

  const { data, isLoading } = useGetRulesQuery({
    page: 1,
    limit: 100,
  })
  const [createPolicy, { isLoading: creating }] = useCreatePolicyMutation()

  const handleConfirmCreate = async () => {
    if (!preview) return

    const payload = {
      name: preview.name.trim(),
      description: preview.description.trim(),
      tags: [],
      rules: preview.rules.map((r, idx) => ({
        rule_id: r.rule_id,
        rule_version: r.rule_version,
        order: idx + 1,
      })),
    }

    try {
      await createPolicy(payload).unwrap()
      toast.success(`"${preview.name}" policy created successfully`)
      setPreview(null)
      history.push(POLICYOPS_PATH.POLICIES)
    } catch {
      toast.error('Failed to create policy. Please try again.')
    }
  }

  return (
    <>
      <PolicyFormPage
              availableRules={data?.data ?? []}
              loading={isLoading}
              saving={creating}
              onCancel={() => history.push(POLICYOPS_PATH.POLICIES)}
              onReview={(payload) => setPreview(payload)} tags={[]}      />

     
    </>
  )
}

export default CreatePolicyPage