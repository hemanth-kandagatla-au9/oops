import React, { useState, useEffect, useRef } from 'react'
import { useHistory, useLocation } from 'react-router-dom'
import {
  Box, Button, Dialog, IconButton, Typography,
} from '@mui/material'
import Editor from '@monaco-editor/react'
import type { editor, IPosition } from 'monaco-editor'
import { AlertCircle, CheckCircle, Code, Copy, X } from 'lucide-react'
import { toast } from 'react-toastify'

import PageHeader from './components/PageHeader'
import StatsHeader from './components/StatsHeader'
import PoliciesToolbar from './components/PoliciesToolbar'
import PoliciesGrid from './components/PoliciesGrid'

import {
  Policy,
  PolicyStatus,
  RuleSeverity,
  StatsOverview,
} from '../../utils/enums'

import { POLICYOPS_PATH } from '../../utils/constant'
import './policies.scss'
import { useGetPoliciesQuery } from '../../redux/slices/policiesSlice'

/* ✅ Toggle mock */
const MOCK_MODE = false

/* ✅ Mock stats */
const mockStats: StatsOverview = {
  policies: 6,
  policies_delta: 2,
  rules: 60,
  rules_delta: 38,
  assigned_systems: 2845,
  systems_delta: 212,
  compliance_coverage: 98.7,
  compliance_delta: 0.4,

  totalPolicies: 0,
  policiesDelta: undefined,
  totalRules: null,
  rulesDelta: undefined,
  assignedSystems: null,
  systemsDelta: undefined,
  complianceCoverage: null,
  coverageDelta: undefined,
}

const DEFAULT_JSON = `{
  "policyName": "Linux Baseline Policy",
  "description": "Standard Linux compliance policy",
  "executionMode": "ENFORCE",
  "rules": [
    {
      "name": "Install Vim",
      "type": "PACKAGE",
      "package": { "name": "vim-enhanced", "action": "INSTALL" }
    },
    {
      "name": "RiseAgent Service",
      "type": "SERVICE",
      "service": { "name": "riseagent", "state": "running", "enabled": true }
    },
    {
      "name": "Ensure Config File Exists",
      "type": "FILE",
      "file": { "path": "/opt/rise/tmp/app.conf", "action": "ENSURE_EXISTS" }
    }
  ]
}`

const PolicyStudioPage: React.FC = () => {
  const history = useHistory()

  const [search, setSearch] = useState('')
  const [jsonEditorOpen, setJsonEditorOpen] = useState(false)
  const [jsonEditorValue, setJsonEditorValue] = useState(DEFAULT_JSON)
  const [jsonValidState, setJsonValidState] = useState<'idle' | 'valid' | 'invalid'>('idle')
  const [page, setPage] = useState(1)
  const [allPolicies, setAllPolicies] = useState<any[]>([])

  /* ✅ API */
  const { data, isLoading, isFetching, isError, refetch } = useGetPoliciesQuery({
    page,
    limit: 10,
    search,
  })


  /* ✅ Append paginated data */
  useEffect(() => {
  if (data?.data) {
    setAllPolicies((prev) => {
      if (page === 1) return data.data

      const newItems = data.data.filter(
        (item: any) =>
          !prev.some((p) => p.policyId === item.policyId)
      )

      return [...prev, ...newItems]
    })
  }
}, [data, page])


  /* ✅ Reset when search changes */
  useEffect(() => {
    setPage(1)
    setAllPolicies([])
  }, [search])

  const location = useLocation()

  useEffect(() => {
  setPage(1)
  setAllPolicies([])
}, [location.pathname])




  /* ✅ Normalize */
  const normalizePolicies = (items: any[]): Policy[] =>
    items.map((item) => ({
      _id: item.policyId,
      policy_id: item.policyId,
      name: item.name,
      description: item.description,

      status: item.status as PolicyStatus,
      environment: 'Production',
      owner: item.createdBy,

      executionInfo: {

        executionMode: item?.executionInfo?.executionMode || 'ENFORCE',
        failureHandling: item?.executionInfo?.failureHandling || 'CONTINUE'

      },
      rules: (item.rules || []).map((r: any, i: number) => ({
        id: r.ruleId,
        rule_id: r.ruleId,
        name: r.name,
        description: '',
        severity: RuleSeverity.MEDIUM,
        rule_version:
          Number(r.versionNumber?.split('.')[0]) || 1,
        order: r.sequenceNumber || i + 1,
      })),

      created_by: item.createdBy,
      created_at: item.createdAt,
      updated_at: item.updatedAt,

      version:
        Number(item.versionNumber?.split('.')[0]) || 1,

      compliance_coverage: 80 + Math.random() * 20,
      compliance_impact: 'Medium',
      risk_reduction: 50,

      systems_protected: 0,
      assignments: 0,
      servers: [],
      tags: item.tags || [],
    }))

  const policies = MOCK_MODE
    ? []
    : normalizePolicies(allPolicies)

  /* ✅ Stats from API */
  const computedStats: StatsOverview = {
    policies: data?.total ?? 0,
    policies_delta: 0,

    rules: data?.config_count ?? 0,
    rules_delta: 0,

    assigned_systems: 0,
    systems_delta: 0,

    compliance_coverage: 0,
    compliance_delta: 0,

    totalPolicies: 0,
    policiesDelta: undefined,
    totalRules: null,
    rulesDelta: undefined,
    assignedSystems: null,
    systemsDelta: undefined,
    complianceCoverage: null,
    coverageDelta: undefined,
  }

  /* ✅ Infinite scroll observer */
  const observerRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const target = entries[0]

        const hasMore = data?.data?.length > 0

        if (
          target.isIntersecting &&
          !isFetching &&
          hasMore
        ) {
          setPage((prev) => prev + 1)
        }
      },
      { threshold: 1 }
    )

    if (observerRef.current) {
      observer.observe(observerRef.current)
    }

    return () => observer.disconnect()
  }, [isFetching, data])

  /* ✅ Shimmer card */
  const ShimmerCard = () => (
    <div className="policy-card shimmer">
      <div className="shimmer-line title" />
      <div className="shimmer-line small" />
      <div className="shimmer-line small" />
    </div>
  )


  const handleDeleteSuccess = () => {
    setPage(1)
    setAllPolicies([])
    refetch()
  }


  return (
    <div className="policies-page">
      {/* ✅ HEADER */}
      <PageHeader
        title="Policy Studio"
        subtitle="Create, organize, and deploy governance policies across hybrid cloud environments."
        search={search}
        onSearch={setSearch}
        onCreateRule={() => history.push(`${POLICYOPS_PATH.RULES}/new`)}
        onCreatePolicy={() => history.push(`${POLICYOPS_PATH.POLICIES}/new`)}
        onJsonEditor={() => setJsonEditorOpen(true)}
      />

      {/* ── JSON Editor Dialog ── */}
      <Dialog
        open={jsonEditorOpen}
        onClose={() => setJsonEditorOpen(false)}
        fullScreen
        PaperProps={{ sx: { display: 'flex', flexDirection: 'column', bgcolor: '#1e1e1e' } }}
      >
        {/* Toolbar */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.5, bgcolor: '#252526', borderBottom: '1px solid #334155' }}>
          <Box display="flex" alignItems="center" gap={1.5}>
            <Code size={18} color="#93c5fd" />
            <Typography fontWeight={600} color="#f1f5f9" fontSize="0.8125rem">JSON Policy Editor</Typography>
          </Box>
          <Box display="flex" alignItems="center" gap={1}>
            <Button
              size="small"
              startIcon={jsonValidState === 'invalid' ? <AlertCircle size={14} /> : <CheckCircle size={14} />}
              onClick={() => {
                try { JSON.parse(jsonEditorValue); setJsonValidState('valid') }
                catch { setJsonValidState('invalid') }
              }}
              sx={{
                textTransform: 'none', fontWeight: 600, fontSize: '0.6875rem', px: 1.25, py: 0.35, borderRadius: '6px',
                bgcolor: jsonValidState === 'valid' ? '#166534' : jsonValidState === 'invalid' ? '#7f1d1d' : 'transparent',
                color: jsonValidState === 'valid' ? '#bbf7d0' : jsonValidState === 'invalid' ? '#fecaca' : '#94a3b8',
                border: '1px solid',
                borderColor: jsonValidState === 'valid' ? '#166534' : jsonValidState === 'invalid' ? '#7f1d1d' : '#334155',
                '&:hover': { bgcolor: jsonValidState === 'valid' ? '#14532d' : jsonValidState === 'invalid' ? '#6b1a1a' : 'rgba(255,255,255,0.08)' },
              }}
            >
              Validate JSON
            </Button>
            <Button
              size="small"
              startIcon={<Copy size={13} />}
              onClick={() => navigator.clipboard.writeText(jsonEditorValue).then(() => toast.success('Copied to clipboard'))}
              sx={{ textTransform: 'none', fontWeight: 600, fontSize: '0.6875rem', px: 1.25, py: 0.35, borderRadius: '6px', color: '#cbd5e1', border: '1px solid #334155', '&:hover': { bgcolor: 'rgba(255,255,255,0.08)', color: '#f1f5f9' } }}
            >
              Copy JSON
            </Button>
            <Button
              size="small"
              onClick={() => toast.info('Saved as draft')}
              sx={{ textTransform: 'none', fontWeight: 600, fontSize: '0.6875rem', px: 1.25, py: 0.35, borderRadius: '6px', color: '#cbd5e1', border: '1px solid #334155', '&:hover': { bgcolor: 'rgba(255,255,255,0.08)', color: '#f1f5f9' } }}
            >
              Save Draft
            </Button>
            <Button
              size="small"
              onClick={() => toast.info('Policy published')}
              sx={{ textTransform: 'none', fontWeight: 600, fontSize: '0.6875rem', px: 1.25, py: 0.35, borderRadius: '6px', bgcolor: '#2563eb', color: '#fff', border: '1px solid #2563eb', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}
            >
              Publish
            </Button>
            <IconButton
              size="small"
              onClick={() => { setJsonEditorOpen(false); setJsonValidState('idle') }}
              sx={{ color: '#94a3b8', ml: 0.5, '&:hover': { color: '#f1f5f9', bgcolor: 'rgba(255,255,255,0.08)' } }}
            >
              <X size={18} />
            </IconButton>
          </Box>
        </Box>
        {/* Editor */}
        <Box sx={{ flex: 1, minHeight: 0, overflow: 'hidden' }}>
          <Editor
            height="100%"
            defaultLanguage="json"
            value={jsonEditorValue}
            onChange={(v) => { setJsonEditorValue(v ?? ''); setJsonValidState('idle') }}
            theme="vs-dark"
            beforeMount={(monaco) => {
              monaco.languages.registerCompletionItemProvider('json', {
                provideCompletionItems: (model: editor.ITextModel, position: IPosition) => {
                  const word = model.getWordUntilPosition(position)
                  const range = {
                    startLineNumber: position.lineNumber,
                    endLineNumber: position.lineNumber,
                    startColumn: word.startColumn,
                    endColumn: word.endColumn,
                  }
                  return {
                    suggestions: [
                      {
                        label: 'policy-template',
                        kind: monaco.languages.CompletionItemKind.Snippet,
                        documentation: 'Full policy template with rules array',
                        insertText: '{\n  "policyName": "${1:MyPolicy}",\n  "description": "${2:Description}",\n  "executionMode": "ENFORCE",\n  "rules": [\n    $0\n  ]\n}',
                        insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                        range,
                      },
                      {
                        label: 'package-rule',
                        kind: monaco.languages.CompletionItemKind.Snippet,
                        documentation: 'Package install rule',
                        insertText: '{\n  "name": "${1:Install Package}",\n  "type": "PACKAGE",\n  "package": {\n    "name": "${2:package-name}",\n    "action": "INSTALL",\n    "version": "${3:latest}"\n  }\n}',
                        insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                        range,
                      },
                      {
                        label: 'file-rule',
                        kind: monaco.languages.CompletionItemKind.Snippet,
                        documentation: 'File ensure-exists rule',
                        insertText: '{\n  "name": "${1:Ensure Config File Exists}",\n  "type": "FILE",\n  "file": {\n    "path": "${2:/opt/app/config.conf}",\n    "action": "${3|ENSURE_EXISTS,VALIDATE_PERMISSION,VALIDATE_OWNER,VALIDATE_GROUP,VALIDATE_CHECKSUM,VALIDATE_CONTENT,DELETE|}"\n  }\n}',
                        insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                        range,
                      },
                      {
                        label: 'service-rule',
                        kind: monaco.languages.CompletionItemKind.Snippet,
                        documentation: 'Service state rule',
                        insertText: '{\n  "name": "${1:Service Name}",\n  "type": "SERVICE",\n  "service": {\n    "name": "${2:service-name}",\n    "state": "${3|running,stopped|}",\n    "enabled": ${4|true,false|}\n  }\n}',
                        insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                        range,
                      },
                    ],
                  }
                },
              })
            }}
            options={{
              minimap: { enabled: false },
              fontSize: 13,
              lineNumbers: 'on',
              scrollBeyondLastLine: false,
              wordWrap: 'on',
              tabSize: 2,
              formatOnPaste: true,
              automaticLayout: true,
              suggestOnTriggerCharacters: true,
              quickSuggestions: true,
            }}
          />
        </Box>
      </Dialog>

      {/* ✅ STATS */}
      <StatsHeader
        stats={MOCK_MODE ? mockStats : computedStats}
        loading={isLoading && page === 1}
      />

      {/* ✅ TOOLBAR */}
      <PoliciesToolbar
        count={policies.length}
        search={search}
        onSearch={setSearch}
      />

      {/* ✅ GRID */}
      {isLoading && page === 1 ? (
        <div style={{ padding: 20 }}>
          Loading policies...
        </div>
      ) : isError ? (
        <div style={{ padding: 20 }}>
          Failed to load policies
        </div>
      ) : (
        <>

          <PoliciesGrid
            policies={policies}
            onDeleteSuccess={handleDeleteSuccess}
          />


          {/* ✅ Shimmer while fetching next page */}
          {isFetching && page > 1 && (
            <div className="policies-grid">
              <ShimmerCard />
              <ShimmerCard />
            </div>
          )}

          {/* ✅ Scroll trigger */}
          <div ref={observerRef} style={{ height: 1 }} />
        </>
      )}
    </div>
  )
}

export default PolicyStudioPage