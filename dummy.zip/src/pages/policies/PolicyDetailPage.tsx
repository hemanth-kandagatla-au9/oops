import React from 'react'
import { useParams, useHistory } from 'react-router-dom'
import RuleRow from './components/RuleRow' // reusable rule row
import './policies.scss'
import {
  Box, Typography, Button, TextField, InputAdornment,
} from '@mui/material'
import { POLICYOPS_PATH } from '../../utils/constant'
import { useGetPolicyByIdQuery } from '../../redux/slices/policiesSlice'

const PolicyDetailPage: React.FC = () => {
  const history = useHistory()

  /* ✅ MOCK DATA (replace later with API) */




  const { id } = useParams<{ id: string }>()

  const { data, isLoading, isError } = useGetPolicyByIdQuery(id, {
    skip: !id,
  })

  const policy = data?.data

  const assignments = policy?.assignments || []
  console.log('Fetched policy:', policy)


  const rules = (policy?.rules || []).map((r: any) => ({
    name: r?.name,
    description: '',
    severity: 'medium',
    rule_type: 'L',
  }))





  return (
    <div className="pdp">

      {/* ✅ HEADER */}
      <div className="pdp-header">
        <div className="pdp-header__left">
          <button className="pdp-back" onClick={() => history.goBack()}>
            ←
          </button>

          <div>
            <p className="pdp-breadcrumb">Policy Studio</p>
            <h2>{policy?.name}</h2>
          </div>
        </div>

        <div className="pdp-header__actions">
          <Button className='ph-rule-btn' sx={{
            border: "1px solid #EAECF0",
            borderRadius: "100px !important",
            backgroundColor: "#FBFCFF !important",
            color: "##667085 !important",
            height: "36px"
          }} onClick={() => history.push(`${POLICYOPS_PATH.POLICIES}/${id}/edit`)}>Modify</Button>
          <Button className="ph-create-btn" sx={{
            border: "1px solid #2961F4",
            borderRadius: "100px !important",
            backgroundColor: "#FBFCFF !important",
            color: "#2961F4 !important",
            height: "36px"
          }}>Assign</Button>
        </div>
      </div>

      {/* ✅ CONTENT */}
      <div className="pdp-content">

        {/* LEFT */}
        <div className="pdp-left">

          {/* ✅ RULES (reused UI) */}
          <div className="pdp-card">
            <div className="policy-preview-modal__section-title">
              Rules
            </div>

            <div className="policy-preview-modal__rules-list">
              {rules.map((rule: any, idx: any) => (
                <RuleRow key={idx} rule={rule as any} index={idx} />
              ))}
            </div>
          </div>

          {/* ✅ POLICY DETAILS */}
          <div className="pdp-card">
            <div className="policy-preview-modal__section-title">
              Policy Details
            </div>

            <div className="pdp-progress">
              <div className="pdp-progress__top">
                <span>Compliance Index</span>
                <span>98.2%</span>
              </div>

              <div className="pdp-progress__bar">
                <div style={{ width: '80%' }} />
              </div>
            </div>

            <div className="pdp-details">

              <p><span>Status:</span> {policy?.status}</p>
              <p><span>Execution Mode:</span> {policy?.executionInfo?.executionMode}</p>
              <p><span>Failure Handling:</span> {policy?.executionInfo?.failureHandling}</p>
              <p><span>Created By:</span> {policy?.createdBy}</p>
            </div>
          </div>
        </div>

        {/* RIGHT */}
        <div className="pdp-right">

          {/* ✅ ASSIGNMENTS */}
          <div className="pdp-card" style={{ height: "70vh" }}>
            <div className="policy-preview-modal__section-title">
              Assignment
            </div>

            {assignments.length === 0 ? (
              <Typography sx={{ color: '#94a3b8', fontSize: '0.8rem' }}>
                No assignments available
              </Typography>
            ) : (
              assignments.map((a: any, i: number) => (
                <div key={i} className="pdp-assignment-card">

                  <div className="pdp-assignment-card__header">
                    <span>{a?.name || 'Unknown Assignment'}</span>
                    <span className="pdp-status">
                      {a?.status || 'Inactive'}
                    </span>
                  </div>

                  <div className="pdp-assignment-card__meta">
                    <div>
                      <span>Environment</span>
                      <p>{a?.environment || '-'}</p>
                    </div>

                    <div>
                      <span>Server</span>
                      <p>{a?.servers ?? '-'}</p>
                    </div>

                    <div className="pdp-assignment-card__progress">
                      <span>Compliance Index</span>

                      <div className="pdp-progress-bar">
                        <div
                          style={{
                            width: `${a?.compliance ?? 0}%`,
                          }}
                        />
                      </div>
                    </div>
                  </div>

                </div>
              ))
            )}
          </div>



        </div>
      </div>
    </div>
  )
}

export default PolicyDetailPage
