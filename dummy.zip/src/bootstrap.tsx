import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import { store, persistor } from "./redux/store";
import {
  PublicClientApplication,
  AuthenticationResult,
  EventMessage,
  EventType,
} from "@azure/msal-browser";
import { MsalProvider } from "@azure/msal-react";
import { msalConfig } from "./utils/msalConfig";
import { registerMsalInstance } from "./utils/tokenService";
import { setupMockAuth } from "./utils/mockAuth";
import { storeMsalInstance } from "./utils/authService";
import AuthWrapper from "./components/auth/AuthWrapper";

const IS_INSIDE_HOST = !!(window as any).__POWERED_BY_IASPHERE__;

// BYPASS_AUTH / IS_INSIDE_HOST — no MSAL, no AuthWrapper
const renderDirect = () => {
  ReactDOM.render(
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <BrowserRouter>
          <App />
        </BrowserRouter>
      </PersistGate>
    </Provider>,
    document.getElementById("root")
  );
};

if (process.env.BYPASS_AUTH === "true" || process.env.MOCK_MODE === "true") {
  setupMockAuth();
  renderDirect();
} else if (IS_INSIDE_HOST) {
  renderDirect();
} else {
  // Standalone MSAL mode — matches platform bootstrap exactly
  const msalInstance = new PublicClientApplication(msalConfig);
  storeMsalInstance(msalInstance);

  async function renderApp() {
    await msalInstance.initialize();

    try {
      const redirectResponse = await msalInstance.handleRedirectPromise();
      if (redirectResponse?.account) {
        msalInstance.setActiveAccount(redirectResponse.account);
        // Restore deep-link if user was redirected from a specific page
        const savedUrl = sessionStorage.getItem("postLoginRedirect");
        if (savedUrl) {
          sessionStorage.removeItem("postLoginRedirect");
          window.location.href = savedUrl;
        } else {
          window.location.href = "/dashboard";
        }
        return;
      }
    } catch (err) {
      console.error("handleRedirectPromise failed:", err);
    }

    const accounts = msalInstance.getAllAccounts();
    if (accounts.length > 0 && !msalInstance.getActiveAccount()) {
      msalInstance.setActiveAccount(accounts[0]);
    }

    msalInstance.addEventCallback((event: EventMessage) => {
      if (event.eventType === EventType.LOGIN_SUCCESS && event.payload) {
        msalInstance.setActiveAccount((event.payload as AuthenticationResult).account);
      }
    });

    registerMsalInstance(msalInstance);

    ReactDOM.render(
      <MsalProvider instance={msalInstance}>
        <Provider store={store}>
          <PersistGate loading={null} persistor={persistor}>
            <BrowserRouter>
              <AuthWrapper>
                <App />
              </AuthWrapper>
            </BrowserRouter>
          </PersistGate>
        </Provider>
      </MsalProvider>,
      document.getElementById("root")
    );
  }

  renderApp().catch(console.error);
}
