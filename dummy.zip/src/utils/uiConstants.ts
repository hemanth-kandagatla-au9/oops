// Single source of truth for all UI color/label maps.
// Import from here — never redefine locally in pages.

// ── Status ────────────────────────────────────────────────────────────────────
export const STATUS_COLORS: Record<string, any> = {
  draft: 'default',
  published: 'success',
  archived: 'error',
}
export const STATUS_LABELS: Record<string, string> = {
  draft: 'Draft',
  published: 'Active',
  archived: 'Archived',
}

// ── Severity ──────────────────────────────────────────────────────────────────
export const SEVERITY_COLORS: Record<string, any> = {
  critical: 'error',
  high: 'warning',
  medium: 'info',
  low: 'default',
}

// ── Enforcement mode ──────────────────────────────────────────────────────────
export const MODE_COLORS: Record<string, any> = {
  enforce: 'error',
  monitor: 'warning',
  audit: 'info',
}
export const MODE_LABELS: Record<string, string> = {
  enforce: 'Enforce',
  monitor: 'Monitor Only',
  audit: 'Audit Only',
}

// ── Agent status ──────────────────────────────────────────────────────────────
export const AGENT_STATUS_COLORS: Record<string, any> = {
  online: 'success',
  stale: 'warning',
  offline: 'error',
}

// ── Audit actions ─────────────────────────────────────────────────────────────
export const ACTION_COLORS: Record<string, any> = {
  created: 'primary',
  updated: 'info',
  published: 'success',
  archived: 'default',
  cloned: 'warning',
}
// Hex versions for use in dot indicators / custom styling
export const ACTION_HEX: Record<string, string> = {
  created: '#6366f1',
  updated: '#0288d1',
  published: '#10b981',
  archived: '#9e9e9e',
  cloned: '#f59e0b',
}

// ── Audit entity types ────────────────────────────────────────────────────────
export const ENTITY_COLORS: Record<string, string> = {
  rule: '#8b5cf6',
  policy: '#0288d1',
  policy_group: '#10b981',
  assignment: '#f59e0b',
  agent: '#6366f1',
}

// ── Drift / remediation ───────────────────────────────────────────────────────
export const DRIFT_STATUS_COLORS: Record<string, any> = {
  detected: 'info',
  remediating: 'warning',
  fixed: 'success',
  failed: 'error',
}
export const REMEDIATION_STATUS_COLORS: Record<string, any> = {
  completed: 'success',
  failed: 'error',
  started: 'warning',
}

// ── Compliance bar ────────────────────────────────────────────────────────────
export const complianceColor = (pct: number): string =>
  pct >= 95 ? '#22c55e' : pct >= 70 ? '#f97316' : '#ef4444'


export const formatDisplayName = (raw: string): string => {
  const stripped = raw.replace(/\[.*?\]/g, '').trim()
  if (stripped.includes(',')) {
    const [last, first] = stripped.split(',').map((s) => s.trim())
    return [first, last].filter(Boolean).join(' ')
  }
  return stripped
}