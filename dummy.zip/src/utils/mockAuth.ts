import Cookies from 'universal-cookie'
import { store } from '../redux/store'
import { setPermissions } from '../redux/slices/permissionSlice'
import { PERMISSION_LIST, MODULE_LIST } from './permissionsUtil'

const cookies = new Cookies()

export const setupMockAuth = () => {
  cookies.set('isAuthenticated', true, { path: '/' })

  store.dispatch(setPermissions([{
    project: 'policyops',
    modules: [{ module: MODULE_LIST.ALL, hasAccess: true, permissions: Object.values(PERMISSION_LIST) }]
  }]))
}
