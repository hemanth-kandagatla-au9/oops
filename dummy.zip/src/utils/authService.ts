import axios from 'axios';
import Cookies from 'universal-cookie';
import { jwtDecode } from 'jwt-decode';

const cookies = new Cookies();
let msalInstance: any = null;

const COOKIE_PATH = '/';
const isSecure = window.location.protocol === 'https:';
const cookieOptions = {
  path: COOKIE_PATH,
  secure: isSecure,
  sameSite: (isSecure ? 'none' : 'lax') as 'none' | 'lax',
};

export const storeMsalInstance = (instance: any) => {
  msalInstance = instance;
};

export const getMsalInstance = () => msalInstance;

export const storeUserInfoCookies = (idToken: string, _accessToken: string, earliestExpiry: number): void => {
  try {
    const decoded: any = jwtDecode(idToken);

    cookies.set('isAuthenticated', 'true', cookieOptions);
    cookies.set('tokenValidity', earliestExpiry, cookieOptions);

    const username =
      decoded?.unique_name?.split('@')[0] ??
      decoded?.preferred_username?.split('@')[0] ??
      decoded?.upn?.split('@')[0] ??
      '';

    const fullName =
      `${decoded?.given_name ?? ''} ${decoded?.family_name ?? ''}`.trim() ||
      decoded?.name ||
      username;

    const email =
      decoded?.upn ??
      decoded?.unique_name ??
      decoded?.preferred_username ??
      decoded?.email ??
      '';

    cookies.set('username', username, cookieOptions);
    cookies.set('user_fullname', fullName, cookieOptions);
    cookies.set('initial_name', `${decoded?.family_name ?? ''}, ${decoded?.given_name ?? ''}`.trim() || fullName, cookieOptions);
    cookies.set('user_email', email, cookieOptions);
  } catch (e) {
    console.error('storeUserInfoCookies failed:', e);
  }
};

export const clearUserInfoCookies = (): void => {
  ['isAuthenticated', 'tokenValidity', 'username', 'user_fullname', 'user_email', 'initial_name'].forEach(
    (key) => cookies.remove(key, { path: COOKIE_PATH })
  );
};

// Same as platform's loginInsights — POST with Bearer header
export const loginInsights = async (data: { action: 'login' | 'logout'; accessToken: string }): Promise<boolean> => {
  const authUrl = process.env.AUTH_URL || '';
  try {
    await axios.post(`${authUrl}auth/loginInsights`, data, {
      headers: {
        Authorization: `Bearer ${data.accessToken}`,
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
    });
    return true;
  } catch (err) {
    console.error('loginInsights failed:', err);
    return false;
  }
};
