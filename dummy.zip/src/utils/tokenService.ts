import {
  PublicClientApplication,
  InteractionRequiredAuthError,
  AccountInfo,
} from "@azure/msal-browser";
import { jwtDecode } from "jwt-decode";
import { loginRequest } from "./msalConfig";

interface HostBridge {
  __POWERED_BY_IASPHERE__?: unknown;
  __HOST_GET_TOKEN__?: () => Promise<string>;
  __HOST_GET_ID_TOKEN__?: () => Promise<string>;
}
const hostWindow = window as unknown as HostBridge;
const IS_INSIDE_HOST = !!hostWindow.__POWERED_BY_IASPHERE__;

let _instance: PublicClientApplication | null = null;

export const registerMsalInstance = (instance: PublicClientApplication): void => {
  _instance = instance;
};

export const getAccessToken = async (): Promise<string | null> => {
  if (IS_INSIDE_HOST && typeof hostWindow.__HOST_GET_TOKEN__ === "function") {
    try {
      return await hostWindow.__HOST_GET_TOKEN__();
    } catch {
      return null;
    }
  }

  if (!_instance) return null;

  try {
    const accounts = _instance.getAllAccounts();
    if (!accounts.length) return null;
    const result = await _instance.acquireTokenSilent({
      ...loginRequest,
      account: accounts[0],
    });
    return result.accessToken;
  } catch (e) {
    if (e instanceof InteractionRequiredAuthError) {
      _instance.loginRedirect(loginRequest);
    }
    return null;
  }
};

export const clearTokenCache = (): void => {};
