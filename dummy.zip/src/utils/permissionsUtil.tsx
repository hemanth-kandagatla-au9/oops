export const PERMISSION_LIST = {
  RULES_READ: "Rules : read",
  RULES_WRITE: "Rules : write",
  RULES_EDIT: "Rules : edit",
  RULES_DELETE: "Rules : delete",

  POLICIES_READ: "Policies : read",
  POLICIES_WRITE: "Policies : write",
  POLICIES_EDIT: "Policies : edit",
  POLICIES_DELETE: "Policies : delete",
  POLICIES_PUBLISH: "Policies : publish",

  POLICY_GROUPS_READ: "Policy Groups : read",
  POLICY_GROUPS_WRITE: "Policy Groups : write",

  ASSIGNMENTS_READ: "Assignments : read",
  ASSIGNMENTS_WRITE: "Assignments : write",
  ASSIGNMENTS_REVOKE: "Assignments : revoke",

  ARTIFACTS_READ: "Artifacts : read",
  ARTIFACTS_WRITE: "Artifacts : write",
  ARTIFACTS_DELETE: "Artifacts : delete",

  COMPLIANCE_READ: "Compliance : read",
  COMPLIANCE_WRITE: "Compliance : write",

  AUDIT_READ: "Audit : read",

  SETTINGS_READ: "Settings : read",
  SETTINGS_WRITE: "Settings : write",
};

export const MODULE_LIST = {
  DASHBOARD: "dashboard",
  RULES: "rules",
  POLICIES: "policies",
  POLICY_GROUPS: "policy_groups",
  ASSIGNMENTS: "assignments",
  ARTIFACTS: "artifacts",
  COMPLIANCE: "compliance",
  AUDIT: "audit",
  SETTINGS: "settings",
  ALL: "All",
};

export const hasModuleAccess = (
  permissions: any[] | null,
  module: string
): boolean => {
  if (!permissions) return true; // default open if permissions not loaded
  const projectPerms = permissions.find((p: any) => p.project === "policyops");
  if (!projectPerms) return false;
  const allModule = projectPerms.modules?.find((m: any) => m.module === "All");
  if (allModule?.hasAccess) return true;
  const modulePerms = projectPerms.modules?.find((m: any) => m.module === module);
  return !!modulePerms?.hasAccess;
};

export const checkPermission = (
  permissions: any[],
  module: string,
  permission: string
): boolean => {
  if (!permissions) return false;

  const projectPerms = permissions.find((p: any) => p.project === "policyops");
  if (!projectPerms) return false;

  const allModule = projectPerms.modules?.find((m: any) => m.module === "All");
  if (allModule?.hasAccess && allModule?.permissions?.includes(permission)) return true;

  const modulePerms = projectPerms.modules?.find((m: any) => m.module === module);
  return !!(modulePerms?.hasAccess && modulePerms?.permissions?.includes(permission));
};
