export const isLoadingInHost = Boolean((window as any).__HOST_APP__);
