import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'

dayjs.extend(relativeTime)

export const formatDate = (v: string): string => dayjs(v).format('MMM D, YYYY')
export const formatDateTime = (v: string): string => dayjs(v).format('MMM D, YYYY HH:mm:ss')
export const formatDateShort = (v: string): string => dayjs(v).format('MMM D HH:mm')
export const formatTime = (v: string): string => dayjs(v).format('HH:mm:ss')
export const formatRelative = (v: string): string => dayjs(v).fromNow()
export const formatExportDate = (): string => dayjs().format('YYYY-MM-DD')
// "12 Feb, 2026 | 02:14 AM" — matches the design table cells
export const formatDateTimeDisplay = (v: string): string => dayjs(v).format('D MMM, YYYY | hh:mm A')
export const formatDayLabel = (): string => dayjs().format('dddd, MMMM D, YYYY')

export { dayjs }
