import React from "react";
import { Route, RouteProps } from "react-router-dom";
import { Box, CircularProgress } from "@mui/material";

interface PrivateRouteProps extends RouteProps {
  component: React.ComponentType<any>;
  module?: string | string[];
  permissions: any;
  permissionType?: "read" | "write";
  isPermissionsLoading?: boolean;
}

const PrivateRoute: React.FC<PrivateRouteProps> = ({
  component: Component,
  module,
  permissions,
  permissionType = "read",
  isPermissionsLoading = false,
  ...rest
}) => {
  return (
    <Route
      {...rest}
      render={(props) => {
        if (isPermissionsLoading) {
          return (
            <Box display="flex" justifyContent="center" alignItems="center" height="50vh">
              <CircularProgress />
            </Box>
          );
        }

        return <Component {...props} />;
      }}
    />
  );
};

export default PrivateRoute;
