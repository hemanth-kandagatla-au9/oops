import React, { useEffect, useRef, useState } from 'react';
import { useIsAuthenticated, useMsal } from '@azure/msal-react';
import { InteractionRequiredAuthError } from '@azure/msal-browser';
import { useLocation } from 'react-router-dom';
import { Box, CircularProgress } from '@mui/material';
import { jwtDecode } from 'jwt-decode';
import { storeUserInfoCookies, clearUserInfoCookies, loginInsights } from '../../utils/authService';
import LoginPage from '../../pages/login/LoginPage';
import { POLICYOPS_PATH } from '../../utils/constant';

const TOKEN_SCOPES = ['User.Read', 'profile', 'email'];
const REFRESH_BUFFER_MS = 5 * 60 * 1000;
const MIN_REFRESH_MS = 60_000;
const FORCE_REFRESH_THRESHOLD_MS = 5 * 60 * 1000;

const SKIP_AUTH_PATHS = [
  POLICYOPS_PATH.LOGOUT,
  POLICYOPS_PATH.SESSION_EXPIRED,
  POLICYOPS_PATH.UNAUTHORIZED,
];

const getTokenExpiry = (token: string) => {
  try {
    const decoded: any = jwtDecode(token);
    const expiresAt = decoded.exp * 1000;
    return { expiresAt, isExpired: Date.now() >= expiresAt };
  } catch {
    return null;
  }
};

const computeRefreshIn = (timeUntilExpiry: number): number => {
  if (timeUntilExpiry > REFRESH_BUFFER_MS) {
    return Math.max(
      Math.min(Math.floor(timeUntilExpiry * 0.8), timeUntilExpiry - REFRESH_BUFFER_MS),
      MIN_REFRESH_MS
    );
  }
  return Math.max(Math.floor(timeUntilExpiry * 0.8), MIN_REFRESH_MS);
};

const Loader = () => (
  <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
    <CircularProgress />
  </Box>
);

const AuthWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { instance, accounts, inProgress } = useMsal();
  const isAuthenticated = useIsAuthenticated();
  const { pathname } = useLocation();
  const [isReady, setIsReady] = useState(false);
  const isReadyRef = useRef(false);
  const refreshTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const clearTimer = () => {
    if (refreshTimerRef.current) {
      clearTimeout(refreshTimerRef.current);
      refreshTimerRef.current = null;
    }
  };

  useEffect(() => {
    if (SKIP_AUTH_PATHS.includes(pathname)) return;
    if (!isAuthenticated || !accounts || accounts.length === 0) return;

    const setupRefresh = async (): Promise<void> => {
      try {
        if (!instance.getActiveAccount()) {
          instance.setActiveAccount(accounts[0]);
        }

        let response = await instance.acquireTokenSilent({
          scopes: TOKEN_SCOPES,
          account: accounts[0],
          forceRefresh: false,
        });

        if (!response.accessToken || !response.idToken) throw new Error('No tokens from MSAL');

        const accessInfo = getTokenExpiry(response.accessToken);
        const idInfo = getTokenExpiry(response.idToken);
        if (!accessInfo || !idInfo) throw new Error('Failed to decode tokens');

        const earliestExpiry = Math.min(accessInfo.expiresAt, idInfo.expiresAt);
        const timeUntilExpiry = earliestExpiry - Date.now();
        if (timeUntilExpiry <= 0) throw new Error('Tokens expired');

        // Force-refresh when near expiry
        if (timeUntilExpiry < FORCE_REFRESH_THRESHOLD_MS) {
          try {
            const fresh = await instance.acquireTokenSilent({
              scopes: TOKEN_SCOPES,
              account: accounts[0],
              forceRefresh: true,
            });
            if (fresh.accessToken && fresh.idToken) response = fresh;
          } catch (forceErr) {
            if (forceErr instanceof InteractionRequiredAuthError) throw forceErr;
          }
        }

        // eslint-disable-next-line no-console
        console.log('[Auth] Access token roles:', (jwtDecode(response.accessToken) as any)?.roles ?? (jwtDecode(response.accessToken) as any));

        // Store user info from JWT into cookies (same as platform)
        storeUserInfoCookies(response.idToken!, response.accessToken, earliestExpiry);

        // TODO: re-enable when auth backend is reachable from this environment
        // await loginInsights({ action: 'login', accessToken: response.accessToken });

        setIsReady(true);
        isReadyRef.current = true;

        // Schedule next token refresh
        clearTimer();
        refreshTimerRef.current = setTimeout(setupRefresh, computeRefreshIn(timeUntilExpiry));
      } catch (err: any) {
        if (err instanceof InteractionRequiredAuthError) {
          clearUserInfoCookies();
          instance.loginRedirect({ scopes: TOKEN_SCOPES });
          return;
        }
        if (!isReadyRef.current) {
          window.location.href = POLICYOPS_PATH.SESSION_EXPIRED;
        }
      }
    };

    setupRefresh();
    return () => clearTimer();
  }, [isAuthenticated, accounts, instance, pathname]);

  // Let logout / session-expired / unauthorized render without auth gate
  if (SKIP_AUTH_PATHS.includes(pathname)) return <>{children}</>;

  if (inProgress === 'startup' || inProgress === 'handleRedirect') return <Loader />;
  if (!isAuthenticated) return <LoginPage />;
  if (!isReady) return <Loader />;

  return <>{children}</>;
};

export default AuthWrapper;
