import React from 'react'
import {
  Box,
  CircularProgress,
  Dialog,
  Grid,
  IconButton,
  Tooltip,
  Typography,
} from '@mui/material'
import moment from 'moment'
import { FileText, LogIn, Settings, Terminal, X } from 'lucide-react'

const pickRowValue = (row: Record<string, unknown>, ...keys: string[]): unknown => {
  for (const key of keys) {
    const value = row[key]
    if (value !== undefined && value !== null && value !== '') return value
  }
  return null
}

export interface DriftLogMetricsData {
  totalExecutions: number
  successRate: number
  failedRate: number
  realtimeRate: number
}

export const parseDriftLogMetrics = (response: unknown): DriftLogMetricsData | null => {
  const payload = (response as { data?: DriftLogMetricsData })?.data
    ?? (response as DriftLogMetricsData | null)

  if (!payload || typeof payload !== 'object') return null

  return {
    totalExecutions: Number(payload.totalExecutions ?? 0),
    successRate: Number(payload.successRate ?? 0),
    failedRate: Number(payload.failedRate ?? 0),
    realtimeRate: Number(payload.realtimeRate ?? 0),
  }
}

export interface DriftTimelineEntry {
  id: string
  date?: string
  time: string
  timeTooltip?: string
  loggedInUser?: string
  currentUser?: string
  title: string
  metadata?: string
  iconType?: 'terminal' | 'settings' | 'login'
}

export interface CommandLogRequest {
  hostname: string
  command: string
}

const extractFileName = (filepath: string): string => {
  const trimmed = filepath.trim()
  if (!trimmed) return ''
  const segments = trimmed.replace(/\\/g, '/').split('/').filter(Boolean)
  return segments.length ? segments[segments.length - 1] : trimmed
}

export const resolveCommandLogPayload = (row: Record<string, unknown>): CommandLogRequest | null => {
  const hostname = String(pickRowValue(row, 'hostname', 'host', 'target') ?? '').trim()
  const ruleType = String(pickRowValue(row, 'ruleType', 'ruletype', 'rule_type') ?? '').toLowerCase()

  let command = ''
  if (ruleType === 'file') {
    const filepath = String(pickRowValue(row, 'filepath', 'filePath', 'file_path', 'path') ?? '').trim()
    command = extractFileName(filepath)
  } else if (ruleType === 'package') {
    command = String(pickRowValue(row, 'artifactName', 'artifact_name', 'artifact') ?? '').trim()
  } else if (ruleType === 'service') {
    command = String(pickRowValue(row, 'serviceName', 'service_name', 'service') ?? '').trim()
  }

  if (!hostname || !command) return null
  return { hostname, command }
}

export interface DriftDetailItem {
  label: string
  value: string
}

export const buildDriftDetailsFromRow = (row: Record<string, unknown>): DriftDetailItem[] => {
  const ruleType = String(pickRowValue(row, 'ruleType', 'ruletype', 'rule_type') ?? '').trim().toLowerCase()
  const items: DriftDetailItem[] = [
    {
      label: 'Hostname',
      value: String(pickRowValue(row, 'hostname', 'host', 'target') ?? '').trim(),
    },
    {
      label: 'Rule Type',
      value: String(pickRowValue(row, 'ruleType', 'ruletype', 'rule_type') ?? '').trim(),
    },
  ]

  if (ruleType === 'file') {
    items.push({
      label: 'Filepath',
      value: String(pickRowValue(row, 'filepath', 'filePath', 'file_path', 'path') ?? '').trim(),
    })
  } else if (ruleType === 'package') {
    items.push({
      label: 'Artifact Name',
      value: String(pickRowValue(row, 'artifactName', 'artifact_name', 'artifact') ?? '').trim(),
    })
  } else if (ruleType === 'service') {
    items.push({
      label: 'Service Name',
      value: String(pickRowValue(row, 'serviceName', 'service_name', 'service') ?? '').trim(),
    })
  }

  items.push(
    {
      label: 'Status',
      value: String(pickRowValue(row, 'status', 'executionStatus', 'execution_status') ?? '').trim(),
    },
    {
      label: 'Action Taken',
      value: String(pickRowValue(row, 'actionTaken', 'action_taken', 'action') ?? '').trim(),
    },
  )

  return items.filter((item) => item.value)
}

export const getCommandLogErrorMessage = (row: Record<string, unknown>): string => {
  const hostname = String(pickRowValue(row, 'hostname', 'host', 'target') ?? '').trim()
  const ruleType = String(pickRowValue(row, 'ruleType', 'ruletype', 'rule_type') ?? '').trim()

  if (!hostname) return 'Hostname is required to load command logs'
  if (!ruleType) return 'Rule type is required to resolve command'

  const normalizedRuleType = ruleType.toLowerCase()
  if (normalizedRuleType === 'file') return 'File path is required to load command logs'
  if (normalizedRuleType === 'package') return 'Artifact name is required to load command logs'
  if (normalizedRuleType === 'service') return 'Service name is required to load command logs'

  return `Command could not be resolved for rule type "${ruleType}"`
}

const formatCommandLogTimestamp = (value: unknown): { date: string; time: string; tooltip?: string } => {
  if (value === null || value === undefined || value === '') {
    return { date: '—', time: '—' }
  }
  const m = moment(value as string | number | Date)
  if (!m.isValid()) {
    return { date: String(value), time: '' }
  }
  const formatted = m.local()
  return {
    date: formatted.format('DD MMM, YYYY'),
    time: formatted.format('hh:mm A'),
    tooltip: formatted.format('DD MMM, YYYY | hh:mm A'),
  }
}

const formatUserLabel = (value: string): string => {
  if (!value) return value
  return value.charAt(0).toUpperCase() + value.slice(1)
}

const buildCommandLogMetadata = (row: Record<string, unknown>): string | undefined => {
  const ipAddress = pickRowValue(row, 'ipAddress', 'ip_address', 'ip')
  const peer = pickRowValue(row, 'peer', 'peerAddress', 'peer_address')

  const metadataParts = [
    ipAddress ? `IP Address: ${ipAddress}` : '',
    peer ? `Peer: ${peer}` : '',
  ].filter(Boolean)

  return metadataParts.length ? metadataParts.join(' · ') : undefined
}

export const mapCommandLogsToTimeline = (response: unknown): DriftTimelineEntry[] => {
  const payload = (response as { data?: unknown })?.data ?? response
  const items = Array.isArray(payload) ? payload : []

  return items.map((item, index) => {
    const row = item as Record<string, unknown>
    const loggedInUser = String(pickRowValue(row, 'logged_in_user', 'loggedInUser') ?? '').trim()
    const currentUser = String(pickRowValue(row, 'current_user', 'currentUser') ?? '').trim()
    const command = String(pickRowValue(row, 'command') ?? '').trim()

    const timestampValue = pickRowValue(row, 'timestamp', 'time', 'createdAt', 'created_at')
    const { date, time, tooltip: timeTooltip } = formatCommandLogTimestamp(timestampValue)

    return {
      id: String(pickRowValue(row, 'id', '_id', 'logId') ?? `${timestampValue ?? 'log'}-${index}`),
      date,
      time,
      timeTooltip,
      loggedInUser: loggedInUser ? formatUserLabel(loggedInUser) : undefined,
      currentUser: currentUser ? formatUserLabel(currentUser) : undefined,
      title: command || '—',
      metadata: buildCommandLogMetadata(row),
      iconType: loggedInUser ? 'login' : 'terminal',
    }
  })
}

export interface DriftLogDialogProps {
  open: boolean
  onClose: () => void
  driftDetails?: DriftDetailItem[]
  timelineEntries?: DriftTimelineEntry[]
  timelineLoading?: boolean
  timelineError?: string
}

const TIMELINE_ICON_STYLES = {
  terminal: { bg: '#dbeafe', color: '#2563eb', icon: <Terminal size={14} /> },
  settings: { bg: '#fef3c7', color: '#d97706', icon: <Settings size={14} /> },
  login: { bg: '#ccfbf1', color: '#0d9488', icon: <LogIn size={14} /> },
} as const

const TRUNCATABLE_DRIFT_LABELS = new Set(['Filepath', 'Artifact Name', 'Service Name'])

const MetricItem: React.FC<{ label: string; value: string | number; truncate?: boolean }> = ({
  label,
  value,
  truncate = false,
}) => {
  const text = String(value)

  const valueTypography = (
    <Typography
      variant="body2"
      fontWeight={700}
      color="#0f172a"
      noWrap={truncate}
      sx={truncate ? { overflow: 'hidden', textOverflow: 'ellipsis' } : undefined}
    >
      {text}
    </Typography>
  )

  return (
    <Box sx={{ minWidth: 0, maxWidth: '100%' }}>
      <Typography variant="caption" color="text.secondary" display="block" mb={0.25}>
        {label}
      </Typography>
      {truncate ? (
        <Tooltip title={text} arrow placement="top">
          <Box component="span" sx={{ display: 'block', minWidth: 0, maxWidth: '100%', cursor: 'default' }}>
            {valueTypography}
          </Box>
        </Tooltip>
      ) : (
        valueTypography
      )}
    </Box>
  )
}

const TimelineMarker: React.FC<{ iconType?: DriftTimelineEntry['iconType'] }> = ({ iconType = 'terminal' }) => {
  const style = TIMELINE_ICON_STYLES[iconType]
  return (
    <Box
      sx={{
        width: 28,
        height: 28,
        borderRadius: '50%',
        bgcolor: style.bg,
        color: style.color,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
        border: '2px solid #fff',
        boxShadow: '0 0 0 1px #e2e8f0',
        zIndex: 1,
      }}
    >
      {style.icon}
    </Box>
  )
}

const UserBadge: React.FC<{ label: string }> = ({ label }) => (
  <Box
    sx={{
      display: 'inline-flex',
      px: 1,
      py: 0.2,
      borderRadius: '6px',
      bgcolor: '#f1f5f9',
      border: '1px solid #e2e8f0',
    }}
  >
    <Typography variant="caption" color="#475569" fontWeight={500}>
      {label}
    </Typography>
  </Box>
)

const TimelineEntry: React.FC<{ entry: DriftTimelineEntry; isLast?: boolean }> = ({ entry, isLast }) => (
  <Box sx={{ display: 'flex', gap: 2, position: 'relative', pb: isLast ? 0 : 2.5 }}>
    <Box sx={{ width: 96, flexShrink: 0, pt: 0.25, textAlign: 'right' }}>
      <Tooltip title={entry.timeTooltip ?? `${entry.date ?? ''} ${entry.time}`.trim()} arrow placement="top">
        <Box sx={{ cursor: 'default' }}>
          {entry.date && (
            <Typography variant="caption" color="text.secondary" fontWeight={500} display="block" lineHeight={1.4}>
              {entry.date}
            </Typography>
          )}
          <Typography variant="caption" color="text.secondary" fontWeight={500} display="block" lineHeight={1.4}>
            {entry.time}
          </Typography>
        </Box>
      </Tooltip>
    </Box>

    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: 28, flexShrink: 0 }}>
      <TimelineMarker iconType={entry.iconType} />
      {!isLast && (
        <Box
          sx={{
            flex: 1,
            width: 0,
            borderLeft: '2px dotted #cbd5e1',
            mt: 0.5,
            minHeight: 24,
          }}
        />
      )}
    </Box>

    <Box sx={{ flex: 1, minWidth: 0, pt: 0.1 }}>
      {(entry.loggedInUser || entry.currentUser) && (
        <Box display="flex" flexDirection="column" gap={0.5} mb={0.75}>
          {entry.loggedInUser && (
            <Typography variant="caption" color="text.secondary" lineHeight={1.5}>
              Logged in User:{' '}
              <Box component="span" fontWeight={600} color="#475569">
                {entry.loggedInUser}
              </Box>
            </Typography>
          )}
          {entry.currentUser && (
            <Typography variant="caption" color="text.secondary" lineHeight={1.5}>
              Current User:{' '}
              <Box component="span" fontWeight={600} color="#475569">
                {entry.currentUser}
              </Box>
            </Typography>
          )}
        </Box>
      )}
      {entry.title && entry.title !== '—' && (
        <Typography variant="caption" color="text.secondary" lineHeight={1.5} mb={entry.metadata ? 0.5 : 0}>
          Command:{' '}
          <Box component="span" fontWeight={600} color="#475569">
            {entry.title}
          </Box>
        </Typography>
      )}
      {entry.metadata && (
        <Typography variant="caption" color="text.secondary" display="block" lineHeight={1.5}>
          {entry.metadata}
        </Typography>
      )}
    </Box>
  </Box>
)

const DriftLogDialog: React.FC<DriftLogDialogProps> = ({
  open,
  onClose,
  driftDetails = [],
  timelineEntries = [],
  timelineLoading = false,
  timelineError,
}) => (
  <Dialog
    open={open}
    onClose={onClose}
    maxWidth="sm"
    fullWidth
    PaperProps={{
      sx: {
        borderRadius: '12px',
        overflow: 'hidden',
        maxHeight: '85vh',
      },
    }}
  >
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        px: 2.5,
        py: 2,
        borderBottom: '1px solid #e2e8f0',
      }}
    >
      <Box display="flex" alignItems="center" gap={1}>
        <FileText size={18} color="#2563eb" />
        <Typography variant="subtitle1" fontWeight={700} color="#0f172a" sx={{ textTransform: 'lowercase' }}>
          logs
        </Typography>
      </Box>
      <IconButton size="small" onClick={onClose} sx={{ color: '#94a3b8' }}>
        <X size={18} />
      </IconButton>
    </Box>

    <Box sx={{ px: 2.5, py: 2.5, overflowY: 'auto', maxHeight: 'calc(85vh - 64px)' }}>
      <Box sx={{ display: 'flex', gap: 2, position: 'relative', pb: timelineEntries.length ? 2.5 : 0 }}>
        <Box sx={{ width: 96, flexShrink: 0 }} />

        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: 28, flexShrink: 0 }}>
          <Box
            sx={{
              width: 28,
              height: 28,
              borderRadius: '50%',
              bgcolor: '#dbeafe',
              color: '#2563eb',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              border: '2px solid #fff',
              boxShadow: '0 0 0 1px #e2e8f0',
              zIndex: 1,
            }}
          >
            <Terminal size={14} />
          </Box>
          {(timelineEntries.length > 0 || timelineLoading) && (
            <Box
              sx={{
                flex: 1,
                width: 0,
                borderLeft: '2px dotted #cbd5e1',
                mt: 0.5,
                minHeight: 24,
              }}
            />
          )}
        </Box>

        <Box sx={{ flex: 1, minWidth: 0 }}>
          <UserBadge label="CSP Agent" />

          <Typography
            variant="caption"
            color="text.secondary"
            fontWeight={600}
            display="block"
            sx={{ mt: 0.75, mb: 1, textTransform: 'uppercase', letterSpacing: '0.04em' }}
          >
            Drift Action Details
          </Typography>

          <Grid container spacing={2}>
            {driftDetails.length ? driftDetails.map((item) => (
              <Grid item xs={6} key={item.label} sx={{ minWidth: 0 }}>
                <MetricItem
                  label={item.label}
                  value={item.value}
                  truncate={TRUNCATABLE_DRIFT_LABELS.has(item.label)}
                />
              </Grid>
            )) : (
              <Grid item xs={12}>
                <Typography variant="body2" color="text.secondary">No drift details available</Typography>
              </Grid>
            )}
          </Grid>
        </Box>
      </Box>

      {timelineLoading && (
        <Box display="flex" justifyContent="center" py={2}>
          <CircularProgress size={22} />
        </Box>
      )}

      {!timelineLoading && timelineError && (
        <Typography variant="body2" color="error" textAlign="center" py={2}>
          {timelineError}
        </Typography>
      )}

      {!timelineLoading && !timelineError && timelineEntries.length === 0 && (
        <Typography variant="body2" color="text.secondary" textAlign="center" py={2}>
          No command logs found
        </Typography>
      )}

      {!timelineLoading && timelineEntries.map((entry, index) => (
        <TimelineEntry
          key={entry.id}
          entry={entry}
          isLast={index === timelineEntries.length - 1}
        />
      ))}
    </Box>
  </Dialog>
)

export default DriftLogDialog
