import React, { useState } from 'react'
import { Policy } from '../../../utils/enums'
import '../policies.scss'
import { POLICYOPS_PATH } from '../../../utils/constant'
import { useHistory } from 'react-router-dom'
import { MoreVertical } from 'lucide-react'
import { Menu, MenuItem, IconButton } from '@mui/material'

import { useDeletePolicyMutation } from '../../../redux/slices/policiesSlice'
import { toast } from 'react-toastify'
import { useRevokeAssignmentMutation } from '../../../redux/slices/assignmentsSlice'

interface Props {
  policy: Policy
  onClick?: () => void
  onDeleteSuccess?: () => void
  onView?: () => void

  type?: 'policy' | 'assignment'
}

const PolicyCard: React.FC<Props> = ({ policy, onClick, onDeleteSuccess, type, onView }) => {
  const coverage = policy.compliance_coverage ?? 0


  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null)
  const [deletePolicy, { isLoading: deletingPolicy }] = useDeletePolicyMutation()
  const [deleteAssignment, { isLoading: deletingAssignment }] = useRevokeAssignmentMutation()

  const open = Boolean(anchorEl)

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>) => {
    event.stopPropagation()
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const history = useHistory()

  const handleCardClick = () => {
    if (onClick) {
      onClick()
    } else {
      history.push(`${POLICYOPS_PATH.POLICIES}/${policy._id}/view`)
    }
  }

  const handleEdit = () => {
    handleClose()

    if (type === 'assignment') {
      history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/${policy._id}/edit`)
    } else {
      history.push(`${POLICYOPS_PATH.POLICIES}/${policy._id}/edit`)

    }
  }

  const handleView = () => {
    handleClose()

    if (type === 'assignment') {
      onView?.()
    } else {
      history.push(`${POLICYOPS_PATH.POLICIES}/${policy._id}/view`)
    }
  }


  const handleDelete = async () => {
    handleClose()
    try {
      if (type === 'assignment') {

        await deleteAssignment(policy._id).unwrap()
      } else {
        await deletePolicy(policy._id).unwrap()
      }



      toast.success('Deleted successfully ')

      onDeleteSuccess?.()

    } catch (err: any) {
      toast.error(err?.data?.message || 'Failed to delete')
    }
  }

  console.log("policy", policy)

  const username = policy.updated_by || policy.created_by || '';
  const getInitials = (name: string): string =>
    name.trim().split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('');


  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);

    const formattedDate = date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });

    const formattedTime = date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

    return `${formattedDate} | ${formattedTime}`;
  };


  return (
    <div
      className="ps-policy-card"
      onClick={handleCardClick}
      role="button"
      tabIndex={0}
    >
      {/* Header */}
      <div className="ps-policy-card__header">
        <p className="ps-policy-card__name">{policy.name}</p>

        {/* RIGHT SIDE */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>

          {/* Status */}
          <span className={`ps-status-badge ps-status-badge--${policy.status.toLowerCase()}`}>
            {policy.status}
          </span>

          {/* 3 DOT MENU */}
          {/* {type !== 'assignment' && ( */}
          <>
            <IconButton
              size="small"
              onClick={handleMenuClick}
              sx={{ color: '#94a3b8' }}
            >
              <MoreVertical size={16} />
            </IconButton>

            <Menu
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
              onClick={(e) => e.stopPropagation()}
              PaperProps={{
                sx: {
                  borderRadius: '10px',
                  mt: 1,
                  minWidth: 140,
                  boxShadow: '0px 4px 16px rgba(0,0,0,0.08)',
                },
              }}
            >
              {type !== 'assignment' && (
              <MenuItem onClick={handleEdit}>Edit</MenuItem>)}
              <MenuItem onClick={handleView}>View</MenuItem>
              <MenuItem onClick={handleDelete} sx={{ color: '#ef4444' }}>
                Delete
              </MenuItem>
            </Menu>
          </>
          {/* )} */}
        </div>
      </div>

      {/* Meta */ }
      <div className="ps-policy-card__meta">
        <div className="ps-policy-card__meta-item">
          <span className="ps-policy-card__meta-label">Execution type</span>
          <span className="ps-policy-card__meta-value">{policy.executionInfo?.executionMode || '—'}</span>
        </div>

        <div className="ps-policy-card__meta-item ps-policy-card__meta-item--right">
          <span className="ps-policy-card__meta-label">{type === 'assignment' ? 'Policies' : 'Rules'}</span>
          <span className="ps-policy-card__meta-value">{policy.rules.length}</span>
        </div>
      </div>


      {/* Footer */}
      <div className="ps-policy-card__footer">
        <div className="ps-policy-card__user">
          <div className="ps-policy-card__avatar-placeholder">
            {getInitials(username)}
          </div>
          <span className="ps-policy-card__username">{policy.updated_by || policy.created_by}</span>
        </div>

        <div className="ps-policy-card__date">
          {formatDateTime(policy.updated_at || policy.created_at)}
        </div>
      </div>
    </div >
  )
}

export default PolicyCard
