import React, { useState } from 'react'
import Cookies from 'universal-cookie'
import { formatDisplayName } from '../../utils/uiConstants'
import {
  Box, Button, Grid, MenuItem, Paper, Select, Typography,
  Table, TableBody, TableCell, TableContainer, TableHead,
  TableRow, Chip, LinearProgress, InputAdornment, TextField,
} from '@mui/material'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, BarChart, Bar,
} from 'recharts'
import {
  FileText, Settings, Server, AlertTriangle, Search,
  TrendingUp, TrendingDown, Zap, Plus, Download, SlidersHorizontal,
  Clock, CheckCircle, Activity, XCircle,
} from 'lucide-react'
import { useHistory } from 'react-router-dom'
import { useGetDashboardSummaryQuery } from '../../redux/slices/complianceSlice'
import { useGetRulesQuery } from '../../redux/slices/rulesSlice'
import { useGetAgentsHealthQuery } from '../../redux/slices/agentsSlice'
import { POLICYOPS_PATH } from '../../utils/constant'

// ── Dummy data ─────────────────────────────────────────────────────────────────

const DEPLOYMENT_TREND = [
  { month: 'Jan', value: 76 },
  { month: 'Feb', value: 80 },
  { month: 'Mar', value: 78 },
  { month: 'Apr', value: 85 },
  { month: 'May', value: 91 },
  { month: 'Jun', value: 95 },
]

const EXECUTION_THROUGHPUT = Array.from({ length: 10 }, (_, i) => ({
  label: `W${i + 1}`,
  light: Math.floor(Math.random() * 400) + 100,
  dark: Math.floor(Math.random() * 600) + 200,
}))

const AGENTS = [
  { id: 'cs-agent-prod-001', version: 'V2.2.1', env: 'Production', lastCheckin: '1 min ago', success: 82, status: 'Healthy' },
  { id: 'cs-agent-prod-002', version: 'V2.2.0', env: 'Production', lastCheckin: '3 min ago', success: 95, status: 'Healthy' },
  { id: 'cs-agent-staging-01', version: 'V2.1.9', env: 'Staging', lastCheckin: '12 min ago', success: 67, status: 'Stale' },
  { id: 'cs-agent-dev-003', version: 'V2.1.8', env: 'Development', lastCheckin: '45 min ago', success: 40, status: 'Offline' },
]

const ACTIVITIES = [
  { title: 'Heartbeat', sub: 'cs-agent-prod-001', time: '1 min ago' },
  { title: 'Policy sync', sub: 'cs-agent-prod-002', time: '2 min ago' },
  { title: 'Config drift detected', sub: 'cs-agent-staging-01', time: '8 min ago' },
  { title: 'Auto remediation triggered', sub: 'cs-agent-prod-001', time: '11 min ago' },
  { title: 'Rule execution failed', sub: 'cs-agent-dev-003', time: '22 min ago' },
  { title: 'Package install complete', sub: 'cs-agent-prod-002', time: '35 min ago' },
]

const TABS = ['Server Compliance', 'Assignment Health', 'Incidents', 'Agent Health']

// ── Gauge component (SVG) ─────────────────────────────────────────────────────

const ResponseGauge: React.FC<{ value: number }> = ({ value }) => (
  <Box display="flex" flexDirection="column" alignItems="center" pt={1}>
    <svg viewBox="0 0 180 110" width={170} height={105}>
      <path d="M20,95 A70,70 0 0,1 160,95" fill="none" stroke="#fee2e2" strokeWidth="14" strokeLinecap="round" />
      <path d="M20,95 A70,70 0 0,1 70,30" fill="none" stroke="#10b981" strokeWidth="14" strokeLinecap="round" />
      <path d="M70,30 A70,70 0 0,1 115,28" fill="none" stroke="#fbbf24" strokeWidth="14" strokeLinecap="round" />
      <path d="M115,28 A70,70 0 0,1 160,95" fill="none" stroke="#f97316" strokeWidth="14" strokeLinecap="round" />
      <line x1="90" y1="95" x2="108" y2="38" stroke="#1a1d2e" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="90" cy="95" r="5" fill="#1a1d2e" />
      <text x="90" y="78" fontSize="22" fontWeight="800" fill="#1a1d2e" textAnchor="middle">{value}</text>
      <text x="90" y="92" fontSize="8.5" fill="#888" textAnchor="middle">Your response time in every millisecond</text>
      <text x="90" y="104" fontSize="8.5" fill="#aaa" textAnchor="middle">Last Check on 21 Apr</text>
    </svg>
  </Box>
)

// ── Status badge ──────────────────────────────────────────────────────────────

const statusColor = (s: string) =>
  s === 'Healthy' ? { bg: '#dcfce7', color: '#16a34a' }
    : s === 'Stale' ? { bg: '#fef9c3', color: '#a16207' }
      : { bg: '#fee2e2', color: '#dc2626' }

// ── Main dashboard ────────────────────────────────────────────────────────────

const DashboardPage: React.FC = () => {
  const history = useHistory()
  const fullName = formatDisplayName(new Cookies().get('user_fullname') || '')
  const [activeTab, setActiveTab] = useState('Agent Health')

  const { data: dashData } = useGetDashboardSummaryQuery()
  const { data: healthData } = useGetAgentsHealthQuery()
  const { data: rulesData } = useGetRulesQuery({ page: 1, limit: 1 })

  const summary = dashData?.data
  const health = healthData?.data ?? { online: 0, stale: 0, offline: 0, total: 142 }
  const complianceRate = summary?.compliance_rate ?? 98.7

  const statCards = [
    {
      label: 'Servers Managed', value: health.total || 142, color: '#3b5bdb',
      icon: <Server size={14} />, trend: '+12', up: true,
    },
    {
      label: 'Auto Redemption', value: `${complianceRate.toFixed(1)}%`, color: '#10b981',
      icon: <CheckCircle size={14} />, trend: '+12%', up: true, green: true,
    },
    {
      label: 'Execution (24H)', value: summary?.executions_today ?? 118, color: '#6366f1',
      icon: <Activity size={14} />, trend: '+5', up: true,
    },
    {
      label: 'Drift Events (24h)', value: summary?.drift_events_today ?? 28, color: '#f97316',
      icon: <AlertTriangle size={14} />, trend: '-8', up: false, warn: true,
    },
    {
      label: 'Failed Execution', value: summary?.failing_servers ?? 14, color: '#ef4444',
      icon: <XCircle size={14} />, trend: '-3', up: false, danger: true,
    },
  ]

  return (
    <Box p={2.5} bgcolor="#f4f5f7" minHeight="100vh">
      {/* Welcome */}
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={2}>
        <Box>
          <Typography variant="h6" fontWeight={700} sx={{ color: '#1a1d2e' }}>Welcome {fullName || 'Emma'}</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.78rem' }}>
            Real-time visibility into configuration compliance, drift events and autonomous remediation across the estate.
          </Typography>
        </Box>
        <Box>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <input
              className="ps-toolbar__search"
              placeholder="Search"
            // value={search}
            // onChange={(e) => onSearch(e.target.value)}
            />
            <Button variant="contained" >Ask Assistant</Button>
          </div>
        </Box>
      </Box>

      {/* Hero banner */}
      <Paper elevation={0} >
        <Grid container alignItems="center" spacing={2}>
          <Grid item xs={12} md={7} 
          sx={{padding: "20px",
    border: '1px solid #D7E2FF',
    background: '#F3F6FF',
    borderRadius: "16px"}}
          >
            <Box sx={{

              fontSize: '0.65rem', border: '1px solid #D7E2FF',
              backgroundColor: '#FFFFFF',
              padding: "10px",
              borderRadius: "20px",
              color: '#2961F4',
              fontWeight: 500, mb: 1,
            }}>
              POLICYOPS ENFORCER
            </Box>
            <Typography variant="h6" fontWeight={700} sx={{ color: '#1a1d2e', mb: 0.75 }}>
              Configuration State &amp; Self-Healing Operations
            </Typography>
            <Typography variant="body2" sx={{ color: '#666', fontSize: '0.8rem', lineHeight: 1.55, maxWidth: 480 }}>
              PolicyOps ensures active configs remain compliant. Try simulating an out-of-order policy drift to view our real-time correction system in play.
            </Typography>
          </Grid>
          <Grid item xs={12} md={5}>
            <Box display="flex" alignItems="center" gap={2} justifyContent={{ xs: 'flex-start', md: 'flex-end' }}>
              <Box>
                <Typography sx={{ fontSize: '3.4rem', fontWeight: 800, color: '#1a1d2e', lineHeight: 1 }}>
                  {complianceRate.toFixed(1)}%
                </Typography>
                <Typography sx={{ fontSize: '0.85rem', fontWeight: 600, color: '#1a1d2e', mt: 0.5 }}>Compliance Posture</Typography>
                <Typography variant="caption" color="text.secondary">Across all managed infrastructure</Typography>
              </Box>
              <Box sx={{
                width: 48, height: 48, bgcolor: '#3b5bdb', borderRadius: 2.5,
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              }}>
                <Zap size={22} color="white" />
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Paper>

      {/* Stat cards */}
      <Grid container spacing={1.5} mb={2}>
        {statCards.map((c) => (
          <Grid item xs={6} sm={4} md key={c.label}>
            <Paper elevation={0} sx={{ p: 1.5, borderRadius: 2, border: '1px solid #e8eaf0', bgcolor: 'white' }}>
              <Box display="flex" alignItems="center" gap={0.75} mb={0.5}>
                <Box sx={{ color: c.color, display: 'flex' }}>{c.icon}</Box>
                <Typography sx={{ fontSize: '0.7rem', color: '#888', fontWeight: 500 }}>{c.label}</Typography>
              </Box>
              <Typography sx={{
                fontSize: '1.5rem', fontWeight: 700,
                color: c.green ? '#10b981' : c.warn ? '#f97316' : c.danger ? '#ef4444' : '#1a1d2e',
              }}>
                {c.value}
              </Typography>
              <Box display="inline-flex" alignItems="center" gap={0.4}
                sx={{
                  bgcolor: c.up ? '#dcfce7' : '#fee2e2',
                  borderRadius: '20px', px: 0.75, py: 0.25, mt: 0.5,
                }}>
                {c.up ? <TrendingUp size={10} color="#16a34a" /> : <TrendingDown size={10} color="#dc2626" />}
                <Typography sx={{ fontSize: '0.65rem', fontWeight: 700, color: c.up ? '#16a34a' : '#dc2626' }}>
                  {c.trend}
                </Typography>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>

      {/* Tabs */}
      <Box display="flex" borderBottom="1px solid #e8eaf0" mb={2}>
        {TABS.map((t) => (
          <Box key={t} onClick={() => setActiveTab(t)} sx={{
            fontSize: '0.78rem', px: 1.75, py: 0.9, cursor: 'pointer',
            borderBottom: activeTab === t ? '2px solid #3b5bdb' : '2px solid transparent',
            color: activeTab === t ? '#3b5bdb' : '#888',
            fontWeight: activeTab === t ? 700 : 400,
            mb: '-1px',
          }}>
            {t}
          </Box>
        ))}
      </Box>

      {/* Charts */}
      <Grid container spacing={1.5} mb={2}>
        {/* Deployment Trends */}
        <Grid item xs={12} md={4.5}>
          <Paper elevation={0} sx={{ p: 2, borderRadius: 2, border: '1px solid #e8eaf0', bgcolor: 'white', height: 200 }}>
            <Typography sx={{ fontSize: '0.82rem', fontWeight: 600, mb: 1 }}>Deployment Trends</Typography>
            <ResponsiveContainer width="100%" height={150}>
              <AreaChart data={DEPLOYMENT_TREND} margin={{ top: 0, right: 5, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="dGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#f43f5e" stopOpacity={0.18} />
                    <stop offset="100%" stopColor="#f43f5e" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#bbb' }} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: '#bbb' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ border: '1px solid #e2e8f0', borderRadius: 8, fontSize: 11 }} />
                <Area type="monotone" dataKey="value" stroke="#f43f5e" strokeWidth={2} fill="url(#dGrad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        {/* Execution Throughput */}
        <Grid item xs={12} md={4.5}>
          <Paper elevation={0} sx={{ p: 2, borderRadius: 2, border: '1px solid #e8eaf0', bgcolor: 'white', height: 200 }}>
            <Typography sx={{ fontSize: '0.82rem', fontWeight: 600, mb: 1 }}>Execution Throughput</Typography>
            <ResponsiveContainer width="100%" height={150}>
              <BarChart data={EXECUTION_THROUGHPUT} margin={{ top: 0, right: 5, left: -25, bottom: 0 }} barCategoryGap="20%">
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 10, fill: '#bbb' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: '#bbb' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ border: '1px solid #e2e8f0', borderRadius: 8, fontSize: 11 }} />
                <Bar dataKey="light" fill="#93c5fd" radius={[3, 3, 0, 0]} barSize={6} />
                <Bar dataKey="dark" fill="#3b82f6" radius={[3, 3, 0, 0]} barSize={6} />
              </BarChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        {/* Response Time gauge */}
        <Grid item xs={12} md={3}>
          <Paper elevation={0} sx={{ p: 2, borderRadius: 2, border: '1px solid #e8eaf0', bgcolor: 'white', height: 200 }}>
            <Typography sx={{ fontSize: '0.82rem', fontWeight: 600, mb: 0.5 }}>Response Time (ms)</Typography>
            <ResponseGauge value={120} />
          </Paper>
        </Grid>
      </Grid>

      {/* Agent Health + Activity */}
      <Grid container spacing={1.5}>
        <Grid item xs={12} md={8}>
          <Paper elevation={0} sx={{ p: 2, borderRadius: 2, border: '1px solid #e8eaf0', bgcolor: 'white' }}>
            <Typography sx={{ fontSize: '0.82rem', fontWeight: 600, mb: 1.5 }}>Agent Health</Typography>
            <Box display="flex" gap={1} mb={1.5}>
              <TextField
                size="small" placeholder="Search"
                InputProps={{
                  startAdornment: <InputAdornment position="start"><Search size={13} /></InputAdornment>,
                  sx: { fontSize: '0.78rem', height: 32 },
                }}
                sx={{ flex: 1, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#e2e5ef' } }}
              />
              <Button variant="outlined" size="small" startIcon={<SlidersHorizontal size={13} />}
                sx={{ borderColor: '#e2e5ef', color: '#555', fontSize: '0.75rem', height: 32 }}>Filter</Button>
              <Button variant="outlined" size="small" startIcon={<Download size={13} />}
                sx={{ borderColor: '#e2e5ef', color: '#555', fontSize: '0.75rem', height: 32 }}>Export</Button>
            </Box>
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell padding="checkbox" />
                    {['Agent', 'Version', 'Environment', 'Last Check-In', 'Success Rate', 'Status'].map((h) => (
                      <TableCell key={h} sx={{ fontSize: '0.7rem', color: '#888', fontWeight: 500 }}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {AGENTS.map((a) => {
                    const sc = statusColor(a.status)
                    const barColor = a.status === 'Healthy' ? '#10b981' : a.status === 'Stale' ? '#fbbf24' : '#ef4444'
                    return (
                      <TableRow key={a.id} hover>
                        <TableCell padding="checkbox"><input type="checkbox" /></TableCell>
                        <TableCell sx={{ fontSize: '0.75rem', fontWeight: 600, color: '#3b5bdb' }}>{a.id}</TableCell>
                        <TableCell sx={{ fontSize: '0.75rem' }}>{a.version}</TableCell>
                        <TableCell sx={{ fontSize: '0.75rem' }}>{a.env}</TableCell>
                        <TableCell sx={{ fontSize: '0.75rem' }}>{a.lastCheckin}</TableCell>
                        <TableCell>
                          <Box display="flex" alignItems="center" gap={0.75}>
                            <LinearProgress variant="determinate" value={a.success}
                              sx={{
                                width: 60, height: 5, borderRadius: 3, bgcolor: '#e8eaf0',
                                '& .MuiLinearProgress-bar': { bgcolor: barColor, borderRadius: 3 },
                              }} />
                            <Typography sx={{ fontSize: '0.72rem' }}>{a.success}%</Typography>
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Chip label={a.status} size="small"
                            sx={{ bgcolor: sc.bg, color: sc.color, fontSize: '0.68rem', height: 20, fontWeight: 600 }} />
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>

        <Grid item xs={12} md={4}>
          <Paper elevation={0} sx={{ p: 2, borderRadius: 2, border: '1px solid #e8eaf0', bgcolor: 'white', height: '100%' }}>
            <Typography sx={{ fontSize: '0.82rem', fontWeight: 600, mb: 1.5 }}>Agent Activity</Typography>
            {ACTIVITIES.map((a, i) => (
              <Box key={i} py={1} borderBottom={i < ACTIVITIES.length - 1 ? '1px solid #f8f8f8' : 'none'}>
                <Box display="flex" justifyContent="space-between" alignItems="flex-start">
                  <Typography sx={{ fontSize: '0.78rem', fontWeight: 600, color: '#1a1d2e' }}>{a.title}</Typography>
                  <Typography sx={{ fontSize: '0.68rem', color: '#bbb', flexShrink: 0, ml: 1 }}>{a.time}</Typography>
                </Box>
                <Typography sx={{ fontSize: '0.72rem', color: '#aaa' }}>{a.sub}</Typography>
              </Box>
            ))}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  )
}

export default DashboardPage