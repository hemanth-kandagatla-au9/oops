import React, { useCallback, useMemo, useState } from 'react'
import {
  Avatar,
  Box,
  Button,
  Checkbox,
  Chip,
  FormControl,
  Grid,
  IconButton,
  InputAdornment,
  InputLabel,
  Menu,
  MenuItem,
  Paper,
  Popover,
  Select,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material'
import moment from 'moment'
import {
  Activity,
  AlertTriangle,
  Columns3,
  List,
  // Download,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Timer,
} from 'lucide-react'
import { toast } from 'react-toastify'
import {
  useGetDriftEventsQuery,
  useGetDriftLogMetricsQuery,
  usePostCommandLogsMutation,
} from '../../redux/slices/complianceSlice'
import DriftLogDialog, {
  buildDriftDetailsFromRow,
  getCommandLogErrorMessage,
  mapCommandLogsToTimeline,
  parseDriftLogMetrics,
  resolveCommandLogPayload,
} from '../../components/DriftLogDialog'
import PolicyTable, { TableColumn } from '../../components/PolicyTable'

type DriftLogRow = Record<string, any>
type LogView = 'execution' | 'drift'

const FORM_FIELD_SX = {
  '& .MuiOutlinedInput-root': {
    borderRadius: '8px',
    bgcolor: '#ffffff',
    fontSize: '0.875rem',
    '& fieldset': { borderColor: '#e2e8f0' },
    '&:hover fieldset': { borderColor: '#cbd5e1' },
    '&.Mui-focused fieldset': { borderColor: '#2563eb', borderWidth: '1px' },
  },
  '& .MuiInputLabel-root': { color: '#64748b', fontSize: '0.875rem' },
}

const pickValue = (row: DriftLogRow, ...keys: string[]): any => {
  for (const key of keys) {
    if (row[key] !== undefined && row[key] !== null && row[key] !== '') return row[key]
  }
  return null
}

const toTitle = (key: string): string =>
  key
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())

const STATUS_FILTER_OPTIONS = ['success', 'failed'] as const

const isDriftActionColumn = (key: string): boolean => /^action$/i.test(key)

const capitalizeStatusLabel = (value: string): string =>
  value
    .toLowerCase()
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())

const formatCell = (value: any): string => {
  if (value === null || value === undefined || value === '') return '-'
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}

const isTimestampKey = (key: string): boolean => {
  const normalized = key.toLowerCase().replace(/_/g, '')
  return (
    normalized === 'timestamp'
    || normalized === 'time'
    || normalized.endsWith('timestamp')
    || normalized === 'createdat'
    || normalized === 'updatedat'
    || normalized === 'eventtime'
  )
}

const formatTimestamp = (value: any): string | null => {
  if (value === null || value === undefined || value === '') return null
  const m = moment(value)
  if (!m.isValid()) return null
  return m.local().format('DD MMM, YYYY | hh:mm A')
}

const formatDriftCell = (key: string, value: any): string => {
  if (isTimestampKey(key)) {
    return formatTimestamp(value) ?? formatCell(value)
  }
  return formatCell(value)
}

const getDriftRowId = (row: DriftLogRow): string =>
  String(
    pickValue(row, 'executionId', 'execution_id', '_id', 'id')
    ?? [row.hostname, row.timestamp, row.ruleId].map(formatCell).join('-'),
  )

const isSuccessStatus = (status: string) =>
  ['success', 'completed', 'fixed', 'pass', 'passed'].includes(status.toLowerCase())

const isFailedStatus = (status: string) =>
  ['failed', 'error', 'failure'].includes(status.toLowerCase())

interface DriftStatCardProps {
  label: string
  value: string | number
  valueColor?: string
  icon: React.ReactNode
  iconColor: string
  iconBg: string
}

const DriftStatCard: React.FC<DriftStatCardProps> = ({
  label,
  value,
  valueColor = '#0f172a',
  icon,
  iconColor,
  iconBg,
}) => (
  <Paper
    elevation={0}
    sx={{
      p: 2.5,
      borderRadius: '10px',
      border: '1px solid #e2e8f0',
      bgcolor: 'white',
      boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
      height: '100%',
    }}
  >
    <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1.5}>
      <Typography variant="caption" color="text.secondary" fontWeight={500}>{label}</Typography>
      <Box
        sx={{
          width: 36,
          height: 36,
          borderRadius: '8px',
          bgcolor: iconBg,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}
      >
        <Box sx={{ color: iconColor, display: 'flex' }}>{icon}</Box>
      </Box>
    </Box>
    <Typography variant="h5" fontWeight={700} color={valueColor}>
      {typeof value === 'number' ? value.toLocaleString() : value}
    </Typography>
  </Paper>
)

const ActionBadge: React.FC<{ action: string }> = ({ action }) => (
  <Chip
    label={action}
    size="small"
    sx={{
      height: 24,
      fontSize: '0.72rem',
      fontWeight: 600,
      bgcolor: '#eff6ff',
      color: '#2563eb',
      borderRadius: '6px',
      '& .MuiChip-label': { px: 1 },
    }}
  />
)

const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const normalized = status.toLowerCase()
  const success = isSuccessStatus(normalized)
  const failed = isFailedStatus(normalized)

  return (
    <Chip
      label={status}
      size="small"
      sx={{
        height: 24,
        fontSize: '0.72rem',
        fontWeight: 600,
        borderRadius: '999px',
        bgcolor: success ? '#dcfce7' : failed ? '#fee2e2' : '#f1f5f9',
        color: success ? '#15803d' : failed ? '#dc2626' : '#64748b',
        '& .MuiChip-label': { px: 1.25 },
      }}
    />
  )
}

const UserCell: React.FC<{ name: string }> = ({ name }) => {
  const initials = name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('')

  return (
    <Box display="flex" alignItems="center" gap={1}>
      <Avatar sx={{ width: 28, height: 28, fontSize: '0.7rem', fontWeight: 700, bgcolor: '#2563eb' }}>
        {initials || '?'}
      </Avatar>
      <Typography variant="body2" color="#0f172a" noWrap>{name}</Typography>
    </Box>
  )
}

const LOG_TOGGLE_SX = {
  display: 'inline-flex',
  bgcolor: '#f8fafc',
  borderRadius: '999px',
  border: '1px solid #e2e8f0',
  p: 0.5,
  gap: 0.5,
}

const logToggleBtnSx = (active: boolean) => ({
  textTransform: 'none' as const,
  fontWeight: 600,
  fontSize: '0.8125rem',
  borderRadius: '999px',
  px: 2.5,
  py: 0.75,
  minWidth: 140,
  boxShadow: 'none',
  bgcolor: active ? '#2563eb' : 'transparent',
  color: active ? '#ffffff' : '#64748b',
  '&:hover': {
    bgcolor: active ? '#1d4ed8' : '#f1f5f9',
    boxShadow: 'none',
  },
})

const DriftPage: React.FC = () => {
  const [logView, setLogView] = useState<LogView>('execution')
  const [search, setSearch] = useState('')
  const [appliedStatusFilter, setAppliedStatusFilter] = useState('')
  const [appliedHostnameFilter, setAppliedHostnameFilter] = useState('')
  const [draftStatusFilter, setDraftStatusFilter] = useState('')
  const [draftHostnameFilter, setDraftHostnameFilter] = useState('')
  const [page, setPage] = useState(0)
  const [pageSize, setPageSize] = useState(25)
  const [filterAnchor, setFilterAnchor] = useState<HTMLElement | null>(null)
  const [columnsAnchor, setColumnsAnchor] = useState<HTMLElement | null>(null)
  const [hiddenColumns, setHiddenColumns] = useState<string[]>([])
  const [logDialogRow, setLogDialogRow] = useState<DriftLogRow | null>(null)
  const [commandTimelineError, setCommandTimelineError] = useState('')

  const driftLogFilters = useMemo(() => ({
    search: search.trim() || undefined,
    status: appliedStatusFilter || undefined,
    hostname: appliedHostnameFilter.trim() || undefined,
    driftDetected: logView === 'drift' ? true : undefined,
  }), [search, appliedStatusFilter, appliedHostnameFilter, logView])

  const { data: metricsData, isLoading: metricsLoading, isFetching: metricsFetching } = useGetDriftLogMetricsQuery(driftLogFilters)

  const [
    fetchCommandLogs,
    { data: commandLogsData, isLoading: commandLogsLoading, reset: resetCommandLogs },
  ] = usePostCommandLogsMutation()

  const commandLogPayload = useMemo(
    () => (logDialogRow ? resolveCommandLogPayload(logDialogRow) : null),
    [logDialogRow],
  )

  const commandTimelineEntries = useMemo(() => {
    if (!commandLogPayload || !commandLogsData) return []
    return mapCommandLogsToTimeline(commandLogsData)
  }, [commandLogPayload, commandLogsData])

  const commandLogsLoadingState = Boolean(logDialogRow && commandLogsLoading)

  const handleOpenLogDialog = useCallback(async (row: DriftLogRow) => {
    setLogDialogRow(row)
    setCommandTimelineError('')

    const payload = resolveCommandLogPayload(row)
    if (!payload) {
      const message = getCommandLogErrorMessage(row)
      setCommandTimelineError(message)
      toast.error(message)
      return
    }

    try {
      await fetchCommandLogs(payload).unwrap()
    } catch {
      const message = 'Failed to load command logs'
      setCommandTimelineError(message)
      toast.error(message)
    }
  }, [fetchCommandLogs])

  const handleCloseLogDialog = useCallback(() => {
    setLogDialogRow(null)
    setCommandTimelineError('')
    resetCommandLogs()
  }, [resetCommandLogs])

  const { data, isLoading, isFetching, isError } = useGetDriftEventsQuery({
    page: page + 1,
    limit: pageSize,
    ...driftLogFilters,
  })

  const rows: DriftLogRow[] = data?.data ?? []

  const hostnameOptions = useMemo(() => {
    const options = new Set<string>()
    rows.forEach((row) => {
      const hostname = String(pickValue(row, 'hostname', 'host', 'target') ?? '').trim()
      if (hostname) options.add(hostname)
    })
    if (appliedHostnameFilter.trim()) options.add(appliedHostnameFilter.trim())
    if (draftHostnameFilter.trim()) options.add(draftHostnameFilter.trim())
    return Array.from(options).sort((a, b) => a.localeCompare(b))
  }, [rows, appliedHostnameFilter, draftHostnameFilter])
  const total: number = data?.total ?? 0
  const tableLoading = isLoading || isFetching

  const allColumnKeys = useMemo(() => {
    if (rows.length === 0) {
      return [
        'executionId',
        'assignment',
        ...(logView === 'drift' ? ['action'] : []),
        'target',
        'status',
        'duration',
        'by',
        'time',
      ]
    }

    const keySet = new Set<string>()
    const ordered: string[] = []

    rows.forEach((row) => {
      Object.keys(row).forEach((key) => {
        if (!keySet.has(key)) {
          keySet.add(key)
          ordered.push(key)
        }
      })
    })

    return ordered
  }, [rows, logView])

  const visibleColumnKeys = useMemo(
    () => allColumnKeys.filter((key) => {
      if (logView === 'execution' && isDriftActionColumn(key)) return false
      return !hiddenColumns.includes(key)
    }),
    [allColumnKeys, hiddenColumns, logView],
  )

  const toggleColumn = (key: string) => {
    setHiddenColumns((prev) => (
      prev.includes(key)
        ? prev.filter((item) => item !== key)
        : [...prev, key]
    ))
  }

  const openFilterPopover = (anchor: HTMLElement) => {
    setDraftHostnameFilter(appliedHostnameFilter)
    setDraftStatusFilter(appliedStatusFilter)
    setFilterAnchor(anchor)
  }

  const applyFilters = () => {
    setAppliedHostnameFilter(draftHostnameFilter)
    setAppliedStatusFilter(draftStatusFilter)
    setPage(0)
    setFilterAnchor(null)
  }

  const clearDraftFilters = () => {
    setDraftHostnameFilter('')
    setDraftStatusFilter('')
  }

  const clearAllAppliedFilters = () => {
    setAppliedHostnameFilter('')
    setAppliedStatusFilter('')
    setDraftHostnameFilter('')
    setDraftStatusFilter('')
    setPage(0)
  }

  const removeAppliedFilter = (key: string) => {
    if (key === 'status') {
      setAppliedStatusFilter('')
      setDraftStatusFilter('')
    }
    if (key === 'hostname') {
      setAppliedHostnameFilter('')
      setDraftHostnameFilter('')
    }
    setPage(0)
  }

  const hasActiveFilters = Boolean(appliedStatusFilter || appliedHostnameFilter.trim())

  const appliedFilterTags = useMemo(() => {
    const tags: { key: string; label: string }[] = []
    if (appliedHostnameFilter.trim()) {
      tags.push({ key: 'hostname', label: `Hostname: ${appliedHostnameFilter.trim()}` })
    }
    if (appliedStatusFilter) {
      tags.push({ key: 'status', label: `Status: ${capitalizeStatusLabel(appliedStatusFilter)}` })
    }
    return tags
  }, [appliedHostnameFilter, appliedStatusFilter])

  const parsedMetrics = parseDriftLogMetrics(metricsData)
  const metricsLoadingState = metricsLoading || metricsFetching

  const formatMetricRate = (value: number) => `${Number(value).toFixed(2)}%`

  const totalExecutions = parsedMetrics?.totalExecutions ?? 0
  const successRate = parsedMetrics?.successRate ?? 0
  const failedRate = parsedMetrics?.failedRate ?? 0
  const realtimeRate = parsedMetrics?.realtimeRate ?? 0

  const logDialogDriftDetails = useMemo(
    () => (logDialogRow ? buildDriftDetailsFromRow(logDialogRow) : []),
    [logDialogRow],
  )

  const renderColumnCell = (key: string, row: DriftLogRow) => {
    const normalizedKey = key.toLowerCase()

    if (/execution.?id|^id$/i.test(normalizedKey)) {
      const value = pickValue(row, key, 'executionId', 'execution_id', 'id')
      const display = formatCell(value)
      return (
        <Tooltip title={display} arrow placement="top">
          <Typography variant="body2" fontWeight={600} color="#0f172a" noWrap sx={{ cursor: 'default' }}>
            {display}
          </Typography>
        </Tooltip>
      )
    }

    if (/assignment|policy/i.test(normalizedKey)) {
      const value = pickValue(row, key, 'assignment', 'assignmentName', 'assignment_name', 'policyName')
      return (
        <Typography variant="body2" color="#475569" noWrap title={formatCell(value)}>
          {formatCell(value)}
        </Typography>
      )
    }

    if (/^action$/i.test(normalizedKey)) {
      const value = formatCell(pickValue(row, key, 'action'))
      return <ActionBadge action={value} />
    }

    if (/target|hostname|host/i.test(normalizedKey)) {
      const value = pickValue(row, key, 'target', 'hostname', 'host', 'targetValue')
      return (
        <Typography variant="body2" color="#475569" noWrap title={formatCell(value)}>
          {formatCell(value)}
        </Typography>
      )
    }

    if (/status/i.test(normalizedKey)) {
      const value = formatCell(pickValue(row, key, 'status', 'executionStatus', 'execution_status'))
      return <StatusBadge status={value} />
    }

    if (/duration/i.test(normalizedKey)) {
      const value = pickValue(row, key, 'duration', 'durationMs', 'duration_ms')
      const display = typeof value === 'number' ? `${value}s` : formatCell(value)
      return <Typography variant="body2" color="#475569">{display}</Typography>
    }

    if (/^by$|user|executed.?by|triggered.?by/i.test(normalizedKey)) {
      const value = formatCell(pickValue(row, key, 'by', 'user', 'executedBy', 'triggeredBy'))
      return value === '-' ? value : <UserCell name={value} />
    }

    if (isTimestampKey(normalizedKey) || isTimestampKey(key)) {
      const value = pickValue(row, key, 'timestamp', 'time', 'createdAt', 'created_at', 'updatedAt', 'updated_at')
      const formatted = formatTimestamp(value) ?? formatCell(value)
      return (
        <Tooltip title={formatted} arrow placement="top">
          <Typography variant="body2" color="#475569" noWrap sx={{ cursor: 'default' }}>
            {formatted}
          </Typography>
        </Tooltip>
      )
    }

    return (
      <Typography variant="body2" color="#475569" noWrap title={formatCell(row[key])}>
        {formatCell(row[key])}
      </Typography>
    )
  }

  const columns: TableColumn[] = useMemo(() => {
    const dataColumns = visibleColumnKeys.map((key) => ({
      key,
      header: toTitle(key),
      minWidth: /message|assignment/i.test(key) ? 200 : 140,
      render: (row: DriftLogRow) => renderColumnCell(key, row),
    }))

    const logsActionColumn: TableColumn = {
      key: '_logs_action',
      header: 'Action',
      width: 72,
      minWidth: 72,
      align: 'center' as const,
      render: (row: DriftLogRow) => (
        <IconButton
          size="small"
          onClick={(e) => {
            e.stopPropagation()
            handleOpenLogDialog(row)
          }}
          sx={{ color: '#64748b', '&:hover': { color: '#2563eb', bgcolor: '#eff6ff' } }}
        >
          <List size={16} />
        </IconButton>
      ),
    }

    return logView === 'drift'
      ? [logsActionColumn, ...dataColumns]
      : dataColumns
  }, [visibleColumnKeys, handleOpenLogDialog, logView])

  // const handleExport = () => {
  //   if (!rows.length) return
  //
  //   const headers = visibleColumnKeys.map(toTitle)
  //   const csvRows = rows.map((row) => (
  //     visibleColumnKeys.map((key) => {
  //       const value = formatDriftCell(key, row[key])
  //       return `"${value.replace(/"/g, '""')}"`
  //     }).join(',')
  //   ))
  //
  //   const blob = new Blob([[headers.join(','), ...csvRows].join('\n')], { type: 'text/csv;charset=utf-8;' })
  //   const url = URL.createObjectURL(blob)
  //   const link = document.createElement('a')
  //   link.href = url
  //   link.download = logView === 'drift' ? 'drift-logs.csv' : 'execution-logs.csv'
  //   link.click()
  //   URL.revokeObjectURL(url)
  // }

  return (
    <Box sx={{ p: 3, bgcolor: '#f1f5f9', minHeight: '100%' }}>
      <Paper
        elevation={0}
        sx={{
          borderRadius: '12px',
          border: '1px solid #e2e8f0',
          bgcolor: 'white',
          boxShadow: '0 2px 12px rgba(15,23,42,0.04)',
          overflow: 'hidden',
        }}
      >
        <Box sx={{ px: 3, pt: 3, pb: 2.5 }}>
          <Box display="flex" justifyContent="space-between" alignItems="flex-start" flexWrap="wrap" gap={2} mb={1}>
            <Box>
              <Typography variant="h5" fontWeight={700} color="#0f172a" mb={0.5}>
                Logs & Activity
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ maxWidth: 720 }}>
                Unified observability for executions, drift, compliance evaluations, governance actions, and platform events.
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" gap={1.5} flexWrap="wrap">
              <TextField
                size="small"
                placeholder="Search logs"
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(0) }}
                InputProps={{ startAdornment: <InputAdornment position="start"><Search size={15} color="#94a3b8" /></InputAdornment> }}
                sx={{
                  width: 240,
                  '& .MuiOutlinedInput-root': { borderRadius: '999px', fontSize: '0.85rem', bgcolor: 'white' },
                }}
              />
              <Button
                variant="outlined"
                size="small"
                startIcon={<SlidersHorizontal size={14} />}
                onClick={(e) => openFilterPopover(e.currentTarget)}
                sx={{
                  borderRadius: '999px',
                  borderColor: hasActiveFilters ? '#93c5fd' : '#e2e8f0',
                  color: hasActiveFilters ? '#2563eb' : '#64748b',
                  bgcolor: hasActiveFilters ? '#eff6ff' : 'white',
                  fontSize: '0.85rem',
                  textTransform: 'none',
                }}
              >
                Filter
              </Button>
              {/* <Button
                variant="outlined"
                size="small"
                startIcon={<Download size={14} />}
                onClick={handleExport}
                sx={{ borderRadius: '999px', borderColor: '#e2e8f0', color: '#64748b', fontSize: '0.85rem', textTransform: 'none' }}
              >
                Export
              </Button> */}
              <Button
                variant="outlined"
                size="small"
                startIcon={<Columns3 size={14} />}
                onClick={(e) => setColumnsAnchor(e.currentTarget)}
                sx={{ borderRadius: '999px', borderColor: '#e2e8f0', color: '#64748b', fontSize: '0.85rem', textTransform: 'none' }}
              >
                Columns
              </Button>
            </Box>
          </Box>

          <Box sx={{ ...LOG_TOGGLE_SX, mb: appliedFilterTags.length ? 1.5 : 3 }}>
            <Button
              disableElevation
              onClick={() => { setLogView('execution'); setPage(0) }}
              sx={logToggleBtnSx(logView === 'execution')}
            >
              Execution logs
            </Button>
            <Button
              disableElevation
              onClick={() => { setLogView('drift'); setPage(0) }}
              sx={logToggleBtnSx(logView === 'drift')}
            >
              Drift Logs
            </Button>
          </Box>

          {appliedFilterTags.length > 0 && (
            <Box display="flex" alignItems="center" gap={1} flexWrap="wrap" mb={3}>
              {appliedFilterTags.map((tag) => (
                <Chip
                  key={tag.key}
                  label={tag.label}
                  size="small"
                  onDelete={() => removeAppliedFilter(tag.key)}
                  sx={{
                    height: 28,
                    fontSize: '0.75rem',
                    fontWeight: 500,
                    bgcolor: '#eff6ff',
                    color: '#1d4ed8',
                    border: '1px solid #bfdbfe',
                    '& .MuiChip-deleteIcon': {
                      color: '#64748b',
                      fontSize: 16,
                      '&:hover': { color: '#1d4ed8' },
                    },
                  }}
                />
              ))}
              <Button
                size="small"
                onClick={clearAllAppliedFilters}
                sx={{
                  textTransform: 'none',
                  fontWeight: 600,
                  fontSize: '0.75rem',
                  color: '#2563eb',
                  minWidth: 'auto',
                  px: 1,
                }}
              >
                Clear all
              </Button>
            </Box>
          )}

          <Grid container spacing={2} mb={1}>
            <Grid item xs={12} sm={6} md={3}>
              <DriftStatCard
                label="Total Execution"
                value={metricsLoadingState ? '—' : totalExecutions}
                icon={<Activity size={18} />}
                iconColor="#0891b2"
                iconBg="#cffafe"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DriftStatCard
                label="Success Rate"
                value={metricsLoadingState ? '—' : formatMetricRate(successRate)}
                valueColor="#15803d"
                icon={<ShieldCheck size={18} />}
                iconColor="#059669"
                iconBg="#d1fae5"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DriftStatCard
                label="Failed Rate"
                value={metricsLoadingState ? '—' : formatMetricRate(failedRate)}
                valueColor="#dc2626"
                icon={<AlertTriangle size={18} />}
                iconColor="#dc2626"
                iconBg="#fee2e2"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DriftStatCard
                label="Realtime Rate"
                value={metricsLoadingState ? '—' : formatMetricRate(realtimeRate)}
                valueColor="#2563eb"
                icon={<Timer size={18} />}
                iconColor="#2563eb"
                iconBg="#dbeafe"
              />
            </Grid>
          </Grid>
        </Box>

        <Box sx={{ px: 3, pb: 3 }}>
          <PolicyTable
            columns={columns}
            rows={rows}
            total={total}
            page={page}
            pageSize={pageSize}
            onPageChange={setPage}
            onPageSizeChange={(size) => { setPageSize(size); setPage(0) }}
            rowsPerPageOptions={[25, 50, 100, 200]}
            loading={tableLoading}
            error={isError}
            errorMessage="Failed to load logs"
            emptyMessage="No results"
            getRowId={getDriftRowId}
            sx={{ borderRadius: '10px' }}
          />
        </Box>
      </Paper>

      <Popover
        open={Boolean(filterAnchor)}
        anchorEl={filterAnchor}
        onClose={() => setFilterAnchor(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        PaperProps={{
          sx: {
            mt: 1,
            borderRadius: '12px',
            border: '1px solid #e2e8f0',
            boxShadow: '0 8px 24px rgba(15,23,42,0.08)',
            width: 320,
            maxWidth: '90vw',
          },
        }}
      >
        <Box sx={{ p: 2 }}>
          <Typography variant="subtitle2" fontWeight={700} color="#0f172a" mb={2}>
            Filters
          </Typography>

          <FormControl fullWidth size="small" sx={{ ...FORM_FIELD_SX, mb: 2 }}>
            <InputLabel>Hostname</InputLabel>
            <Select
              value={draftHostnameFilter}
              label="Hostname"
              onChange={(e) => setDraftHostnameFilter(e.target.value)}
            >
              <MenuItem value=""><em>All</em></MenuItem>
              {hostnameOptions.map((hostname) => (
                <MenuItem key={hostname} value={hostname}>{hostname}</MenuItem>
              ))}
            </Select>
          </FormControl>

          <Typography variant="subtitle2" fontWeight={700} color="#0f172a" mb={1}>
            Status
          </Typography>
          <Box display="flex" flexDirection="column" gap={0.5}>
            <MenuItem
              onClick={() => setDraftStatusFilter('')}
              sx={{ borderRadius: '8px', py: 0.75 }}
            >
              <Checkbox size="small" checked={draftStatusFilter === ''} />
              <Typography variant="body2">All Statuses</Typography>
            </MenuItem>
            {STATUS_FILTER_OPTIONS.map((status) => (
              <MenuItem
                key={status}
                onClick={() => setDraftStatusFilter(status)}
                sx={{ borderRadius: '8px', py: 0.75 }}
              >
                <Checkbox size="small" checked={draftStatusFilter === status} />
                <Typography variant="body2">{capitalizeStatusLabel(status)}</Typography>
              </MenuItem>
            ))}
          </Box>

          <Box display="flex" justifyContent="flex-end" gap={1} mt={2}>
            <Button
              size="small"
              onClick={clearDraftFilters}
              sx={{ textTransform: 'none', color: '#64748b' }}
            >
              Clear
            </Button>
            <Button
              size="small"
              variant="contained"
              onClick={applyFilters}
              sx={{ textTransform: 'none', bgcolor: '#2563eb', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}
            >
              Apply
            </Button>
          </Box>
        </Box>
      </Popover>

      <Menu anchorEl={columnsAnchor} open={!!columnsAnchor} onClose={() => setColumnsAnchor(null)}>
        {allColumnKeys
          .filter((key) => logView === 'drift' || !isDriftActionColumn(key))
          .map((key) => (
          <MenuItem key={key} onClick={() => toggleColumn(key)}>
            <Checkbox size="small" checked={!hiddenColumns.includes(key)} />
            <Typography variant="body2">{toTitle(key)}</Typography>
          </MenuItem>
        ))}
      </Menu>

      <DriftLogDialog
        open={Boolean(logDialogRow)}
        onClose={handleCloseLogDialog}
        driftDetails={logDialogDriftDetails}
        timelineEntries={commandTimelineEntries}
        timelineLoading={commandLogsLoadingState}
        timelineError={commandTimelineError}
      />
    </Box>
  )
}

export default DriftPage
