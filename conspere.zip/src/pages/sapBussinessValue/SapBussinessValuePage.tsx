import React, { useState, useCallback } from 'react'
import Cookies from 'universal-cookie'
import { formatDisplayName } from '../../utils/uiConstants'
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  ResponsiveContainer, Tooltip,
} from 'recharts'
import {
  Clock, ShieldAlert, TrendingUp, FileText, Bot,
  TrendingDown, Check, Shield, Calculator, Server,
  Info, X, Star, Search,
} from 'lucide-react'

// ─── Types ────────────────────────────────────────────────────────────────────
type DrilldownKey = 'time' | 'downtime' | 'dollars' | 'audit' | 'efficiency'

interface AssetItem {
  color: string
  icon: 'check' | 'shield' | 'trend-down' | 'file' | 'bot'
  text: string
}

interface DrilldownData {
  title: string
  desc: string
  assets: AssetItem[]
  policy: string
  formula: string
  outcome: string
}

// ─── Static Data ──────────────────────────────────────────────────────────────
const timeData = [
  { m: 'Jan', v: 400 }, { m: 'Feb', v: 900 }, { m: 'Mar', v: 1600 },
  { m: 'Apr', v: 2400 }, { m: 'May', v: 3200 }, { m: 'Jun', v: 4120 },
]
const riskData = [
  { m: 'Jan', v: 0.2 }, { m: 'Feb', v: 0.5 }, { m: 'Mar', v: 0.8 },
  { m: 'Apr', v: 1.4 }, { m: 'May', v: 1.9 }, { m: 'Jun', v: 2.4 },
]
const autoData = [
  { w: 'W1', a: 120, manual: 80 }, { w: 'W2', a: 150, manual: 60 },
  { w: 'W3', a: 180, manual: 45 }, { w: 'W4', a: 220, manual: 30 },
  { w: 'W5', a: 250, manual: 20 }, { w: 'W6', a: 280, manual: 12 },
]

const drilldownData: Record<DrilldownKey, DrilldownData> = {
  time: {
    title: '4,120 Platform Effort Saved',
    desc: 'Manual operational effort eliminated',
    assets: [
      { color: '#10b981', icon: 'check', text: 'Auto-restarting failed SAP services (1,200 events)' },
      { color: '#10b981', icon: 'check', text: 'Auto-syncing OS user permissions (850 events)' },
      { color: '#10b981', icon: 'check', text: 'Pre-flight checks for system copies (400 events)' },
    ],
    policy: 'policy-operational-efficiency-v3',
    formula: '(Total Automated Remediations × 1.5 hrs Avg Manual Fix Time)\n+ (Automated Audit Reports × 40 hrs)',
    outcome: 'Equivalent to 2.5 FTEs',
  },
  downtime: {
    title: '6 P1 Outages Prevented',
    desc: 'Critical configuration deviations (drift) that historically cause immediate, severe SAP Production crashes were intercepted and reverted autonomously.',
    assets: [
      { color: '#6366f1', icon: 'shield', text: 'PRD-HANA-01: Reverted rogue memory limit change' },
      { color: '#6366f1', icon: 'shield', text: 'PRD-ECC-02: Prevented deletion of /usr/sap mount' },
      { color: '#6366f1', icon: 'shield', text: 'SCM-DB-01: Blocked unauthorized port closure' },
    ],
    policy: 'rule-tier1-business-continuity',
    formula: "Count(Severity 'Critical' Drift Events on Systems\nTagged 'Production' resolved within < 1 min)",
    outcome: 'Zero Unplanned Downtime',
  },
  dollars: {
    title: '$2.4M Financial Risk Mitigated',
    desc: 'The estimated dollar value saved by preventing system outages, avoiding SLA breach penalties, and redirecting engineer time to strategic projects.',
    assets: [
      { color: '#10b981', icon: 'trend-down', text: 'Downtime Cost Avoidance ($1.8M)' },
      { color: '#10b981', icon: 'trend-down', text: 'Labor Redirection Value ($400k)' },
      { color: '#10b981', icon: 'trend-down', text: 'Compliance Risk Reduction ($200k)' },
    ],
    policy: 'financial-roi-aggregator-model',
    formula: '(6 Prevented Outages × 2 hrs Avg Downtime × $150,000/hr)\n+ (4,120 Hrs Saved × $100/hr Blended Eng Rate)',
    outcome: '$2,412,000 Value YTD',
  },
  audit: {
    title: '85% Audit Prep Time Cut',
    desc: 'Reduction in time spent gathering screenshots, logs, and evidence for internal risk teams and external auditors (e.g., SOX, GDPR, SAP baseline audits).',
    assets: [
      { color: '#3b82f6', icon: 'file', text: 'Automated SOX 404 Control Evidence' },
      { color: '#3b82f6', icon: 'file', text: 'Continuous CIS Benchmark reporting' },
      { color: '#3b82f6', icon: 'file', text: 'Real-time SAP Security Baseline (SG22) mapping' },
    ],
    policy: 'policy-continuous-compliance-export',
    formula: 'Historical Manual Audit Prep Time (Weeks)\nvs.\nTime to Generate ConfigSphere Automated Ledger (Minutes)',
    outcome: '3 Weeks Saved per Quarter',
  },
  efficiency: {
    title: '1,842 Zero-Touch Fixes',
    desc: 'The raw volume of issues that were detected and corrected by the system without a human engineer ever having to log in or create a Jira ticket.',
    assets: [
      { color: '#f59e0b', icon: 'bot', text: 'RPM Package versions enforced' },
      { color: '#f59e0b', icon: 'bot', text: 'File ownership / permissions corrected' },
      { color: '#f59e0b', icon: 'bot', text: 'Systemctl daemon states maintained' },
    ],
    policy: 'global-auto-remediation-enabled',
    formula: 'Total Actions Taken via Automated Playbooks\n─────────────────────────────────────────\nTotal Configuration Drifts Detected',
    outcome: '98.9% Automation Rate',
  },
}

// ─── Sub-components ───────────────────────────────────────────────────────────
const AssetIcon: React.FC<{ type: AssetItem['icon']; color: string }> = ({ type, color }) => {
  const props = { size: 14, color, style: { flexShrink: 0 } }
  if (type === 'check') return <Check {...props} />
  if (type === 'shield') return <Shield {...props} />
  if (type === 'trend-down') return <TrendingDown {...props} />
  if (type === 'file') return <FileText {...props} />
  return <Bot {...props} />
}

const DrilldownModal: React.FC<{ dataKey: DrilldownKey; onClose: () => void }> = ({ dataKey, onClose }) => {
  const data = drilldownData[dataKey]

  const handleBackdrop = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) onClose()
  }, [onClose])

  return (
    <div
      onClick={handleBackdrop}
      style={{
        position: 'fixed', inset: 0, zIndex: 1300,
        background: 'rgba(15,23,42,0.4)', backdropFilter: 'blur(4px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16,
      }}
    >
      <div style={{
        background: 'white', borderRadius: 16,
        boxShadow: '0 25px 50px -12px rgba(0,0,0,0.25)',
        width: '100%', maxWidth: 840, maxHeight: '90vh',
        display: 'flex', flexDirection: 'column',
        border: '1px solid #e2e8f0', overflow: 'hidden',
      }}>
        {/* Header */}
        <div style={{
          padding: '20px 24px', borderBottom: '1px solid #f1f5f9',
          background: '#f8fafc', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
        }}>
          <div>
            <span style={{
              display: 'inline-block', padding: '3px 8px',
              background: '#e0e7ff', color: '#3730a3',
              fontSize: 10, fontWeight: 700, letterSpacing: '0.08em',
              textTransform: 'uppercase', borderRadius: 4, border: '1px solid #c7d2fe',
            }}>
              Business Value Calculation
            </span>
            <h2 style={{ fontSize: 22, fontWeight: 700, color: '#1e293b', margin: '8px 0 0' }}>{data.title}</h2>
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: '#94a3b8', padding: 4, borderRadius: '50%',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <X size={20} />
          </button>
        </div>

        {/* Body */}
        <div style={{ padding: 24, overflowY: 'auto', flex: 1, background: 'white' }}>
          <p style={{
            fontSize: 14, color: '#475569', marginBottom: 32,
            borderLeft: '4px solid #e2e8f0', paddingLeft: 16, lineHeight: 1.6,
          }}>
            {data.desc}
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32 }}>
            {/* Business Math */}
            <div>
              <h3 style={{
                fontSize: 11, fontWeight: 700, color: '#94a3b8',
                textTransform: 'uppercase', letterSpacing: '0.08em',
                display: 'flex', alignItems: 'center', gap: 6, marginBottom: 16,
              }}>
                <Calculator size={13} /> The Business Math
              </h3>
              <div style={{
                background: '#f8fafc', padding: 20, borderRadius: 12,
                border: '1px solid #e2e8f0', display: 'flex', flexDirection: 'column', height: 'calc(100% - 36px)',
              }}>
                <p style={{ fontSize: 12, color: '#64748b', marginBottom: 10 }}>Applied Formula:</p>
                <pre style={{
                  background: 'white', padding: 16, borderRadius: 8,
                  border: '1px solid #e2e8f0', fontFamily: 'monospace',
                  fontSize: 13, color: '#334155', whiteSpace: 'pre-wrap',
                  wordBreak: 'break-word', margin: 0,
                  boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
                }}>
                  {data.formula}
                </pre>
                <div style={{
                  marginTop: 'auto', paddingTop: 16,
                  background: '#eef2ff', border: '1px solid #e0e7ff',
                  borderRadius: 8, padding: 16,
                }}>
                  <p style={{ fontSize: 10, color: '#6366f1', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', margin: 0 }}>
                    Bottom Line Impact
                  </p>
                  <p style={{ fontSize: 22, fontWeight: 700, color: '#4338ca', margin: '4px 0 0' }}>{data.outcome}</p>
                </div>
              </div>
            </div>

            {/* Technical Evidence */}
            <div>
              <h3 style={{
                fontSize: 11, fontWeight: 700, color: '#94a3b8',
                textTransform: 'uppercase', letterSpacing: '0.08em',
                display: 'flex', alignItems: 'center', gap: 6, marginBottom: 16,
              }}>
                <Server size={13} /> Technical Evidence
              </h3>
              <div style={{
                background: 'white', padding: 20, borderRadius: 12,
                border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
                height: 'calc(100% - 36px)',
              }}>
                <p style={{ fontSize: 12, color: '#64748b', marginBottom: 4 }}>Active Policy Enforcing This:</p>
                <code style={{
                  fontSize: 12, color: '#334155', background: '#f1f5f9',
                  padding: '4px 8px', borderRadius: 4, border: '1px solid #e2e8f0',
                  display: 'inline-block', marginBottom: 20,
                }}>
                  {data.policy}
                </code>

                <p style={{ fontSize: 12, color: '#64748b', marginBottom: 10 }}>Systems Protected / Actions Taken:</p>
                <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {data.assets.map((asset, i) => (
                    <li key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 14, color: '#334155' }}>
                      <AssetIcon type={asset.icon} color={asset.color} />
                      {asset.text}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{
          padding: '16px 24px', borderTop: '1px solid #f1f5f9',
          background: '#f8fafc', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <span style={{ fontSize: 12, color: '#94a3b8', fontStyle: 'italic' }}>
            Data is real-time from the ConfigSphere policy engine.
          </span>
          <button
            onClick={onClose}
            style={{
              padding: '8px 20px', background: '#1e293b', color: 'white',
              border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 500,
              cursor: 'pointer',
            }}
          >
            Close Breakdown
          </button>
        </div>
      </div>
    </div>
  )
}

const VALUE_CONTRIBUTORS = [
  'Downtime Cost Avoidance ($1.8M)',
  'Engineering Productivity Gain ($412K)',
  'Compliance Risk Reduction ($588K)',
  'Operational Automation Value ($1.0M)',
]

const ValueDeliveredModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const handleBackdrop = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) onClose()
  }, [onClose])

  return (
    <div
      onClick={handleBackdrop}
      style={{
        position: 'fixed', inset: 0, zIndex: 1300,
        background: 'rgba(15,23,42,0.4)', backdropFilter: 'blur(4px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16,
      }}
    >
      <div style={{
        background: 'white', borderRadius: 16,
        boxShadow: '0 25px 50px -12px rgba(0,0,0,0.25)',
        width: '100%', maxWidth: 840, maxHeight: '90vh',
        display: 'flex', flexDirection: 'column',
        border: '1px solid #e2e8f0', overflow: 'hidden',
      }}>
        <div style={{
          padding: '20px 24px', borderBottom: '1px solid #f1f5f9',
          background: '#f8fafc', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
        }}>
          <div>
            <span style={{
              display: 'inline-block', padding: '3px 8px',
              background: '#e0e7ff', color: '#3730a3',
              fontSize: 10, fontWeight: 700, letterSpacing: '0.08em',
              textTransform: 'uppercase', borderRadius: 4, border: '1px solid #c7d2fe',
            }}>
              Executive Value Breakdown
            </span>
            <h2 style={{ fontSize: 22, fontWeight: 700, color: '#1e293b', margin: '8px 0 0' }}>
              Total Value Delivered (YTD)
            </h2>
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: '#94a3b8', padding: 4, borderRadius: '50%',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <X size={20} />
          </button>
        </div>

        <div style={{ padding: 24, overflowY: 'auto', flex: 1, background: 'white' }}>
          <p style={{
            fontSize: 14, color: '#475569', marginBottom: 32,
            borderLeft: '4px solid #e2e8f0', paddingLeft: 16, lineHeight: 1.6,
          }}>
            The estimated business value generated through automated remediation,
            downtime prevention, compliance improvements, and engineering effort reduction.
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 32 }}>
            <div>
              <h3 style={{
                fontSize: 11, fontWeight: 700, color: '#94a3b8',
                textTransform: 'uppercase', letterSpacing: '0.08em',
                display: 'flex', alignItems: 'center', gap: 6, marginBottom: 16,
              }}>
                <Calculator size={13} /> The Business Math
              </h3>
              <div style={{
                background: '#f8fafc', padding: 20, borderRadius: 12,
                border: '1px solid #e2e8f0', display: 'flex', flexDirection: 'column', minHeight: '100%',
              }}>
                <p style={{ fontSize: 12, color: '#64748b', marginBottom: 12 }}>Applied Formula:</p>
                <div style={{
                  background: 'white', padding: 16, borderRadius: 8,
                  border: '1px solid #e2e8f0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
                  fontFamily: 'monospace', fontSize: 14, color: '#334155',
                  lineHeight: 1.7, marginBottom: 16,
                }}>
                  ($1.8M Downtime Cost Avoidance)<br />
                  + ($412K Engineering Productivity Gain)<br />
                  + ($588K Compliance Risk Reduction)<br />
                  + ($1.0M Operational Automation Value)
                </div>
                <div style={{
                  marginTop: 'auto',
                  background: '#eef2ff', border: '1px solid #e0e7ff',
                  borderRadius: 8, padding: 16,
                }}>
                  <p style={{ fontSize: 10, color: '#6366f1', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', margin: 0 }}>
                    Bottom Line Impact
                  </p>
                  <p style={{ fontSize: 30, fontWeight: 700, color: '#4338ca', margin: '4px 0 0' }}>
                    $3,800,000 Value YTD
                  </p>
                  <p style={{ fontSize: 14, color: '#475569', margin: '8px 0 0', lineHeight: 1.5 }}>
                    Combined value delivered through automation,
                    operational efficiency, compliance improvements,
                    and business continuity protection.
                  </p>
                </div>
              </div>
            </div>

            <div>
              <h3 style={{
                fontSize: 11, fontWeight: 700, color: '#94a3b8',
                textTransform: 'uppercase', letterSpacing: '0.08em',
                display: 'flex', alignItems: 'center', gap: 6, marginBottom: 16,
              }}>
                <TrendingUp size={13} /> Value Contributors
              </h3>
              <div style={{
                background: 'white', padding: 20, borderRadius: 12,
                border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
                minHeight: '100%', display: 'flex', flexDirection: 'column',
              }}>
                <div style={{ marginBottom: 16 }}>
                  <p style={{ fontSize: 12, color: '#64748b', marginBottom: 4 }}>Primary Sources of Value:</p>
                  <code style={{
                    fontSize: 12, color: '#334155', background: '#f1f5f9',
                    padding: '4px 8px', borderRadius: 4, border: '1px solid #e2e8f0',
                    display: 'inline-block',
                  }}>
                    ConfigSphere Business Value Model
                  </code>
                </div>

                <div>
                  <p style={{ fontSize: 12, color: '#64748b', marginBottom: 12 }}>Measured Contributions:</p>
                  <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: 12 }}>
                    {VALUE_CONTRIBUTORS.map((item) => (
                      <li key={item} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14, color: '#334155' }}>
                        <TrendingUp size={14} color="#10b981" style={{ flexShrink: 0 }} />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div style={{
                  marginTop: 24,
                  background: '#ecfdf5', border: '1px solid #d1fae5',
                  borderRadius: 8, padding: 16,
                }}>
                  <p style={{ fontSize: 10, color: '#059669', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', margin: 0 }}>
                    Industry Comparison
                  </p>
                  <p style={{ fontSize: 24, fontWeight: 700, color: '#047857', margin: '4px 0 0' }}>
                    24% Above Industry Benchmark
                  </p>
                  <p style={{ fontSize: 14, color: '#475569', margin: '8px 0 0', lineHeight: 1.5 }}>
                    Based on automation adoption, remediation efficiency,
                    governance coverage, and operational risk reduction.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div style={{
          padding: '16px 24px', borderTop: '1px solid #f1f5f9',
          background: '#f8fafc', display: 'flex', justifyContent: 'flex-end',
        }}>
          <button
            onClick={onClose}
            style={{
              padding: '8px 20px', background: '#1e293b', color: 'white',
              border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 500,
              cursor: 'pointer',
            }}
          >
            Close Breakdown
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Main Page ────────────────────────────────────────────────────────────────
const SapBusinessValuePage: React.FC = () => {
  const [activeModal, setActiveModal] = useState<DrilldownKey | null>(null)
  const [showValueDeliveredModal, setShowValueDeliveredModal] = useState(false)

  const kpiCards = [
    {
      key: 'time' as DrilldownKey,
      icon: <Clock size={16} color="#6366f1" />,
      accentColor: '#6366f1',
      hoverBorder: '#a5b4fc',
      bgHover: '#eef2ff',
      label: 'Platform Effort Saved',
      value: '4,120',
      valueColor: '#1e293b',
      sub: 'Manual labor eliminated',
    },
    {
      key: 'downtime' as DrilldownKey,
      icon: <ShieldAlert size={16} color="#f43f5e" />,
      accentColor: '#f43f5e',
      hoverBorder: '#fda4af',
      bgHover: '#fff1f2',
      label: 'P1 Outages Prevented',
      value: '6',
      valueColor: '#e11d48',
      sub: 'Critical SAP crashes averted',
    },
    {
      key: 'dollars' as DrilldownKey,
      icon: <TrendingUp size={16} color="#10b981" />,
      accentColor: '#10b981',
      hoverBorder: '#6ee7b7',
      bgHover: '#ecfdf5',
      label: 'Financial Risk Mitigated',
      value: '$2.4M',
      valueColor: '#059669',
      sub: 'In projected downtime costs',
    },
    {
      key: 'audit' as DrilldownKey,
      icon: <FileText size={16} color="#3b82f6" />,
      accentColor: '#3b82f6',
      hoverBorder: '#93c5fd',
      bgHover: '#eff6ff',
      label: 'Audit Prep Time Cut',
      value: '85%',
      valueColor: '#1e293b',
      sub: 'Automated evidence gathering',
    },
    {
      key: 'efficiency' as DrilldownKey,
      icon: <Bot size={16} color="#f59e0b" />,
      accentColor: '#f59e0b',
      hoverBorder: '#fcd34d',
      bgHover: '#fffbeb',
      label: 'Zero-Touch Fixes',
      value: '1,842',
      valueColor: '#1e293b',
      sub: 'Issues resolved without humans',
    },
  ]

  const [search, setSearch] = useState('')
  const fullName = formatDisplayName(new Cookies().get('user_fullname') || '')

  return (
    <div style={{
      height: '100%', overflowY: 'auto', backgroundColor: '#f8fafc',
      fontFamily: '"JohnsonText", Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      color: '#334155',
    }}>
      <div style={{ maxWidth: 1600, margin: '0 auto', padding: 24, display: 'flex', flexDirection: 'column', gap: 24 }}>

        {/* ── Page Header ── */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          flexWrap: 'wrap', gap: 16,
          background: 'white', borderRadius: 12, padding: '16px 24px',
          border: '1px solid #e2e8f0', boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
        }}>
          <div>
            <h1 style={{ margin: 0, fontSize: 20, fontWeight: 700, color: '#0f172a' }}>
              Welcome {fullName}
            </h1>
            <p style={{ margin: '2px 0 0', fontSize: 13, color: '#64748b' }}>
              Real-time visibility into financial savings, effort reduction, and SAP risk mitigation.
            </p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {/* Search */}
            <div style={{ position: 'relative' }}>
              <Search
                size={14}
                style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }}
              />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search SAP SIDs or Business Units"
                style={{
                  paddingLeft: 30, paddingRight: 12, paddingTop: 8, paddingBottom: 8,
                  fontSize: 13, border: '1px solid #e2e8f0', borderRadius: 8,
                  outline: 'none', color: '#334155', background: '#f8fafc', width: 240,
                }}
              />
            </div>
            {/* Period */}
            <button style={{
              padding: '8px 14px', fontSize: 13, fontWeight: 500,
              border: '1px solid #e2e8f0', borderRadius: 8, background: 'white',
              color: '#334155', cursor: 'pointer',
            }}>
              Year-to-Date (YTD)
            </button>
            {/* Export */}
            <button style={{
              padding: '8px 16px', fontSize: 13, fontWeight: 600,
              border: 'none', borderRadius: 8,
              background: 'linear-gradient(135deg, #6366f1, #4f46e5)',
              color: 'white', cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <Star size={13} /> Export ROI Report
            </button>
          </div>
        </div>

        {/* ── Summary Row ── */}
        <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap' }}>
          <div style={{
            flex: 1, minWidth: 280, background: '#f4f7fb',
            border: '1px solid #dbeafe', borderRadius: 12, padding: 24,
            position: 'relative', overflow: 'hidden',
          }}>
            <div style={{
              position: 'absolute', inset: 0,
              background: 'linear-gradient(to right, transparent, rgba(255,255,255,0.5))',
              pointerEvents: 'none',
            }} />
            <span style={{
              display: 'inline-block', padding: '4px 12px',
              background: 'white', color: '#2563eb',
              fontSize: 10, fontWeight: 700, letterSpacing: '0.1em',
              textTransform: 'uppercase' as const, borderRadius: 999,
              border: '1px solid #dbeafe', marginBottom: 16,
              boxShadow: '0 1px 2px rgba(0,0,0,0.05)',
            }}>
              SAP Executive Value Summary
            </span>
            <h2 style={{ fontSize: 20, fontWeight: 700, color: '#1e293b', margin: '0 0 8px' }}>
              Automated Governance &amp; Financial Impact
            </h2>
            <p style={{ fontSize: 14, color: '#475569', maxWidth: 600, margin: 0, lineHeight: 1.6 }}>
              ConfigSphere translates technical configuration management directly into business value. By enforcing SAP best practices autonomously, we eliminate manual engineering toil, prevent costly production downtime, and ensure audit readiness with zero human effort.
            </p>
          </div>

          <div style={{
            width: '100%',
            maxWidth: 384,
            flexShrink: 0,
            background: 'linear-gradient(135deg, #4f46e5 0%, #2563eb 50%, #1d4ed8 100%)',
            borderRadius: 12,
            padding: 24,
            boxShadow: '0 20px 25px -5px rgba(79,70,229,0.35), 0 8px 10px -6px rgba(79,70,229,0.2)',
            position: 'relative',
            overflow: 'hidden',
          }}>
            <div style={{
              position: 'absolute',
              top: 16,
              right: 16,
              width: 48,
              height: 48,
              borderRadius: '50%',
              background: 'rgba(255,255,255,0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <TrendingUp size={20} color="#6ee7b7" />
            </div>

            <div style={{ position: 'relative', zIndex: 1 }}>
              <p style={{
                fontSize: 10,
                textTransform: 'uppercase' as const,
                letterSpacing: '0.2em',
                color: '#c7d2fe',
                fontWeight: 600,
                margin: 0,
              }}>
                Total Value Delivered (YTD)
              </p>

              <h2 style={{
                fontSize: 48,
                fontWeight: 700,
                color: 'white',
                margin: '8px 0 0',
                lineHeight: 1,
              }}>
                $3.8M
              </h2>

              <p style={{ fontSize: 14, color: '#e0e7ff', margin: '8px 0 0' }}>
                Combined Downtime Avoidance + Effort Saved
              </p>

              <button
                type="button"
                onClick={() => setShowValueDeliveredModal(true)}
                style={{
                  marginTop: 16,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  background: 'none',
                  border: 'none',
                  padding: 0,
                  cursor: 'pointer',
                  textAlign: 'left',
                }}
              >
                <span style={{
                  background: 'rgba(16,185,129,0.2)',
                  color: '#6ee7b7',
                  fontSize: 12,
                  fontWeight: 700,
                  padding: '4px 8px',
                  borderRadius: 999,
                }}>
                  ↑ 24%
                </span>
                <span style={{ fontSize: 12, color: '#e0e7ff' }}>
                  Above Industry Benchmark
                </span>
              </button>


            </div>
          </div>
        </div>

        {/* ── 5 KPI Cards ── */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 16 }}>
          {kpiCards.map(card => (
            <KpiCard key={card.key} card={card} onClick={() => setActiveModal(card.key)} />
          ))}
        </div>

        {/* ── 3 Charts ── */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }}>
          <ChartCard title="Cumulative Time Saved (Hrs)" tag="Effort">
            <ResponsiveContainer width="100%" height={128}>
              <AreaChart data={timeData} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="gradTime" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <Tooltip
                  contentStyle={{ background: '#1e293b', border: 'none', borderRadius: 4, color: 'white', fontSize: 12 }}
                  cursor={{ stroke: '#6366f1', strokeWidth: 1 }}
                />
                <Area type="monotone" dataKey="v" stroke="#6366f1" strokeWidth={2} fill="url(#gradTime)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Financial Risk Reduced ($M)" tag="Value">
            <ResponsiveContainer width="100%" height={128}>
              <BarChart data={riskData} margin={{ top: 4, right: 0, left: 0, bottom: 0 }} barCategoryGap="30%">
                <Tooltip
                  contentStyle={{ background: '#1e293b', border: 'none', borderRadius: 4, color: 'white', fontSize: 12 }}
                  formatter={(v: number) => [`$${v}M`, 'Risk Reduced']}
                  cursor={{ fill: 'rgba(16,185,129,0.08)' }}
                />
                <Bar dataKey="v" fill="#10b981" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Manual vs Auto Resolutions" tag="Efficiency">
            <ResponsiveContainer width="100%" height={128}>
              <LineChart data={autoData} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
                <Tooltip
                  contentStyle={{ background: '#1e293b', border: 'none', borderRadius: 4, color: 'white', fontSize: 12 }}
                  cursor={{ stroke: '#cbd5e1', strokeWidth: 1 }}
                />
                <Line type="monotone" dataKey="a" name="Auto Resolved" stroke="#3b82f6" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="manual" name="Manual Tickets" stroke="#cbd5e1" strokeWidth={2} strokeDasharray="5 5" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* ── Table + AI Insights ── */}
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 24 }}>
          {/* Business Impact Table */}
          <div style={{
            background: 'white', border: '1px solid #e2e8f0',
            borderRadius: 12, overflow: 'hidden',
            boxShadow: '0 2px 10px -2px rgba(0,0,0,0.05)',
          }}>
            <div style={{
              borderBottom: '1px solid #f1f5f9', background: '#f8fafc',
              padding: '12px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, color: '#1e293b', margin: 0 }}>
                Recent Business Impact Events
              </h3>
              <button style={{ fontSize: 12, color: '#2563eb', background: 'none', border: 'none', cursor: 'pointer' }}>
                View Full Impact Ledger
              </button>
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14, color: '#475569' }}>
                <thead>
                  <tr style={{ background: 'rgba(248,250,252,0.5)', borderBottom: '1px solid #f1f5f9' }}>
                    {['Business Unit / System', 'Prevented Risk', 'Business Impact / Savings', 'Resolution'].map(h => (
                      <th key={h} style={{
                        padding: '10px 20px', textAlign: 'left',
                        fontSize: 11, fontWeight: 500, color: '#94a3b8',
                        textTransform: 'uppercase' as const, letterSpacing: '0.06em',
                      }}>
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {impactRows.map((row, i) => (
                    <tr key={i} style={{ borderBottom: '1px solid #f1f5f9' }}>
                      <td style={{ padding: '12px 20px' }}>
                        <span style={{ fontWeight: 600, color: '#1e293b', display: 'block' }}>{row.unit}</span>
                        <span style={{ fontSize: 12, color: '#94a3b8' }}>{row.sid}</span>
                      </td>
                      <td style={{ padding: '12px 20px', fontSize: 13 }}>{row.risk}</td>
                      <td style={{ padding: '12px 20px', fontSize: 13, fontWeight: 600, color: row.impactColor }}>{row.impact}</td>
                      <td style={{ padding: '12px 20px' }}>
                        <span style={{
                          padding: '3px 8px', background: '#eef2ff',
                          color: '#4338ca', border: '1px solid #e0e7ff',
                          borderRadius: 4, fontSize: 10, fontWeight: 700,
                        }}>
                          Zero-Touch Fix
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* AI Insights */}
          <div style={{
            background: 'linear-gradient(to bottom, #f8fafc, white)',
            border: '1px solid #e2e8f0', borderRadius: 12, padding: 20,
            boxShadow: '0 2px 10px -2px rgba(0,0,0,0.05)',
            display: 'flex', flexDirection: 'column',
          }}>
            <h3 style={{
              fontSize: 14, fontWeight: 700, color: '#1e293b',
              display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20, marginTop: 0,
            }}>
              <Star size={15} color="#6366f1" /> AI Financial Insights
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 16, flex: 1 }}>
              <div style={{ borderLeft: '2px solid #818cf8', paddingLeft: 12 }}>
                <p style={{ fontSize: 14, color: '#475569', margin: 0, lineHeight: 1.6 }}>
                  <strong style={{ color: '#1e293b' }}>Effort Reduction:</strong> The SAP BASIS team has reclaimed the equivalent of{' '}
                  <strong style={{ color: '#4338ca' }}>2 full-time engineers'</strong> worth of hours this quarter by eliminating manual configuration checks.
                </p>
              </div>
              <div style={{ borderLeft: '2px solid #34d399', paddingLeft: 12 }}>
                <p style={{ fontSize: 14, color: '#475569', margin: 0, lineHeight: 1.6 }}>
                  <strong style={{ color: '#1e293b' }}>Risk Mitigation:</strong> We intercepted a critical network route change on the main ERP DB yesterday. This action alone preserved an estimated{' '}
                  <strong style={{ color: '#059669' }}>$450,000</strong> in prevented supply chain downtime.
                </p>
              </div>
              <div style={{ borderLeft: '2px solid #60a5fa', paddingLeft: 12 }}>
                <p style={{ fontSize: 14, color: '#475569', margin: 0, lineHeight: 1.6 }}>
                  <strong style={{ color: '#1e293b' }}>Audit Velocity:</strong> Time spent gathering evidence for the upcoming SOX compliance audit has been reduced by 85% compared to last year.
                </p>
              </div>
            </div>

            <div style={{
              marginTop: 16, paddingTop: 12, borderTop: '1px solid #f1f5f9',
              display: 'flex', alignItems: 'flex-start', gap: 6,
            }}>
              <Info size={12} color="#cbd5e1" style={{ flexShrink: 0, marginTop: 2 }} />
              <p style={{ fontSize: 11, color: '#94a3b8', margin: 0, lineHeight: 1.5 }}>
                *Financial figures are estimated based on historical downtime costs ($112k/hr). Advanced GenAI predictive modeling arriving next quarter.
              </p>
            </div>
          </div>
        </div>

      </div>

      {/* Drilldown Modal */}
      {activeModal && (
        <DrilldownModal dataKey={activeModal} onClose={() => setActiveModal(null)} />
      )}
      {showValueDeliveredModal && (
        <ValueDeliveredModal onClose={() => setShowValueDeliveredModal(false)} />
      )}
    </div>
  )
}

// ─── Helper sub-components ────────────────────────────────────────────────────
interface KpiCardProps {
  card: {
    key: DrilldownKey
    icon: React.ReactNode
    accentColor: string
    hoverBorder: string
    bgHover: string
    label: string
    value: string
    valueColor: string
    sub: string
  }
  onClick: () => void
}

const KpiCard: React.FC<KpiCardProps> = ({ card, onClick }) => {
  const [hovered, setHovered] = useState(false)

  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered ? card.bgHover : 'white',
        border: `1px solid ${hovered ? card.hoverBorder : '#e2e8f0'}`,
        borderRadius: 12, padding: 20,
        textAlign: 'left', cursor: 'pointer',
        boxShadow: '0 2px 10px -2px rgba(0,0,0,0.05)',
        transition: 'all 0.15s ease',
        position: 'relative', overflow: 'hidden',
        width: '100%',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        {card.icon}
        <span style={{ fontSize: 11, fontWeight: 600, color: '#64748b', textTransform: 'uppercase' as const, letterSpacing: '0.06em' }}>
          {card.label}
        </span>
      </div>
      <p style={{ fontSize: 30, fontWeight: 700, color: card.valueColor, margin: 0, lineHeight: 1 }}>
        {card.value}
      </p>
      <p style={{ fontSize: 11, color: '#64748b', margin: '8px 0 0', fontWeight: 500 }}>
        {card.sub}
      </p>
      {hovered && (
        <div style={{
          position: 'absolute', top: 0, right: 0,
          width: 32, height: 32, background: `${card.accentColor}15`,
          borderBottomLeftRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Search size={12} color={card.accentColor} />
        </div>
      )}
    </button>
  )
}

const ChartCard: React.FC<{ title: string; tag: string; children: React.ReactNode }> = ({ title, tag, children }) => (
  <div style={{
    background: 'white', padding: 20, borderRadius: 12,
    border: '1px solid #e2e8f0', boxShadow: '0 2px 10px -2px rgba(0,0,0,0.05)',
  }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
      <h3 style={{ fontSize: 14, fontWeight: 700, color: '#1e293b', margin: 0 }}>{title}</h3>
      <span style={{ fontSize: 10, color: '#94a3b8', textTransform: 'uppercase' as const, letterSpacing: '0.08em' }}>{tag}</span>
    </div>
    {children}
  </div>
)

const impactRows = [
  {
    unit: 'Global Supply Chain', sid: 'PRD-HANA-01',
    risk: 'HANA Memory Limit Misconfiguration',
    impact: 'Avoided estimated 4hr outage', impactColor: '#059669',
  },
  {
    unit: 'Finance & Payroll', sid: 'PRD-ECC-04',
    risk: "Unauthorized 'SAP*' Admin Access",
    impact: 'Prevented Audit Failure / Fine', impactColor: '#2563eb',
  },
  {
    unit: 'Manufacturing Plant A', sid: 'QAS-APP-02',
    risk: 'OS Patch Drift vs Baseline',
    impact: 'Saved 2.5 hrs manual patching', impactColor: '#475569',
  },
]

export default SapBusinessValuePage
