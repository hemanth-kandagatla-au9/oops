import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react'
import {
  Box, Button, Checkbox, Chip, Dialog, DialogActions, DialogContent, FormControl, FormControlLabel, FormHelperText,
  IconButton, InputLabel, ListItemText, MenuItem, Paper, Select, Stack, Step, StepButton,
  StepConnector, StepLabel, Stepper, Switch, TextField, Tooltip, Typography,
} from '@mui/material'
import { styled } from '@mui/material/styles'
import { stepConnectorClasses } from '@mui/material/StepConnector'
import Editor from '@monaco-editor/react'
import { ChevronLeft, Pencil, Maximize2, Minimize2, X } from 'lucide-react'
import { useHistory, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import {
  useGetRuleByIdQuery,
  useCreateRuleMutation,
  useUpdateRuleMutation,
  useGetRuleCategoriesMetadataQuery,
  useGetRuleCategoriesQuery,
  useGetGovernanceTeamsQuery,
} from '../../redux/slices/rulesSlice'
import { POLICYOPS_PATH } from '../../utils/constant'
import { MONACO_EDITOR_OPTIONS } from '../../utils/monacoConfig'
import { RuleCategoryField, RuleCategoryMetadata } from '../../types'
import blueStepper from '../../assets/policyStepper/policy1ststepper.svg'
import completedStepper from '../../assets/policyStepper/completedStepper.svg'
import defaultStepper from '../../assets/policyStepper/defaultStepper.svg'
import './RulesFormPage.scss'
import { showErrorToast, showSuccessToast } from '../../utils/toastHelper'

// ── Assignment-style MUI Stepper ──────────────────────────────────────────────

const RULE_STEPS = ['Basic Info', 'Configuration', 'Actions', 'Review']

const RuleStepConnector = styled(StepConnector)(() => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 20,
    left: 'calc(-50% + 20px)',
    right: 'calc(50% + 20px)',
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 2,
    border: 0,
    backgroundColor: '#e2e8f0',
    borderRadius: 1,
  },
  [`&.${stepConnectorClasses.active} .${stepConnectorClasses.line}`]: {
    backgroundColor: '#2563eb',
  },
  [`&.${stepConnectorClasses.completed} .${stepConnectorClasses.line}`]: {
    backgroundColor: '#22c55e',
  },
}))

const RuleStepIcon: React.FC<{ active: boolean; completed: boolean }> = ({ active, completed }) => {
  const src = completed ? completedStepper : active ? blueStepper : defaultStepper
  return <Box component="img" src={src} sx={{ width: 36, height: 36, objectFit: 'contain' }} />
}

// ── Helpers ───────────────────────────────────────────────────────────────────

const TAG_COLORS = [
  { bg: '#eff6ff', color: '#2563eb', border: '#bfdbfe' },
  { bg: '#f0fdf4', color: '#16a34a', border: '#bbf7d0' },
  { bg: '#faf5ff', color: '#7c3aed', border: '#e9d5ff' },
  { bg: '#fff7ed', color: '#d97706', border: '#fde68a' },
  { bg: '#fdf2f8', color: '#db2777', border: '#fbcfe8' },
  { bg: '#f0fdfa', color: '#0d9488', border: '#99f6e4' },
]
const tagColor = (i: number) => TAG_COLORS[i % TAG_COLORS.length]

const buildInitialValues = (fields: RuleCategoryField[]): Record<string, any> => {
  const vals: Record<string, any> = {}
  // Top-level toggles default ON; nested toggles (inside another field's nestedFields) default OFF
  const walk = (list: RuleCategoryField[], depth: number) => {
    list.forEach((f) => {
      const ft = f.fieldType as string
      if (ft === 'toggle') vals[f.field] = depth === 0
      else if (ft === 'checkbox' || ft === '') vals[f.field] = false
      else if (ft === 'multiselect') vals[f.field] = []
      else vals[f.field] = ''
      if (f.nestedFields?.length) walk(f.nestedFields, depth + 1)
    })
  }
  walk(fields, 0)
  return vals
}

const mergeExisting = (fields: RuleCategoryField[], existing: Record<string, any>): Record<string, any> => {
  const base = buildInitialValues(fields)
  const walk = (list: RuleCategoryField[]) => {
    list.forEach((f) => {
      if (f.field in existing) base[f.field] = existing[f.field]
      if (f.nestedFields?.length) walk(f.nestedFields)
    })
  }
  walk(fields)
  return base
}

// If any nested field is a textarea, stack all fields vertically so textarea gets full width
const nestedGridVariant = (fields: RuleCategoryField[]) =>
  fields.length === 1 || fields.some((f) => (f.fieldType as string) === 'textarea')
    ? 'single'
    : fields.length === 2 ? 'double' : 'triple'

// When a toggle is turned OFF, reset all its descendant fields to their blank defaults
const collectNestedDefaults = (fields: RuleCategoryField[]): Record<string, any> => {
  const defaults: Record<string, any> = {}
  const walk = (list: RuleCategoryField[]) => {
    list.forEach((f) => {
      const ft = f.fieldType as string
      defaults[f.field] = ft === 'toggle' ? false : ft === 'multiselect' ? [] : ''
      if (f.nestedFields?.length) walk(f.nestedFields)
    })
  }
  walk(fields)
  return defaults
}

type FieldErrors = Record<string, string>

const validateOptionValues = (fields: RuleCategoryField[], values: Record<string, any>): FieldErrors => {
  const errs: FieldErrors = {}
  const walk = (list: RuleCategoryField[]) => {
    list.forEach((f) => {
      const ft = f.fieldType as string
      if (ft === 'toggle' || ft === 'checkbox' || ft === '') {
        if (f.nestedFields?.length) walk(f.nestedFields)
        return
      }
      const val = values[f.field]
      if (ft === 'select' && val !== '' && val !== null && val !== undefined && f.options?.length) {
        if (!f.options.includes(val)) {
          errs[f.field] = `"${val}" is not valid. Allowed: ${f.options.join(', ')}`
        }
      }
      if (ft === 'multiselect' && Array.isArray(val) && val.length > 0 && f.options?.length) {
        const invalid = val.filter((v: string) => !f.options!.includes(v))
        if (invalid.length > 0) {
          errs[f.field] = `Invalid value(s): ${invalid.join(', ')}. Allowed: ${f.options.join(', ')}`
        }
      }
    })
  }
  walk(fields)
  return errs
}


type RuleFormSnapshot = {
  name: string
  description: string
  severity: string
  checkType: string
  category: string
  tags: string[]
  ownerTeam: string
  changeTicket: string
  configValues: Record<string, any>
  driftValues: Record<string, any>
}

const EMPTY_RULE_SNAPSHOT: RuleFormSnapshot = {
  name: '',
  description: '',
  severity: '',
  checkType: '',
  category: '',
  tags: [],
  ownerTeam: '',
  changeTicket: '',
  configValues: {},
  driftValues: {},
}

const validateConfigStep = (fields: RuleCategoryField[], values: Record<string, any>): FieldErrors => {
  const errs: FieldErrors = {}
  const walk = (list: RuleCategoryField[]) => {
    list.forEach((f) => {
      const ft = f.fieldType as string

      if (ft === 'toggle' || ft === 'checkbox') {
        // insertAtEnd is inverted: nested fields validated when OFF
        const shouldRecurse = f.field === 'insertAtEnd' ? !values[f.field] : !!values[f.field]
        if (shouldRecurse && f.nestedFields?.length) walk(f.nestedFields)
        return
      }

      if (ft === '') {
        // Grouping/conditional wrapper — always recurse; its own "value" is never set by the user
        if (f.nestedFields?.length) walk(f.nestedFields)
        return
      }

        const val = values[f.field]
        const empty = val === '' || val === null || val === undefined || (Array.isArray(val) && val.length === 0)
      if (f.isMandatory && empty) {
        errs[f.field] = `${f.displayName} is required`
        return
      }
      // Validate that dropdown values are within the allowed options list
      if (ft === 'select' && !empty && f.options?.length && !f.options.includes(val)) {
        errs[f.field] = `"${val}" is not valid. Allowed: ${f.options.join(', ')}`
      }
      if (ft === 'multiselect' && Array.isArray(val) && val.length > 0 && f.options?.length) {
        const invalid = val.filter((v: string) => !f.options!.includes(v))
        if (invalid.length > 0) {
          errs[f.field] = `Invalid value(s): ${invalid.join(', ')}. Allowed: ${f.options.join(', ')}`
        }
      }
    })
  }
  walk(fields)
  return errs
}

const validateStep0 = (name: string, severity: string, checkType: string, category: string, ownerTeam: string): FieldErrors => {
  const errs: FieldErrors = {}
  if (!name.trim()) errs.name = 'Rule name is required'
  if (!severity) errs.severity = 'Severity is required'
  if (!checkType) errs.checkType = 'Check type is required'
  if (!category) errs.category = 'Category is required'
  if (!ownerTeam) errs.ownerTeam = 'Owner team is required'
  return errs
}

// ── Nested field renderer ─────────────────────────────────────────────────────

interface NestedFieldProps {
  field: RuleCategoryField
  values: Record<string, any>
  onChange: React.Dispatch<React.SetStateAction<Record<string, any>>>
  errors?: Record<string, string>
  onClearError?: (key: string) => void
}

const NestedField: React.FC<NestedFieldProps> = ({ field, values, onChange, errors, onClearError }) => {
  const set = (v: any) => onChange((prev) => ({ ...prev, [field.field]: v }))
  const val = values[field.field]
  const ft = field.fieldType as string

  if (ft === 'toggle') {
    const isChecked = !!val
    // insertAtEnd is inverted: show nested fields when OFF (specific line needed), hide when ON (insert at end)
    const isInverted = field.field === 'insertAtEnd'
    const showNested = isInverted ? !isChecked : isChecked

    const handleToggle = (checked: boolean) => {
      // Clear nested values when the nested section becomes hidden
      const becomesHidden = isInverted ? checked : !checked
      if (becomesHidden && field.nestedFields?.length) {
        onChange((prev: Record<string, any>) => ({ ...prev, [field.field]: checked, ...collectNestedDefaults(field.nestedFields!) }))
      } else {
        set(checked)
      }
    }
    return (
      <div className={`rule-checkbox-group${isChecked ? ' rule-checkbox-group--checked' : ''}${(field.nestedFields?.length ?? 0) > 0 ? ' rule-checkbox-group--has-nested' : ''}`}>
        <FormControlLabel
          className="rule-checkbox-row"
          control={
            <Switch size="small" checked={isChecked} onChange={(e) => handleToggle(e.target.checked)}
              sx={{ '& .MuiSwitch-switchBase.Mui-checked': { color: '#2563eb' }, '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': { bgcolor: '#2563eb' } }} />
          }
          label={field.displayName}
        />
        {showNested && (field.nestedFields?.length ?? 0) > 0 && (
          <div className="rule-nested-fields">
            <div className={`rule-nested-grid rule-nested-grid--${nestedGridVariant(field.nestedFields!)}`}>
              {field.nestedFields!.map((nf) => (
                <NestedField key={nf.field} field={nf} values={values} onChange={onChange} errors={errors} onClearError={onClearError} />
              ))}
            </div>
          </div>
        )}
      </div>
    )
  }

  if (ft === 'checkbox' || ft === '') {
    const isChecked = !!val
    return (
      <div className={`rule-checkbox-group${isChecked ? ' rule-checkbox-group--checked' : ''}${(field.nestedFields?.length ?? 0) > 0 ? ' rule-checkbox-group--has-nested' : ''}`}>
        <FormControlLabel
          className="rule-checkbox-row"
          control={
            <Checkbox size="small" checked={isChecked} onChange={(e) => set(e.target.checked)}
              sx={{ color: '#cbd5e1', '&.Mui-checked': { color: '#2563eb' }, p: '3px' }} />
          }
          label={
            <Typography sx={{ fontSize: '0.875rem', fontWeight: 500, color: '#334155' }}>
              {field.displayName}
              {field.description && (
                <Typography component="span" sx={{ fontSize: '0.75rem', color: '#64748b', display: 'block' }}>{field.description}</Typography>
              )}
            </Typography>
          }
        />
        {isChecked && (field.nestedFields?.length ?? 0) > 0 && (
          <div className="rule-nested-fields">
            <div className={`rule-nested-grid rule-nested-grid--${nestedGridVariant(field.nestedFields!)}`}>
              {field.nestedFields.map((nf) => (
                <NestedField key={nf.field} field={nf} values={values} onChange={onChange} errors={errors} onClearError={onClearError} />
              ))}
            </div>
          </div>
        )}
      </div>
    )
  }

  if (ft === 'multiselect') {
    const selected: string[] = Array.isArray(val) ? val : []
    return (
      <FormControl fullWidth size="small" className="rule-form-field">
        <InputLabel>{field.displayName}{field.isMandatory ? ' *' : ''}</InputLabel>
        <Select
          multiple
          value={selected}
          label={field.displayName + (field.isMandatory ? ' *' : '')}
          onChange={(e: any) => set(e.target.value)}
          renderValue={(s: any) => (
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
              {(s as string[]).map((v: string) => (
                <Chip key={v} label={v} size="small"
                  onDelete={(e: React.MouseEvent) => { e.stopPropagation(); set(selected.filter((x: string) => x !== v)) }}
                  sx={{ height: 20, fontSize: '0.75rem' }} />
              ))}
            </Box>
          )}
        >
          {field.options?.map((o) => (
            <MenuItem key={o} value={o}>
              <Checkbox size="small" checked={selected.includes(o)} sx={{ p: '3px', mr: 0.5, color: '#cbd5e1', '&.Mui-checked': { color: '#2563eb' } }} />
              <ListItemText primary={o} primaryTypographyProps={{ fontSize: '0.875rem' }} />
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    )
  }

  if (ft === 'select') {
    // Separate plain nested fields from fieldType="" conditional sections
    const conditionalSections = (field.nestedFields ?? []).filter((nf: RuleCategoryField) => (nf.fieldType as string) === '')
    const firstOption = field.options?.[0]
    const showConditional = !!val && val === firstOption

    return (
      <Box sx={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 1.5 }}>
        <FormControl fullWidth size="small" className="rule-form-field" error={!!errors?.[field.field]}>
          <InputLabel>{field.displayName}{field.isMandatory ? ' *' : ''}</InputLabel>
          <Select value={val ?? ''} label={field.displayName + (field.isMandatory ? ' *' : '')}
            onChange={(e: any) => { set(e.target.value); onClearError?.(field.field) }}>
            {field.options?.map((o: string) => <MenuItem key={o} value={o}>{o}</MenuItem>)}
          </Select>
          {errors?.[field.field] && <FormHelperText>{errors[field.field]}</FormHelperText>}
        </FormControl>
        {showConditional && conditionalSections.map((section: RuleCategoryField) => (
          <Box key={section.field} sx={{ pl: 2, borderLeft: '2px solid #bfdbfe', display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            {section.nestedFields?.map((nf: RuleCategoryField) => (
              <NestedField key={nf.field} field={nf} values={values} onChange={onChange} errors={errors} onClearError={onClearError} />
            ))}
          </Box>
        ))}
      </Box>
    )
  }

  if (ft === 'textarea') {
    return (
      <TextField multiline minRows={4} maxRows={16} fullWidth size="small" className="rule-form-field"
        label={field.displayName} required={field.isMandatory}
        placeholder={field.placeholder} value={val ?? ''}
        error={!!errors?.[field.field]} helperText={errors?.[field.field]}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) => { set(e.target.value); onClearError?.(field.field) }}
        sx={{ '& .MuiInputBase-input': { resize: 'vertical' } }} />
    )
  }

  if (ft === 'number') {
    return (
      <TextField type="number" fullWidth size="small" className="rule-form-field"
        label={field.displayName} required={field.isMandatory}
        placeholder={field.placeholder} value={val ?? ''}
        error={!!errors?.[field.field]} helperText={errors?.[field.field]}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) => { set(e.target.value); onClearError?.(field.field) }} />
    )
  }

  return (
    <TextField fullWidth size="small" className="rule-form-field"
      label={field.displayName} required={field.isMandatory}
      placeholder={field.placeholder} value={val ?? ''}
      error={!!errors?.[field.field]} helperText={errors?.[field.field]}
      onChange={(e: React.ChangeEvent<HTMLInputElement>) => { set(e.target.value); onClearError?.(field.field) }} />
  )
}

// ── Dynamic field renderer ────────────────────────────────────────────────────

interface FieldRendererProps {
  field: RuleCategoryField
  values: Record<string, any>
  onChange: React.Dispatch<React.SetStateAction<Record<string, any>>>
  errors?: Record<string, string>
  onClearError?: (key: string) => void
}

const FieldRenderer: React.FC<FieldRendererProps> = ({ field, values, onChange, errors, onClearError }) => {
  const set = (v: any) => onChange((prev) => ({ ...prev, [field.field]: v }))
  const val = values[field.field]
  const ft = field.fieldType as string

  if (ft === 'toggle') {
    const isChecked = !!val
    const handleToggle = (checked: boolean) => {
      if (!checked && field.nestedFields?.length) {
        onChange((prev: Record<string, any>) => ({ ...prev, [field.field]: false, ...collectNestedDefaults(field.nestedFields!) }))
      } else {
        set(checked)
      }
    }
    return (
      <div className={`rule-checkbox-group${isChecked ? ' rule-checkbox-group--checked' : ''}${(field.nestedFields?.length ?? 0) > 0 ? ' rule-checkbox-group--has-nested' : ''}`}>
        <FormControlLabel
          className="rule-checkbox-row"
          control={
            <Switch size="small" checked={isChecked} onChange={(e) => handleToggle(e.target.checked)}
              sx={{ '& .MuiSwitch-switchBase.Mui-checked': { color: '#2563eb' }, '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': { bgcolor: '#2563eb' } }} />
          }
          label={
            <Typography sx={{ fontSize: '0.875rem', color: '#334155' }}>
              {field.displayName}
              {field.description && (
                <Typography component="span" sx={{ fontSize: '0.75rem', color: '#64748b', display: 'block' }}>{field.description}</Typography>
              )}
            </Typography>
          }
        />
        {isChecked && (field.nestedFields?.length ?? 0) > 0 && (
          <div className="rule-nested-fields">
            <div className={`rule-nested-grid rule-nested-grid--${nestedGridVariant(field.nestedFields!)}`}>
              {field.nestedFields.map((nf) => (
                <NestedField key={nf.field} field={nf} values={values} onChange={onChange} errors={errors} onClearError={onClearError} />
              ))}
            </div>
          </div>
        )}
      </div>
    )
  }

  if (ft === 'checkbox' || ft === '') {
    const isChecked = !!val
    return (
      <div className={`rule-checkbox-group${isChecked ? ' rule-checkbox-group--checked' : ''}${(field.nestedFields?.length ?? 0) > 0 ? ' rule-checkbox-group--has-nested' : ''}`}>
        <FormControlLabel
          className="rule-checkbox-row"
          control={
            <Checkbox size="small" checked={isChecked} onChange={(e) => set(e.target.checked)}
              sx={{ color: '#cbd5e1', '&.Mui-checked': { color: '#2563eb' }, p: '3px' }} />
          }
          label={
            <Typography sx={{ fontSize: '0.875rem', fontWeight: 500, color: '#334155' }}>
              {field.displayName}
              {field.description && (
                <Typography component="span" sx={{ fontSize: '0.75rem', color: '#64748b', display: 'block' }}>{field.description}</Typography>
              )}
            </Typography>
          }
        />
        {isChecked && (field.nestedFields?.length ?? 0) > 0 && (
          <div className="rule-nested-fields">
            <div className={`rule-nested-grid rule-nested-grid--${nestedGridVariant(field.nestedFields!)}`}>
              {field.nestedFields.map((nf) => (
                <NestedField key={nf.field} field={nf} values={values} onChange={onChange} errors={errors} onClearError={onClearError} />
              ))}
            </div>
          </div>
        )}
      </div>
    )
  }

  if (ft === 'multiselect') {
    const selected: string[] = Array.isArray(val) ? val : []
    return (
      <div className="rule-dynamic-fields__item">
        <FormControl fullWidth size="small" className="rule-form-field">
          <InputLabel>{field.displayName}{field.isMandatory ? ' *' : ''}</InputLabel>
          <Select
            multiple
            value={selected}
            label={field.displayName + (field.isMandatory ? ' *' : '')}
            onChange={(e) => set(e.target.value)}
            renderValue={(s) => (
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                {(s as string[]).map((v) => (
                  <Chip key={v} label={v} size="small"
                    onDelete={(e: React.MouseEvent) => { e.stopPropagation(); set(selected.filter((x: string) => x !== v)) }}
                    sx={{ height: 20, fontSize: '0.75rem' }} />
                ))}
              </Box>
            )}
          >
            {field.options?.map((o) => (
              <MenuItem key={o} value={o}>
                <Checkbox size="small" checked={selected.includes(o)} sx={{ p: '3px', mr: 0.5, color: '#cbd5e1', '&.Mui-checked': { color: '#2563eb' } }} />
                <ListItemText primary={o} primaryTypographyProps={{ fontSize: '0.875rem' }} />
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </div>
    )
  }

  if (ft === 'select') {
    return (
      <div className="rule-dynamic-fields__item">
        <FormControl fullWidth size="small" className="rule-form-field" error={!!errors?.[field.field]}>
          <InputLabel>{field.displayName}{field.isMandatory ? ' *' : ''}</InputLabel>
          <Select value={val ?? ''} label={field.displayName + (field.isMandatory ? ' *' : '')}
            onChange={(e) => { set(e.target.value); onClearError?.(field.field) }}>
            {field.options?.map((o) => <MenuItem key={o} value={o}>{o}</MenuItem>)}
          </Select>
          {errors?.[field.field] && <FormHelperText>{errors[field.field]}</FormHelperText>}
        </FormControl>
      </div>
    )
  }

  if (ft === 'textarea') {
    return (
      <div className="rule-dynamic-fields__item">
        <TextField multiline minRows={4} maxRows={16} fullWidth size="small" className="rule-form-field"
          label={field.displayName} required={field.isMandatory}
          placeholder={field.placeholder} value={val ?? ''} onChange={(e) => set(e.target.value)}
          sx={{ '& .MuiInputBase-input': { resize: 'vertical' } }} />
      </div>
    )
  }

  if (ft === 'number') {
    const lineErr = val !== '' && val !== null && val !== undefined &&
      /line.*num|linenum/i.test(field.field + field.displayName) &&
      (!Number.isInteger(Number(val)) || Number(val) < 1)
      ? 'Must be a positive whole number' : null
    return (
      <div className="rule-dynamic-fields__item rule-dynamic-fields__item--half">
        <TextField type="number" fullWidth size="small" className="rule-form-field"
          label={field.displayName} required={field.isMandatory}
          placeholder={field.placeholder} value={val ?? ''}
          error={!!errors?.[field.field] || !!lineErr}
          helperText={errors?.[field.field] || lineErr}
          onChange={(e) => { set(e.target.value); onClearError?.(field.field) }} />
      </div>
    )
  }

  const pathErr = val && /path/i.test(field.field + field.displayName) &&
    !/^(\/|[a-zA-Z]:[\\/]|\\\\)/.test(val)
    ? 'Enter an absolute path (e.g. /etc/config or C:\\folder)' : null
  return (
    <div className="rule-dynamic-fields__item">
      <TextField fullWidth size="small" className="rule-form-field"
        label={field.displayName} required={field.isMandatory}
        placeholder={field.placeholder} value={val ?? ''}
        error={!!errors?.[field.field] || !!pathErr}
        helperText={errors?.[field.field] || pathErr}
        onChange={(e) => { set(e.target.value); onClearError?.(field.field) }} />
    </div>
  )
}

// Recursively collect keys of fields nested inside fieldType="" sections → go to source
const collectSourceKeys = (fields: RuleCategoryField[], keys: Set<string>) => {
  fields.forEach((f) => {
    if ((f.fieldType as string) === '') {
      f.nestedFields?.forEach((nf) => keys.add(nf.field))
    } else if (f.nestedFields?.length) {
      collectSourceKeys(f.nestedFields, keys)
    }
  })
}

const SOURCE_FIELDS = new Set(['url', 'checksum'])

const buildPayload = (
  configFields: RuleCategoryField[],
  configValues: Record<string, any>,
) => {
  const sourceKeys = new Set<string>([...SOURCE_FIELDS])
  collectSourceKeys(configFields, sourceKeys)

  const source: Record<string, any> = {}
  const configuration: Record<string, any> = {}
  Object.entries(configValues).forEach(([k, v]) => {
    if (sourceKeys.has(k)) {
      if (v !== '' && v !== null && v !== undefined) source[k] = v
    } else {
      configuration[k] = v
    }
  })

  if (Object.keys(source).length > 0) {
    configuration.source = source
  }

  return { configuration }
}

// ── Review row ────────────────────────────────────────────────────────────────

const ReviewRow: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <Box display="flex" py={0.75} sx={{ '&:not(:last-child)': { borderBottom: '1px solid #f8fafc' } }}>
    <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', minWidth: 200, flexShrink: 0 }}>{label}</Typography>
    <Box flex={1}>
      {typeof value === 'string'
        ? <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#0f172a' }}>{value || '-'}</Typography>
        : value}
    </Box>
  </Box>
)

// ── Page ──────────────────────────────────────────────────────────────────────

const RuleFormPage: React.FC = () => {
  const { id } = useParams<{ id?: string }>()
  const isEdit = !!id && id !== 'new'
  const history = useHistory()

  const { data: ruleData, isLoading: loadingRule } = useGetRuleByIdQuery(id!, { skip: !isEdit, refetchOnMountOrArgChange: true })
  const { data: metaData } = useGetRuleCategoriesMetadataQuery()
  const { data: catData } = useGetRuleCategoriesQuery()
  const { data: govData } = useGetGovernanceTeamsQuery()
  const [createRule, { isLoading: creating }] = useCreateRuleMutation()
  const [updateRule, { isLoading: updating }] = useUpdateRuleMutation()

  const allMetadata: RuleCategoryMetadata[] = metaData?.data ?? []
  const categoryOptions: string[] = (catData?.data ?? []).map((c: any) => c.name ?? c)
  const govTeams: string[] = (govData?.data ?? []).map((t: any) => t.name ?? t)

  const [step, setStep] = useState(0)
  const [errors, setErrors] = useState<FieldErrors>({})
  const [configErrors, setConfigErrors] = useState<FieldErrors>({})

  // Basic Info
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [severity, setSeverity] = useState('')
  const [checkType, setCheckType] = useState('')
  const [category, setCategory] = useState('')
  const [tags, setTags] = useState<string[]>([])
  const [tagInput, setTagInput] = useState('')
  const [ownerTeam, setOwnerTeam] = useState('')
  const [changeTicket, setChangeTicket] = useState('')

  // Dynamic fields
  const [configValues, setConfigValues] = useState<Record<string, any>>({})
  const [driftValues, setDriftValues] = useState<Record<string, any>>({})

  // JSON editor state – Configuration
  const [configJson, setConfigJson] = useState('')
  const [configJsonError, setConfigJsonError] = useState(false)
  const [editorMaximized, setEditorMaximized] = useState(false)

  // JSON editor state – Actions
  const [driftJson, setDriftJson] = useState('')
  const [driftJsonError, setDriftJsonError] = useState(false)
  const [driftEditorMax, setDriftEditorMax] = useState(false)

  // Unsaved-changes guard
  const [confirmLeaveOpen, setConfirmLeaveOpen] = useState(false)
  const [snapshotVersion, setSnapshotVersion] = useState(0)
  const initialSnapshotRef = useRef<RuleFormSnapshot | null>(null)
  const pendingNavigationRef = useRef<(() => void) | null>(null)
  const unblockHistoryRef = useRef<(() => void) | null>(null)
  const allowNavigationRef = useRef(false)

  const selectedMeta: RuleCategoryMetadata | undefined =
    allMetadata.find((m) => m.categoryCode === checkType)
  const configFields = selectedMeta?.configFields ?? []
  const driftFields = selectedMeta?.driftResponses ?? []

  // Sync configValues → JSON editor
  useEffect(() => {
    try {
      setConfigJson(JSON.stringify(configValues, null, 2))
      setConfigJsonError(false)
    } catch {
      // ignore
    }
  }, [configValues])

  // Sync driftValues → Actions JSON editor (primaryAction shown as array)
  useEffect(() => {
    try {
      const display = { ...driftValues }
      if (typeof display.primaryAction === 'string') {
        display.primaryAction = display.primaryAction !== '' ? [display.primaryAction] : []
      }
      setDriftJson(JSON.stringify(display, null, 2))
      setDriftJsonError(false)
    } catch {
      // ignore
    }
  }, [driftValues])

  // Re-init dynamic fields when checkType changes (create only)
  useEffect(() => {
    if (isEdit) return
    const init = buildInitialValues(configFields)
    setConfigValues(init)
    setDriftValues(buildInitialValues(driftFields))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [checkType])

  // Load existing rule
  useEffect(() => {
    const rule = ruleData?.data
    if (!rule) return
    setName(rule.name ?? '')
    setDescription(rule.description ?? '')
    setSeverity((rule.severity ?? '').toUpperCase())
    const storedType = rule.checkType ?? ''
    const byName = allMetadata.find((m) => m.name === storedType)?.categoryCode
    setCheckType(byName ?? storedType)
    setCategory(rule.rulecategory ?? '')
    setTags(rule.tags ?? [])
    setOwnerTeam(rule.governance?.ownerTeam ?? '')
    setChangeTicket(rule.governance?.associatedChangeTicket ?? '')
  }, [ruleData])

  // Seed dynamic fields after metadata loads in edit mode
  useEffect(() => {
    if (!isEdit) return
    const rule = ruleData?.data
    if (!rule || !selectedMeta) return
    // Merge configuration + source back into a flat configValues object
    const configData = rule.configuration ?? rule.definition ?? {}
    const merged = { ...configData, ...(configData.source ?? {}), ...(rule.source ?? {}) }
    const mergedConfig = mergeExisting(configFields, merged)
    setConfigValues(mergedConfig)
    const driftMerged = mergeExisting(driftFields, rule.driftresponse ?? {})
    // Unwrap primaryAction array → string for select UI
    if (Array.isArray(driftMerged.primaryAction)) {
      driftMerged.primaryAction = driftMerged.primaryAction[0] ?? ''
    }
    setDriftValues(driftMerged)

    // Capture the dirty-tracking baseline once both basic and dynamic fields are loaded.
    initialSnapshotRef.current = {
      name: (rule.name ?? '').trim(),
      description: (rule.description ?? '').trim(),
      severity: (rule.severity ?? '').toUpperCase(),
      checkType,
      category: rule.rulecategory ?? '',
      tags: [...(rule.tags ?? [])].map(String).sort(),
      ownerTeam: rule.governance?.ownerTeam ?? '',
      changeTicket: rule.governance?.associatedChangeTicket ?? '',
      configValues: mergedConfig,
      driftValues: driftMerged,
    }
    setSnapshotVersion((v: number) => v + 1)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedMeta])

  // ── Unsaved-changes guard ────────────────────────────────────────────────
  const getCurrentSnapshot = useCallback((): RuleFormSnapshot => ({
    name: name.trim(),
    description: description.trim(),
    severity,
    checkType,
    category,
    tags: [...tags].sort(),
    ownerTeam,
    changeTicket,
    configValues,
    driftValues,
  }), [name, description, severity, checkType, category, tags, ownerTeam, changeTicket, configValues, driftValues])

  const isDirty = useMemo(() => {
    if (!initialSnapshotRef.current) return false
    return JSON.stringify(getCurrentSnapshot()) !== JSON.stringify(initialSnapshotRef.current)
  }, [getCurrentSnapshot, snapshotVersion])

  const clearHistoryBlock = useCallback(() => {
    unblockHistoryRef.current?.()
    unblockHistoryRef.current = null
  }, [])

  const allowHistoryNavigation = useCallback(() => {
    allowNavigationRef.current = true
  }, [])

  const requestLeave = (navigate: () => void) => {
    if (isDirty) {
      pendingNavigationRef.current = navigate
      setConfirmLeaveOpen(true)
      return
    }
    navigate()
  }

  const goToRules = () =>
    requestLeave(() => {
      allowHistoryNavigation()
      history.push(POLICYOPS_PATH.RULES)
    })

  const handleConfirmLeave = () => {
    const navigate = pendingNavigationRef.current
    pendingNavigationRef.current = null
    setConfirmLeaveOpen(false)
    navigate?.()
  }

  const handleDismissLeaveConfirm = () => {
    pendingNavigationRef.current = null
    setConfirmLeaveOpen(false)
  }

  // Seed an empty baseline snapshot for create mode so edits are detected.
  useEffect(() => {
    if (isEdit) return
    if (!initialSnapshotRef.current) {
      initialSnapshotRef.current = { ...EMPTY_RULE_SNAPSHOT }
      setSnapshotVersion((v: number) => v + 1)
    }
  }, [isEdit])

  // Block in-app route changes (and browser back) while there are unsaved changes.
  useEffect(() => {
    if (!isDirty) {
      clearHistoryBlock()
      return
    }

    unblockHistoryRef.current = history.block((location: { pathname: string; search?: string; hash?: string }, action: string) => {
      if (allowNavigationRef.current) {
        allowNavigationRef.current = false
        return undefined
      }

      const targetPath = `${location.pathname}${location.search ?? ''}${location.hash ?? ''}`
      const currentPath = `${history.location.pathname}${history.location.search ?? ''}${history.location.hash ?? ''}`
      if (targetPath === currentPath) {
        return undefined
      }

      pendingNavigationRef.current = () => {
        allowHistoryNavigation()
        if (action === 'POP') history.goBack()
        else history.push(targetPath)
      }
      setConfirmLeaveOpen(true)
      return false
    })

    return clearHistoryBlock
  }, [history, isDirty, clearHistoryBlock, allowHistoryNavigation])

  // Warn on browser/tab close while dirty.
  useEffect(() => {
    if (!isDirty) return

    const handleBeforeUnload = (event: BeforeUnloadEvent) => {
      event.preventDefault()
      event.returnValue = ''
    }

    window.addEventListener('beforeunload', handleBeforeUnload)
    return () => window.removeEventListener('beforeunload', handleBeforeUnload)
  }, [isDirty])

  const clearErr = (key: string) => setErrors((prev) => { const n = { ...prev }; delete n[key]; return n })

  // JSON editor change handler – Configuration
  const handleJsonChange = useCallback((value: string | undefined) => {
    const raw = value ?? ''
    setConfigJson(raw)
    try {
      const parsed = JSON.parse(raw)
      setConfigValues(parsed)
      setConfigJsonError(false)
      // Immediately flag invalid dropdown values so errors show on the form fields
      const optionErrs = validateOptionValues(configFields, parsed)
      setConfigErrors((prev: FieldErrors) => {
        const next = { ...prev }
        // Clear stale option errors first, then apply fresh ones
        configFields.forEach((f) => { if (next[f.field] && !optionErrs[f.field]) delete next[f.field] })
        return { ...next, ...optionErrs }
      })
    } catch {
      setConfigJsonError(true)
    }
  }, [configFields])

  // JSON editor change handler – Actions (unwrap primaryAction array → string for UI)
  const handleDriftJsonChange = useCallback((value: string | undefined) => {
    const raw = value ?? ''
    setDriftJson(raw)
    try {
      const parsed = JSON.parse(raw)
      if (Array.isArray(parsed.primaryAction)) {
        parsed.primaryAction = parsed.primaryAction[0] ?? ''
      }
      setDriftValues(parsed)
      setDriftJsonError(false)
    } catch {
      setDriftJsonError(true)
    }
  }, [driftFields])

  const goNext = () => {
    if (step === 0) {
      const errs = validateStep0(name, severity, checkType, category, ownerTeam)
      if (Object.keys(errs).length) { setErrors(errs); return }
      setErrors({})
    }
    if (step === 1) {
      const errs = validateConfigStep(configFields, configValues)
      if (Object.keys(errs).length) { setConfigErrors(errs); return }
      setConfigErrors({})
    }
    setStep((s) => Math.min(s + 1, RULE_STEPS.length - 1))
  }

  const goPrev = () => setStep((s) => Math.max(s - 1, 0))

  const handleStepClick = (i: number) => {
    if (i < step) { setStep(i); return }
    if (step === 0 && i > 0) {
      const errs = validateStep0(name, severity, checkType, category, ownerTeam)
      if (Object.keys(errs).length) { setErrors(errs); return }
      setErrors({})
    }
    if (step === 1 && i > 1) {
      const errs = validateConfigStep(configFields, configValues)
      if (Object.keys(errs).length) { setConfigErrors(errs); return }
      setConfigErrors({})
    }
    setStep(i)
  }

  const handleSave = async () => {
    const errs = validateStep0(name, severity, checkType, category, ownerTeam)
    if (Object.keys(errs).length) { setErrors(errs); setStep(0); return }
    const cfgErrs = validateConfigStep(configFields, configValues)
    if (Object.keys(cfgErrs).length) { setConfigErrors(cfgErrs); setStep(1); return }

    const { configuration } = buildPayload(configFields, configValues)
    const payload: any = {
      ...(isEdit && id ? { id } : {}),
      name: name.trim(),
      description: description.trim(),
      severity,
      checkType: selectedMeta?.name ?? checkType,
      rulecategory: category,
      status: 'PUBLISHED',
      tags,
      governance: { ownerTeam, associatedChangeTicket: changeTicket },
      configuration,
      driftresponse: {
        ...driftValues,
        ...(driftValues.primaryAction !== undefined && {
          primaryAction: typeof driftValues.primaryAction === 'string'
            ? (driftValues.primaryAction !== '' ? [driftValues.primaryAction] : [])
            : driftValues.primaryAction,
        }),
      },
    }

    try {
      if (isEdit) {
        await updateRule({ id: id!, data: payload }).unwrap()
        // toast.success(`"${name}" updated successfully`)
        showSuccessToast(`"${name}" updated successfully`)
      } else {
        await createRule(payload).unwrap()
        // toast.success(`"${name}" created successfully`)
        showSuccessToast(`"${name}" created successfully`)
      }
      allowHistoryNavigation()
      history.push(POLICYOPS_PATH.RULES)
    } catch (err: any) {
      // toast.error('Failed to save rule. Please try again.')
      showErrorToast({
        title: err?.data?.message || 'Failed to save rule. Please try again.',
        message: err?.data?.message,
      })

    }
  }

  const isFormComplete =
    !!name.trim() && !!severity && !!checkType && !!category && !!ownerTeam &&
    Object.keys(validateConfigStep(configFields, configValues)).length === 0

  if (isEdit && loadingRule) {
    return (
      <Box sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Typography sx={{ color: '#64748b' }}>Loading rule…</Typography>
      </Box>
    )
  }

  return (
    <div className="rule-form-page">

      {/* ── Header ── */}
      <div className="rule-form-page__header">
        <Box display="flex" alignItems="center" gap={1}>
          <IconButton size="small" onClick={goToRules}
            sx={{ color: '#64748b', border: '1px solid #e2e8f0', borderRadius: '8px', p: '4px', '&:hover': { bgcolor: '#f8fafc' } }}>
            <ChevronLeft size={16} />
          </IconButton>
          <Box>
            <Typography variant="caption"
              sx={{ color: '#2563eb', cursor: 'pointer', fontWeight: 500, display: 'block', lineHeight: 1.4, '&:hover': { textDecoration: 'underline' } }}
              onClick={goToRules}>
              Rules Repository
            </Typography>
            <Typography sx={{ fontSize: '1.05rem', fontWeight: 700, color: '#0f172a', lineHeight: 1.2 }}>
              {isEdit ? 'Modify Rule' : 'Configure Rule'}
            </Typography>
          </Box>
        </Box>

        <Box display="flex" gap={1.5}>
          <Button variant="outlined" size="small" onClick={goToRules}
            className="rule-btn rule-btn--cancel">
            Cancel
          </Button>
          <Button variant="contained" size="small"
            disabled={creating || updating || step !== RULE_STEPS.length - 1 || !isFormComplete}
            onClick={handleSave} className="rule-btn rule-btn--publish">
            {creating || updating ? 'Saving…' : isEdit ? 'Save Changes' : 'Create Rule'}
          </Button>
        </Box>
      </div>

      {/* ── Stepper ── */}
      <div className="rule-form-page__stepper-wrap">
        <Stepper
          nonLinear
          activeStep={step}
          alternativeLabel
          connector={<RuleStepConnector />}
          sx={{
            maxWidth: 820, mx: 'auto',
            '& .MuiStepLabel-label': { mt: 0.75, fontSize: '0.78rem' },
            '& .MuiStepLabel-labelContainer': { maxWidth: 'none' },
          }}
        >
          {RULE_STEPS.map((label, index) => (
            <Step key={label} completed={index < step}>
              <StepButton disableRipple onClick={() => handleStepClick(index)}>
                <StepLabel StepIconComponent={() => (
                  <RuleStepIcon active={index === step} completed={index < step} />
                )}>
                  <Typography sx={{ fontSize: '0.78rem', fontWeight: index === step ? 700 : 400, color: index <= step ? '#1e293b' : '#94a3b8' }}>
                    {label}
                  </Typography>
                </StepLabel>
              </StepButton>
            </Step>
          ))}
        </Stepper>
      </div>

      {/* ── Step content ── */}
      <div className="rule-form-page__content">

        {/* ── Step 0: Basic Info ── */}
        {step === 0 && (
          <Box display="flex" flexDirection="column" gap={2} sx={{ width: '100%' }}>

            {/* Rule Information */}
            <div className="rule-card">
              <p className="rule-card__title">Rule Information</p>
              <p className="rule-card__subtitle">Core identity and classification of this rule.</p>

              <Box display="grid" gridTemplateColumns="1fr 1fr" gap={2} mb={2}>
                <TextField
                  label="Rule Name *"
                  value={name}
                  onChange={(e) => { setName(e.target.value); clearErr('name') }}
                  fullWidth size="small" className="rule-form-field"
                  error={!!errors.name}
                  helperText={errors.name}
                />
                <FormControl fullWidth size="small" className="rule-form-field" error={!!errors.severity}>
                  <InputLabel>Severity *</InputLabel>
                  <Select value={severity} label="Severity *"
                    onChange={(e) => { setSeverity(e.target.value); clearErr('severity') }}>
                    {['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map((v) => (
                      <MenuItem key={v} value={v}>{v}</MenuItem>
                    ))}
                  </Select>
                  {errors.severity && <FormHelperText>{errors.severity}</FormHelperText>}
                </FormControl>
              </Box>

              <TextField
                label="Description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                fullWidth size="small" multiline rows={2}
                className="rule-form-field"
                sx={{ mb: 2 }}
              />

              <Box display="grid" gridTemplateColumns="1fr 1fr" gap={2} mb={2}>
                <FormControl fullWidth size="small" className="rule-form-field" error={!!errors.checkType}>
                  <InputLabel>Check Type *</InputLabel>
                  <Select value={checkType} label="Check Type *" disabled={isEdit}
                    onChange={(e) => { setCheckType(e.target.value); clearErr('checkType') }}>
                    {allMetadata.map((m) => (
                      <MenuItem key={m.categoryCode} value={m.categoryCode}>{m.name}</MenuItem>
                    ))}
                  </Select>
                  {errors.checkType && <FormHelperText>{errors.checkType}</FormHelperText>}
                </FormControl>
                <FormControl fullWidth size="small" className="rule-form-field" error={!!errors.category}>
                  <InputLabel>Category *</InputLabel>
                  <Select value={category} label="Category *" onChange={(e: any) => { setCategory(e.target.value); setErrors((p: FieldErrors) => { const n = { ...p }; delete n.category; return n }) }}>
                    {categoryOptions.map((c) => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                  </Select>
                  {errors.category && <FormHelperText>{errors.category}</FormHelperText>}
                </FormControl>
              </Box>

              <TextField
                placeholder="Type a tag and press Enter"
                label="Tags"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && tagInput.trim()) {
                    e.preventDefault()
                    if (!tags.includes(tagInput.trim())) setTags((prev) => [...prev, tagInput.trim()])
                    setTagInput('')
                  }
                }}
                fullWidth size="small" className="rule-form-field"
              />
              {tags.length > 0 && (
                <Stack direction="row" spacing={1} flexWrap="wrap" mt={1.5}>
                  {tags.map((tag) => (
                    <Tooltip key={tag} title={tag} arrow>
                      <Chip key={tag} label={tag} size="small"
                        onDelete={() => setTags((prev) => prev.filter((t) => t !== tag))}
                        sx={{
                          borderRadius: '999px', bgcolor: '#eff6ff', color: '#2563eb', border: '1px solid #bfdbfe', fontSize: '0.78rem',
                          maxWidth: '200px',
                          cursor: "pointer",
                          '& .MuiChip-label': {
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          },
                        }} />
                    </Tooltip>
                  ))}
                </Stack>
              )}
            </div>

            {/* Governance */}
            <div className="rule-card">
              <p className="rule-card__title">Governance</p>
              <p className="rule-card__subtitle">Ownership and change management details.</p>
              <Box display="grid" gridTemplateColumns="1fr 1fr" gap={2}>
                {govTeams.length > 0 ? (
                  <FormControl fullWidth size="small" className="rule-form-field" error={!!errors.ownerTeam}>
                    <InputLabel>Owner Team *</InputLabel>
                    <Select value={ownerTeam} label="Owner Team *" onChange={(e: any) => { setOwnerTeam(e.target.value); setErrors((p: FieldErrors) => { const n = { ...p }; delete n.ownerTeam; return n }) }}>
                      {govTeams.map((t) => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                    </Select>
                    {errors.ownerTeam && <FormHelperText>{errors.ownerTeam}</FormHelperText>}
                  </FormControl>
                ) : (
                  <TextField label="Owner Team *" value={ownerTeam}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => { setOwnerTeam(e.target.value); setErrors((p: FieldErrors) => { const n = { ...p }; delete n.ownerTeam; return n }) }}
                    fullWidth size="small" className="rule-form-field"
                    error={!!errors.ownerTeam} helperText={errors.ownerTeam} />
                )}
                <TextField label="Associated Change Ticket" value={changeTicket}
                  onChange={(e) => setChangeTicket(e.target.value)}
                  fullWidth size="small" className="rule-form-field" />
              </Box>
            </div>
          </Box>
        )}

        {/* ── Step 1: Configuration ── */}
        {step === 1 && (
          <div className="rule-split-layout" style={{ width: '100%' }}>
            {/* Form fields */}
            <div className="rule-split-layout__form">
              <div className="rule-card">
                <p className="rule-card__title">Configuration</p>
                <p className="rule-card__subtitle">
                  {selectedMeta ? `Fields for "${selectedMeta.name}"` : 'Select a Check Type in Basic Info to see configuration fields.'}
                </p>
                {configFields.length === 0 ? (
                  <Typography sx={{ fontSize: '0.875rem', color: '#94a3b8', fontStyle: 'italic' }}>
                    No configuration fields for this check type.
                  </Typography>
                ) : (
                  <div className="rule-dynamic-fields">
                    {configFields.map((field) => (
                      <FieldRenderer
                        key={field.field}
                        field={field}
                        values={configValues}
                        onChange={setConfigValues}
                        errors={configErrors}
                        onClearError={(key: string) => setConfigErrors((prev: FieldErrors) => { const n = { ...prev }; delete n[key]; return n })}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* JSON editor */}
            <div className="rule-split-layout__editor">
              <div className={`rule-json-editor${editorMaximized ? ' rule-json-editor--maximized' : ''}`}>
                <div className="rule-json-editor__header">
                  <span className="rule-json-editor__title">JSON Editor</span>
                  <Box display="flex" alignItems="center" gap={1}>
                    <span className={`rule-json-editor__badge rule-json-editor__badge--${configJsonError ? 'error' : 'synced'}`}>
                      {configJsonError ? 'Error' : 'Synced'}
                    </span>
                    <IconButton size="small" onClick={() => setEditorMaximized((v: boolean) => !v)}
                      sx={{ color: '#94a3b8', p: '4px', '&:hover': { color: '#f1f5f9', bgcolor: '#334155' }, borderRadius: '4px' }}>
                      {editorMaximized ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
                    </IconButton>
                  </Box>
                </div>
                <div className="rule-json-editor__body">
                  <Editor
                    language="json"
                    value={configJson}
                    onChange={handleJsonChange}
                    options={MONACO_EDITOR_OPTIONS}
                    theme="vs-dark"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── Step 2: Actions ── */}
        {step === 2 && (
          <div className="rule-split-layout" style={{ width: '100%' }}>
            {/* Form fields */}
            <div className="rule-split-layout__form">
              <div className="rule-card">
                <p className="rule-card__title">Actions</p>
                <p className="rule-card__subtitle">Define the drift response actions for this rule.</p>
                {driftFields.length === 0 ? (
                  <Typography sx={{ fontSize: '0.875rem', color: '#94a3b8', fontStyle: 'italic' }}>
                    No action fields for this check type.
                  </Typography>
                ) : (
                  <div className="rule-dynamic-fields">
                    {driftFields.map((field) => (
                      <FieldRenderer key={field.field} field={field} values={driftValues} onChange={setDriftValues} />
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* JSON editor */}
            <div className="rule-split-layout__editor">
              <div className={`rule-json-editor${driftEditorMax ? ' rule-json-editor--maximized' : ''}`}>
                <div className="rule-json-editor__header">
                  <span className="rule-json-editor__title">JSON Editor</span>
                  <Box display="flex" alignItems="center" gap={1}>
                    <span className={`rule-json-editor__badge rule-json-editor__badge--${driftJsonError ? 'error' : 'synced'}`}>
                      {driftJsonError ? 'Error' : 'Synced'}
                    </span>
                    <IconButton size="small" onClick={() => setDriftEditorMax((v) => !v)}
                      sx={{ color: '#94a3b8', p: '4px', '&:hover': { color: '#f1f5f9', bgcolor: '#334155' }, borderRadius: '4px' }}>
                      {driftEditorMax ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
                    </IconButton>
                  </Box>
                </div>
                <div className="rule-json-editor__body">
                  <Editor
                    language="json"
                    value={driftJson}
                    onChange={handleDriftJsonChange}
                    options={MONACO_EDITOR_OPTIONS}
                    theme="vs-dark"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── Step 3: Review ── */}
        {step === 3 && (
          <Box sx={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 2 }}>

            {/* Basic Information */}
            <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5 }}>
              <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
                <Typography sx={{ fontSize: '0.9375rem', fontWeight: 700, color: '#102459' }}>Basic Information</Typography>
                <IconButton size="small" onClick={() => setStep(0)}
                  sx={{ color: '#94a3b8', '&:hover': { color: '#2563eb', bgcolor: '#eff6ff' } }}>
                  <Pencil size={15} />
                </IconButton>
              </Box>
              <ReviewRow label="Rule Name" value={name} />
              <ReviewRow label="Rule Category" value={selectedMeta?.name ?? checkType} />
              <ReviewRow label="Severity" value={severity} />
              <ReviewRow label="Description" value={description || '-'} />
              {category && <ReviewRow label="Category" value={category} />}
              {tags.length > 0 && (
                <ReviewRow label="Tags" value={
                  <Stack direction="row" spacing={0.75} flexWrap="wrap">
                    {tags.map((t: string, i: number) => {
                      const c = tagColor(i)

                      return (
                        <Tooltip key={t} title={t} arrow>
                          <Chip
                            label={t}
                            size="small"
                            sx={{
                              borderRadius: '999px',
                              bgcolor: c.bg,
                              color: c.color,
                              border: `1px solid ${c.border}`,
                              fontSize: '0.75rem',
                              fontWeight: 500,
                              height: 22,

                              maxWidth: 220,

                              '& .MuiChip-label': {
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                                display: 'block',
                              },
                            }}
                          />
                        </Tooltip>
                      )
                    })}
                  </Stack>
                } />
              )}
            </Paper>

            {/* Configuration + Actions & Governance side by side */}
            <Box display="grid" gridTemplateColumns="1fr 1fr" gap={2} sx={{ alignItems: 'start' }}>

              {/* Configuration */}
              <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5 }}>
                <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
                  <Typography sx={{ fontSize: '0.9375rem', fontWeight: 700, color: '#102459' }}>Configuration</Typography>
                  <IconButton size="small" onClick={() => setStep(1)}
                    sx={{ color: '#94a3b8', '&:hover': { color: '#2563eb', bgcolor: '#eff6ff' } }}>
                    <Pencil size={15} />
                  </IconButton>
                </Box>
                {configFields.length > 0
                  ? configFields.map((f) => {
                    const v = configValues[f.field]
                    if (v === '' || v === null || v === undefined || v === false) return null
                    return <ReviewRow key={f.field} label={f.displayName} value={String(v)} />
                  })
                  : <Typography sx={{ fontSize: '0.8125rem', color: '#94a3b8', fontStyle: 'italic' }}>No configuration values set</Typography>
                }
              </Paper>

              {/* Actions & Governance */}
              <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5 }}>
                <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
                  <Typography sx={{ fontSize: '0.9375rem', fontWeight: 700, color: '#102459' }}>Actions & Governance</Typography>
                  <IconButton size="small" onClick={() => setStep(2)}
                    sx={{ color: '#94a3b8', '&:hover': { color: '#2563eb', bgcolor: '#eff6ff' } }}>
                    <Pencil size={15} />
                  </IconButton>
                </Box>
                {driftFields.length > 0
                  ? driftFields.map((f) => {
                    const v = driftValues[f.field]
                    if (v === '' || v === null || v === undefined || v === false) return null
                    return <ReviewRow key={f.field} label={f.displayName} value={String(v)} />
                  })
                  : <Typography sx={{ fontSize: '0.8125rem', color: '#94a3b8', fontStyle: 'italic' }}>No actions configured</Typography>
                }
                {ownerTeam && <ReviewRow label="Owner Team" value={ownerTeam} />}
                {changeTicket && <ReviewRow label="Associated Change Ticket" value={changeTicket} />}
              </Paper>

            </Box>
          </Box>
        )}

      </div>

      {/* ── Footer ── */}
      <div className="rule-form-page__footer">
        {step > 0 && (
          <Button variant="outlined" size="small" onClick={goPrev} className="rule-btn rule-btn--previous">
            Previous
          </Button>
        )}
        {step < RULE_STEPS.length - 1 && (
          <Button variant="contained" size="small" onClick={goNext} className="rule-btn rule-btn--next">
            Next
          </Button>
        )}
      </div>

      <Dialog
        open={confirmLeaveOpen}
        onClose={handleDismissLeaveConfirm}
        maxWidth="xs"
        fullWidth
        PaperProps={{ sx: { borderRadius: 2 } }}
      >
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            px: 2.5,
            py: 2,
            borderBottom: '1px solid #e2e8f0',
          }}
        >
          <Typography variant="subtitle1" fontWeight={700} color="#0f172a">
            Unsaved Changes
          </Typography>
          <IconButton size="small" onClick={handleDismissLeaveConfirm} sx={{ color: '#94a3b8' }}>
            <X size={18} />
          </IconButton>
        </Box>
        <DialogContent sx={{ pt: 2.5 }}>
          <Typography sx={{ fontSize: '0.85rem', color: '#64748b' }}>
            You have unsaved changes. Are you sure you want to leave? Your changes will be lost.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 2.5, pb: 2.5, gap: 1 }}>
          <Button
            onClick={handleDismissLeaveConfirm}
            variant="outlined"
            size="small"
            sx={{ textTransform: 'none', borderRadius: 1.5 }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleConfirmLeave}
            variant="contained"
            size="small"
            sx={{
              textTransform: 'none',
              borderRadius: 1.5,
              bgcolor: '#2563eb',
              '&:hover': { bgcolor: '#1d4ed8' },
            }}
          >
            Yes, Leave
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  )
}

export default RuleFormPage
