import React, { useState } from 'react'
import {
  Box, Button, FormControl, IconButton, InputAdornment,
  MenuItem, Popover, Select, TextField, Tooltip, Typography,
} from '@mui/material'
import { Search, SlidersHorizontal, X } from 'lucide-react'
import dayjs from 'dayjs'
import { useGetAuditLogsQuery, useGetAuditUsersQuery } from '../../redux/slices/auditSlice'
import PolicyTable, { TableColumn } from '../../components/PolicyTable'

// ── Color maps ────────────────────────────────────────────────────────────────

type PillStyle = { bg: string; color: string; border: string }

const MODULE_STYLE: Record<string, PillStyle> = {
  rules:        { bg: '#faf5ff', color: '#7c3aed', border: '#ddd6fe' },
  policy:       { bg: '#eff6ff', color: '#2563eb', border: '#bfdbfe' },
  policy_group: { bg: '#f0fdf4', color: '#16a34a', border: '#bbf7d0' },
  assignment:   { bg: '#fffbeb', color: '#d97706', border: '#fde68a' },
  server_groups: { bg: '#f0f9ff', color: '#0369a1', border: '#bae6fd' },
}

const DEFAULT_PILL: PillStyle = { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' }

const getStatusStyle = (code: number): PillStyle => {
  if (code >= 200 && code < 300) return { bg: '#f0fdf4', color: '#16a34a', border: '#bbf7d0' }
  if (code >= 400 && code < 500) return { bg: '#fffbeb', color: '#d97706', border: '#fde68a' }
  if (code >= 500) return { bg: '#fef2f2', color: '#dc2626', border: '#fecaca' }
  return DEFAULT_PILL
}

const ColorPill: React.FC<{ label: string; style: PillStyle }> = ({ label, style }) => (
  <Box sx={{ px: 1.25, py: 0.3, borderRadius: '999px', bgcolor: style.bg, color: style.color, border: `1px solid ${style.border}`, fontSize: '0.72rem', fontWeight: 600, display: 'inline-block', whiteSpace: 'nowrap' }}>
    {label}
  </Box>
)

// ── Main page ─────────────────────────────────────────────────────────────────

const AuditPage: React.FC = () => {
  const [search, setSearch]     = useState('')
  const [page, setPage]         = useState(0)
  const [pageSize, setPageSize] = useState(10)

  // applied filters (wired to query)
  const [moduleFilter, setModuleFilter] = useState('')
  const [requestedBy, setRequestedBy]   = useState('')
  const [fromDate, setFromDate]         = useState('')
  const [toDate, setToDate]             = useState('')

  // pending filters (edited inside popover before Apply)
  const [filterAnchorEl, setFilterAnchorEl]         = useState<HTMLButtonElement | null>(null)
  const [pendingModule, setPendingModule]             = useState('')
  const [pendingRequestedBy, setPendingRequestedBy]   = useState('')
  const [pendingFrom, setPendingFrom]                 = useState('')
  const [pendingTo, setPendingTo]                     = useState('')

  const { data: usersData } = useGetAuditUsersQuery()
  const userOptions: string[] = usersData?.data ?? []

  const { data, isLoading, isError } = useGetAuditLogsQuery({
    page: page + 1, limit: pageSize,
    module:       moduleFilter || undefined,
    requested_by: requestedBy  || undefined,
    search:       search       || undefined,
    from_date:    fromDate     || undefined,
    to_date:      toDate       || undefined,
  })

  const logs: any[]   = data?.data  ?? []
  const total: number = data?.total ?? 0
  const filterOpen = Boolean(filterAnchorEl)
  const activeFilterCount = [moduleFilter, requestedBy, fromDate, toDate].filter(Boolean).length

  const openFilter = (e: React.MouseEvent<HTMLButtonElement>) => {
    setPendingModule(moduleFilter)
    setPendingRequestedBy(requestedBy)
    setPendingFrom(fromDate)
    setPendingTo(toDate)
    setFilterAnchorEl(e.currentTarget)
  }

  const closeFilter = () => setFilterAnchorEl(null)

  const handleApplyFilters = () => {
    setModuleFilter(pendingModule)
    setRequestedBy(pendingRequestedBy)
    setFromDate(pendingFrom)
    setToDate(pendingTo)
    setPage(0)
    closeFilter()
  }

  const handleClearFilters = () => {
    setPendingModule(''); setPendingRequestedBy(''); setPendingFrom(''); setPendingTo('')
    setModuleFilter(''); setRequestedBy(''); setFromDate(''); setToDate('')
    setPage(0)
  }

  const columns: TableColumn[] = [
    {
      key: 'timestamp', header: 'Timestamp', width: '16%',
      render: (row: any) => (
        <Box>
          <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#102459' }}>
            {dayjs(row.timestamp).format('MMM D, YYYY')}
          </Typography>
          <Typography sx={{ fontSize: '0.75rem', color: '#64748b', mt: 0.25 }}>
            {dayjs(row.timestamp).format('HH:mm:ss')}
          </Typography>
        </Box>
      ),
    },
    {
      key: 'module', header: 'Module', width: '11%',
      render: (row: any) => {
        const style = MODULE_STYLE[(row.module ?? '').toLowerCase()] ?? DEFAULT_PILL
        return <ColorPill label={row.module ?? '-'} style={style} />
      },
    },
    {
      key: 'requested_by', header: 'Requested By', width: '22%',
      render: (row: any) => (
        <Tooltip title={row.requested_by || ''} placement="top" arrow
          disableHoverListener={!row.requested_by || row.requested_by.length < 20}
          slotProps={{ tooltip: { sx: { fontSize: '0.78rem' } } }}>
          <Typography sx={{ fontSize: '0.875rem', fontWeight: 500, color: '#102459', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'block' }}>
            {row.requested_by || '-'}
          </Typography>
        </Tooltip>
      ),
    },
    {
      key: 'status_code', header: 'Status', width: '14%',
      render: (row: any) => (
        <ColorPill label={String(row.status_code ?? '-')} style={getStatusStyle(row.status_code ?? 0)} />
      ),
    },
  ]

  return (
    <Box p={2.5} sx={{ height: '100%', display: 'flex', flexDirection: 'column', boxSizing: 'border-box' }}>

      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1.5}>
        <Box>
          <Box display="flex" alignItems="center" gap={1}>
            <Typography variant="h5" fontWeight={700}>Audit Logs</Typography>
            <Box sx={{ px: 1, py: 0.15, bgcolor: '#eff6ff', borderRadius: '999px', border: '1px solid #dbeafe' }}>
              <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: '#2563eb' }}>{total}</Typography>
            </Box>
          </Box>
          <Typography variant="body2" color="text.secondary" mt={0.25}>
            Immutable record of all API activity
          </Typography>
        </Box>

        <Box display="flex" alignItems="center" gap={1.5}>
          <TextField
            size="small" placeholder="Search" value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(0) }}
            InputProps={{ startAdornment: <InputAdornment position="start"><Search size={15} color="#94a3b8" /></InputAdornment> }}
            sx={{ width: 220, '& .MuiOutlinedInput-root': { borderRadius: '999px', fontSize: '0.85rem', bgcolor: 'white', '& fieldset': { borderColor: '#e2e8f0' } } }}
          />
          <Button
            variant="outlined" size="small"
            startIcon={<SlidersHorizontal size={14} />}
            onClick={openFilter}
            sx={{ borderColor: activeFilterCount ? '#2563eb' : '#e2e8f0', color: activeFilterCount ? '#2563eb' : '#374151', fontSize: '0.85rem', bgcolor: 'white', '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' }, position: 'relative' }}
          >
            Filter{activeFilterCount > 0 ? ` (${activeFilterCount})` : ''}
          </Button>
        </Box>
      </Box>

      {/* Table */}
      <Box sx={{ flex: 1, minHeight: 0 }}>
        <PolicyTable
          columns={columns} rows={logs} total={total} page={page} pageSize={pageSize}
          onPageChange={setPage} onPageSizeChange={(s: number) => { setPageSize(s); setPage(0) }}
          loading={isLoading} error={isError} errorMessage="Failed to load audit logs"
          getRowId={(row: any) => row.audit_id ?? row._id}
          sx={{ height: '100%' }}
        />
      </Box>

      {/* ── Filter popover ────────────────────────────────────────────────── */}
      <Popover
        open={filterOpen}
        anchorEl={filterAnchorEl}
        onClose={closeFilter}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        PaperProps={{ sx: { mt: 1, width: 360, borderRadius: '12px', boxShadow: '0 8px 30px rgba(0,0,0,0.12)', border: '1px solid #e2e8f0', overflow: 'hidden' } }}
      >
        {/* header */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2.5, py: 2, borderBottom: '1px solid #f1f5f9' }}>
          <Typography sx={{ fontWeight: 700, fontSize: '0.9375rem', color: '#0f172a' }}>Filter</Typography>
          <IconButton size="small" onClick={closeFilter} sx={{ color: '#94a3b8', p: 0.5, '&:hover': { bgcolor: '#f1f5f9' } }}>
            <X size={15} />
          </IconButton>
        </Box>

        <Box sx={{ px: 2.5, py: 2, display: 'flex', flexDirection: 'column', gap: 2.5 }}>
          {/* Module */}
          <Box>
            <Typography sx={{ fontWeight: 600, fontSize: '0.8125rem', color: '#374151', mb: 1 }}>Module</Typography>
            <FormControl fullWidth size="small">
              <Select displayEmpty value={pendingModule} onChange={(e) => setPendingModule(e.target.value)}
                sx={{ borderRadius: '8px', fontSize: '0.875rem', bgcolor: 'white' }}>
                <MenuItem value=""><em style={{ color: '#94a3b8', fontStyle: 'normal' }}>Select</em></MenuItem>
                <MenuItem value="rules">Rules</MenuItem>
                <MenuItem value="policy">Policy</MenuItem>
                <MenuItem value="policy_group">Policy Group</MenuItem>
                <MenuItem value="assignment">Assignment</MenuItem>
                <MenuItem value="Target Groups">Target Groups</MenuItem>
              </Select>
            </FormControl>
          </Box>

          {/* Requested By */}
          <Box>
            <Typography sx={{ fontWeight: 600, fontSize: '0.8125rem', color: '#374151', mb: 1 }}>Requested By</Typography>
            <FormControl fullWidth size="small">
              <Select displayEmpty value={pendingRequestedBy} onChange={(e) => setPendingRequestedBy(e.target.value)}
                sx={{ borderRadius: '8px', fontSize: '0.875rem', bgcolor: 'white' }}>
                <MenuItem value=""><em style={{ color: '#94a3b8', fontStyle: 'normal' }}>Select</em></MenuItem>
                {userOptions.map((user) => <MenuItem key={user} value={user}>{user}</MenuItem>)}
              </Select>
            </FormControl>
          </Box>

          {/* Date */}
          <Box>
            <Typography sx={{ fontWeight: 600, fontSize: '0.8125rem', color: '#374151', mb: 1 }}>Date</Typography>
            <Box display="flex" gap={1.5}>
              <Box flex={1}>
                <Typography sx={{ fontSize: '0.75rem', color: '#94a3b8', mb: 0.5 }}>From</Typography>
                <TextField type="date" size="small" fullWidth value={pendingFrom}
                  onChange={(e) => setPendingFrom(e.target.value)}
                  sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px', fontSize: '0.875rem', bgcolor: 'white' } }} />
              </Box>
              <Box flex={1}>
                <Typography sx={{ fontSize: '0.75rem', color: '#94a3b8', mb: 0.5 }}>To</Typography>
                <TextField type="date" size="small" fullWidth value={pendingTo}
                  onChange={(e) => setPendingTo(e.target.value)}
                  sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px', fontSize: '0.875rem', bgcolor: 'white' } }} />
              </Box>
            </Box>
          </Box>
        </Box>

        {/* footer */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2.5, py: 2, borderTop: '1px solid #f1f5f9' }}>
          <Button variant="text" onClick={handleClearFilters}
            sx={{ color: '#2563eb', textTransform: 'none', fontWeight: 500, fontSize: '0.875rem', p: 0, '&:hover': { bgcolor: 'transparent', textDecoration: 'underline' } }}>
            Clear All
          </Button>
          <Button variant="contained" onClick={handleApplyFilters}
            sx={{ bgcolor: '#2563eb', textTransform: 'none', fontWeight: 600, fontSize: '0.875rem', px: 3, borderRadius: '8px', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}>
            Apply
          </Button>
        </Box>
      </Popover>

    </Box>
  )
}

export default AuditPage
