import React, { useState } from 'react'
import {
  Box, Typography, Button, IconButton,
  TextField, InputAdornment, Tabs, Tab, Divider,
  Dialog, DialogContent, DialogActions, MenuItem, Select, FormControl,
} from '@mui/material'
import {
  Activity, FileText, Clock, CheckCircle, Server, GitMerge, RotateCcw,
  UploadCloud, Plus, ArrowRight, Search, Filter, ShieldCheck, MoreVertical,
  XCircle, GitPullRequest, Copy, Eye, Settings, X,
  Box as BoxIcon, Grid as GridIcon, Layout as LayoutIcon,
} from 'lucide-react'

// ── Types ─────────────────────────────────────────────────────────────────────

interface PackageVersion {
  version: string
  status: string
  channel: string
  date: string
  notes: string
  approval: string
}

interface ReleasePackage {
  id: string
  name: string
  type: string
  currentVersion: string
  status: string
  channel: string
  assignments: number
  servers: number
  complianceScore: number
  lastUpdated: string
  owner: string
  description: string
  versions: PackageVersion[]
}

// ── Style helpers ─────────────────────────────────────────────────────────────

const getStatusStyle = (status: string) => {
  const map: Record<string, { bg: string; color: string; border: string }> = {
    'Active':           { bg: '#f0fdf4', color: '#15803d', border: '#bbf7d0' },
    'Released':         { bg: '#eff6ff', color: '#1d4ed8', border: '#bfdbfe' },
    'Draft':            { bg: '#f8fafc', color: '#475569', border: '#e2e8f0' },
    'Pending Approval': { bg: '#fffbeb', color: '#b45309', border: '#fde68a' },
    'Archived':         { bg: '#f8fafc', color: '#94a3b8', border: '#e2e8f0' },
    'New':              { bg: '#faf5ff', color: '#7c3aed', border: '#ddd6fe' },
  }
  return map[status] ?? { bg: '#f8fafc', color: '#475569', border: '#e2e8f0' }
}

const getChannelStyle = (channel: string) => {
  const map: Record<string, { bg: string; color: string; border: string }> = {
    'Production':  { bg: '#faf5ff', color: '#7c3aed', border: '#ddd6fe' },
    'Stable':      { bg: '#eef2ff', color: '#4338ca', border: '#c7d2fe' },
    'Testing':     { bg: '#fff7ed', color: '#c2410c', border: '#fed7aa' },
    'Development': { bg: '#ecfeff', color: '#0e7490', border: '#a5f3fc' },
    'QA':          { bg: '#f0fdf4', color: '#15803d', border: '#bbf7d0' },
  }
  return map[channel] ?? { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' }
}

// ── Sub-components ─────────────────────────────────────────────────────────────

const StatusBadge = ({ status, size = 'sm' }: { status: string; size?: 'sm' | 'md' }) => {
  const s = getStatusStyle(status)
  return (
    <Box sx={{ px: size === 'md' ? 1.5 : 1.25, py: 0.25, borderRadius: '999px', bgcolor: s.bg, color: s.color, border: `1px solid ${s.border}`, fontSize: size === 'md' ? '0.75rem' : '0.68rem', fontWeight: 600, display: 'inline-block', whiteSpace: 'nowrap', lineHeight: 1.6 }}>
      {status}
    </Box>
  )
}

const ChannelBadge = ({ channel, size = 'sm' }: { channel: string; size?: 'sm' | 'md' }) => {
  const s = getChannelStyle(channel)
  return (
    <Box sx={{ px: size === 'md' ? 1.5 : 1.25, py: 0.25, borderRadius: '999px', bgcolor: s.bg, color: s.color, border: `1px solid ${s.border}`, fontSize: size === 'md' ? '0.75rem' : '0.68rem', fontWeight: 600, display: 'inline-block', whiteSpace: 'nowrap', lineHeight: 1.6 }}>
      {channel}
    </Box>
  )
}

const ProgressBar = ({ progress, color }: { progress: number; color: string }) => (
  <Box sx={{ width: '100%', height: 6, bgcolor: '#f1f5f9', borderRadius: '999px', overflow: 'hidden', mt: 0.75 }}>
    <Box sx={{ width: `${progress}%`, height: '100%', bgcolor: color, borderRadius: '999px' }} />
  </Box>
)

// ── KPI Definitions ───────────────────────────────────────────────────────────

const KPI_DEFS = [
  { label: 'Total Packages',     Icon: BoxIcon as React.FC<{size:number}>,  color: '#2563eb', bg: '#eff6ff' },
  { label: 'Active Packages',    Icon: Activity,      color: '#059669', bg: '#ecfdf5' },
  { label: 'Draft Versions',     Icon: FileText,      color: '#475569', bg: '#f8fafc' },
  { label: 'Pending Approval',   Icon: Clock,         color: '#d97706', bg: '#fffbeb' },
  { label: 'Released (30d)',     Icon: CheckCircle,   color: '#4f46e5', bg: '#eef2ff' },
  { label: 'Servers Impacted',   Icon: Server,        color: '#0891b2', bg: '#ecfeff' },
  { label: 'Active Assignments', Icon: GitMerge,      color: '#7c3aed', bg: '#faf5ff' },
  { label: 'Rollbacks',          Icon: RotateCcw,     color: '#dc2626', bg: '#fef2f2' },
]
const KPI_STATIC = ['', '89', '24', '12', '45', '24.5k', '312', '3']

// ── Mock Data ─────────────────────────────────────────────────────────────────

const INITIAL_PACKAGES: ReleasePackage[] = [
  {
    id: 'pkg-001',
    name: 'Enterprise Linux Baseline',
    type: 'OS Configuration',
    currentVersion: 'v2.4.1',
    status: 'Active',
    channel: 'Production',
    assignments: 42,
    servers: 12450,
    complianceScore: 98,
    lastUpdated: '2 hours ago',
    owner: 'Platform Eng Team',
    description: 'Core security and operational baseline for all Enterprise Linux 8 & 9 instances.',
    versions: [
      { version: 'v2.5.0', status: 'Draft',    channel: 'Development', date: 'Just now',    notes: 'Added CIS Level 2 rules for SSH.',               approval: 'Pending' },
      { version: 'v2.4.1', status: 'Released', channel: 'Production',  date: '14 days ago', notes: 'Hotfix for auditd configuration drift.',          approval: 'Approved' },
      { version: 'v2.4.0', status: 'Released', channel: 'Production',  date: '30 days ago', notes: 'Major update to network kernel parameters.',      approval: 'Approved' },
    ],
  },
  {
    id: 'pkg-002',
    name: 'Kubernetes Core Security',
    type: 'Container Sec',
    currentVersion: 'v1.1.0',
    status: 'Active',
    channel: 'Stable',
    assignments: 18,
    servers: 450,
    complianceScore: 92,
    lastUpdated: '1 day ago',
    owner: 'SecOps',
    description: 'OPA Gatekeeper policies and RBAC hardening for managed k8s clusters.',
    versions: [
      { version: 'v1.1.0', status: 'Released', channel: 'Stable', date: '1 day ago',    notes: 'Added namespace boundary policies.', approval: 'Approved' },
      { version: 'v1.0.0', status: 'Archived', channel: 'Stable', date: '6 months ago', notes: 'Initial release.',                   approval: 'Approved' },
    ],
  },
  {
    id: 'pkg-003',
    name: 'Windows IIS Hardening',
    type: 'App Config',
    currentVersion: 'v3.0.0-beta',
    status: 'Pending Approval',
    channel: 'Testing',
    assignments: 5,
    servers: 850,
    complianceScore: 85,
    lastUpdated: '3 days ago',
    owner: 'Windows App Team',
    description: 'IIS web server configuration standards including TLS protocols and cipher suites.',
    versions: [
      { version: 'v3.0.0-beta', status: 'Pending Approval', channel: 'Testing', date: '3 days ago', notes: 'TLS 1.3 enforcement.', approval: 'Pending Review' },
    ],
  },
]

const TABS = [
  { id: 'overview',    label: 'Overview' },
  { id: 'versions',   label: 'Versions & Timeline' },
  { id: 'content',    label: 'Package Content' },
  { id: 'assignments',label: 'Assignment Impact' },
  { id: 'deployments',label: 'Deployment Tracking' },
]

// ── Page ──────────────────────────────────────────────────────────────────────

const ReleasePackagePage: React.FC = () => {
  const [packages, setPackages] = useState<ReleasePackage[]>(INITIAL_PACKAGES)
  const [selectedPackage, setSelectedPackage] = useState<ReleasePackage | null>(null)
  const [activeTab, setActiveTab] = useState('versions')

  const [createModalOpen, setCreateModalOpen] = useState(false)
  const [newName, setNewName]       = useState('')
  const [newType, setNewType]       = useState('OS Configuration')
  const [newChannel, setNewChannel] = useState('Development')
  const [newDesc, setNewDesc]       = useState('')

  const selectPackage = (pkg: ReleasePackage) => { setSelectedPackage(pkg); setActiveTab('versions') }
  const closeDrawer   = () => setSelectedPackage(null)

  const openCreateModal  = () => setCreateModalOpen(true)
  const closeCreateModal = () => {
    setCreateModalOpen(false)
    setNewName(''); setNewType('OS Configuration'); setNewChannel('Development'); setNewDesc('')
  }

  const handleCreateSubmit = () => {
    if (!newName.trim()) return
    const pkg: ReleasePackage = {
      id: `pkg-${Date.now()}`,
      name: newName.trim(), type: newType,
      currentVersion: 'v0.1.0-draft', status: 'New', channel: newChannel,
      assignments: 0, servers: 0, complianceScore: 0,
      lastUpdated: 'Just now', owner: 'Current User', description: newDesc,
      versions: [{ version: 'v0.1.0-draft', status: 'Draft', channel: newChannel, date: 'Just now', notes: 'Initial draft package structure created.', approval: 'Pending' }],
    }
    const updated = [pkg, ...packages]
    setPackages(updated)
    closeCreateModal()
    selectPackage(pkg)
  }

  const kpiValues = [packages.length.toString(), ...KPI_STATIC.slice(1)]

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden', boxSizing: 'border-box' }}>
      <Box sx={{ flex: 1, overflowY: 'auto', p: 2.5, display: 'flex', flexDirection: 'column', gap: 2.5, bgcolor: '#f8fafc' }}>

        {/* ── Header ── */}
        <Box display="flex" justifyContent="space-between" alignItems="flex-start" sx={{ flexShrink: 0 }}>
          <Box>
            <Typography variant="h5" fontWeight={700} color="#0f172a" sx={{ letterSpacing: '-0.01em' }}>
              Release Package Management
            </Typography>
            <Typography variant="body2" color="#64748b" mt={0.25}>
              Manage deployable, versioned configuration units, track assignments, and govern release lifecycles.
            </Typography>
          </Box>
          <Box display="flex" gap={1.5}>
            <Button variant="outlined" startIcon={<UploadCloud size={15} />}
              sx={{ borderColor: '#e2e8f0', color: '#374151', bgcolor: 'white', fontSize: '0.875rem', fontWeight: 500, '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' } }}>
              Import
            </Button>
            <Button variant="contained" startIcon={<Plus size={15} />} onClick={openCreateModal}
              sx={{ bgcolor: '#2563eb', fontSize: '0.875rem', fontWeight: 500, '&:hover': { bgcolor: '#1d4ed8' }, boxShadow: 'none' }}>
              Create Package
            </Button>
          </Box>
        </Box>

        {/* ── KPI Strip ── */}
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 2, flexShrink: 0 }}>
          {KPI_DEFS.map((kpi, i) => (
            <Box key={kpi.label} sx={{ bgcolor: 'white', p: 2, borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1.25}>
                <Typography sx={{ fontSize: '0.6rem', fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', lineHeight: 1.4 }}>
                  {kpi.label}
                </Typography>
                <Box sx={{ p: 0.75, borderRadius: '6px', bgcolor: kpi.bg, color: kpi.color, display: 'flex', alignItems: 'center' }}>
                  <kpi.Icon size={13} />
                </Box>
              </Box>
              <Typography sx={{ fontSize: '1.5rem', fontWeight: 700, color: '#1e293b', lineHeight: 1 }}>
                {kpiValues[i]}
              </Typography>
            </Box>
          ))}
        </Box>

        {/* ── Executive Insights ── */}
        <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', p: 2.5, flexShrink: 0 }}>
          <Box display="flex" alignItems="center" gap={1} mb={2}>
            <LayoutIcon size={15} color="#2563eb" />
            <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#1e293b' }}>Executive Insights</Typography>
          </Box>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 3 }}>
            <Box>
              <Typography sx={{ fontSize: '0.75rem', color: '#64748b', mb: 0.5 }}>Release Adoption Rate</Typography>
              <Box display="flex" alignItems="flex-end" gap={1}>
                <Typography sx={{ fontSize: '1.25rem', fontWeight: 700, color: '#1e293b' }}>84%</Typography>
                <Typography sx={{ fontSize: '0.72rem', color: '#16a34a', fontWeight: 500, mb: 0.25 }}>+2.4%</Typography>
              </Box>
              <ProgressBar progress={84} color="#6366f1" />
              <Typography sx={{ fontSize: '0.65rem', color: '#94a3b8', mt: 0.5 }}>Servers running latest stable version</Typography>
            </Box>
            <Box>
              <Typography sx={{ fontSize: '0.75rem', color: '#64748b', mb: 0.5 }}>Deployment Success (30d)</Typography>
              <Typography sx={{ fontSize: '1.25rem', fontWeight: 700, color: '#1e293b' }}>99.2%</Typography>
              <ProgressBar progress={99.2} color="#10b981" />
              <Typography sx={{ fontSize: '0.65rem', color: '#94a3b8', mt: 0.5 }}>Across 124 executed deployment strategies</Typography>
            </Box>
            <Box>
              <Typography sx={{ fontSize: '0.75rem', color: '#64748b', mb: 0.5 }}>Version Distribution</Typography>
              <Box sx={{ display: 'flex', gap: '2px', mt: 1 }}>
                <Box sx={{ bgcolor: '#10b981', width: '60%', height: 10, borderRadius: '6px 0 0 6px' }} />
                <Box sx={{ bgcolor: '#f59e0b', width: '25%', height: 10 }} />
                <Box sx={{ bgcolor: '#ef4444', width: '15%', height: 10, borderRadius: '0 6px 6px 0' }} />
              </Box>
              <Box display="flex" justifyContent="space-between" mt={1}>
                {[['#10b981','Latest','60%'],['#f59e0b','N-1','25%'],['#ef4444','Legacy','15%']].map(([c,l,p]) => (
                  <Box key={l as string} display="flex" alignItems="center" gap={0.5}>
                    <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: c as string, flexShrink: 0 }} />
                    <Typography sx={{ fontSize: '0.65rem', color: '#64748b', fontWeight: 500 }}>{l}</Typography>
                    <Typography sx={{ fontSize: '0.62rem', color: '#94a3b8' }}>({p})</Typography>
                  </Box>
                ))}
              </Box>
            </Box>
            <Box>
              <Typography sx={{ fontSize: '0.75rem', color: '#64748b', mb: 0.5 }}>Compliance Impact (Projected)</Typography>
              <Box display="flex" alignItems="center" gap={2} mt={0.5}>
                <Box textAlign="center">
                  <Typography sx={{ fontSize: '1.125rem', fontWeight: 700, color: '#94a3b8' }}>88%</Typography>
                  <Typography sx={{ fontSize: '0.62rem', textTransform: 'uppercase', color: '#94a3b8' }}>Current</Typography>
                </Box>
                <ArrowRight size={14} color="#cbd5e1" />
                <Box textAlign="center">
                  <Typography sx={{ fontSize: '1.125rem', fontWeight: 700, color: '#16a34a' }}>96%</Typography>
                  <Typography sx={{ fontSize: '0.62rem', textTransform: 'uppercase', color: '#16a34a', fontWeight: 600 }}>Post-Release</Typography>
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>

        {/* ── Main Content ── */}
        <Box sx={{ display: 'flex', gap: 2.5, minHeight: 680, flexShrink: 0 }}>

          {/* LIST COLUMN */}
          <Box sx={{
            display: 'flex', flexDirection: 'column',
            bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '12px',
            boxShadow: '0 1px 3px rgba(0,0,0,0.05)', overflow: 'hidden',
            transition: 'width 0.25s ease',
            width: selectedPackage ? '33%' : '100%',
            flexShrink: 0,
          }}>
            {/* Toolbar */}
            <Box sx={{ p: 1.5, borderBottom: '1px solid #f1f5f9', display: 'flex', gap: 1.5, alignItems: 'center', bgcolor: '#f8fafc', flexShrink: 0 }}>
              <TextField size="small" placeholder="Search packages by name, type, or owner..."
                InputProps={{ startAdornment: <InputAdornment position="start"><Search size={14} color="#94a3b8" /></InputAdornment> }}
                sx={{ flex: 1, '& .MuiOutlinedInput-root': { borderRadius: '8px', fontSize: '0.85rem', bgcolor: 'white', '& fieldset': { borderColor: '#e2e8f0' } } }}
              />
              <IconButton size="small" sx={{ border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', color: '#64748b', p: '6px' }}>
                <Filter size={14} />
              </IconButton>
              {!selectedPackage && (
                <IconButton size="small" sx={{ border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', color: '#64748b', p: '6px' }}>
                  <GridIcon size={14} />
                </IconButton>
              )}
            </Box>

            {/* Table header — full view */}
            {!selectedPackage && (
              <Box sx={{ display: 'grid', gridTemplateColumns: '3fr 1fr 2fr 2fr 2fr 2fr', gap: 1, px: 2.5, py: 1.25, borderBottom: '1px solid #e2e8f0', bgcolor: '#f8fafc', flexShrink: 0 }}>
                {[
                  { label: 'Package Name',          align: 'left',   pr: 0 },
                  { label: 'Version',               align: 'left',   pr: 0 },
                  { label: 'Status & Channel',      align: 'left',   pr: 0 },
                  { label: 'Assignments / Servers', align: 'right',  pr: 3 },
                  { label: 'Compliance',            align: 'center', pr: 0 },
                  { label: 'Last Updated',          align: 'left',   pr: 0 },
                ].map(({ label, align, pr }) => (
                  <Typography key={label} sx={{ fontSize: '0.68rem', fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.06em', textAlign: align, pr }}>
                    {label}
                  </Typography>
                ))}
              </Box>
            )}

            {/* List items */}
            <Box sx={{ flex: 1, overflowY: 'auto' }}>
              {packages.map((pkg: ReleasePackage) => {
                const isSelected = selectedPackage?.id === pkg.id
                return (
                  <Box
                    key={pkg.id}
                    onClick={() => selectPackage(pkg)}
                    sx={{
                      px: 2.5, py: 1.75,
                      borderBottom: '1px solid #f1f5f9', cursor: 'pointer',
                      boxShadow: isSelected ? 'inset 3px 0 0 #2563eb' : 'none',
                      bgcolor: isSelected ? '#eff6ff' : 'white',
                      transition: 'background-color 0.1s',
                      '&:hover': { bgcolor: isSelected ? '#eff6ff' : '#f8fafc' },
                      '&:hover .row-menu': { opacity: 1 },
                    }}
                  >
                    {selectedPackage ? (
                      /* Compact view */
                      <Box>
                        <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1}>
                          <Typography sx={{ fontWeight: 600, fontSize: '0.875rem', color: isSelected ? '#1d4ed8' : '#0f172a', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1, mr: 1 }}>
                            {pkg.name}
                          </Typography>
                          <MoreVertical size={14} color="#94a3b8" style={{ flexShrink: 0 }} />
                        </Box>
                        <Box display="flex" alignItems="center" gap={0.75} mb={1}>
                          <Box sx={{ fontSize: '0.75rem', fontWeight: 500, color: '#374151', bgcolor: '#f1f5f9', px: 1.25, py: 0.4, borderRadius: '5px', border: '1px solid #e2e8f0', display: 'inline-block' }}>
                            {pkg.currentVersion}
                          </Box>
                          <StatusBadge status={pkg.status} />
                        </Box>
                        <Box display="flex" justifyContent="space-between" sx={{ fontSize: '0.72rem', color: '#64748b' }}>
                          <Box display="flex" alignItems="center" gap={0.5}><GitMerge size={11} /> {pkg.assignments}</Box>
                          <Box display="flex" alignItems="center" gap={0.5}><Server size={11} /> {pkg.servers.toLocaleString()}</Box>
                        </Box>
                      </Box>
                    ) : (
                      /* Full table row */
                      <Box sx={{ display: 'grid', gridTemplateColumns: '3fr 1fr 2fr 2fr 2fr 2fr', gap: 1, alignItems: 'center' }}>
                        <Box display="flex" alignItems="center" gap={1}>
                          <BoxIcon size={15} color="#94a3b8" style={{ flexShrink: 0 }} />
                          <Box>
                            <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#0f172a' }}>{pkg.name}</Typography>
                            <Typography sx={{ fontSize: '0.72rem', color: '#64748b', mt: 0.25 }}>{pkg.type}</Typography>
                          </Box>
                        </Box>
                        <Box>
                          <Box sx={{ display: 'inline-block', fontSize: '0.8rem', fontWeight: 500, color: '#374151', bgcolor: '#f1f5f9', px: 1.25, py: 0.5, borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                            {pkg.currentVersion}
                          </Box>
                        </Box>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, alignItems: 'flex-start' }}>
                          <StatusBadge status={pkg.status} />
                          <ChannelBadge channel={pkg.channel} />
                        </Box>
                        <Box textAlign="right" pr={3}>
                          <Typography sx={{ fontSize: '0.875rem', fontWeight: 500, color: '#374151' }}>{pkg.assignments}</Typography>
                          <Box display="flex" alignItems="center" justifyContent="flex-end" gap={0.5} sx={{ fontSize: '0.72rem', color: '#64748b', mt: 0.25 }}>
                            <Server size={11} /> {pkg.servers.toLocaleString()} nodes
                          </Box>
                        </Box>
                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                          <Box display="flex" alignItems="center" gap={0.5}>
                            <ShieldCheck size={14} color={pkg.complianceScore > 90 ? '#10b981' : pkg.complianceScore > 0 ? '#f59e0b' : '#cbd5e1'} />
                            <Typography sx={{ fontSize: '0.875rem', fontWeight: 700, color: '#374151' }}>
                              {pkg.complianceScore > 0 ? `${pkg.complianceScore}%` : 'N/A'}
                            </Typography>
                          </Box>
                          <Box sx={{ width: 80, height: 6, bgcolor: '#f1f5f9', borderRadius: '999px', overflow: 'hidden', mt: 0.5 }}>
                            <Box sx={{ width: `${pkg.complianceScore}%`, height: '100%', bgcolor: pkg.complianceScore > 90 ? '#10b981' : '#f59e0b', borderRadius: '999px' }} />
                          </Box>
                        </Box>
                        <Box display="flex" justifyContent="space-between" alignItems="center" pl={1}>
                          <Box>
                            <Typography sx={{ fontSize: '0.78rem', color: '#64748b' }}>{pkg.lastUpdated}</Typography>
                            <Typography sx={{ fontSize: '0.72rem', color: '#94a3b8', mt: 0.25 }}>by {pkg.owner}</Typography>
                          </Box>
                          <IconButton size="small" className="row-menu"
                            sx={{ color: '#94a3b8', borderRadius: '6px', opacity: 0, transition: 'opacity 0.15s', '&:hover': { color: '#475569' } }}>
                            <MoreVertical size={14} />
                          </IconButton>
                        </Box>
                      </Box>
                    )}
                  </Box>
                )
              })}
            </Box>
          </Box>

          {/* DETAILS DRAWER */}
          {selectedPackage && (
            <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', overflow: 'hidden' }}>

              {/* Drawer Header */}
              <Box sx={{ p: 2.5, borderBottom: '1px solid #e2e8f0', bgcolor: 'rgba(248,250,252,0.5)', flexShrink: 0 }}>
                <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={2}>
                  <Box flex={1} mr={2}>
                    <Box display="flex" alignItems="center" gap={1.5} mb={0.5} flexWrap="wrap">
                      <Typography sx={{ fontSize: '1.125rem', fontWeight: 700, color: '#0f172a' }}>{selectedPackage.name}</Typography>
                      <StatusBadge status={selectedPackage.status} size="md" />
                      <ChannelBadge channel={selectedPackage.channel} size="md" />
                    </Box>
                    <Typography sx={{ fontSize: '0.8125rem', color: '#64748b' }}>{selectedPackage.description}</Typography>
                  </Box>
                  <IconButton size="small" onClick={closeDrawer}
                    sx={{ color: '#94a3b8', '&:hover': { color: '#475569', bgcolor: '#f1f5f9' }, borderRadius: '6px' }}>
                    <XCircle size={18} />
                  </IconButton>
                </Box>
                <Box display="flex" alignItems="center" gap={1.5}>
                  <Button size="small" variant="contained" startIcon={<GitPullRequest size={13} />}
                    sx={{ bgcolor: '#2563eb', fontSize: '0.8125rem', fontWeight: 500, boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}>
                    Create New Version
                  </Button>
                  <Divider orientation="vertical" flexItem sx={{ borderColor: '#cbd5e1' }} />
                  <Button size="small" variant="outlined" startIcon={<Copy size={13} />}
                    sx={{ borderColor: '#e2e8f0', color: '#374151', fontSize: '0.8125rem', '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' } }}>
                    Clone
                  </Button>
                </Box>
              </Box>

              {/* Tabs */}
              <Box sx={{ borderBottom: '1px solid #e2e8f0', flexShrink: 0, overflowX: 'auto' }}>
                <Tabs value={activeTab} onChange={(_: React.SyntheticEvent, v: string) => setActiveTab(v)}
                  sx={{
                    minHeight: 42,
                    '& .MuiTab-root': { minHeight: 42, fontSize: '0.8125rem', fontWeight: 500, textTransform: 'none', color: '#64748b', px: 2 },
                    '& .Mui-selected': { color: '#2563eb', fontWeight: 600 },
                    '& .MuiTabs-indicator': { bgcolor: '#2563eb' },
                  }}>
                  {TABS.map((t) => <Tab key={t.id} value={t.id} label={t.label} />)}
                </Tabs>
              </Box>

              {/* Tab Content */}
              <Box sx={{ flex: 1, overflowY: 'auto', p: 2.5 }}>

                {/* VERSIONS TAB */}
                {activeTab === 'versions' && (
                  <Box>
                    <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#1e293b', mb: 2.5 }}>Release Version Lineage</Typography>
                    <Box sx={{ pl: 2, borderLeft: '2px solid #f1f5f9', display: 'flex', flexDirection: 'column', gap: 3 }}>
                      {selectedPackage.versions.map((ver, idx) => (
                        <Box key={ver.version} sx={{ position: 'relative' }}>
                          <Box sx={{
                            position: 'absolute', left: -25, top: 8,
                            width: 10, height: 10, borderRadius: '50%',
                            bgcolor: idx === 0 ? '#3b82f6' : '#cbd5e1',
                            boxShadow: idx === 0 ? '0 0 0 4px #eff6ff' : '0 0 0 4px white',
                          }} />
                          <Box sx={{ p: 2, borderRadius: '10px', border: idx === 0 ? '1px solid #bfdbfe' : '1px solid #e2e8f0', bgcolor: idx === 0 ? 'rgba(239,246,255,0.4)' : 'white', boxShadow: idx === 0 ? '0 1px 4px rgba(37,99,235,0.08)' : 'none' }}>
                            <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1.5}>
                              <Box display="flex" alignItems="center" gap={1.25} flexWrap="wrap">
                                <Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#1e293b', fontFamily: 'monospace' }}>{ver.version}</Typography>
                                <StatusBadge status={ver.status} />
                                <ChannelBadge channel={ver.channel} />
                              </Box>
                              <Typography sx={{ fontSize: '0.72rem', color: '#94a3b8', whiteSpace: 'nowrap', ml: 1 }}>{ver.date}</Typography>
                            </Box>
                            <Typography sx={{ fontSize: '0.8375rem', color: '#475569', mb: 2 }}>{ver.notes}</Typography>
                            <Box display="flex" alignItems="center" gap={1} sx={{ borderTop: '1px solid #f1f5f9', pt: 1.5 }}>
                              {ver.status === 'Draft' && (
                                <Button size="small" variant="contained"
                                  sx={{ bgcolor: '#2563eb', fontSize: '0.75rem', fontWeight: 500, px: 2, boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}>
                                  Submit for Approval
                                </Button>
                              )}
                              {ver.status === 'Released' && (
                                <Button size="small" variant="outlined"
                                  sx={{ borderColor: '#e2e8f0', color: '#374151', fontSize: '0.75rem', px: 2, '&:hover': { borderColor: '#cbd5e1', bgcolor: '#f8fafc' } }}>
                                  Promote to next channel
                                </Button>
                              )}
                              <Button size="small" variant="text" startIcon={<Eye size={12} />}
                                sx={{ ml: 'auto', color: '#64748b', fontSize: '0.75rem', '&:hover': { color: '#1e293b', bgcolor: '#f8fafc' } }}>
                                View Content
                              </Button>
                            </Box>
                          </Box>
                        </Box>
                      ))}
                    </Box>
                  </Box>
                )}

                {/* ASSIGNMENTS TAB */}
                {activeTab === 'assignments' && (
                  <Box>
                    <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2, mb: 3 }}>
                      {[
                        { label: 'Total Assignments', value: selectedPackage.assignments.toString() },
                        { label: 'Servers Governed',  value: selectedPackage.servers.toLocaleString() },
                      ].map(({ label, value }) => (
                        <Box key={label} sx={{ bgcolor: '#f8fafc', p: 2.5, borderRadius: '10px', border: '1px solid #e2e8f0' }}>
                          <Typography sx={{ fontSize: '0.68rem', fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.06em', mb: 0.75 }}>{label}</Typography>
                          <Typography sx={{ fontSize: '1.5rem', fontWeight: 700, color: '#1e293b' }}>{value}</Typography>
                        </Box>
                      ))}
                    </Box>
                    <Typography sx={{ fontSize: '0.875rem', fontWeight: 600, color: '#1e293b', mb: 1.5, pb: 1.5, borderBottom: '1px solid #f1f5f9' }}>
                      Active Assignments Consuming this Package
                    </Typography>
                    <Box sx={{ textAlign: 'center', py: 5, fontSize: '0.875rem', color: '#94a3b8', bgcolor: '#f8fafc', borderRadius: '10px', border: '1px dashed #e2e8f0' }}>
                      {selectedPackage.assignments > 0 ? 'Assignment records would list here.' : 'No assignments are currently using this package.'}
                    </Box>
                  </Box>
                )}

                {/* PLACEHOLDER TABS */}
                {!['versions', 'assignments'].includes(activeTab) && (
                  <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 200, border: '2px dashed #f1f5f9', borderRadius: '12px', bgcolor: 'rgba(248,250,252,0.5)' }}>
                    <Settings size={32} color="#cbd5e1" style={{ marginBottom: 8 }} />
                    <Typography sx={{ fontSize: '0.875rem', color: '#94a3b8' }}>
                      {TABS.find(t => t.id === activeTab)?.label} module
                    </Typography>
                    <Typography sx={{ fontSize: '0.75rem', color: '#cbd5e1', mt: 0.5 }}>Data loads here dynamically.</Typography>
                  </Box>
                )}

              </Box>
            </Box>
          )}

        </Box>
      </Box>

      {/* ── Create Package Modal ── */}
      <Dialog open={createModalOpen} onClose={closeCreateModal} maxWidth="sm" fullWidth
        PaperProps={{ sx: { borderRadius: '16px' } }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', px: 3, pt: 3, pb: 2, borderBottom: '1px solid #f1f5f9' }}>
          <Box>
            <Typography sx={{ fontSize: '1.125rem', fontWeight: 700, color: '#0f172a' }}>Create Release Package</Typography>
            <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', mt: 0.25 }}>Define a new governable unit for deployment.</Typography>
          </Box>
          <IconButton size="small" onClick={closeCreateModal} sx={{ color: '#94a3b8', '&:hover': { bgcolor: '#f1f5f9' }, borderRadius: '8px' }}>
            <X size={16} />
          </IconButton>
        </Box>

        <DialogContent sx={{ px: 3, pt: 2.5, pb: 1 }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
            <Box>
              <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 0.75 }}>
                Package Name <Box component="span" sx={{ color: '#ef4444' }}>*</Box>
              </Typography>
              <TextField fullWidth size="small" placeholder="e.g., Ubuntu 22.04 Hardening"
                value={newName} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewName(e.target.value)}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px', fontSize: '0.875rem', '& fieldset': { borderColor: '#e2e8f0' }, '&.Mui-focused fieldset': { borderColor: '#2563eb' } } }}
              />
            </Box>

            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
              <Box>
                <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 0.75 }}>
                  Package Type <Box component="span" sx={{ color: '#ef4444' }}>*</Box>
                </Typography>
                <FormControl fullWidth size="small">
                  <Select value={newType} onChange={(e: { target: { value: string } }) => setNewType(e.target.value)}
                    sx={{ borderRadius: '8px', fontSize: '0.875rem', '& fieldset': { borderColor: '#e2e8f0' } }}>
                    {['OS Configuration','Container Security','Application Config','Network Policy'].map((t) => (
                      <MenuItem key={t} value={t} sx={{ fontSize: '0.875rem' }}>{t}</MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Box>
              <Box>
                <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 0.75 }}>Owner</Typography>
                <TextField fullWidth size="small" value="Current User" inputProps={{ readOnly: true }}
                  sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px', fontSize: '0.875rem', bgcolor: '#f8fafc', '& fieldset': { borderColor: '#e2e8f0' } } }}
                />
              </Box>
            </Box>

            <Box>
              <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 0.75 }}>Target Initial Channel</Typography>
              <FormControl fullWidth size="small">
                <Select value={newChannel} onChange={(e: { target: { value: string } }) => setNewChannel(e.target.value)}
                  sx={{ borderRadius: '8px', fontSize: '0.875rem', '& fieldset': { borderColor: '#e2e8f0' } }}>
                  <MenuItem value="Development" sx={{ fontSize: '0.875rem' }}>Development (Drafts allowed)</MenuItem>
                  <MenuItem value="Testing"     sx={{ fontSize: '0.875rem' }}>Testing</MenuItem>
                  <MenuItem value="QA"          sx={{ fontSize: '0.875rem' }}>QA</MenuItem>
                </Select>
              </FormControl>
            </Box>

            <Box>
              <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151', mb: 0.75 }}>Description</Typography>
              <TextField fullWidth multiline rows={3} placeholder="Describe the purpose and scope of this package..."
                value={newDesc} onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewDesc(e.target.value)}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px', fontSize: '0.875rem', '& fieldset': { borderColor: '#e2e8f0' }, '&.Mui-focused fieldset': { borderColor: '#2563eb' } } }}
              />
            </Box>
          </Box>
        </DialogContent>

        <DialogActions sx={{ px: 3, pb: 3, pt: 2, gap: 1.5, bgcolor: '#f8fafc', borderTop: '1px solid #f1f5f9' }}>
          <Button variant="outlined" onClick={closeCreateModal}
            sx={{ borderColor: '#e2e8f0', color: '#475569', px: 3, borderRadius: '8px', textTransform: 'none', fontWeight: 500, '&:hover': { borderColor: '#cbd5e1' } }}>
            Cancel
          </Button>
          <Button variant="contained" disabled={!newName.trim()} onClick={handleCreateSubmit}
            startIcon={<Plus size={14} />}
            sx={{ bgcolor: '#2563eb', px: 3, borderRadius: '8px', textTransform: 'none', fontWeight: 600, boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' }, '&.Mui-disabled': { bgcolor: '#bfdbfe', color: 'white' } }}>
            Create & Initialize
          </Button>
        </DialogActions>
      </Dialog>

    </Box>
  )
}

export default ReleasePackagePage
