import React, { useMemo, useState, useEffect, useRef, useCallback } from 'react'
import {
  Box, Button, Grid, IconButton, Paper, Skeleton, Tooltip, Typography,
} from '@mui/material'
import { FileText, Plus, RefreshCw } from 'lucide-react'
import { useHistory } from 'react-router-dom'
import { useGetAssignmentsQuery } from '../../redux/slices/assignmentsSlice'
import { POLICYOPS_PATH } from '../../utils/constant'
import PolicyCard from '../policies/components/PolicyCard'
import SearchFilterBar from '../../components/SearchFilterBar'
import ListFilterPopover, { FilterFieldConfig } from '../../components/ListFilterPopover'
import AppliedFilterTags from '../../components/AppliedFilterTags'

import CardGridShimmer from '../../components/CardGridShimmer'
import { useDebouncedValue } from '../../components/useDebouncedValue'
import '../policies/policies.scss'
import { Policy, RuleSeverity, PolicyStatus } from '../../utils/enums'

type AssignmentLikePolicy = Policy & {
  assignmentMeta?: {
    executionConfig?: any
    scheduleConfig?: any
    excludeExecutionWindowConfig?: any
    policyMode?: string
    priority?: string
    assignmentType?: string
    targetType?: string
    serverGroupCount?: number
  }
}

const mapAssignmentToPolicy = (assignment: AssignmentCardData): AssignmentLikePolicy => {
  return {
    _id: assignment.id,
    policy_id: assignment.id,
    name: assignment.name,
    description: assignment.description ?? '',

    status: assignment.status as PolicyStatus,

    environment: 'Production',
    owner: 'System',

    rules: (assignment.policies || []).map((p, i) => ({
      id: p.policyId,
      rule_id: p.policyId,
      name: p.name,
      description: '',
      severity: RuleSeverity.MEDIUM,
      rule_version: Number(p.versionNumber?.split('.')[0]) || 1,
      order: p.sequenceNumber || i + 1,
    })),

    created_by: assignment.createdBy ?? 'system',
    created_at: assignment.createdAt ?? '',
    updated_at: assignment.updatedAt ?? assignment.createdAt ?? '',
    updated_by: assignment.updatedBy,

    version: 1,

    systems_protected: assignment.config_count ?? assignment.configCount ?? assignment.targets?.length ?? 0,
    compliance_coverage: 85 + Math.random() * 15,
    compliance_impact: 'Medium',
    risk_reduction: 50,

    assignments: 1,
    servers: assignment.targets?.map(t => t.hostname) ?? [],
    tags: assignment.tags ?? [],

    assignmentMeta: {
      executionConfig: assignment.executionConfig,
      scheduleConfig: assignment.scheduleConfig,
      excludeExecutionWindowConfig: assignment.excludeExecutionWindowConfig,
      policyMode: assignment.policyMode,
      priority: assignment.priority,
      assignmentType: assignment.assignmentType,
      targetType: assignment.targetType,
      serverGroupCount: assignment.serverGroupCount ?? assignment.serverGroups?.length ?? 0,
    },

    executionInfo: {
      executionMode: assignment.executionConfig?.executionMode || '—',
      failureHandling: assignment.executionConfig?.failureHandling || '—',
    }
  }
}

interface ApiTarget {
  hostname: string
}

interface ApiPolicy {
  policyId: string
  name: string
  sequenceNumber: number
  versionNumber: string
}

interface AssignmentCardData {
  excludeExecutionWindowConfig: any
  scheduleConfig: any
  executionConfig: any
  id: string
  name: string
  description?: string
  versionNumber?: string
  assignmentType?: string
  priority?: string
  policyMode?: string
  policies?: ApiPolicy[]
  policyCount?: number
  targets?: ApiTarget[]
  config_count?: number
  configCount?: number
  serverGroups?: { id?: string; name?: string; serverCount?: number }[]
  serverGroupCount?: number
  targetType?: string
  tags?: string[]
  status: string
  isActive?: boolean
  createdAt?: string
  updatedAt?: string
  createdBy?: string
  updatedBy?: string
}

const getAssignmentRouteId = (assignment: AssignmentCardData): string => assignment.id || ''

const ASSIGNMENT_FILTER_FIELDS: FilterFieldConfig[] = [
  {
    key: 'priority',
    label: 'Priority',
    type: 'select',
    options: [
      { value: 'CRITICAL', label: 'Critical' },
      { value: 'HIGH', label: 'High' },
      { value: 'MEDIUM', label: 'Medium' },
      { value: 'LOW', label: 'Low' },
    ],
  },
  {
    key: 'assignment_type',
    label: 'Assignment Type',
    type: 'select',
    options: [
      { value: 'POLICY', label: 'Policy' },
    ],
  },
  {
    key: 'status',
    label: 'Status',
    type: 'radio',
    options: [
      { value: 'ACTIVE', label: 'Active' },
      { value: 'INACTIVE', label: 'Inactive' },
      { value: 'DRAFT', label: 'Draft' },
    ],
  },
]

export interface AssignmentFilters {
  status: string
  priority: string
  assignment_type: string
  [key: string]: string
}

const EMPTY_ASSIGNMENT_FILTERS: AssignmentFilters = {
  status: '',
  priority: '',
  assignment_type: '',
}

const STATUS_STYLE: Record<string, { bg: string; color: string; label: string }> = {
  ACTIVE: { bg: '#dcfce7', color: '#15803d', label: 'Active' },
  INACTIVE: { bg: '#f1f5f9', color: '#64748b', label: 'Inactive' },
  DRAFT: { bg: '#f1f5f9', color: '#64748b', label: 'Draft' },
  ARCHIVED: { bg: '#fef9c3', color: '#a16207', label: 'Archived' },
}

const PRIORITY_COLOR: Record<string, string> = {
  CRITICAL: '#ef4444',
  HIGH: '#f97316',
  MEDIUM: '#2563eb',
  LOW: '#64748b',
}

interface StatCardProps {
  label: string
  value: string | number
}

const StatCard: React.FC<StatCardProps> = ({ label, value }) => (
  <Paper
    elevation={0}
    sx={{
      background: '#fff',
      border: '1px solid #f1f5f9',
      borderRadius: '24px',
      p: '20px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      minWidth: 0,
      height: '100%',
      boxShadow: '0px 4px 12px 0px rgba(213, 213, 213, 0.16)',
    }}
  >
    <Typography
      sx={{
        fontSize: '0.78rem !important',
        color: '#94a3b8 !important',
        fontWeight: 400 ,
        marginBottom: '2px !important',
        fontFamily: '"JohnsonDisplay"',
      }}
    >
      {label}
    </Typography>

    <Typography
      sx={{
        fontSize: '16px !important',
        fontWeight: '700 !important',
        color: '#0f172a !important',
        lineHeight: '1.2 !important',
      }}
    >
      {value}
    </Typography>
  </Paper>
)

interface AssignmentCardProps {
  assignment: AssignmentCardData
  onClick: () => void
}

const AssignmentCard: React.FC<AssignmentCardProps> = ({ assignment, onClick }) => {
  const status = STATUS_STYLE[assignment.status] ?? { bg: '#f1f5f9', color: '#64748b', label: assignment.status }
  const targetCount = assignment.config_count ?? assignment.configCount ?? assignment.targets?.length ?? 0
  const serverGroupCount = assignment.serverGroupCount ?? assignment.serverGroups?.length ?? 0
  const hasServerGroups = serverGroupCount > 0
  const firstPolicy = assignment.policies?.[0]

  return (
    <Paper
      elevation={0}
      onClick={onClick}
      sx={{
        p: 2.5,
        borderRadius: '10px',
        border: '1px solid #e2e8f0',
        bgcolor: 'white',
        boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
        cursor: 'pointer',
        transition: 'all 0.15s',
        '&:hover': { borderColor: '#93c5fd', boxShadow: '0 4px 12px rgba(37,99,235,0.08)' },
      }}
    >
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={2}>
        <Typography variant="subtitle2" fontWeight={700} color="#0f172a" sx={{ pr: 1 }}>{assignment.name}</Typography>
        <Box sx={{ px: 1.25, py: 0.35, borderRadius: '999px', bgcolor: status.bg, color: status.color, fontSize: '0.72rem', fontWeight: 600, whiteSpace: 'nowrap', flexShrink: 0 }}>
          {status.label}
        </Box>
      </Box>

      {firstPolicy && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, bgcolor: '#f8fafc', borderRadius: '8px', px: 1.5, py: 1, mb: 2.5 }}>
          <FileText size={16} color="#2563eb" />
          <Typography variant="body2" color="#64748b" noWrap>{firstPolicy.name}</Typography>
        </Box>
      )}

      <Grid container spacing={2} mb={2.5}>
        <Grid item xs={6}>
          <Typography variant="caption" color="text.secondary" display="block" mb={0.25}>Priority</Typography>
          <Typography variant="body2" fontWeight={700} color={PRIORITY_COLOR[assignment.priority ?? ''] ?? '#64748b'}>
            {assignment.priority || '—'}
          </Typography>
        </Grid>
        <Grid item xs={6}>
          <Typography variant="caption" color="text.secondary" display="block" mb={0.25}>
            {hasServerGroups ? 'Target Groups' : 'Targets'}
          </Typography>
          <Typography variant="body2" fontWeight={700} color="#0f172a">
            {hasServerGroups ? serverGroupCount : targetCount}
          </Typography>
        </Grid>
        <Grid item xs={6}>
          <Typography variant="caption" color="text.secondary" display="block" mb={0.25}>Target Scope</Typography>
          <Typography variant="body2" fontWeight={600} color="#0f172a">
            {assignment.targetType === 'global' ? 'Global' : assignment.targetType === 'serverGroup' ? 'Target Group' : 'Local'}
          </Typography>
        </Grid>
        <Grid item xs={6}>
          <Typography variant="caption" color="text.secondary" display="block" mb={0.25}>Policies</Typography>
          <Typography variant="body2" fontWeight={700} color="#0f172a">{assignment.policyCount ?? assignment.policies?.length ?? 0}</Typography>
        </Grid>
      </Grid>

      <Typography variant="caption" color="text.secondary">{assignment.policyMode || '—'}</Typography>
    </Paper>
  )
}

const ShimmerCard: React.FC = () => (
  <Box
    className="ps-policy-card"
    sx={{ p: 2, borderRadius: '12px', border: '1px solid #eef2f7', bgcolor: '#fff', minHeight: 200 }}
  >
    <Box display="flex" justifyContent="space-between" alignItems="center" mb={1.5}>
      <Skeleton variant="rounded" width={70} height={20} />
      <Skeleton variant="circular" width={20} height={20} />
    </Box>
    <Skeleton variant="text" width="70%" height={26} />
    <Box display="flex" justifyContent="space-between" mt={2} mb={1.5}>
      <Skeleton variant="text" width="30%" />
      <Skeleton variant="text" width="20%" />
    </Box>
    <Skeleton variant="rounded" width="100%" height={28} sx={{ mb: 2 }} />
    <Box display="flex" justifyContent="space-between" alignItems="center">
      <Skeleton variant="circular" width={28} height={28} />
      <Skeleton variant="text" width="30%" />
    </Box>
  </Box>
)

const AssignmentsPage: React.FC = () => {
  const history = useHistory()
  const PAGE_SIZE = 20

  const [search, setSearch] = useState('')
  const debouncedSearch = useDebouncedValue(search, 400)
  const [filterAnchor, setFilterAnchor] = useState<HTMLElement | null>(null)
  const [appliedFilters, setAppliedFilters] = useState<AssignmentFilters>(EMPTY_ASSIGNMENT_FILTERS)
  const [draftFilters, setDraftFilters] = useState<AssignmentFilters>(EMPTY_ASSIGNMENT_FILTERS)
  const [page, setPage] = useState(1)
  const [allAssignments, setAllAssignments] = useState<AssignmentCardData[]>([])
  const [knownTotal, setKnownTotal] = useState(0)

  const scrollContainerRef = useRef<HTMLDivElement | null>(null)
  const observerRef = useRef<HTMLDivElement | null>(null)
  const loadingMoreRef = useRef(false)
  const isFetchingRef = useRef(false)
  const hasMoreRef = useRef(false)
  const skipFilterResetRef = useRef(true)
  const pageRef = useRef(page)
  const prevLengthRef = useRef(0)

  const { data, isLoading, isFetching, refetch } = useGetAssignmentsQuery({
    page,
    limit: PAGE_SIZE,
    search: debouncedSearch.trim() || undefined,
    status: appliedFilters.status || undefined,
    priority: appliedFilters.priority || undefined,
    assignment_type: appliedFilters.assignment_type || undefined,
  }, { refetchOnMountOrArgChange: true })

  const handleRefresh = useCallback(() => {
    setPage(1)
    setAllAssignments([])
    refetch()
  }, [refetch])

  useEffect(() => {
    pageRef.current = page
  }, [page])

  useEffect(() => {
    if (typeof data?.total === 'number') setKnownTotal(data.total)
  }, [data?.total])

  useEffect(() => {
    if (!data?.data) return

    setAllAssignments((prev) => {
      if (pageRef.current === 1) return data.data

      const seen = new Set(prev.map((assignment) => assignment.id))
      const newItems = data.data.filter((item: AssignmentCardData) => !seen.has(item.id))

      return newItems.length ? [...prev, ...newItems] : prev
    })
  }, [data])

  useEffect(() => {
    if (allAssignments.length > prevLengthRef.current) {
      loadingMoreRef.current = false
    }
    prevLengthRef.current = allAssignments.length
  }, [allAssignments.length])

  useEffect(() => {
    if (skipFilterResetRef.current) {
      skipFilterResetRef.current = false
      return
    }

    setPage(1)
    setAllAssignments([])
    setKnownTotal(0)
  }, [debouncedSearch, appliedFilters])

  const sourceItems = allAssignments.length > 0
    ? allAssignments
    : page === 1
      ? data?.data ?? []
      : []

  const assignments: AssignmentCardData[] = sourceItems
  const hasMore = knownTotal > 0
    ? allAssignments.length < knownTotal
    : (data?.data?.length ?? 0) >= PAGE_SIZE
  const initialLoading = (isLoading || isFetching) && page === 1
  const loadingMore = isFetching && page > 1

  useEffect(() => {
    isFetchingRef.current = isFetching
    if (!isFetching) loadingMoreRef.current = false
  }, [isFetching])

  useEffect(() => {
    hasMoreRef.current = hasMore
  }, [hasMore])

  const loadNextPage = useCallback(() => {
    if (!hasMoreRef.current || loadingMoreRef.current || isFetchingRef.current) return
    loadingMoreRef.current = true
    setPage((prev) => prev + 1)
  }, [])

  const checkAndLoadMore = useCallback(() => {
    const node = observerRef.current
    const root = scrollContainerRef.current
    if (!node || !root || !hasMoreRef.current || loadingMoreRef.current || isFetchingRef.current) return

    const rootRect = root.getBoundingClientRect()
    const nodeRect = node.getBoundingClientRect()
    if (nodeRect.top <= rootRect.bottom + 200) {
      loadNextPage()
    }
  }, [loadNextPage])

  useEffect(() => {
    const node = observerRef.current
    const root = scrollContainerRef.current
    if (!node || !hasMore) return

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          loadNextPage()
        }
      },
      { root: root ?? null, rootMargin: '200px', threshold: 0 },
    )

    observer.observe(node)
    return () => observer.disconnect()
  }, [hasMore, loadNextPage, allAssignments.length])

  useEffect(() => {
    if (initialLoading || isFetching) return
    checkAndLoadMore()
  }, [allAssignments.length, hasMore, initialLoading, isFetching, checkAndLoadMore])

  useEffect(() => {
    const container = scrollContainerRef.current
    if (!container) return
    container.addEventListener('scroll', checkAndLoadMore, { passive: true })
    return () => container.removeEventListener('scroll', checkAndLoadMore)
  }, [checkAndLoadMore])

  useEffect(() => {
    const handleVisible = () => {
      if (document.visibilityState === 'visible') {
        requestAnimationFrame(checkAndLoadMore)
      }
    }

    document.addEventListener('visibilitychange', handleVisible)
    window.addEventListener('focus', handleVisible)
    requestAnimationFrame(checkAndLoadMore)

    return () => {
      document.removeEventListener('visibilitychange', handleVisible)
      window.removeEventListener('focus', handleVisible)
    }
  }, [checkAndLoadMore])

  const hasActiveFilters = Boolean(
    appliedFilters.status
    || appliedFilters.priority
    || appliedFilters.assignment_type,
  )

  const appliedFilterTags = useMemo(() => {
    const tags: { key: string; label: string }[] = []
    if (appliedFilters.status) {
      tags.push({ key: 'status', label: `Status: ${appliedFilters.status}` })
    }
    if (appliedFilters.priority) {
      tags.push({ key: 'priority', label: `Priority: ${appliedFilters.priority}` })
    }
    if (appliedFilters.assignment_type) {
      tags.push({ key: 'assignment_type', label: `Assignment Type: ${appliedFilters.assignment_type}` })
    }
    return tags
  }, [appliedFilters])

  const openFilterPopover = (anchor: HTMLElement) => {
    setDraftFilters(appliedFilters)
    setFilterAnchor(anchor)
  }

  const applyFilters = () => {
    setAppliedFilters(draftFilters)
    setFilterAnchor(null)
    setPage(1)
    setAllAssignments([])
    setKnownTotal(0)
  }

  const clearDraftFilters = () => {
    setDraftFilters(EMPTY_ASSIGNMENT_FILTERS)
    setAppliedFilters(EMPTY_ASSIGNMENT_FILTERS)
    setFilterAnchor(null)
    setPage(1)
    setAllAssignments([])
    setKnownTotal(0)
  }

  const clearAllAppliedFilters = () => {
    setAppliedFilters(EMPTY_ASSIGNMENT_FILTERS)
    setDraftFilters(EMPTY_ASSIGNMENT_FILTERS)
    setPage(1)
    setAllAssignments([])
    setKnownTotal(0)
  }

  const removeAppliedFilter = (key: string) => {
    setAppliedFilters((prev) => ({ ...prev, [key]: '' }))
    setPage(1)
    setAllAssignments([])
    setKnownTotal(0)
  }

  const handleDraftChange = (key: string, value: string) => {
    setDraftFilters((prev) => ({ ...prev, [key]: value }))
  }

  const totalServers = typeof data?.config_count === 'number'
    ? data.config_count
    : assignments.reduce(
      (sum, a) => sum + (a.config_count ?? a.configCount ?? a.targets?.length ?? 0),
      0,
    )
  const activeCount = assignments.filter((a) => a.status === 'ACTIVE').length
  const pendingApproval = assignments.filter((a) => a.status !== 'ACTIVE').length

  return (
    <Box
      sx={{
        p: 3,
        bgcolor: '#FBFCFF',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        boxSizing: 'border-box',
      }}
    >
      <Box sx={{ flexShrink: 0 }}>
        <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={0.5}>
          <Typography variant="h5" fontWeight={700} color="#0f172a">
            Assignment Center
          </Typography>
          <Button
            variant="contained"
            endIcon={<Plus size={16} />}
            onClick={() => history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/new`)}
            sx={{
              bgcolor: "#2563eb",
              textTransform: "none",
              fontWeight: 500,
              borderRadius: "100px",
              px: 2.5,
              boxShadow: "none",
              "&:hover": { bgcolor: "#1d4ed8", boxShadow: "none" },
            }}
          >
            New Assignment
          </Button>
        </Box>

        <Typography variant="body2" color="text.secondary" mb={3}>
          Deploy and manage policies across global, environment, region or Target Group scopes
        </Typography>

        <Grid container  spacing={2} mb="12px" >
          <Grid item xs={6} sm={3}>
            <StatCard label="Total Assignments" value={knownTotal || assignments.length} />
          </Grid>
          <Grid item xs={6} sm={3}>
            <StatCard label="Assigned Targets" value={totalServers} />
          </Grid>
          <Grid item xs={6} sm={3}>
            <StatCard label="Active" value={activeCount} />
          </Grid>
          <Grid item xs={6} sm={3}>
            <StatCard label="Inactive / Draft" value={pendingApproval} />
          </Grid>
        </Grid>

        <Box display="flex" justifyContent="space-between" alignItems="center" mb="10px" flexWrap="wrap" gap={2}>
          <Box display="flex" alignItems="center" gap={1}>
            <Typography variant="subtitle1" fontWeight={600} color="#0f172a">
              Active Assignments
            </Typography>
            {/* <Box sx={{ px: 1, py: 0.2, bgcolor: '#dbeafe', borderRadius: '999px', minWidth: 28, textAlign: 'center' }}>
              <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: '#2563eb' }}>
                {String(knownTotal || assignments.length).padStart(2, '0')}
              </Typography>
            </Box> */}
          </Box>
          <Box display="flex" alignItems="center" gap={1.5} flexWrap="wrap">
            <Tooltip title="Refresh" arrow>
              <IconButton
                size="small"
                onClick={handleRefresh}
                disabled={isLoading || isFetching}
                sx={{
                  bgcolor: 'white',
                  border: '1px solid #e2e8f0',
                  borderRadius: '999px',
                  '&:hover': { bgcolor: '#f8fafc' },
                }}
              >
                <RefreshCw size={15} color="#64748b" />
              </IconButton>
            </Tooltip>
            <SearchFilterBar
              search={search}
              onSearchChange={setSearch}
              searchPlaceholder="Search by assignment name"
              onFilterClick={(e: React.MouseEvent<HTMLElement>) => openFilterPopover(e.currentTarget)}
              hasActiveFilters={hasActiveFilters}
            />
          </Box>
        </Box>

        <AppliedFilterTags
          tags={appliedFilterTags}
          onRemove={removeAppliedFilter}
          onClearAll={clearAllAppliedFilters}
        />

        <ListFilterPopover
          open={Boolean(filterAnchor)}
          anchorEl={filterAnchor}
          onClose={() => setFilterAnchor(null)}
          fields={ASSIGNMENT_FILTER_FIELDS}
          draftValues={draftFilters}
          onDraftChange={handleDraftChange}
          onApply={applyFilters}
          onClear={clearDraftFilters}
        />
      </Box>

      <Box
        ref={scrollContainerRef}
        sx={{
          flex: 1,
          minHeight: 0,
          overflowY: 'auto',
          pr: 0.5,
        }}
      >
        {initialLoading ? (
          <CardGridShimmer count={6} layout="mui-grid" />
        ) : !assignments.length ? (
          <Paper elevation={0} sx={{ p: 3, borderRadius: '10px', border: '1px dashed #cbd5e1', bgcolor: 'white' }}>
            <Typography variant="body2" color="text.secondary">
              No assignments found.
            </Typography>
          </Paper>
        ) : (
          <>
            <div className="ps-grid">
              {assignments.map((assignment) => (
                  <PolicyCard
                    policy={mapAssignmentToPolicy(assignment)}
                    type="assignment"
                    onView={() => {
                      history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/${assignment.id}/edit`)
                    }}
                    onClick={() => {
                      history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/${assignment.id}/edit`)
                    }}
                    onDeleteSuccess={() => {
                      setPage(1)
                      setAllAssignments([])
                      setKnownTotal(0)
                    }}
                  />
              ))}
              {loadingMore
                && Array.from({ length: 3 }).map((_, i) => (
                  <ShimmerCard key={`assignment-shimmer-${i}`} />
                ))}
            </div>
            <div ref={observerRef} style={{ height: 40, marginTop: 8, width: '100%', gridColumn: '1 / -1' }} />
          </>
        )}
      </Box>
    </Box>
  )
}

export default AssignmentsPage
