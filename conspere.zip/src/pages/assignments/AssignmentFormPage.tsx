import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react'
import {
  Alert,
  Box,
  Button,
  Checkbox,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  FormControl,
  Grid,
  IconButton,
  InputAdornment,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  SelectChangeEvent,
  Step,
  StepButton,
  StepConnector,
  StepLabel,
  Stepper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
  Stack,
  Tooltip,
} from '@mui/material'
import { styled } from '@mui/material/styles'
import { stepConnectorClasses } from '@mui/material/StepConnector'
import {
  AlertCircle, ArrowDown, ArrowLeft, Bell, CheckCircle2, ChevronDown, Clock,
  FileText, GripVertical, Pencil, Plus, Rocket, RotateCcw, Search, Shield, X,
} from 'lucide-react'
import { useHistory, useParams, useLocation } from 'react-router-dom'
import { toast } from 'react-toastify'
import {
  useGetAssignmentByIdQuery,
  useCreateAssignmentMutation,
  useUpdateAssignmentMutation,
} from '../../redux/slices/assignmentsSlice'
import { useGetPoliciesQuery } from '../../redux/slices/policiesSlice'
import {
  useGetTargetServersMetadataQuery,
  useGetTargetServersQuery,
} from '../../redux/slices/targetServersSlice'
import { useGetServerGroupsQuery } from '../../redux/slices/serverGroupsSlice'
import { POLICYOPS_PATH } from '../../utils/constant'
import FormToggleRow from '../../components/FormToggleRow'
import { useDebouncedValue } from '../../components/useDebouncedValue'
import ScmTab from '../../components/ScmTab'

import {
  DndContext,
  closestCenter,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core'

import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
  arrayMove,
} from '@dnd-kit/sortable'

import { CSS } from '@dnd-kit/utilities'

import blueStepper from '../../assets/policyStepper/policy1ststepper.svg'
import completedStepper from '../../assets/policyStepper/completedStepper.svg'
import defaultStepper from '../../assets/policyStepper/defaultStepper.svg'
import { showErrorToast, showSuccessToast } from '../../utils/toastHelper'


const SortableSelectedPolicy: React.FC<{
  policy: PolicyItem
  index: number
  onRemove: (id: string) => void
}> = ({ policy, index, onRemove }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: String(policy.id) })

  return (
    <Box
      ref={setNodeRef}
      style={{
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.5 : 1,
      }}
      sx={{
        display: 'flex',
        alignItems: 'center',
        gap: "20px",
        padding: "16px",
        bgcolor: '#FFFFFF',
        border: '1px solid',
        borderColor: isDragging ? '#93c5fd' : '#F2F2F2',
        borderRadius: "16px",
      }}
    >
      {/* Drag handle */}

      <Box
        {...attributes}
        {...listeners}
        sx={{
          cursor: 'grab',
          color: '#cbd5e1',
          display: 'flex',
          flexShrink: 0,
          touchAction: 'none',
        }}
      >
        <GripVertical size={15} />
      </Box>


      {/* Order */}
      <Typography
        sx={{
          fontSize: '0.7rem',
          fontWeight: 700,
          color: '#94a3b8',
          width: 20,
          textAlign: 'center',
        }}
      >
        {String(index + 1).padStart(2, '0')}
      </Typography>

      {/* Icon */}
      <PolicyIconBubble label={policy.name} />

      {/* Info */}
      <Box flex={1} minWidth={0}>
        <Typography fontSize="0.8rem" fontWeight={600} noWrap>
          {policy.name}
        </Typography>

        <Typography fontSize="0.7rem" color="#94a3b8" noWrap>
          Version: {policy.versionNumber ?? '1.0.0'}
        </Typography>
      </Box>

      {/* Remove */}
      <IconButton
        size="small"
        onClick={() => onRemove(policy.id)}
        sx={{ color: '#cbd5e1', '&:hover': { color: '#ef4444' } }}
      >
        <X size={14} />
      </IconButton>
    </Box>
  )
}

const PolicyIconBubble: React.FC<{ label?: string }> = ({ label = 'P' }) => (
  <Box
    sx={{
      width: 28,
      height: 28,
      borderRadius: '50%',
      background: 'linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%)',
      border: '1.5px solid #7dd3fc',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0,
    }}
  >
    <Typography sx={{ fontSize: '0.6rem', fontWeight: 700, color: '#0369a1' }}>
      {label.slice(0, 1).toUpperCase()}
    </Typography>
  </Box>
)

const STEPS = ['Basic Info', 'Policy Selection', 'Target Selection', 'Deployment Strategy', 'Summary']

const AssignmentStepConnector = styled(StepConnector)(() => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 20,
    left: 'calc(-50% + 20px)',
    right: 'calc(50% + 20px)',
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 2,
    border: 0,
    backgroundColor: '#e2e8f0',
    borderRadius: 1,
  },
  [`&.${stepConnectorClasses.active} .${stepConnectorClasses.line}`]: {
    backgroundColor: '#2563eb',
  },
  [`&.${stepConnectorClasses.completed} .${stepConnectorClasses.line}`]: {
    backgroundColor: '#22c55e',
  },
}))

const FORM_FIELD_SX = {
  '& .MuiOutlinedInput-root': {
    borderRadius: '10px',
    bgcolor: '#ffffff',
    fontSize: '0.875rem',
    '& fieldset': { borderColor: '#e2e8f0' },
    '&:hover fieldset': { borderColor: '#cbd5e1' },
    '&.Mui-focused fieldset': { borderColor: '#2563eb', borderWidth: '1px' },
  },
  '& .MuiInputLabel-root': { color: '#64748b', fontSize: '0.875rem' },
  '& .MuiInputLabel-root.Mui-focused': { color: '#2563eb' },
}

const CARD_SX = {
  borderRadius: '8px',
  border: '1px solid #e2e8f0',
  bgcolor: 'white',
  p: 3.5,
  height: '100%',
  overflow: 'auto',
}

const ASSIGNMENT_TYPES = ['Policy']
const PRIORITIES = ['Critical', 'High', 'Medium', 'Low']
const EXECUTION_MODES = ['Enforce', 'Dry-Run']
type ExecutionMode = (typeof EXECUTION_MODES)[number]

const formatPriorityFromApi = (value?: string): string => {
  if (!value) return 'Critical'
  const normalized = value.trim().toUpperCase()
  return PRIORITIES.find((priority) => priority.toUpperCase() === normalized) ?? 'Critical'
}
const POLICY_SELECTION_MODES = ['Single Policy', 'Multiple Policies']
const TARGET_TYPES = ['Server']
const SCHEDULE_TYPES = ['Hourly', 'Daily', 'Weekly', 'Monthly', 'Minutes', 'Cron']
const TIMEZONES = ['UTC', 'EST', 'PST', 'CET', 'IST']
const MINUTE_OPTIONS = Array.from({ length: 60 }, (_, index) => index + 1)

const EMPTY_TARGET_FILTERS = {
  region: '',
  os: '',
  sid: '',
  owner: '',
  application: '',
  environment: '',
}
interface TargetServerMetadata {
  region: string[]
  os: string[]
  sid: string[]
  owner: string[]
  application: string[]
  environment: string[]
}

interface TargetServerItem {
  hostname: string
  environment: string
  region: string
  service: string
  sid: string
  application: string
  businessService: string
  owner: string
  serverType: string
  os: string
  status: string
  createdDate?: string
  lastUpdated?: string
}

interface PolicyItem {
  id: string
  policyId?: string
  name: string
  versionNumber?: string
  env: string
  envBg: string
  envColor: string
  rules: number
  status: string
}

type FieldErrors = Record<string, string>

type TargetMode = 'global' | 'serverGroup' | 'local'

const TARGET_MODE_LABEL: Record<TargetMode, string> = {
  global: 'Global',
  serverGroup: 'Target Group',
  local: 'Local',
}

type AssignmentFormSnapshot = {
  name: string
  assignmentType: string
  priority: string
  executionMode: ExecutionMode
  description: string
  tags: string[]
  selectedPolicyIds: string[]
  targetMode: TargetMode
  selectedServerGroupIds: string[]
  selectedTargetHosts: string[]
  deploymentStrategy: string
  scheduleType: string
  scheduleMinutes: string
  cronExpression: string
  timezone: string
  startDate: string
  endDate: string
  exclusionEnabled: boolean
  excludedFromTime: string
  excludedToTime: string
}

const EMPTY_ASSIGNMENT_SNAPSHOT: AssignmentFormSnapshot = {
  name: '',
  assignmentType: '',
  priority: '',
  executionMode: '',
  description: '',
  tags: [],
  selectedPolicyIds: [],
  targetMode: 'local',
  selectedServerGroupIds: [],
  selectedTargetHosts: [],
  deploymentStrategy: 'immediate',
  scheduleType: 'Manual',
  scheduleMinutes: '1',
  cronExpression: '',
  timezone: 'UTC',
  startDate: '',
  endDate: '',
  exclusionEnabled: false,
  excludedFromTime: '',
  excludedToTime: '',
}

type PendingNavigation =
  | { type: 'step'; step: number }
  | { type: 'leave'; action: 'push' | 'goBack'; path?: string }

const resolveTargetModeFromApi = (a: Record<string, unknown>): TargetMode => {
  const t = String(a.targetType ?? '').toLowerCase()
  if (t === 'global') return 'global'
  if (t === 'servergroup') return 'serverGroup'
  if (a.isGlobal) return 'global'
  if (Array.isArray(a.serverGroups) && (a.serverGroups as any[]).length > 0) return 'serverGroup'
  return 'local'
}

const buildSnapshotFromAssignment = (a: Record<string, unknown>): AssignmentFormSnapshot => {
  const targetMode = resolveTargetModeFromApi(a)
  return {
    name: String(a.name ?? ''),
    assignmentType: 'Policy',
    priority: formatPriorityFromApi(a.priority as string),
    executionMode: a.executionMode === 'Dry-Run' ? 'Dry-Run' : 'Enforce',
    description: String(a.description ?? ''),
    tags: [...(Array.isArray(a.tags) ? a.tags : [])].map(String).sort(),
    selectedPolicyIds: (Array.isArray(a.policies) ? a.policies : [])
      .map((p: { policyId?: string }) => String(p.policyId ?? ''))
      .filter(Boolean)
      .sort(),
    targetMode,
    selectedServerGroupIds: (Array.isArray(a.serverGroups) ? a.serverGroups : [])
      .map((g: { id?: string; _id?: string }) => String(g.id ?? g._id ?? ''))
      .filter(Boolean)
      .sort(),
    selectedTargetHosts: targetMode === 'local'
      ? (Array.isArray(a.targets) ? a.targets : [])
        .map((t: { hostname?: string }) => String(t.hostname ?? ''))
        .filter(Boolean)
        .sort()
      : [],
    deploymentStrategy: String(a.deploymentStrategy ?? 'immediate'),
    scheduleType: String((a.scheduleConfig as { scheduleType?: string })?.scheduleType ?? 'Manual'),
    scheduleMinutes: (a.scheduleConfig as { minutes?: number })?.minutes != null
      ? String((a.scheduleConfig as { minutes?: number }).minutes)
      : '1',
    cronExpression: String((a.scheduleConfig as { cronExpression?: string })?.cronExpression ?? ''),
    timezone: String((a.scheduleConfig as { timezone?: string })?.timezone ?? 'UTC'),
    startDate: String((a.scheduleConfig as { startDate?: string })?.startDate ?? ''),
    endDate: String((a.scheduleConfig as { endDate?: string })?.endDate ?? ''),
    exclusionEnabled: Boolean((a.excludeExecutionWindowConfig as { enabled?: boolean })?.enabled),
    excludedFromTime: String((a.excludeExecutionWindowConfig as { fromTime?: string })?.fromTime ?? ''),
    excludedToTime: String((a.excludeExecutionWindowConfig as { toTime?: string })?.toTime ?? ''),
  }
}

const validateStep0 = (name: string, assignmentType: string, priority: string): FieldErrors => {
  const errors: FieldErrors = {}
  if (!name.trim()) errors.name = 'Assignment name is required'
  if (!assignmentType) errors.assignmentType = 'Assignment type is required'
  if (!priority) errors.priority = 'Priority is required'
  return errors
}

const validateStep1 = (selectedCount: number): FieldErrors => {
  const errors: FieldErrors = {}
  if (!selectedCount) errors.selectedPolicies = 'Select at least one policy'
  return errors
}

const validateStep2 = (targetMode: TargetMode, selectedServerCount: number, selectedGroupCount: number): FieldErrors => {
  const errors: FieldErrors = {}
  if (targetMode === 'local' && !selectedServerCount) errors.selectedServers = 'Select at least one server'
  if (targetMode === 'serverGroup' && !selectedGroupCount) errors.selectedGroups = 'Select at least one Target Group'
  return errors
}

const StepIcon: React.FC<{
  index: number
  active: boolean
  completed: boolean
}> = ({ index, active, completed }) => {

  const getIcon = () => {
    if (completed) return completedStepper
    if (active) return blueStepper
    return defaultStepper
  }

  return (
    <Box
      component="img"
      src={getIcon()}
      alt={`step-${index}`}
      sx={{
        width: 36,
        height: 36,
        objectFit: 'contain',
      }}
    />
  )
}

const PolicyRow: React.FC<{
  policy: PolicyItem
  action?: 'add' | 'remove'
  onAction?: () => void
  showDrag?: boolean
  disabled?: boolean
}> = ({ policy, action, onAction, showDrag, disabled }) => (
  <Box sx={{
    display: 'flex', alignItems: 'center', gap: 1.5, p: 1.5,
    border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', mb: 1, overflow: 'hidden',
  }}
  >
    {/* {showDrag && <GripVertical size={16} color="#94a3b8" style={{ flexShrink: 0 }} />} */}
    {/* {!showDrag && <ChevronDown size={16} color="#94a3b8" style={{ flexShrink: 0 }} />} */}
    {/* <FileText size={18} color="#2563eb" style={{ flexShrink: 0 }} /> */}
    <Box flex={1} minWidth={0}>
      <Typography variant="body2" fontWeight={600} color="#0f172a" noWrap>{policy.name}</Typography>
      <Typography variant="caption" color="text.secondary" sx={{ mt: 0.25, display: 'block' }}>
        Version: {policy.versionNumber ?? '1.0.0'}
      </Typography>
    </Box>
    {action === 'add' && (
      <IconButton size="small" onClick={onAction} disabled={disabled} sx={{ color: disabled ? '#cbd5e1' : '#2563eb' }}><Plus size={18} /></IconButton>
    )}
    {action === 'remove' && (
      <IconButton size="small" onClick={onAction} sx={{ color: '#94a3b8' }}><X size={16} /></IconButton>
    )}
  </Box>
)

interface ReviewCardProps {
  title: string
  onEdit?: () => void
  rows: {
    label: string
    value: React.ReactNode
  }[]

}

const ReviewCard: React.FC<ReviewCardProps> = ({ title, onEdit, rows }) => (
  <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto', mb: 2.5, p: 3 }}>
    <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
      <Typography variant="subtitle1" fontWeight={700} color="#0f172a">{title}</Typography>
      {onEdit && (
        <IconButton size="small" onClick={onEdit} sx={{ color: '#64748b' }}><Pencil size={15} /></IconButton>
      )}
    </Box>
    {rows.map(({ label, value }) => (
      <Box key={label} sx={{ display: 'grid', gridTemplateColumns: '180px minmax(0, 1fr)', py: 0.8 }}>
        {/* LABEL */}
        <Typography
          sx={{
            fontSize: '0.8rem',
            color: '#64748b',
          }}
        >
          {label}
        </Typography>

        {/* VALUE */}
        {typeof value === 'string' ? (
          <Tooltip title={value || '—'} arrow>
            <Typography
              sx={{
                fontSize: '0.85rem',
                fontWeight: 600,
                color: '#0f172a',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                minWidth: 0,
                width: '100%',
                display: 'block',
              }}
            >
              {value || '—'}
            </Typography>
          </Tooltip>
        ) : (
          value
        )}
      </Box>

    ))}
  </Paper>
)

const AssignmentFormPage: React.FC = () => {

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  )

  const handlePolicyDragEnd = (event: DragEndEvent) => {
    const { active, over } = event

    if (!over || active.id === over.id) return

    setSelectedPolicies((items) => {

      const oldIndex = items.findIndex((p) => String(p.id) === active.id)
      const newIndex = items.findIndex((p) => String(p.id) === over.id)

      return arrayMove(items, oldIndex, newIndex)
    })
  }
  const { id } = useParams<{ id?: string }>()
  const isEdit = !!id
  const history = useHistory()
  const location = useLocation<{ editMode?: boolean }>()

  const [viewMode, setViewMode] = useState(isEdit && !location.state?.editMode)
  const [activeStep, setActiveStep] = useState(0)
  const [activeViewTab, setActiveViewTab] = useState('overview')
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})
  const [name, setName] = useState('')
  const [assignmentType, setAssignmentType] = useState('')
  const [priority, setPriority] = useState('')
  const [executionMode, setExecutionMode] = useState<ExecutionMode>('')
  const [description, setDescription] = useState('')
  const [tags, setTags] = useState<string[]>([])
  const [tagInput, setTagInput] = useState('')
  const [selectedPolicies, setSelectedPolicies] = useState<PolicyItem[]>([])
  const [policySearch, setPolicySearch] = useState('')
  const debouncedPolicySearch = useDebouncedValue(policySearch, 400)
  const [targetMode, setTargetMode] = useState<TargetMode>('local')
  const [selectedServerGroupIds, setSelectedServerGroupIds] = useState<string[]>([])
  const [serverGroupSearch, setServerGroupSearch] = useState('')
  const debouncedServerGroupSearch = useDebouncedValue(serverGroupSearch, 400)
  const [selectedTargetHosts, setSelectedTargetHosts] = useState<string[]>([])
  const [targetSearch, setTargetSearch] = useState('')
  const debouncedTargetSearch = useDebouncedValue(targetSearch, 400)
  const [targetFilters, setTargetFilters] = useState(EMPTY_TARGET_FILTERS)
  const [deploymentStrategy, setDeploymentStrategy] = useState('immediate')
  const [scheduleType, setScheduleType] = useState('Manual')
  const [scheduleMinutes, setScheduleMinutes] = useState('1')
  const [cronExpression, setCronExpression] = useState('')
  const [timezone, setTimezone] = useState('UTC')
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [exclusionEnabled, setExclusionEnabled] = useState(false)
  const [excludedFromTime, setExcludedFromTime] = useState('')
  const [excludedToTime, setExcludedToTime] = useState('')
  const [confirmLeaveOpen, setConfirmLeaveOpen] = useState(false)
  const [snapshotVersion, setSnapshotVersion] = useState(0)

  const initialSnapshotRef = useRef<AssignmentFormSnapshot | null>(null)
  const pendingNavigationRef = useRef<PendingNavigation | null>(null)
  const unblockHistoryRef = useRef<(() => void) | null>(null)
  const allowNavigationRef = useRef(false)

  const getCurrentFormSnapshot = useCallback((): AssignmentFormSnapshot => ({
    name: name.trim(),
    assignmentType,
    priority,
    executionMode,
    description: description.trim(),
    tags: [...tags].sort(),
    selectedPolicyIds: selectedPolicies.map((p) => String(p.id ?? p.policyId)).sort(),
    targetMode,
    selectedServerGroupIds: [...selectedServerGroupIds].sort(),
    selectedTargetHosts: [...selectedTargetHosts].sort(),
    deploymentStrategy,
    scheduleType,
    scheduleMinutes,
    cronExpression,
    timezone,
    startDate,
    endDate,
    exclusionEnabled,
    excludedFromTime,
    excludedToTime,
  }), [
    name, assignmentType, priority, executionMode, description, tags, selectedPolicies,
    targetMode, selectedServerGroupIds, selectedTargetHosts, deploymentStrategy,
    scheduleType, scheduleMinutes,
    cronExpression, timezone, startDate, endDate, exclusionEnabled, excludedFromTime, excludedToTime,
  ])

  const isDirty = useMemo(() => {
    if (!initialSnapshotRef.current) return false
    return JSON.stringify(getCurrentFormSnapshot()) !== JSON.stringify(initialSnapshotRef.current)
  }, [getCurrentFormSnapshot, snapshotVersion])

  const shouldConfirmNavigation = !viewMode && isDirty

  const clearHistoryBlock = useCallback(() => {
    unblockHistoryRef.current?.()
    unblockHistoryRef.current = null
  }, [])

  const allowHistoryNavigation = useCallback(() => {
    allowNavigationRef.current = true
  }, [])

  const { data: assignmentData, isLoading: loadingAssignment } = useGetAssignmentByIdQuery(id!, { skip: !isEdit, refetchOnMountOrArgChange: true })
  const [createAssignment, { isLoading: creating }] = useCreateAssignmentMutation()
  const [updateAssignment, { isLoading: updating }] = useUpdateAssignmentMutation()
  const { data: targetMetadataData } = useGetTargetServersMetadataQuery()

  const isSaving = creating || updating
  const isReviewStep = activeStep === STEPS.length - 1

  const targetServersQueryArgs = useMemo(
    () => ({
      page: 1,
      limit: 100,
      region: targetFilters.region || undefined,
      os: targetFilters.os || undefined,
      sid: targetFilters.sid || undefined,
      owner: targetFilters.owner || undefined,
      application: targetFilters.application || undefined,
      environment: targetFilters.environment || undefined,
      search: debouncedTargetSearch.trim() || undefined,
    }),
    [targetFilters, debouncedTargetSearch],
  )
  const { data: targetServersData, isLoading: loadingTargetServers, isFetching: fetchingTargetServers } = useGetTargetServersQuery(targetServersQueryArgs)

  const { data: serverGroupsData, isLoading: loadingServerGroups } = useGetServerGroupsQuery(
    { page: 1, limit: 100, search: debouncedServerGroupSearch || undefined },
    { skip: targetMode !== 'serverGroup' },
  )

  const isGlobalTarget = targetMode === 'global'

  const usePoliciesFromApi = true
  const policiesQueryArgs = useMemo(
    () => ({
      page: 1,
      limit: 100,
      status: 'PUBLISHED' as const,
      search: debouncedPolicySearch.trim() || undefined,
    }),
    [debouncedPolicySearch],
  )

  const {
    currentData: policiesData,
    isLoading: policiesLoading,
    isFetching: policiesFetching,
  } = useGetPoliciesQuery(policiesQueryArgs, { skip: !usePoliciesFromApi })

  const apiPolicies: PolicyItem[] = useMemo(
    () => (policiesData?.data ?? []).map((p: any) => ({
      id: p.policyId ?? p.policy_id ?? p._id ?? p.id,
      policyId: p.policyId ?? p.policy_id ?? p._id ?? p.id,
      name: p.name,
      versionNumber: p.versionNumber ?? p.version ?? '1.0.0',
      env: 'Prod',
      envBg: '#dcfce7',
      envColor: '#15803d',
      rules: Array.isArray(p.rules) ? p.rules.length : (p.rulesCount ?? 0),
      status: p.status ?? 'Active',
    })),
    [policiesData],
  )

  const policySource = usePoliciesFromApi ? apiPolicies : []
  const policiesListLoading = policiesLoading || (policiesFetching && !policiesData)

  const selectedPolicyIds = useMemo(
    () => new Set(selectedPolicies.map((p) => String(p.id ?? p.policyId))),
    [selectedPolicies],
  )

  const availablePolicies = useMemo(
    () => policySource.filter((p) => !selectedPolicyIds.has(String(p.id ?? p.policyId))),
    [policySource, selectedPolicyIds],
  )

  const targetMetadata: TargetServerMetadata = {
    region: targetMetadataData?.data?.region ?? [],
    os: targetMetadataData?.data?.os ?? [],
    sid: targetMetadataData?.data?.sid ?? [],
    owner: targetMetadataData?.data?.owner ?? [],
    application: targetMetadataData?.data?.application ?? [],
    environment: targetMetadataData?.data?.environment ?? [],
  }

  const targetServers: TargetServerItem[] = targetServersData?.data ?? []
  const filteredTargetServers = targetServers
  const selectedTargets = targetServers.filter((server) => selectedTargetHosts.includes(server.hostname))
  const selectedServerGroups = (serverGroupsData?.data ?? []).filter((g: any) =>
    selectedServerGroupIds.includes(String(g._id ?? g.id ?? ''))
  )

  const setTargetFilter = (key: keyof typeof targetFilters, value: string) => {
    setTargetFilters((prev) => ({ ...prev, [key]: value }))
    setSelectedTargetHosts([])
  }

  const clearTargetFilters = () => {
    setTargetFilters(EMPTY_TARGET_FILTERS)
    setTargetSearch('')
    setSelectedTargetHosts([])
  }

  const handleTargetModeChange = (mode: TargetMode) => {
    setTargetMode(mode)
    setFieldErrors((prev) => ({ ...prev, selectedServers: '', selectedGroups: '' }))
    if (mode !== 'local') setSelectedTargetHosts([])
    if (mode !== 'serverGroup') setSelectedServerGroupIds([])
  }

  const toggleServerGroup = (groupId: string) => {
    setSelectedServerGroupIds((prev) =>
      prev.includes(groupId) ? prev.filter((id) => id !== groupId) : [...prev, groupId]
    )
    setFieldErrors((prev) => ({ ...prev, selectedGroups: '' }))
  }

  useEffect(() => {
    const a = assignmentData?.data
    if (!a) return

    console.log("API RESPONSE:", a)

    setName(a.name || '')
    setDescription(a.description || '')
    setTags(Array.isArray(a.tags) ? a.tags : [])
    setAssignmentType('Policy')
    setPriority(formatPriorityFromApi(a.priority))
    setExecutionMode(a.executionMode === 'Dry-Run' ? 'Dry-Run' : 'Enforce')

    const resolvedMode = resolveTargetModeFromApi(a as Record<string, unknown>)
    setTargetMode(resolvedMode)

    setSelectedServerGroupIds(
      Array.isArray(a.serverGroups)
        ? a.serverGroups.map((g: any) => String(g.id ?? g._id ?? '')).filter(Boolean)
        : []
    )

    setSelectedPolicies(
      a.policies?.length
        ? a.policies.map((p: any) => ({
          id: p.policyId,
          policyId: p.policyId,
          name: p.name,
          versionNumber: p.versionNumber || '1.0.0',
          env: 'Prod',
          envBg: '#dcfce7',
          envColor: '#15803d',
          rules: 0,
          status: 'Active',
        }))
        : []
    )

    setSelectedTargetHosts(
      resolvedMode === 'local' && a.targets?.length
        ? a.targets.map((t: any) => t.hostname)
        : []
    )

    setDeploymentStrategy(a.deploymentStrategy ? String(a.deploymentStrategy) : 'immediate')

    const sch = a.scheduleConfig ?? {}
    setScheduleType(sch.scheduleType || 'Manual')
    setTimezone(sch.timezone || 'UTC')
    setCronExpression(sch.cronExpression || '')
    setScheduleMinutes(sch.minutes != null ? String(sch.minutes) : '1')
    setStartDate(sch.startDate || '')
    setEndDate(sch.endDate || '')

    const ex = a.excludeExecutionWindowConfig ?? {}
    setExclusionEnabled(ex.enabled || false)
    setExcludedFromTime(ex.fromTime || '')
    setExcludedToTime(ex.toTime || '')

    initialSnapshotRef.current = buildSnapshotFromAssignment(a as Record<string, unknown>)
    setSnapshotVersion((v) => v + 1)

  }, [assignmentData])

  useEffect(() => {
    if (!isEdit && !initialSnapshotRef.current) {
      initialSnapshotRef.current = { ...EMPTY_ASSIGNMENT_SNAPSHOT }
      setSnapshotVersion((v) => v + 1)
    }
  }, [isEdit])

  useEffect(() => {
    if (viewMode || !isDirty) {
      clearHistoryBlock()
      return
    }

    unblockHistoryRef.current = history.block((location, action) => {
      if (allowNavigationRef.current) {
        allowNavigationRef.current = false
        return undefined
      }

      const targetPath = `${location.pathname}${location.search ?? ''}${location.hash ?? ''}`
      const currentPath = `${history.location.pathname}${history.location.search ?? ''}${history.location.hash ?? ''}`
      if (targetPath === currentPath) {
        return undefined
      }

      pendingNavigationRef.current = {
        type: 'leave',
        action: action === 'POP' ? 'goBack' : 'push',
        path: action === 'POP' ? undefined : targetPath,
      }
      setConfirmLeaveOpen(true)
      return false
    })

    return clearHistoryBlock
  }, [history, isDirty, viewMode, clearHistoryBlock])

  useEffect(() => {
    if (viewMode || !isDirty) return

    const handleBeforeUnload = (event: BeforeUnloadEvent) => {
      event.preventDefault()
      event.returnValue = ''
    }

    window.addEventListener('beforeunload', handleBeforeUnload)
    return () => window.removeEventListener('beforeunload', handleBeforeUnload)
  }, [isDirty, viewMode])


  const isStep0Valid = Boolean(name.trim() && assignmentType && priority)
  const isStep1Valid = Boolean(selectedPolicies.length > 0)
  const isStep2Valid = Boolean(
    targetMode === 'global' ||
    (targetMode === 'serverGroup' && selectedServerGroupIds.length > 0) ||
    (targetMode === 'local' && selectedTargetHosts.length > 0)
  )
  const canReview = isStep0Valid && isStep1Valid && isStep2Valid

  const handleAddPolicy = (policy: PolicyItem) => {
    setSelectedPolicies((prev) => {
      if (prev.some((p) => p.id === policy.id)) return prev
      return [...prev, policy]
    })
  }

  const handleRemovePolicy = (id: string) => {
    setSelectedPolicies((prev) => prev.filter((p) => p.id !== id))
  }

  const movePolicy = (index: number, direction: 'up' | 'down') => {
    setSelectedPolicies((prev) => {
      const next = [...prev]
      const swapIndex = direction === 'up' ? index - 1 : index + 1
      if (swapIndex < 0 || swapIndex >= next.length) return prev
        ;[next[index], next[swapIndex]] = [next[swapIndex], next[index]]
      return next
    })
  }

  const toggleServer = (hostname: string) => {
    if (isGlobalTarget) return
    setSelectedTargetHosts((prev) => (
      prev.includes(hostname) ? prev.filter((item) => item !== hostname) : [...prev, hostname]
    ))
  }

  const toggleAllServers = () => {
    if (isGlobalTarget) return
    setSelectedTargetHosts((prev) => (
      prev.length === filteredTargetServers.length ? [] : filteredTargetServers.map((server) => server.hostname)
    ))
  }

  const validateStep = (step: number): boolean => {
    let errors: FieldErrors = {}
    if (step === 0) errors = validateStep0(name, assignmentType, priority)
    if (step === 1) errors = validateStep1(selectedPolicies.length)
    if (step === 2) errors = validateStep2(targetMode, selectedTargetHosts.length, selectedServerGroupIds.length)

    setFieldErrors(errors)
    if (Object.keys(errors).length) {
      toast.error(Object.values(errors)[0])
      return false
    }
    return true
  }

  const executeNavigation = (action: PendingNavigation) => {
    if (action.type === 'step') {
      setFieldErrors({})
      setActiveStep(action.step)
      return
    }

    allowHistoryNavigation()
    if (action.action === 'goBack') {
      history.goBack()
      return
    }
    history.push(action.path ?? POLICYOPS_PATH.ASSIGNMENTS)
  }

  const requestNavigation = (action: PendingNavigation) => {
    if (shouldConfirmNavigation) {
      pendingNavigationRef.current = action
      setConfirmLeaveOpen(true)
      return
    }
    executeNavigation(action)
  }

  const requestStepChange = (targetStep: number, options?: { skipValidation?: boolean }) => {
    if (targetStep === activeStep) return

    if (!options?.skipValidation && targetStep > activeStep && !validateStep(activeStep)) {
      return
    }

    executeNavigation({ type: 'step', step: targetStep })
  }

  const requestLeavePage = (action: 'push' | 'goBack' = 'push', path?: string) => {
    requestNavigation({ type: 'leave', action, path })
  }

  const handleConfirmLeave = () => {
    const action = pendingNavigationRef.current
    pendingNavigationRef.current = null
    setConfirmLeaveOpen(false)
    if (action) executeNavigation(action)
  }

  const handleDismissLeaveConfirm = () => {
    pendingNavigationRef.current = null
    setConfirmLeaveOpen(false)
  }

  const handleStepClick = (targetStep: number) => {
    requestStepChange(targetStep)
  }

  const handleNext = () => {
    const targetStep = Math.min(activeStep + 1, STEPS.length - 1)
    if (targetStep === activeStep) return
    if (!validateStep(activeStep)) return
    setFieldErrors({})
    setActiveStep(targetStep)
  }

  const handlePrevious = () => {
    setFieldErrors({})
    setActiveStep((s) => Math.max(s - 1, 0))
  }

  const handleSubmit = async () => {
    const allErrors = {
      ...validateStep0(name, assignmentType, priority),
      ...validateStep1(selectedPolicies.length),
      ...validateStep2(targetMode, selectedTargetHosts.length, selectedServerGroupIds.length),
    }
    if (Object.keys(allErrors).length) {
      setFieldErrors(allErrors)
      toast.error(Object.values(allErrors)[0])
      return
    }

    const payload = {
      ...(isEdit && id ? { id } : {}),
      name: name.trim(),
      assignmentType: assignmentType.toUpperCase(),
      priority: priority.toUpperCase(),
      executionMode,
      description: description.trim(),
      tags,
      policyMode: selectedPolicies.length > 1 ? 'Multiple Policies' : 'Single Policy',
      policies: selectedPolicies.map((p, index) => ({
        policyId: p.policyId ?? p.id,
        name: p.name,
        versionNumber: p.versionNumber ?? '1.0.0',
        sequenceNumber: index + 1,
      })),
      targets: targetMode === 'local' ? selectedTargets.map((server) => ({ hostname: server.hostname })) : [],
      serverGroups: targetMode === 'serverGroup'
        ? selectedServerGroups.map((g: any) => ({
          ...g,
          id: g._id ?? g.id,
        }))
        : [],
      targetType: targetMode,
      deploymentStrategy,
      status: 'ACTIVE',
      scheduleConfig: {
        scheduleType,
        timezone,

        ...(scheduleType === 'Cron' && {
          cronExpression,
        }),

        ...(scheduleType === 'Minutes' && {
          minutes: Number(scheduleMinutes),
        }),

        startDate: startDate || null,
        endDate: endDate || null,
      },
      excludeExecutionWindowConfig: {
        enabled: exclusionEnabled,
        fromTime: excludedFromTime || null,
        toTime: excludedToTime || null,
      },
    }

    try {
      if (isEdit) {
        await updateAssignment({ id: id!, data: payload }).unwrap()
        // toast.success('Assignment updated')
        showSuccessToast(`${name} updated successfully`)
        allowHistoryNavigation()
        history.push(POLICYOPS_PATH.ASSIGNMENTS)
      } else {
        await createAssignment(payload).unwrap()
        // toast.success('Assignment created')
        showSuccessToast(`${name} created successfully`)
        allowHistoryNavigation()
        history.push(POLICYOPS_PATH.ASSIGNMENTS)
      }
    } catch (err: any) {
      // toast.error('Save failed. Please try again.')
      showErrorToast({
        title: isEdit
          ? `Failed to update ${name}. Please try again.`
          : `Failed to create ${name}. Please try again.`,
        message: err?.data?.message,
      })
    }
  }

  if (isEdit && loadingAssignment) {
    return (
      <Box sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', bgcolor: '#FBFCFF' }}>
        <CircularProgress />
      </Box>
    )
  }
  if (isEdit && !assignmentData?.data) {
    return (
      <Box sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', bgcolor: '#FBFCFF', p: 3 }}>
        <Alert severity="error">Assignment not found</Alert>
      </Box>
    )
  }

  const handleEditClick = () => {
    setViewMode(false)
    setActiveStep(0)
  }

  const goToAssignmentsPage = () => requestLeavePage('push', POLICYOPS_PATH.ASSIGNMENTS)

  const isCurrentStepValid = () => {
    switch (activeStep) {
      case 0:
        return name.trim() && assignmentType && priority
      case 1:
        return selectedPolicies.length > 0
      case 2:
        return (
          targetMode === 'global' ||
          (targetMode === 'serverGroup' && selectedServerGroupIds.length > 0) ||
          (targetMode === 'local' && selectedTargetHosts.length > 0)
        )
      case 3:
        return true
      default:
        return false
    }
  }

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <Box sx={{ mx: "auto", width: "100%", height: "100%" }}>
            <Paper elevation={0} sx={CARD_SX}>
              <Typography variant="subtitle1" fontWeight={600} mb={0.5} color="#0f172a">
                Basic Information
              </Typography>
              <Typography variant="body2" color="text.secondary" mb={3}>
                Give your assignment a clear name and purpose. You can edit this later.
              </Typography>
              <Grid container spacing={2.5}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    required
                    size="small"
                    sx={FORM_FIELD_SX}
                    label="Assignment Name"
                    placeholder="Assignment Name"
                    value={name}
                    error={Boolean(fieldErrors.name)}
                    helperText={fieldErrors.name}
                    onChange={(e) => {
                      setName(e.target.value);
                      setFieldErrors((prev) => ({ ...prev, name: "" }));
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControl
                    fullWidth
                    required
                    size="small"
                    sx={FORM_FIELD_SX}
                    error={Boolean(fieldErrors.assignmentType)}
                  >
                    <InputLabel>Assignment Type</InputLabel>
                    <Select
                      value={assignmentType}
                      label="Assignment Type"
                      onChange={(e) => {
                        setAssignmentType(e.target.value);
                        setFieldErrors((prev) => ({ ...prev, assignmentType: "" }));
                      }}
                    >
                      {ASSIGNMENT_TYPES.map((t) => (
                        <MenuItem key={t} value={t}>
                          {t}
                        </MenuItem>
                      ))}
                    </Select>
                    {fieldErrors.assignmentType && (
                      <Typography variant="caption" color="error" sx={{ mt: 0.5, ml: 1.75 }}>
                        {fieldErrors.assignmentType}
                      </Typography>
                    )}
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControl fullWidth required size="small" sx={FORM_FIELD_SX} error={Boolean(fieldErrors.priority)}>
                    <InputLabel>Priority</InputLabel>
                    <Select
                      value={priority}
                      label="Priority"
                      onChange={(e) => {
                        setPriority(e.target.value);
                        setFieldErrors((prev) => ({ ...prev, priority: "" }));
                      }}
                    >
                      {PRIORITIES.map((p) => (
                        <MenuItem key={p} value={p}>
                          {p}
                        </MenuItem>
                      ))}
                    </Select>
                    {fieldErrors.priority && (
                      <Typography variant="caption" color="error" sx={{ mt: 0.5, ml: 1.75 }}>
                        {fieldErrors.priority}
                      </Typography>
                    )}
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                    <InputLabel>Execution Mode</InputLabel>
                    <Select
                      value={executionMode}
                      label="Execution Mode"
                      onChange={(e: SelectChangeEvent) => setExecutionMode(e.target.value as ExecutionMode)}
                    >
                      {EXECUTION_MODES.map((mode) => (
                        <MenuItem key={mode} value={mode}>
                          {mode}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    size="small"
                    sx={FORM_FIELD_SX}
                    label="Description"
                    placeholder="Description"
                    value={description}
                    multiline
                    rows={3}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    size="small"
                    sx={FORM_FIELD_SX}
                    placeholder="Tag"
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && tagInput.trim()) {
                        e.preventDefault()
                        const nextTag = tagInput.trim()
                        if (!tags.includes(nextTag)) {
                          setTags((prev) => [...prev, nextTag])
                        }
                        setTagInput('')
                      }
                    }}
                  />
                  <Typography variant="caption" color="text.secondary" display="block" mt={1} mb={0.5}>
                    Selected: {tags.length}
                  </Typography>
                  <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                    {tags.map((tag, index) => (
                      <Tooltip key={index} title={tag} arrow>
                      <Chip
                        key={`${tag}-${index}`}
                        label={tag}
                        size="small"
                        onDelete={() => setTags((prev) => prev.filter((_, i) => i !== index))}
                        sx={{
                          borderRadius: '16px',
                          bgcolor: '#eef2ff',
                          color: '#4f46e5',
                          fontSize: '12px',
                          fontWeight: 500,
                          cursor: "pointer",

                          maxWidth: '200px',
                          '& .MuiChip-label': {
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          },

                        }}
                      />
                      </Tooltip>
                    ))}
                  </Stack>
                </Grid>
              </Grid>
            </Paper>
          </Box>
        );

      case 1:
        return (
          <Box sx={{ mx: 'auto', width: '100%', height: '100%' }}>


            <Box
              sx={{
                display: 'flex',
                gap: '10px', // ✅ exact gap
                width: '100%',
                height: '100%',
              }}
            >
              {/* LEFT PANEL (fixed 348px) */}
              <Box
                sx={{
                  width: '35%',
                  flexShrink: 0,
                }}
              >
                <Box
                  sx={{
                    width: '100%',
                    height: '100%',
                    bgcolor: '#fff',
                    border: '1px solid #f1f5f9',
                    borderRadius: 2,
                    display: 'flex',
                    flexDirection: 'column',
                    overflow: 'hidden',
                    padding: '16px',
                  }}
                >
                  {/* ✅ Your existing Policy Library content */}
                  <Paper elevation={0} sx={CARD_SX}>
                    <Typography variant="subtitle1" fontWeight={700} color="#0f172a">
                      Policy Library <Typography component="span" color="error">*</Typography>
                    </Typography>
                    <Typography variant="caption" color="text.secondary" display="block" mb={2}>
                      {policiesListLoading
                        ? 'Loading…'
                        : `${availablePolicies.length} policies · ${availablePolicies.reduce((s, p) => s + p.rules, 0)} rules`}
                    </Typography>
                    <TextField
                      fullWidth size="small" placeholder="Search Policy" value={policySearch}
                      onChange={(e) => setPolicySearch(e.target.value)}
                      sx={{ ...FORM_FIELD_SX, mb: 2 }}
                      InputProps={{ startAdornment: <InputAdornment position="start"><Search size={16} color="#94a3b8" /></InputAdornment> }}
                    />
                    <Box>
                      {policiesListLoading ? (
                        <Box display="flex" justifyContent="center" py={3}>
                          <CircularProgress size={22} />
                        </Box>
                      ) : (
                        <>
                          {availablePolicies.map((policy) => (
                            <PolicyRow key={policy.id} policy={policy} action="add" onAction={() => handleAddPolicy(policy)} />
                          ))}
                          {!availablePolicies.length && (
                            <Typography variant="body2" color="text.secondary" textAlign="center" py={3}>
                              {policySearch.trim() ? 'No policies match your search' : 'No policies available'}
                            </Typography>
                          )}
                        </>
                      )}
                    </Box>
                  </Paper>
                </Box>
              </Box>

              {/* RIGHT PANEL (auto-fill remaining space) */}
              <Box
                sx={{
                  flex: 1,
                  minWidth: 0, // ✅ prevents overflow issues
                }}
              >
                <Paper
                  elevation={0}
                  sx={{
                    ...CARD_SX,
                    bgcolor: '#fff',
                    // backgroundImage: 'radial-gradient(#e2e8f0 1px, transparent 1px)',
                    // backgroundSize: '16px 16px',
                    height: '100%',
                  }}
                >
                  {/* ✅ Your existing right side content */}
                  <Paper elevation={0} sx={{ ...CARD_SX, bgcolor: '#fff', backgroundSize: '16px 16px' }}>
                    <Typography variant="subtitle1" fontWeight={700} color="#0f172a">
                      Selected Policies <Typography component="span" color="error">*</Typography>
                    </Typography>
                    <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                      Policy Execution Order · Drag to reorder
                    </Typography>
                    {fieldErrors.selectedPolicies && (
                      <Typography variant="caption" color="error" display="block" mb={1}>{fieldErrors.selectedPolicies}</Typography>
                    )}
                    <Box sx={{ height: "85%" }} >
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, overflowY: 'auto' }}>
                        {selectedPolicies.length === 0 ? (
                          <Box
                            sx={{
                              border: '2px dashed #cbd5e1',
                              borderRadius: '8px',
                              p: 4,
                              textAlign: 'center',
                            }}
                          >
                            <Typography variant="body2" color="text.secondary">
                              Add policies from the library
                            </Typography>
                          </Box>
                        ) : (
                          <DndContext
                            sensors={sensors}
                            collisionDetection={closestCenter}
                            onDragEnd={handlePolicyDragEnd}
                          >
                            <SortableContext
                              items={selectedPolicies.map((p) => String(p.id))}
                              strategy={verticalListSortingStrategy}
                            >
                              {selectedPolicies.map((policy, index) => (
                                <SortableSelectedPolicy
                                  key={policy.id}
                                  policy={policy}
                                  index={index}
                                  onRemove={handleRemovePolicy}
                                />
                              ))}
                            </SortableContext>
                          </DndContext>
                        )}
                      </Box>
                      {/* {!selectedPolicies.length && (
                        <Box sx={{ border: fieldErrors.selectedPolicies ? '2px dashed #ef4444' : '2px dashed #cbd5e1', borderRadius: '8px', p: 4, textAlign: 'center' }}>
                          <Typography variant="body2" color="text.secondary">Add policies from the library</Typography>
                        </Box>
                      )} */}
                    </Box>
                  </Paper>
                </Paper>
              </Box>
            </Box>
          </Box>
        )

      case 2: {
        const TARGET_MODE_CARDS: { mode: TargetMode; label: string; description: string; icon: React.ReactNode }[] = [
          {
            mode: 'global',
            label: 'Global',
            description: 'Apply to all matching servers across all environments.',
            icon: (
              <Box sx={{ width: 36, height: 36, borderRadius: '50%', bgcolor: '#eff6ff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><line x1="2" y1="12" x2="22" y2="12" /><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" /></svg>
              </Box>
            ),
          },
          {
            mode: 'serverGroup',
            label: 'Target Groups',
            description: 'Select specific Target Groups for this assignment.',
            icon: (
              <Box sx={{ width: 36, height: 36, borderRadius: '50%', bgcolor: '#f0fdf4', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" /><path d="M8 21h8M12 17v4" /></svg>
              </Box>
            ),
          },
          {
            mode: 'local',
            label: 'Local',
            description: 'Manually select individual servers from the list.',
            icon: (
              <Box sx={{ width: 36, height: 36, borderRadius: '50%', bgcolor: '#fefce8', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ca8a04" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2" /><path d="M8 21h8M12 17v4" /></svg>
              </Box>
            ),
          },
        ]

        const serverGroups = serverGroupsData?.data ?? []

        return (
          <Box sx={{ mx: 'auto', width: '100%' }}>
            {/* Mode selector cards */}
            <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
              {TARGET_MODE_CARDS.map(({ mode, label, description, icon }) => {
                const selected = targetMode === mode
                return (
                  <Box
                    key={mode}
                    onClick={() => handleTargetModeChange(mode)}
                    sx={{
                      flex: 1,
                      cursor: 'pointer',
                      border: '1.5px solid',
                      borderColor: selected ? '#2563eb' : '#e2e8f0',
                      borderRadius: '12px',
                      p: 2.5,
                      bgcolor: selected ? '#eff6ff' : '#fff',
                      position: 'relative',
                      transition: 'all 0.15s',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      textAlign: 'center',
                      '&:hover': { borderColor: '#2563eb', bgcolor: '#f8fafc' },
                    }}
                  >
                    {selected && (
                      <Box sx={{ position: 'absolute', top: 10, right: 10 }}>
                        <CheckCircle2 size={18} color="#2563eb" />
                      </Box>
                    )}
                    <Box mb={1.5}>{icon}</Box>
                    <Typography fontWeight={700} fontSize="0.875rem" color="#0f172a" mb={0.5}>{label}</Typography>
                    <Typography fontSize="0.75rem" color="#64748b">{description}</Typography>
                  </Box>
                )
              })}
            </Box>

            {/* Global — no extra config */}
            {targetMode === 'global' && (
              <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto', display: 'flex', alignItems: 'center', gap: 2, p: 3 }}>
                <Box sx={{ width: 44, height: 44, borderRadius: '50%', bgcolor: '#eff6ff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><line x1="2" y1="12" x2="22" y2="12" /><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" /></svg>
                </Box>
                <Box>
                  <Typography fontWeight={700} color="#0f172a" fontSize="0.9rem">Global Target Enabled</Typography>
                  <Typography fontSize="0.8rem" color="#64748b">This assignment will be applied to all matching servers immediately.</Typography>
                </Box>
              </Paper>
            )}

            {/* Target Groups */}
            {targetMode === 'serverGroup' && (
              <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto' }}>
                <Typography variant="subtitle1" fontWeight={700} color="#0f172a" mb={0.5}>
                  Target Groups <Typography component="span" color="error">*</Typography>
                </Typography>
                <Typography variant="caption" color="text.secondary" display="block" mb={2}>
                  Select one or more Target Groups
                </Typography>
                {fieldErrors.selectedGroups && (
                  <Typography variant="caption" color="error" display="block" mb={1}>{fieldErrors.selectedGroups}</Typography>
                )}
                <TextField
                  fullWidth size="small" placeholder="Search Target Groups" value={serverGroupSearch}
                  onChange={(e) => setServerGroupSearch(e.target.value)}
                  sx={{ ...FORM_FIELD_SX, mb: 2 }}
                  InputProps={{ startAdornment: <InputAdornment position="start"><Search size={16} color="#94a3b8" /></InputAdornment> }}
                />
                {loadingServerGroups ? (
                  <Box display="flex" justifyContent="center" py={4}><CircularProgress size={24} /></Box>
                ) : serverGroups.length === 0 ? (
                  <Typography variant="body2" color="text.secondary" textAlign="center" py={3}>
                    {serverGroupSearch.trim() ? 'No Target Groups match your search' : 'No Target Groups available'}
                  </Typography>
                ) : (
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, maxHeight: 360, overflowY: 'auto' }}>
                    {serverGroups.map((group: any) => {
                      const gid = String(group._id ?? group.id ?? '')
                      const selected = selectedServerGroupIds.includes(gid)
                      return (
                        <Box
                          key={gid}
                          onClick={() => toggleServerGroup(gid)}
                          sx={{
                            display: 'flex', alignItems: 'center', gap: 1.5,
                            p: 1.5, border: '1px solid', cursor: 'pointer',
                            borderColor: selected ? '#2563eb' : '#e2e8f0',
                            bgcolor: selected ? '#eff6ff' : '#fff',
                            borderRadius: '8px',
                            transition: 'all 0.1s',
                            '&:hover': { borderColor: '#2563eb', bgcolor: '#f8fafc' },
                          }}
                        >
                          <Checkbox
                            size="small"
                            checked={selected}
                            onChange={() => toggleServerGroup(gid)}
                            onClick={(e) => e.stopPropagation()}
                            sx={{ p: 0, color: '#cbd5e1', '&.Mui-checked': { color: '#2563eb' } }}
                          />
                          <Box flex={1} minWidth={0}>
                            <Typography variant="body2" fontWeight={600} color="#0f172a" noWrap>{group.name}</Typography>
                            {group.description && (
                              <Typography variant="caption" color="text.secondary" noWrap display="block">{group.description}</Typography>
                            )}
                          </Box>
                          <Chip
                            label={group.groupType ?? group.type ?? 'Static'}
                            size="small"
                            variant="outlined"
                            sx={{ fontSize: '0.7rem', flexShrink: 0 }}
                          />
                          <Typography variant="caption" color="text.secondary" sx={{ flexShrink: 0 }}>
                            {group.serverCount ?? group.servers ?? 0} servers
                          </Typography>
                        </Box>
                      )
                    })}
                  </Box>
                )}
                {selectedServerGroupIds.length > 0 && (
                  <Box mt={2}>
                    <Typography variant="caption" color="text.secondary" display="block" mb={0.75}>
                      {selectedServerGroupIds.length} group(s) selected
                    </Typography>
                  </Box>
                )}
              </Paper>
            )}

            {/* Local — existing table */}
            {targetMode === 'local' && (
              <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto' }}>
                <Typography variant="subtitle1" fontWeight={700} color="#0f172a" mb={2.5}>
                  Target Servers <Typography component="span" color="error">*</Typography>
                </Typography>

                <Box display="flex" justifyContent="flex-end" alignItems="center" gap={2} flexWrap="wrap" mb={1.5}>
                  <Button
                    variant="outlined" size="small" onClick={clearTargetFilters}
                    sx={{ textTransform: 'none', borderRadius: '999px', flexShrink: 0 }}
                  >
                    Clear
                  </Button>
                  <TextField
                    size="small" placeholder="Search by hostname" value={targetSearch}
                    onChange={(e) => setTargetSearch(e.target.value)}
                    sx={{ ...FORM_FIELD_SX, minWidth: 240, maxWidth: 360 }}
                    InputProps={{ startAdornment: <InputAdornment position="start"><Search size={16} color="#94a3b8" /></InputAdornment> }}
                  />
                </Box>

                <Grid container spacing={2.5} mb={2.5}>
                  {(['region', 'os', 'sid', 'owner', 'application', 'environment'] as const).map((key) => (
                    <Grid key={key} item xs={12} sm={4} md={2}>
                      <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                        <InputLabel sx={{ textTransform: 'capitalize' }}>{key === 'os' ? 'OS' : key.charAt(0).toUpperCase() + key.slice(1)}</InputLabel>
                        <Select value={targetFilters[key]} label={key === 'os' ? 'OS' : key.charAt(0).toUpperCase() + key.slice(1)} onChange={(e) => setTargetFilter(key, e.target.value)}>
                          <MenuItem value=""><em>All</em></MenuItem>
                          {targetMetadata[key].map((option) => <MenuItem key={option} value={option}>{option}</MenuItem>)}
                        </Select>
                      </FormControl>
                    </Grid>
                  ))}
                </Grid>

                {selectedTargetHosts.length > 0 && (
                  <Box mb={2}>
                    <Typography variant="body2" fontWeight={600} color="#0f172a" mb={0.75}>
                      {selectedTargetHosts.length} target(s) selected
                    </Typography>
                    <Box display="flex" gap={1} flexWrap="wrap">
                      {selectedTargetHosts.map((hostname: string) => (
                        <Chip key={hostname} label={hostname} onDelete={() => toggleServer(hostname)} sx={{ bgcolor: '#eff6ff' }} />
                      ))}
                    </Box>
                  </Box>
                )}

                {fieldErrors.selectedServers && (
                  <Typography variant="caption" color="error" display="block" mb={1}>{fieldErrors.selectedServers}</Typography>
                )}
                <TableContainer sx={{ border: fieldErrors.selectedServers ? '1px solid #ef4444' : '1px solid #e2e8f0', borderRadius: '8px', overflowX: 'auto' }}>
                  <Table size="small" stickyHeader>
                    <TableHead>
                      <TableRow sx={{ bgcolor: '#f8fafc' }}>
                        <TableCell padding="checkbox">
                          <Checkbox
                            size="small"
                            indeterminate={selectedTargetHosts.length > 0 && selectedTargetHosts.length < filteredTargetServers.length}
                            checked={filteredTargetServers.length > 0 && selectedTargetHosts.length === filteredTargetServers.length}
                            onChange={toggleAllServers}
                          />
                        </TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Hostname</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Region</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Environment</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Service</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>SID</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Application</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Business Service</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Owner</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Server Type</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>OS</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {(loadingTargetServers || fetchingTargetServers) ? (
                        <TableRow>
                          <TableCell colSpan={12}>
                            <Box display="flex" justifyContent="center" py={3}><CircularProgress size={24} /></Box>
                          </TableCell>
                        </TableRow>
                      ) : filteredTargetServers.length ? (
                        filteredTargetServers.map((server) => (
                          <TableRow key={server.hostname} hover selected={selectedTargetHosts.includes(server.hostname)}>
                            <TableCell padding="checkbox">
                              <Checkbox
                                size="small"
                                checked={selectedTargetHosts.includes(server.hostname)}
                                onChange={() => {
                                  toggleServer(server.hostname)
                                  setFieldErrors((prev) => ({ ...prev, selectedServers: '' }))
                                }}
                              />
                            </TableCell>
                            <TableCell>{server.hostname}</TableCell>
                            <TableCell>{server.region}</TableCell>
                            <TableCell>{server.environment}</TableCell>
                            <TableCell>{server.service}</TableCell>
                            <TableCell>{server.sid}</TableCell>
                            <TableCell>{server.application}</TableCell>
                            <TableCell>{server.businessService}</TableCell>
                            <TableCell>{server.owner}</TableCell>
                            <TableCell>{server.serverType}</TableCell>
                            <TableCell>{server.os}</TableCell>
                            <TableCell>{server.status}</TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={12}>
                            <Typography variant="body2" color="text.secondary" textAlign="center" py={3}>
                              {targetSearch.trim() ? 'No target servers match your search.' : 'No target servers match the selected filters.'}
                            </Typography>
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Paper>
            )}
          </Box>
        )
      }

      case 3: {
        const matchingServers = targetMode === 'global'
          ? (targetServersData?.data?.length ?? 0)
          : targetMode === 'local'
            ? selectedTargetHosts.length
            : selectedServerGroups.reduce((sum: number, g: any) => sum + (g.serverCount ?? 0), 0)

        const STRATEGY_CARDS = [
          {
            id: 'immediate',
            label: 'Immediate',
            description: 'Deploy to all matching targets immediately.',
            icon: (
              <Box sx={{ width: 40, height: 40, borderRadius: '50%', bgcolor: '#eff6ff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Rocket size={22} color="#2563eb" />
              </Box>
            ),
          },
          {
            id: 'scheduled',
            label: 'Scheduled',
            description: 'Deploy at a future date and time.',
            icon: (
              <Box sx={{ width: 40, height: 40, borderRadius: '50%', bgcolor: '#f0fdf4', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" /><line x1="16" y1="2" x2="16" y2="6" /><line x1="8" y1="2" x2="8" y2="6" /><line x1="3" y1="10" x2="21" y2="10" /></svg>
              </Box>
            ),
          },
          {
            id: 'incremental',
            label: 'Incremental',
            description: 'Deploy in batches or waves to the same target group.',
            icon: (
              <Box sx={{ width: 40, height: 40, borderRadius: '50%', bgcolor: '#fefce8', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ca8a04" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="8" y1="6" x2="21" y2="6" /><line x1="8" y1="12" x2="21" y2="12" /><line x1="8" y1="18" x2="21" y2="18" /><line x1="3" y1="6" x2="3.01" y2="6" /><line x1="3" y1="12" x2="3.01" y2="12" /><line x1="3" y1="18" x2="3.01" y2="18" /></svg>
              </Box>
            ),
          },
          {
            id: 'stageBased',
            label: 'Stage-Based',
            description: 'Deploy across multiple Target Groups or environments.',
            icon: (
              <Box sx={{ width: 40, height: 40, borderRadius: '50%', bgcolor: '#fdf4ff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#9333ea" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12" /></svg>
              </Box>
            ),
          },
          {
            id: 'approvalGated',
            label: 'Approval-Gated',
            description: 'Require approval before advancing to the next stage or batch.',
            icon: (
              <Box sx={{ width: 40, height: 40, borderRadius: '50%', bgcolor: '#fff7ed', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ea580c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /></svg>
              </Box>
            ),
          },
        ]

        const renderStrategyDetail = () => {
          switch (deploymentStrategy) {
            case 'immediate':
              return (
                <Box>
                  <Box sx={{ display: 'flex', gap: 2.5, mt: 3 }}>
                    {/* Left detail panel */}
                    <Paper elevation={0} sx={{ flex: 1, border: '1px solid #e2e8f0', borderRadius: '12px', p: 3 }}>
                      <Typography fontWeight={700} fontSize="0.875rem" color="#2563eb" mb={2}>Immediate Deployment Details</Typography>
                      <Typography fontSize="0.8rem" color="#64748b" mb={2.5}>This assignment will be applied to all matching targets immediately after activation.</Typography>
                      {[
                        { label: 'Target Type', value: 'Dynamic Target Group' },
                        { label: 'Target', value: 'Linux Production Servers' },
                        { label: 'Matching Servers', value: matchingServers.toLocaleString(), highlight: true },
                        { label: 'Excluded Servers', value: '0' },
                        { label: 'Effective Targets', value: matchingServers.toLocaleString(), highlight: true },
                      ].map(({ label, value, highlight }) => (
                        <Box key={label} sx={{ display: 'grid', gridTemplateColumns: '160px 1fr', py: 0.8, borderBottom: '1px solid #f1f5f9' }}>
                          <Typography fontSize="0.8rem" color="#64748b">{label}</Typography>
                          <Typography fontSize="0.8rem" fontWeight={600} color={highlight ? '#2563eb' : '#0f172a'}>{value}</Typography>
                        </Box>
                      ))}
                    </Paper>
                    {/* Right what happens next */}
                    <Box sx={{ width: 240, flexShrink: 0, display: 'flex', flexDirection: 'column' }}>
                      <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5, flex: 1 }}>
                        <Typography fontWeight={700} fontSize="0.8rem" color="#0f172a" mb={1.5}>What happens next?</Typography>
                        <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'flex-start' }}>
                          <Box sx={{ width: 28, height: 28, borderRadius: '50%', bgcolor: '#dcfce7', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, mt: 0.25 }}>
                            <CheckCircle2 size={14} color="#16a34a" />
                          </Box>
                          <Typography fontSize="0.78rem" color="#64748b" lineHeight={1.6}>
                            The assignment will be created and deployed immediately to all{' '}
                            <Box component="span" fontWeight={700} color="#2563eb">{matchingServers.toLocaleString()}</Box>{' '}
                            matching servers.
                          </Typography>
                        </Box>
                      </Paper>
                    </Box>
                  </Box>
                  <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.25, border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', cursor: 'pointer', '&:hover': { bgcolor: '#f8fafc' } }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Shield size={16} color="#64748b" />
                        <Typography fontSize="0.8rem" color="#0f172a">Maintenance Window <Box component="span" sx={{ color: '#94a3b8', fontSize: '0.78rem' }}>(Optional)</Box></Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography fontSize="0.8rem" color="#94a3b8">Not Configured</Typography>
                        <ChevronDown size={14} color="#94a3b8" />
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.25, border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', cursor: 'pointer', '&:hover': { bgcolor: '#f8fafc' } }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Bell size={16} color="#64748b" />
                        <Typography fontSize="0.8rem" color="#0f172a">Notifications <Box component="span" sx={{ color: '#94a3b8', fontSize: '0.78rem' }}>(Optional)</Box></Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography fontSize="0.8rem" color="#94a3b8">On Failure, On Success</Typography>
                        <ChevronDown size={14} color="#94a3b8" />
                      </Box>
                    </Box>
                  </Box>
                </Box>
              )

            case 'scheduled':
              return (
                <Box>
                  <Box sx={{ display: 'flex', gap: 2.5, mt: 3 }}>
                    <Paper elevation={0} sx={{ flex: 1, border: '1px solid #e2e8f0', borderRadius: '12px', p: 3 }}>
                      <Typography fontWeight={700} fontSize="0.875rem" color="#16a34a" mb={2}>Scheduled Deployment Details</Typography>
                      <Typography fontSize="0.8rem" color="#64748b" mb={2.5}>Select the date and time when you want the deployment to start.</Typography>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={6}>
                          <TextField fullWidth size="small" label="Date" type="date" defaultValue="2026-07-15" sx={FORM_FIELD_SX} InputLabelProps={{ shrink: true }} />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <TextField fullWidth size="small" label="Time" type="time" defaultValue="22:00" sx={FORM_FIELD_SX} InputLabelProps={{ shrink: true }} />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                            <InputLabel>Timezone</InputLabel>
                            <Select defaultValue="UTC" label="Timezone">
                              {TIMEZONES.map((t) => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                            </Select>
                          </FormControl>
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <FormControl fullWidth size="small" sx={FORM_FIELD_SX}>
                            <InputLabel>Recurrence</InputLabel>
                            <Select defaultValue="one_time" label="Recurrence">
                              <MenuItem value="one_time">One Time</MenuItem>
                              <MenuItem value="daily">Daily</MenuItem>
                              <MenuItem value="weekly">Weekly</MenuItem>
                            </Select>
                          </FormControl>
                        </Grid>
                      </Grid>
                      <Box sx={{ mt: 2, p: 1.5, bgcolor: '#f0fdf4', borderRadius: '8px', border: '1px solid #bbf7d0', display: 'flex', gap: 1, alignItems: 'center' }}>
                        <CheckCircle2 size={14} color="#16a34a" />
                        <Typography fontSize="0.78rem" color="#15803d">The assignment will be deployed during the selected window.</Typography>
                      </Box>
                    </Paper>
                    <Box sx={{ width: 220, flexShrink: 0, display: 'flex', flexDirection: 'column' }}>
                      <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5, flex: 1 }}>
                        <Typography fontWeight={700} fontSize="0.8rem" color="#0f172a" mb={1.5}>Deployment Preview</Typography>
                        <Typography fontSize="0.78rem" color="#64748b" mb={0.5}>Deployment will begin on</Typography>
                        <Typography fontSize="0.85rem" fontWeight={700} color="#0f172a" mb={1.5}>15-Jul-2026 at 22:00 UTC</Typography>
                        <Box sx={{ height: '1px', bgcolor: '#f1f5f9', my: 1.5 }} />
                        <Typography fontSize="0.78rem" color="#64748b" mb={0.5}>Target Servers</Typography>
                        <Typography fontSize="0.85rem" fontWeight={700} color="#2563eb">{matchingServers.toLocaleString()}</Typography>
                      </Paper>
                    </Box>
                  </Box>
                  <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.25, border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', cursor: 'pointer', '&:hover': { bgcolor: '#f8fafc' } }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Shield size={16} color="#64748b" />
                        <Typography fontSize="0.8rem" color="#0f172a">Maintenance Window <Box component="span" sx={{ color: '#94a3b8', fontSize: '0.78rem' }}>(Optional)</Box></Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography fontSize="0.8rem" color="#94a3b8">Not Configured</Typography>
                        <ChevronDown size={14} color="#94a3b8" />
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.25, border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', cursor: 'pointer', '&:hover': { bgcolor: '#f8fafc' } }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Bell size={16} color="#64748b" />
                        <Typography fontSize="0.8rem" color="#0f172a">Notifications <Box component="span" sx={{ color: '#94a3b8', fontSize: '0.78rem' }}>(Optional)</Box></Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography fontSize="0.8rem" color="#94a3b8">On Failure, On Success</Typography>
                        <ChevronDown size={14} color="#94a3b8" />
                      </Box>
                    </Box>
                  </Box>
                </Box>
              )

            case 'incremental':
              return (
                <Box>
                  <Box sx={{ display: 'flex', gap: 2.5, mt: 3 }}>
                    <Paper elevation={0} sx={{ flex: 1, border: '1px solid #e2e8f0', borderRadius: '12px', p: 3 }}>
                      <Typography fontWeight={700} fontSize="0.875rem" color="#ca8a04" mb={0.5}>Incremental Deployment Details</Typography>
                      <Typography fontSize="0.8rem" color="#64748b" mb={2.5}>Deploy to the same target group in batches or waves.</Typography>
                      <Box sx={{ display: 'grid', gridTemplateColumns: '160px 1fr', py: 0.8, borderBottom: '1px solid #f1f5f9', mb: 0.5 }}>
                        <Typography fontSize="0.8rem" color="#64748b">Target</Typography>
                        <Typography fontSize="0.8rem" fontWeight={600} color="#2563eb" sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}>Linux Production Servers</Typography>
                      </Box>
                      <Box sx={{ display: 'grid', gridTemplateColumns: '160px 1fr', py: 0.8, borderBottom: '1px solid #f1f5f9', mb: 2 }}>
                        <Typography fontSize="0.8rem" color="#64748b">Total Matching Servers</Typography>
                        <Typography fontSize="0.8rem" fontWeight={700} color="#0f172a">{matchingServers.toLocaleString()}</Typography>
                      </Box>
                      <Typography fontSize="0.8rem" fontWeight={600} color="#0f172a" mb={1}>Deployment Method</Typography>
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, mb: 2 }}>
                        {[{ label: 'Fixed Batch Size', sub: 'Batch Size: 100 Servers · Interval: Every 2 Hours' }, { label: 'Percentage Based', sub: 'Deploy in % increments' }].map((opt, i) => (
                          <Box key={opt.label} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, p: 1.5, border: '1px solid', borderColor: i === 0 ? '#2563eb' : '#e2e8f0', borderRadius: '8px', cursor: 'pointer' }}>
                            <Box sx={{ width: 14, height: 14, borderRadius: '50%', border: '2px solid', borderColor: i === 0 ? '#2563eb' : '#cbd5e1', bgcolor: i === 0 ? '#2563eb' : 'transparent', flexShrink: 0 }} />
                            <Box>
                              <Typography fontSize="0.8rem" fontWeight={600} color="#0f172a">{opt.label}</Typography>
                              <Typography fontSize="0.72rem" color="#64748b">{opt.sub}</Typography>
                            </Box>
                          </Box>
                        ))}
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', p: 1.5, bgcolor: '#f8fafc', borderRadius: '8px' }}>
                        <Typography fontSize="0.8rem" color="#64748b">Approval Between Batches</Typography>
                        <Box sx={{ width: 36, height: 20, borderRadius: '10px', bgcolor: '#e2e8f0', position: 'relative', cursor: 'pointer' }}>
                          <Box sx={{ position: 'absolute', top: 2, left: 2, width: 16, height: 16, borderRadius: '50%', bgcolor: 'white', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }} />
                        </Box>
                      </Box>
                    </Paper>
                    <Box sx={{ width: 220, flexShrink: 0, display: 'flex', flexDirection: 'column' }}>
                      <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5, flex: 1 }}>
                        <Typography fontWeight={700} fontSize="0.8rem" color="#0f172a" mb={1.5}>Batch Preview</Typography>
                        <Table size="small">
                          <TableHead>
                            <TableRow>
                              <TableCell sx={{ fontSize: '0.72rem', fontWeight: 600, p: '4px 8px' }}>Batch</TableCell>
                              <TableCell sx={{ fontSize: '0.72rem', fontWeight: 600, p: '4px 8px' }}>Servers</TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {[1, 2, 3].map((b) => (
                              <TableRow key={b}>
                                <TableCell sx={{ fontSize: '0.78rem', p: '4px 8px' }}>Batch {b}</TableCell>
                                <TableCell sx={{ fontSize: '0.78rem', p: '4px 8px' }}>100</TableCell>
                              </TableRow>
                            ))}
                            <TableRow>
                              <TableCell sx={{ fontSize: '0.78rem', p: '4px 8px', color: '#94a3b8' }}>…</TableCell>
                              <TableCell sx={{ fontSize: '0.78rem', p: '4px 8px', color: '#94a3b8' }}>—</TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell sx={{ fontSize: '0.78rem', fontWeight: 600, p: '4px 8px' }}>Total</TableCell>
                              <TableCell sx={{ fontSize: '0.78rem', fontWeight: 700, color: '#2563eb', p: '4px 8px' }}>{matchingServers.toLocaleString()}</TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                        <Typography fontSize="0.72rem" color="#64748b" mt={1.5}>Deployment will start with the first batch after activation.</Typography>
                      </Paper>
                    </Box>
                  </Box>
                  <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.25, border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', cursor: 'pointer', '&:hover': { bgcolor: '#f8fafc' } }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <AlertCircle size={16} color="#64748b" />
                        <Typography fontSize="0.8rem" color="#0f172a">Failure Handling <Box component="span" sx={{ color: '#94a3b8', fontSize: '0.78rem' }}>(Optional)</Box></Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography fontSize="0.8rem" color="#94a3b8">Stop on Failure</Typography>
                        <ChevronDown size={14} color="#94a3b8" />
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.25, border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', cursor: 'pointer', '&:hover': { bgcolor: '#f8fafc' } }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Bell size={16} color="#64748b" />
                        <Typography fontSize="0.8rem" color="#0f172a">Notifications <Box component="span" sx={{ color: '#94a3b8', fontSize: '0.78rem' }}>(Optional)</Box></Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography fontSize="0.8rem" color="#94a3b8">On Failure, On Success</Typography>
                        <ChevronDown size={14} color="#94a3b8" />
                      </Box>
                    </Box>
                  </Box>
                </Box>
              )

            case 'stageBased':
              return (
                <Box>
                  <Box sx={{ display: 'flex', gap: 2.5, mt: 3 }}>
                    <Paper elevation={0} sx={{ flex: 1, border: '1px solid #e2e8f0', borderRadius: '12px', p: 3 }}>
                      <Typography fontWeight={700} fontSize="0.875rem" color="#9333ea" mb={0.5}>Stage-Based Deployment Details</Typography>
                      <Typography fontSize="0.8rem" color="#64748b" mb={2.5}>Create a deployment pipeline across multiple Target Groups or environments.</Typography>
                      <Table size="small">
                        <TableHead>
                          <TableRow sx={{ bgcolor: '#f8fafc' }}>
                            {['Stage', 'Target Group', 'Wait Duration', 'Approval Required', 'Actions'].map((h) => (
                              <TableCell key={h} sx={{ fontSize: '0.75rem', fontWeight: 600 }}>{h}</TableCell>
                            ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {[
                            { stage: 1, group: 'Dev Linux Servers', wait: '3 Days', approval: 'No Approval', color: '#22c55e' },
                            { stage: 2, group: 'QA Linux Servers', wait: '5 Days', approval: 'Manager Approval', color: '#3b82f6' },
                            { stage: 3, group: 'Prod Linux Servers', wait: '—', approval: 'CAB Approval', color: '#f97316' },
                          ].map((row) => (
                            <TableRow key={row.stage}>
                              <TableCell><Box sx={{ width: 20, height: 20, borderRadius: '50%', bgcolor: row.color, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Typography sx={{ fontSize: '0.65rem', color: 'white', fontWeight: 700 }}>{row.stage}</Typography></Box></TableCell>
                              <TableCell sx={{ fontSize: '0.8rem' }}>{row.group}</TableCell>
                              <TableCell sx={{ fontSize: '0.8rem' }}>{row.wait}</TableCell>
                              <TableCell sx={{ fontSize: '0.8rem' }}>{row.approval}</TableCell>
                              <TableCell><Box display="flex" gap={0.5}><IconButton size="small"><Pencil size={13} /></IconButton></Box></TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                      <Button size="small" startIcon={<Plus size={13} />} sx={{ mt: 1.5, textTransform: 'none', color: '#2563eb', fontSize: '0.8rem' }}>Add Stage</Button>
                      <Typography fontSize="0.75rem" color="#64748b" mt={2} sx={{ p: 1.5, bgcolor: '#f8fafc', borderRadius: '8px' }}>
                        Next stage will start automatically once the current stage completes and conditions are met.
                      </Typography>
                    </Paper>
                    <Box sx={{ width: 200, flexShrink: 0, display: 'flex', flexDirection: 'column' }}>
                      <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5, flex: 1 }}>
                        <Typography fontWeight={700} fontSize="0.8rem" color="#0f172a" mb={2}>Pipeline Preview</Typography>
                        {[
                          { label: 'Dev Linux Servers', sub: 'Wait 3 Days', color: '#22c55e' },
                          { label: 'QA Linux Servers', sub: 'Wait 5 Days + Manager Approval', color: '#14b8a6' },
                          { label: 'Prod Linux Servers', sub: 'CAB Approval', color: '#9333ea' },
                        ].map((s, i, arr) => {
                          const isLast = i === arr.length - 1
                          return (
                            <Box key={s.label} sx={{ display: 'flex', gap: 1.25 }}>
                              {/* timeline rail */}
                              <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                                <Box sx={{ width: 14, height: 14, borderRadius: '50%', border: `2px solid ${s.color}`, bgcolor: i === 1 ? '#fff' : s.color, mt: '2px' }} />
                                {!isLast && (
                                  <>
                                    <Box sx={{ width: 2, flex: 1, minHeight: 6, bgcolor: '#e2e8f0', mt: 0.5 }} />
                                    <ArrowDown size={12} color="#94a3b8" />
                                    <Box sx={{ width: 2, flex: 1, minHeight: 6, bgcolor: '#e2e8f0', mb: 0.5 }} />
                                  </>
                                )}
                              </Box>
                              {/* content */}
                              <Box sx={{ pb: isLast ? 0 : 2 }}>
                                <Typography fontSize="0.76rem" fontWeight={600} color="#0f172a">{s.label}</Typography>
                                <Typography fontSize="0.68rem" color="#64748b">{s.sub}</Typography>
                              </Box>
                            </Box>
                          )
                        })}
                      </Paper>
                    </Box>
                  </Box>
                  <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.25, border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', cursor: 'pointer', '&:hover': { bgcolor: '#f8fafc' } }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <RotateCcw size={16} color="#64748b" />
                        <Typography fontSize="0.8rem" color="#0f172a">Rollback Strategy <Box component="span" sx={{ color: '#94a3b8', fontSize: '0.78rem' }}>(Optional)</Box></Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography fontSize="0.8rem" color="#94a3b8">Automatic Rollback</Typography>
                        <ChevronDown size={14} color="#94a3b8" />
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.25, border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', cursor: 'pointer', '&:hover': { bgcolor: '#f8fafc' } }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Bell size={16} color="#64748b" />
                        <Typography fontSize="0.8rem" color="#0f172a">Notifications <Box component="span" sx={{ color: '#94a3b8', fontSize: '0.78rem' }}>(Optional)</Box></Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography fontSize="0.8rem" color="#94a3b8">On Failure, On Success</Typography>
                        <ChevronDown size={14} color="#94a3b8" />
                      </Box>
                    </Box>
                  </Box>
                </Box>
              )

            case 'approvalGated':
              return (
                <Box>
                  <Box sx={{ display: 'flex', gap: 2.5, mt: 3 }}>
                    <Paper elevation={0} sx={{ flex: 1, border: '1px solid #e2e8f0', borderRadius: '12px', p: 3 }}>
                      <Typography fontWeight={700} fontSize="0.875rem" color="#ea580c" mb={0.5}>Approval-Gated Deployment Details</Typography>
                      <Typography fontSize="0.8rem" color="#64748b" mb={2.5}>Require approvals before advancing to the next stage or batch.</Typography>
                      <Table size="small">
                        <TableHead>
                          <TableRow sx={{ bgcolor: '#f8fafc' }}>
                            {['Stage', 'Target/Batch', 'Approval Required', 'Actions'].map((h) => (
                              <TableCell key={h} sx={{ fontSize: '0.75rem', fontWeight: 600 }}>{h}</TableCell>
                            ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {[
                            { stage: 1, batch: `Deploy to 10% (${Math.round(matchingServers * 0.1)} Servers)`, approval: 'Security Team', color: '#22c55e' },
                            { stage: 2, batch: `Deploy to 50% (${Math.round(matchingServers * 0.5)} Servers)`, approval: 'Manager Approval', color: '#3b82f6' },
                            { stage: 3, batch: `Deploy to 100% (${matchingServers} Servers)`, approval: 'CAB Approval', color: '#f97316' },
                          ].map((row) => (
                            <TableRow key={row.stage}>
                              <TableCell><Box sx={{ width: 20, height: 20, borderRadius: '50%', bgcolor: row.color, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Typography sx={{ fontSize: '0.65rem', color: 'white', fontWeight: 700 }}>{row.stage}</Typography></Box></TableCell>
                              <TableCell sx={{ fontSize: '0.8rem' }}>{row.batch}</TableCell>
                              <TableCell sx={{ fontSize: '0.8rem' }}>{row.approval}</TableCell>
                              <TableCell><IconButton size="small"><Pencil size={13} /></IconButton></TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                      <Button size="small" startIcon={<Plus size={13} />} sx={{ mt: 1.5, textTransform: 'none', color: '#2563eb', fontSize: '0.8rem' }}>Add Stage</Button>
                      <Typography fontSize="0.75rem" color="#64748b" mt={2} sx={{ p: 1.5, bgcolor: '#fff7ed', borderRadius: '8px', border: '1px solid #fed7aa' }}>
                        Deployment will pause at each stage and wait for the required approval.
                      </Typography>
                    </Paper>
                    <Box sx={{ width: 200, flexShrink: 0, display: 'flex', flexDirection: 'column' }}>
                      <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5, flex: 1 }}>
                        <Typography fontWeight={700} fontSize="0.8rem" color="#0f172a" mb={1.5}>Approval Flow</Typography>
                        {[
                          { label: 'Deploy to 10%', approval: 'Security Approval', color: '#22c55e' },
                          { label: 'Deploy to 50%', approval: 'Manager Approval', color: '#3b82f6' },
                          { label: 'Deploy to 100%', approval: null, color: '#9333ea' },
                        ].map((s, i, arr) => {
                          const isLast = i === arr.length - 1
                          return (
                            <Box key={s.label}>
                              {/* stage node + label */}
                              {isLast ? (
                                <Box sx={{ display: 'inline-flex', alignItems: 'center', gap: 0.75, px: 1.25, py: 0.75, borderRadius: '8px', border: `1px solid ${s.color}59`, bgcolor: `${s.color}14` }}>
                                  <CheckCircle2 size={15} color={s.color} style={{ flexShrink: 0 }} />
                                  <Typography fontSize="0.78rem" fontWeight={700} color={s.color}>{s.label}</Typography>
                                </Box>
                              ) : (
                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                  <Box sx={{ width: 16, height: 16, borderRadius: '50%', border: `2px solid ${s.color}`, bgcolor: '#fff', flexShrink: 0 }} />
                                  <Typography fontSize="0.78rem" fontWeight={600} color="#0f172a">{s.label}</Typography>
                                </Box>
                              )}
                              {s.approval && (
                                <>
                                  <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 0.5 }}>
                                    <Box sx={{ width: 2, height: 12, bgcolor: '#e2e8f0' }} />
                                    <ArrowDown size={13} color="#cbd5e1" style={{ marginTop: -2 }} />
                                  </Box>
                                  <Box sx={{ p: 1, border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: '#f8fafc', textAlign: 'center' }}>
                                    <Typography fontSize="0.72rem" fontWeight={600} color="#475569">{s.approval}</Typography>
                                  </Box>
                                  <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 0.5 }}>
                                    <Box sx={{ width: 2, height: 12, bgcolor: '#e2e8f0' }} />
                                    <ArrowDown size={13} color="#cbd5e1" style={{ marginTop: -2 }} />
                                  </Box>
                                </>
                              )}
                            </Box>
                          )
                        })}
                      </Paper>
                    </Box>
                  </Box>
                  <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.25, border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', cursor: 'pointer', '&:hover': { bgcolor: '#f8fafc' } }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Clock size={16} color="#64748b" />
                        <Typography fontSize="0.8rem" color="#0f172a">Timeout Settings <Box component="span" sx={{ color: '#94a3b8', fontSize: '0.78rem' }}>(Optional)</Box></Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography fontSize="0.8rem" color="#94a3b8">No Timeout</Typography>
                        <ChevronDown size={14} color="#94a3b8" />
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.25, border: '1px solid #e2e8f0', borderRadius: '8px', bgcolor: 'white', cursor: 'pointer', '&:hover': { bgcolor: '#f8fafc' } }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Bell size={16} color="#64748b" />
                        <Typography fontSize="0.8rem" color="#0f172a">Notifications <Box component="span" sx={{ color: '#94a3b8', fontSize: '0.78rem' }}>(Optional)</Box></Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography fontSize="0.8rem" color="#94a3b8">On Failure, On Success</Typography>
                        <ChevronDown size={14} color="#94a3b8" />
                      </Box>
                    </Box>
                  </Box>
                </Box>
              )

            default:
              return null
          }
        }

        return (
          <Box sx={{ mx: 'auto', width: '100%' }}>
            <Typography variant="subtitle1" fontWeight={700} color="#0f172a" mb={0.5}>Deployment Strategy</Typography>
            <Typography variant="body2" color="text.secondary" mb={2.5}>Choose how you want this assignment to be deployed.</Typography>

            {/* Strategy selector cards */}
            <Box sx={{ display: 'flex', gap: 1.5 }}>
              {STRATEGY_CARDS.map(({ id, label, description, icon }) => {
                const selected = deploymentStrategy === id
                return (
                  <Box
                    key={id}
                    onClick={() => setDeploymentStrategy(id)}
                    sx={{
                      flex: 1,
                      cursor: 'pointer',
                      border: '1.5px solid',
                      borderColor: selected ? '#2563eb' : '#e2e8f0',
                      borderRadius: '12px',
                      p: 2,
                      bgcolor: selected ? '#eff6ff' : '#fff',
                      position: 'relative',
                      transition: 'all 0.15s',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      textAlign: 'center',
                      '&:hover': { borderColor: '#2563eb', bgcolor: '#f8fafc' },
                    }}
                  >
                    {selected && (
                      <Box sx={{ position: 'absolute', top: 8, right: 8 }}>
                        <CheckCircle2 size={16} color="#2563eb" />
                      </Box>
                    )}
                    <Box mb={1.5}>{icon}</Box>
                    <Typography fontWeight={700} fontSize="0.8rem" color="#0f172a" mb={0.5}>{label}</Typography>
                    <Typography fontSize="0.72rem" color="#64748b" lineHeight={1.4}>{description}</Typography>
                  </Box>
                )
              })}
            </Box>

            {renderStrategyDetail()}
          </Box>
        )
      }

      case 4:
        return (
          <Grid container spacing={3}>
            <Grid item xs={12} lg={7}>
              <ReviewCard
                title="Basic Information"
                onEdit={() => requestStepChange(0)}
                rows={[
                  { label: 'Assignment Name', value: name || '—' },
                  { label: 'Assignment Type', value: assignmentType || '—' },
                  { label: 'Priority', value: priority || '—' },
                  { label: 'Execution Mode', value: executionMode },
                  { label: 'Description', value: description || '—' },
                  { label: 'Tags', value: tags.length ? tags.join(', ') : '—' },
                ]}
              />
              <ReviewCard
                title="Policy Selection"
                onEdit={() => requestStepChange(1)}
                rows={[
                  { label: 'Selected Policies', value: selectedPolicies.map((p) => p.name).join(', ') || '—' },
                ]}
              />
              <ReviewCard
                title="Target Selection"
                onEdit={() => requestStepChange(2)}
                rows={[
                  { label: 'Target Mode', value: TARGET_MODE_LABEL[targetMode] },
                  { label: 'Selected Targets', value: targetMode === 'global' ? 'Global' : targetMode === 'serverGroup' ? `${selectedServerGroupIds.length} group(s)` : (selectedTargetHosts.length ? `${selectedTargetHosts.length} server(s)` : '—') },
                ]}
              />
              <ReviewCard
                title="Deployment Strategy"
                onEdit={() => requestStepChange(3)}
                rows={[
                  { label: 'Strategy', value: ({ immediate: 'Immediate', scheduled: 'Scheduled', incremental: 'Incremental', stageBased: 'Stage-Based', approvalGated: 'Approval-Gated' } as Record<string, string>)[deploymentStrategy] ?? deploymentStrategy },
                ]}
              />
            </Grid>
            <Grid item xs={12} lg={5}>
              <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto' }}>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                  <Typography variant="subtitle1" fontWeight={700} color="#0f172a">Policy</Typography>
                  <IconButton size="small" onClick={() => requestStepChange(1)} sx={{ color: '#64748b' }}><Pencil size={15} /></IconButton>
                </Box>
                {selectedPolicies.map((policy) => (
                  <Box key={policy.id} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, p: 1.5, border: '1px solid #F2F2F2', bgcolor: '#FFFFFF', borderRadius: '8px', mb: 1 }}>
                    <FileText size={18} color="#2563eb" />
                    <Box flex={1}>
                      <Typography variant="body2" fontWeight={600}>{policy.name}</Typography>
                      <Box display="flex" gap={1} alignItems="center">
                        <Typography variant="caption" color="text.secondary">
                          {`Version: ${policy.versionNumber ?? '1.0.0'}`}
                        </Typography>
                      </Box>
                    </Box>
                  </Box>
                ))}
              </Paper>
            </Grid>
          </Grid>
        )

      default:
        return null
    }
  }

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', bgcolor: '#FBFCFF' }}>
      <Box sx={{ px: 3, py: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Box display="flex" alignItems="center" gap={1.5}>
          <IconButton size="small" onClick={() => requestLeavePage('goBack')} sx={{ color: '#64748b' }}>
            <ArrowLeft size={18} />
          </IconButton>
          <Box>
            <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.8125rem', cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }} onClick={goToAssignmentsPage}>
              Assignment Center
            </Typography>
            <Typography variant="h5" fontWeight={700} lineHeight={1.2} color="#0f172a">
              {viewMode ? 'View Assignment' : (isEdit ? 'Edit Assignment' : 'Create Assignment')}
            </Typography>
          </Box>
        </Box>

        <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'center' }}>
          {viewMode && isEdit && (
            <Button variant="contained" onClick={handleEditClick} endIcon={<Pencil size={16} />} sx={{ textTransform: 'none', fontWeight: 500, padding: "6px 16px", color: "#667085", bgcolor: '#FFFFFF', border: "1px solid #F2F2F2", boxShadow: 'none', '&:hover': { bgcolor: '#E3F0FF', boxShadow: 'none' } }}>
              Modify
            </Button>
          )}
          {!viewMode && isReviewStep && (
            <Button variant="text" onClick={handlePrevious} sx={{ textTransform: 'none', color: '#2563eb', fontWeight: 500 }}>
              Previous
            </Button>
          )}
          {!viewMode && (
            <Button onClick={goToAssignmentsPage} sx={{ color: '#2961F4', bgcolor: '#E3F0FF', borderRadius: '32px', textTransform: 'none', fontWeight: 500, padding: '6px 16px', '&:hover': { bgcolor: '#d6e8ff' } }}>
              Cancel
            </Button>
          )}
          {!viewMode && isReviewStep ? (
            <Button variant="contained" onClick={handleSubmit} disabled={!canReview || isSaving} sx={{ textTransform: 'none', fontWeight: 500, px: 2.5, bgcolor: '#2563eb', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}>
              {isSaving ? (isEdit ? 'Updating…' : 'Creating…') : (isEdit ? 'Update' : 'Create')}
            </Button>
          ) : !viewMode ? (
            <Button
              variant="contained"
              disabled={!canReview || isSaving}
              onClick={() => canReview && requestStepChange(STEPS.length - 1, { skipValidation: true })}
              sx={{ textTransform: 'none', fontWeight: 500, bgcolor: canReview ? '#2563eb' : '#D9D9D9', color: canReview ? '#FFFFFF' : '#FFFFFF', borderRadius: "32px", boxShadow: 'none', padding: "6px 16px", '&:hover': { bgcolor: canReview ? '#1d4ed8' : '#e2e8f0', boxShadow: 'none' } }}
            >
              {isEdit ? 'Update' : 'Create'}
            </Button>
          ) : null}
        </Box>
      </Box>

      {viewMode && (
        <Box sx={{ display: 'flex', borderBottom: '1px solid #e2e8f0', bgcolor: 'white', px: 3 }}>
          {[['overview', 'Overview'], ['scm', 'SCM']].map(([key, label]) => (
            <Box key={key} onClick={() => setActiveViewTab(key)}
              sx={{
                px: 2, py: 1.5, cursor: 'pointer', fontSize: '0.875rem',
                fontWeight: activeViewTab === key ? 600 : 400,
                color: activeViewTab === key ? '#2563eb' : '#64748b',
                borderBottom: `2px solid ${activeViewTab === key ? '#2563eb' : 'transparent'}`,
                transition: 'color 0.15s', userSelect: 'none',
                '&:hover': { color: '#2563eb' },
              }}>
              {label}
            </Box>
          ))}
        </Box>
      )}

      {!viewMode && (
        <Box sx={{ padding: "8px 24px 24px" }}>
          <Stepper
            nonLinear
            activeStep={activeStep}
            alternativeLabel
            connector={<AssignmentStepConnector />}
            sx={{
              maxWidth: 820,
              mx: 'auto',
              pb: 1.5,
              '& .MuiStepLabel-label': { mt: 0.75, fontSize: '0.78rem' },
              '& .MuiStepLabel-labelContainer': { maxWidth: 'none' },
            }}
          >
            {STEPS.map((label, index) => (
              <Step key={label} completed={index < activeStep}>
                <StepButton disableRipple onClick={() => handleStepClick(index)}>
                  <StepLabel StepIconComponent={() => (<StepIcon index={index} active={index === activeStep} completed={index < activeStep} />)}>
                    <Typography fontWeight={index === activeStep ? 700 : 400} color={index <= activeStep ? '#1e293b' : '#94a3b8'} sx={{ fontSize: '0.78rem' }}>
                      {label}
                    </Typography>
                  </StepLabel>
                </StepButton>
              </Step>
            ))}
          </Stepper>
        </Box>
      )}

      <Box sx={{ flex: 1, overflow: 'auto', padding: "24px 24px 16px 24px" }}>
        {viewMode ? (
          activeViewTab === 'scm' ? (
            <Box sx={{ pt: 2 }}>
              <ScmTab name={name || ''} type="assignment" />
            </Box>
          ) : (
            <Grid container spacing={3}>
              <Grid item xs={12} lg={7}>
                <ReviewCard
                  title="Basic Information"
                  onEdit={() => { setViewMode(false); requestStepChange(0) }}
                  rows={[
                    { label: 'Assignment Name', value: name || '—' },
                    { label: 'Assignment Type', value: assignmentType || '—' },
                    { label: 'Priority', value: priority || '—' },
                    { label: 'Execution Mode', value: executionMode },
                    { label: 'Description', value: description || '—' },
                    // { label: 'Tags', value: tags.length ? tags.join(', ') : '—' },
                    {
                      label: 'Tags',
                      value: tags.length ? (
                        <Stack
                          direction="row"
                          spacing={1}
                          useFlexGap
                          flexWrap="wrap"
                          sx={{ maxWidth: '100%' }}
                        >
                          {tags.map((tag, index) => (
                            <Tooltip key={`${tag}-${index}`} title={tag} arrow>
                              <Chip
                                label={tag}
                                size="small"
                                sx={{
                                  maxWidth: 200,

                                  borderRadius: '16px',
                                  bgcolor: '#eef2ff',
                                  color: '#667085',
                                  fontSize: '12px',
                                  fontWeight: 500,
                                  cursor: "pointer",
                                  '& .MuiChip-label': {
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                    whiteSpace: 'nowrap',
                                  },
                                }}
                              />
                            </Tooltip>
                          ))}
                        </Stack>
                      ) : (
                        '—'
                      ),
                    },
                  ]}
                />
                <ReviewCard
                  title="Policy Selection"
                  onEdit={() => { setViewMode(false); requestStepChange(1) }}
                  rows={[
                    { label: 'Selected Policies', value: selectedPolicies.map((p) => p.name).join(', ') || '—' },
                  ]}
                />
                <ReviewCard
                  title="Target Selection"
                  onEdit={() => { setViewMode(false); requestStepChange(2) }}
                  rows={[
                    { label: 'Target Mode', value: TARGET_MODE_LABEL[targetMode] },
                    { label: 'Selected Targets', value: targetMode === 'global' ? 'All Servers' : targetMode === 'serverGroup' ? `${selectedServerGroupIds.length} group(s)` : (selectedTargets.length ? `${selectedTargets.length} server(s)` : '—') },
                  ]}
                />
                <ReviewCard
                  title="Deployment Strategy"
                  onEdit={() => { setViewMode(false); requestStepChange(3) }}
                  rows={[
                    { label: 'Strategy', value: ({ immediate: 'Immediate', scheduled: 'Scheduled', incremental: 'Incremental', stageBased: 'Stage-Based', approvalGated: 'Approval-Gated' } as Record<string, string>)[deploymentStrategy] ?? deploymentStrategy },
                  ]}
                />
              </Grid>
              <Grid item xs={12} lg={5}>
                <Paper elevation={0} sx={{ ...CARD_SX, height: 'auto' }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                    <Typography variant="subtitle1" fontWeight={700} color="#0f172a">Policy</Typography>
                    <IconButton size="small" onClick={() => { setViewMode(false); requestStepChange(1) }} sx={{ color: '#64748b' }}><Pencil size={15} /></IconButton>
                  </Box>
                  {selectedPolicies.map((policy) => (
                    <Box key={policy.id} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, p: 1.5, border: "1px solid #F2F2F2", borderRadius: '8px', mb: 1 }}>
                      <FileText size={18} color="#2563eb" />
                      <Box flex={1}>
                        <Typography variant="body2" fontWeight={600}>{policy.name}</Typography>
                        <Box display="flex" gap={1} alignItems="center">
                          <Typography variant="caption" color="text.secondary">{`Version: ${policy.versionNumber ?? '1.0.0'}`}</Typography>
                        </Box>
                      </Box>
                    </Box>
                  ))}
                </Paper>
              </Grid>
            </Grid>
          )
        ) : renderStepContent()}
      </Box>

      {!viewMode && !isReviewStep && (
        <Box sx={{ bgcolor: 'white', borderTop: '1px solid #e2e8f0', px: 3, py: 2, display: 'flex', justifyContent: 'flex-end', gap: 1.5 }}>
          {activeStep > 0 && (
            <Button onClick={handlePrevious} sx={{ borderColor: '#e2e8f0', color: '#2961F4', textTransform: 'none', fontWeight: 500, px: 2.5 }}>
              Previous
            </Button>
          )}
          <Button variant="contained" disabled={!isCurrentStepValid()} onClick={handleNext} sx={{ textTransform: 'none', fontWeight: 500, borderRadius: "32px", padding: "6px 16px", bgcolor: '#2961F4', boxShadow: 'none', '&:hover': { bgcolor: '#1d4ed8', boxShadow: 'none' } }}>
            Next
          </Button>
        </Box>
      )}

      <Dialog
        open={confirmLeaveOpen}
        onClose={handleDismissLeaveConfirm}
        maxWidth="xs"
        fullWidth
        PaperProps={{ sx: { borderRadius: 2 } }}
      >
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            px: 2.5,
            py: 2,
            borderBottom: '1px solid #e2e8f0',
          }}
        >
          <Typography variant="subtitle1" fontWeight={700} color="#0f172a">
            Unsaved Changes
          </Typography>
          <IconButton size="small" onClick={handleDismissLeaveConfirm} sx={{ color: '#94a3b8' }}>
            <X size={18} />
          </IconButton>
        </Box>
        <DialogContent sx={{ pt: 2.5 }}>
          <Typography sx={{ fontSize: '0.85rem', color: '#64748b' }}>
            You have unsaved changes. Are you sure you want to leave? Your changes will be lost.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 2.5, pb: 2.5, gap: 1 }}>
          <Button
            onClick={handleDismissLeaveConfirm}
            variant="outlined"
            size="small"
            sx={{ textTransform: 'none', borderRadius: 1.5 }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleConfirmLeave}
            variant="contained"
            size="small"
            sx={{
              textTransform: 'none',
              borderRadius: 1.5,
              bgcolor: '#2563eb',
              '&:hover': { bgcolor: '#1d4ed8' },
            }}
          >
            Yes, Leave
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default AssignmentFormPage