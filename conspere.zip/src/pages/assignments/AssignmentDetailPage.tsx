import React, { useState } from 'react'
import {
  Box, Typography, Button, Chip, CircularProgress, Alert, Paper,
  Grid, IconButton, Dialog, DialogTitle, DialogContent,
  DialogContentText, DialogActions,
} from '@mui/material'
import { ArrowLeft, Edit2, Copy, CheckCircle } from 'lucide-react'
import { useHistory, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import dayjs from 'dayjs'
import {
  useGetAssignmentByIdQuery,
  usePublishAssignmentMutation,
  useCloneAssignmentMutation,
} from '../../redux/slices/assignmentsSlice'
import DetailSkeleton from '../../components/DetailSkeleton'
import { POLICYOPS_PATH } from '../../utils/constant'

const STATUS_COLORS: Record<string, any> = { draft: 'default', published: 'success', archived: 'error' }
const MODE_COLORS: Record<string, any> = { enforce: 'error', monitor: 'warning', audit: 'info' }

const MODE_DESCRIPTIONS: Record<string, string> = {
  audit: 'Check and log only — no remediation, no alerts',
  monitor: 'Check, log, and raise alerts — no remediation',
  enforce: 'Check and auto-remediate drift — full enforcement',
}

const formatTargetValue = (type: string, value: any): React.ReactNode => {
  if (!value) return <Typography variant="body2">—</Typography>
  if (type === 'global') return <Chip label="All servers" size="small" variant="outlined" />
  if (type === 'metadata' && typeof value === 'object') {
    return (
      <Box display="flex" gap={0.5} flexWrap="wrap">
        {Object.entries(value).map(([k, v]) => (
          <Chip key={k} label={`${k} = ${v}`} size="small" variant="outlined" />
        ))}
      </Box>
    )
  }
  if (Array.isArray(value)) {
    return (
      <Box display="flex" gap={0.5} flexWrap="wrap">
        {value.map((v: string) => <Chip key={v} label={v} size="small" variant="outlined" />)}
      </Box>
    )
  }
  return <Typography variant="body2">{String(value)}</Typography>
}

const InfoRow: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <Box display="flex" py={1.5} borderBottom="1px solid" borderColor="divider" alignItems="flex-start">
    <Typography variant="body2" color="text.secondary" sx={{ minWidth: 180, fontWeight: 500, flexShrink: 0 }}>{label}</Typography>
    <Box flex={1}>{typeof value === 'string' ? <Typography variant="body2">{value}</Typography> : value}</Box>
  </Box>
)

const AssignmentDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>()
  const history = useHistory()
  const [confirmPublish, setConfirmPublish] = useState(false)

  const { data, isLoading, isError } = useGetAssignmentByIdQuery(id, { refetchOnMountOrArgChange: true })
  const [publishAssignment, { isLoading: publishing }] = usePublishAssignmentMutation()
  const [cloneAssignment] = useCloneAssignmentMutation()

  const assignment = data?.data

  const handlePublish = async () => {
    setConfirmPublish(false)
    try { await publishAssignment(id).unwrap(); toast.success(`"${assignment.name}" published`) }
    catch { toast.error('Publish failed.') }
  }

  const handleClone = async () => {
    try { await cloneAssignment(id).unwrap(); toast.success(`"${assignment.name}" cloned as draft`) }
    catch { toast.error('Clone failed.') }
  }

  if (isLoading) return <DetailSkeleton />
  if (isError || !assignment) return <Box p={3}><Alert severity="error">Assignment not found</Alert></Box>

  return (
    <Box p={3}>
      {/* Breadcrumb */}
      <Box display="flex" alignItems="center" gap={1} mb={2}>
        <IconButton size="small" onClick={() => history.push(POLICYOPS_PATH.ASSIGNMENTS)}><ArrowLeft size={18} /></IconButton>
        <Typography variant="body2" color="text.secondary"
          sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}
          onClick={() => history.push(POLICYOPS_PATH.ASSIGNMENTS)}>Assignments</Typography>
        <Typography variant="body2" color="text.secondary">/</Typography>
        <Typography variant="body2">{assignment.name}</Typography>
      </Box>

      {/* Header */}
      <Paper elevation={0} variant="outlined" sx={{ p: 3, mb: 3, borderRadius: 2 }}>
        <Box display="flex" justifyContent="space-between" alignItems="flex-start" flexWrap="wrap" gap={2}>
          <Box>
            <Box display="flex" alignItems="center" gap={1.5} mb={1} flexWrap="wrap">
              <Typography variant="h5" fontWeight="bold">{assignment.name}</Typography>
              <Chip label={assignment.status} size="small" color={STATUS_COLORS[assignment.status] ?? 'default'} />
              <Chip label={assignment.mode} size="small" color={MODE_COLORS[assignment.mode] ?? 'default'} />
              <Chip label={`v${assignment.version}`} size="small" variant="outlined" />
            </Box>
            <Typography variant="body2" color="text.secondary" mb={0.5}>{assignment.description}</Typography>
            <Typography variant="caption" color="text.secondary" sx={{ fontStyle: 'italic' }}>
              {MODE_DESCRIPTIONS[assignment.mode]}
            </Typography>
          </Box>
          <Box display="flex" gap={1} flexWrap="wrap">
            {assignment.status === 'draft' && (
              <Button variant="outlined" startIcon={<Edit2 size={15} />}
                onClick={() => history.push(`${POLICYOPS_PATH.ASSIGNMENTS}/${id}/edit`)}>Edit</Button>
            )}
            <Button variant="outlined" startIcon={<Copy size={15} />} onClick={handleClone}>Clone</Button>
            {assignment.status === 'draft' && (
              <Button variant="contained" color="success" startIcon={<CheckCircle size={15} />}
                onClick={() => setConfirmPublish(true)}>Publish</Button>
            )}
          </Box>
        </Box>
      </Paper>

      {/* Details */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper elevation={0} variant="outlined" sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="subtitle2" fontWeight="bold" mb={1.5} color="text.secondary" textTransform="uppercase" letterSpacing={0.5}>
              Configuration
            </Typography>
            <InfoRow label="Assignment ID" value={assignment.assignment_id} />
            <InfoRow label="Policy Group ID" value={
              <Typography variant="body2" color="primary" sx={{ cursor: 'pointer', '&:hover': { textDecoration: 'underline' } }}
                onClick={() => history.push(`${POLICYOPS_PATH.POLICY_GROUPS}/${assignment.policy_group_id}`)}>
                {assignment.policy_group_id}
              </Typography>
            } />
            <InfoRow label="Policy Group Version" value={`v${assignment.policy_group_version}`} />
            <InfoRow label="Mode" value={<Chip label={assignment.mode} size="small" color={MODE_COLORS[assignment.mode]} />} />
            <InfoRow label="Frequency" value={`Every ${assignment.frequency} minutes`} />
            <InfoRow label="Version" value={`v${assignment.version}`} />
            <InfoRow label="Status" value={<Chip label={assignment.status} size="small" color={STATUS_COLORS[assignment.status]} />} />
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper elevation={0} variant="outlined" sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="subtitle2" fontWeight="bold" mb={1.5} color="text.secondary" textTransform="uppercase" letterSpacing={0.5}>
              Target
            </Typography>
            <InfoRow label="Target Type" value={<Chip label={assignment.target_type} size="small" variant="outlined" />} />
            <InfoRow label="Target Value" value={formatTargetValue(assignment.target_type, assignment.target_value)} />

            <Typography variant="subtitle2" fontWeight="bold" mt={3} mb={1.5} color="text.secondary" textTransform="uppercase" letterSpacing={0.5}>
              Audit
            </Typography>
            <InfoRow label="Created By" value={assignment.created_by} />
            <InfoRow label="Created At" value={dayjs(assignment.created_at).format('MMM D, YYYY HH:mm')} />
            <InfoRow label="Updated At" value={dayjs(assignment.updated_at).format('MMM D, YYYY HH:mm')} />
            <InfoRow label="Published By" value={assignment.published_by ?? '—'} />
            <InfoRow label="Published At" value={assignment.published_at ? dayjs(assignment.published_at).format('MMM D, YYYY HH:mm') : '—'} />
          </Paper>
        </Grid>
      </Grid>

      <Dialog open={confirmPublish} onClose={() => setConfirmPublish(false)} maxWidth="xs" fullWidth>
        <DialogTitle>Publish Assignment</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Publish "{assignment.name}"? The policy group must be published. Agents will start receiving this assignment on their next sync.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmPublish(false)}>Cancel</Button>
          <Button onClick={handlePublish} variant="contained" color="success" disabled={publishing}>Publish</Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default AssignmentDetailPage
