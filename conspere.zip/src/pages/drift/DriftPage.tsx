import React, { useCallback, useEffect, useMemo, useState } from 'react'
import {
  Box,
  Button,
  Checkbox,
  Chip,
  Grid,
  IconButton,
  InputAdornment,
  Menu,
  MenuItem,
  Paper,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material'
import moment from 'moment'
import {
  Activity,
  AlertTriangle,
  Columns3,
  List,
  // Download,
  RefreshCw,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Timer,
} from 'lucide-react'
import { toast } from 'react-toastify'
import {
  useGetDriftExecutionDataQuery,
  useGetDriftLogFiltersQuery,
  useGetDriftExecutionMetricsQuery,
  usePostCommandLogsMutation,
} from '../../redux/slices/complianceSlice'
import DriftLogDialog, {
  buildDriftDetailsFromRow,
  DriftRowDetailsDialog,
  mapCommandLogsToTimeline,
  parseDriftLogMetrics,
  resolveCommandLogPayload,
} from '../../components/DriftLogDialog'
import ListFilterPopover, { FilterFieldConfig } from '../../components/ListFilterPopover'
import PolicyTable, { TableColumn } from '../../components/PolicyTable'
import { useDebouncedValue } from '../../components/useDebouncedValue'

type DriftLogRow = Record<string, any>
type LogView = 'execution' | 'drift'

const pickValue = (row: DriftLogRow, ...keys: string[]): any => {
  for (const key of keys) {
    if (row[key] !== undefined && row[key] !== null && row[key] !== '') return row[key]
  }
  return null
}

const toTitle = (key: string): string =>
  key
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())

const DRIFT_FILTER_KEYS = [
  'hostname',
  'ruleId',
  'ruleName',
  'ruleType',
  'policyId',
  'policyName',
  'severity',
  'executionStatus',
  'businessUnit',
  'assignmentName',
  'assignmentId',
  'filePath',
  'serviceName',
  'environment',
  'actionTaken',
] as const

type DriftFilterKey = typeof DRIFT_FILTER_KEYS[number]

interface DriftFilters {
  [key: string]: string
}

const DRIFT_FILTER_LABELS: Record<DriftFilterKey, string> = {
  hostname: 'Hostname',
  ruleId: 'Rule ID',
  ruleName: 'Rule Name',
  ruleType: 'Rule Type',
  policyId: 'Policy ID',
  policyName: 'Policy Name',
  severity: 'Severity',
  executionStatus: 'Execution Status',
  businessUnit: 'Business Unit',
  assignmentName: 'Assignment Name',
  assignmentId: 'Assignment ID',
  filePath: 'File Path',
  serviceName: 'Service Name',
  environment: 'Environment',
  actionTaken: 'Action Taken',
}

const EMPTY_DRIFT_FILTERS: DriftFilters = Object.fromEntries(
  DRIFT_FILTER_KEYS.map((key) => [key, '']),
)

interface DriftColumnDef {
  id: string
  label: string
  aliases: string[]
}

const DEFAULT_DRIFT_COLUMNS: DriftColumnDef[] = [
  { id: 'action', label: 'Action', aliases: ['action'] },
  { id: 'hostname', label: 'Hostname', aliases: ['hostname', 'host', 'target'] },
  { id: 'timestampRealtime', label: 'Timestamp Realtime', aliases: ['timestampRealtime', 'timestamp_realtime', 'timestamprealtime', 'timestamp', 'time'] },
  { id: 'ruleName', label: 'Rule Name', aliases: ['ruleName', 'rule_name', 'rulename'] },
  { id: 'ruleType', label: 'Rule Type', aliases: ['ruleType', 'rule_type', 'ruletype'] },
  { id: 'policyName', label: 'Policy Name', aliases: ['policyName', 'policy_name', 'policyname'] },
  { id: 'message', label: 'Message', aliases: ['message'] },
  { id: 'executionStatus', label: 'Execution Status', aliases: ['executionStatus', 'execution_status', 'executionstatus', 'status'] },
  { id: 'assignmentName', label: 'Assignment Name', aliases: ['assignmentName', 'assignment_name', 'assignmentname', 'assignment'] },
  { id: 'filepath', label: 'Filepath', aliases: ['filepath', 'filePath', 'file_path', 'path'] },
  { id: 'serviceName', label: 'Service Name', aliases: ['serviceName', 'service_name', 'servicename', 'service'] },
  { id: 'username', label: 'Username', aliases: ['username', 'user_name', 'userName', 'user'] },
  { id: 'artifact', label: 'Artifact Name', aliases: ['artifact', 'artifactName', 'artifact_name'] },
  { id: 'driftDetected', label: 'Drift Detected', aliases: ['driftDetected', 'drift_detected', 'driftdetect', 'driftDetect'] },
  { id: 'actionTaken', label: 'Action Taken', aliases: ['actionTaken', 'action_taken', 'actiontaken'] },
  { id: 'realtime', label: 'Realtime', aliases: ['realtime', 'isRealtime', 'is_realtime'] },
]

const DEFAULT_COLUMN_IDS = DEFAULT_DRIFT_COLUMNS.map((column) => column.id)

const isDefaultVisibleColumn = (columnId: string): boolean =>
  DEFAULT_COLUMN_IDS.includes(columnId)

const DEFAULT_COLUMN_ALIAS_SET = new Set(
  DEFAULT_DRIFT_COLUMNS.flatMap((column) => [column.id, ...column.aliases].map((key) => key.toLowerCase())),
)

const getColumnDef = (columnId: string): DriftColumnDef | undefined =>
  DEFAULT_DRIFT_COLUMNS.find((column) => column.id === columnId)

const getColumnLabel = (columnId: string): string =>
  getColumnDef(columnId)?.label ?? toTitle(columnId)

const getColumnValue = (row: DriftLogRow, columnId: string): any => {
  const def = getColumnDef(columnId)
  if (def) return pickValue(row, columnId, ...def.aliases)
  return row[columnId]
}

const formatCell = (value: any): string => {
  if (value === null || value === undefined || value === '') return '-'
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}

const isTimestampKey = (key: string): boolean => {
  const normalized = key.toLowerCase().replace(/_/g, '')
  return (
    normalized === 'timestamp'
    || normalized === 'time'
    || normalized.startsWith('timestamp')
    || normalized.endsWith('timestamp')
    || normalized === 'createdat'
    || normalized === 'updatedat'
    || normalized === 'eventtime'
  )
}

const formatTimestamp = (value: any): string | null => {
  if (value === null || value === undefined || value === '') return null
  const m = moment(value)
  if (!m.isValid()) return null
  return m.local().format('DD MMM, YYYY | hh:mm A')
}

const formatDriftCell = (key: string, value: any): string => {
  if (isTimestampKey(key)) {
    return formatTimestamp(value) ?? formatCell(value)
  }
  return formatCell(value)
}

const getDriftRowId = (row: DriftLogRow): string =>
  String(
    pickValue(row, 'executionId', 'execution_id', '_id', 'id')
    ?? [row.hostname, row.timestamp, row.ruleId].map(formatCell).join('-'),
  )

const isSuccessStatus = (status: string) =>
  ['success', 'completed', 'fixed', 'pass', 'passed'].includes(status.toLowerCase())

const isFailedStatus = (status: string) =>
  ['failed', 'error', 'failure'].includes(status.toLowerCase())

interface DriftStatCardProps {
  label: string
  value: string | number
  valueColor?: string
  icon: React.ReactNode
  iconColor: string
  iconBg: string
}

const DriftStatCard: React.FC<DriftStatCardProps> = ({
  label,
  value,
  valueColor = '#0f172a',
  icon,
  iconColor,
  iconBg,
}) => (
  <Paper
    elevation={0}
    sx={{
      p: 2.5,
      borderRadius: '10px',
      border: '1px solid #e2e8f0',
      bgcolor: 'white',
      boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
      height: '100%',
    }}
  >
    <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1.5}>
      <Typography variant="caption" color="#05060F99" fontSize="14px" fontWeight={400} fontFamily='JohnsonDisplay'>{label}</Typography>
      <Box
        sx={{
          width: 36,
          height: 36,
          borderRadius: '8px',
          bgcolor: iconBg,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}
      >
        <Box sx={{ color: iconColor, display: 'flex' }}>{icon}</Box>
      </Box>
    </Box>
    <Typography variant="h5" fontWeight={700} fontFamily='JohnsonText' color={valueColor}>
      {typeof value === 'number' ? value.toLocaleString() : value}
    </Typography>
  </Paper>
)

const ActionBadge: React.FC<{ action: string }> = ({ action }) => (
  <Chip
    label={action}
    size="small"
    sx={{
      height: 24,
      fontSize: '0.72rem',
      fontWeight: 600,
      bgcolor: '#eff6ff',
      color: '#2563eb',
      borderRadius: '6px',
      '& .MuiChip-label': { px: 1 },
    }}
  />
)

const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const normalized = status.toLowerCase()
  const success = isSuccessStatus(normalized)
  const failed = isFailedStatus(normalized)

  return (
    <Chip
      label={status}
      size="small"
      sx={{
        height: 24,
        fontSize: '0.72rem',
        fontWeight: 600,
        borderRadius: '999px',
        bgcolor: success ? '#dcfce7' : failed ? '#fee2e2' : '#f1f5f9',
        color: success ? '#15803d' : failed ? '#dc2626' : '#64748b',
        '& .MuiChip-label': { px: 1.25 },
      }}
    />
  )
}

const LOG_TOGGLE_SX = {
  display: 'inline-flex',
  bgcolor: '#f8fafc',
  borderRadius: '999px',
  border: '1px solid #e2e8f0',
  p: 0.5,
  gap: 0.5,
}

const logToggleBtnSx = (active: boolean) => ({
  textTransform: 'none' as const,
  fontWeight: 600,
  fontSize: '0.8125rem',
  borderRadius: '999px',
  px: 2.5,
  py: 0.75,
  minWidth: 140,
  boxShadow: 'none',
  bgcolor: active ? '#2563eb' : 'transparent',
  color: active ? '#ffffff' : '#64748b',
  '&:hover': {
    bgcolor: active ? '#1d4ed8' : '#f1f5f9',
    boxShadow: 'none',
  },
})

const DriftPage: React.FC = () => {
  const [logView, setLogView] = useState<LogView>('execution')
  const [search, setSearch] = useState('')
  const debouncedSearch = useDebouncedValue(search, 400)
  const [appliedFilters, setAppliedFilters] = useState<DriftFilters>(EMPTY_DRIFT_FILTERS)
  const [draftFilters, setDraftFilters] = useState<DriftFilters>(EMPTY_DRIFT_FILTERS)
  const [page, setPage] = useState(0)
  const [pageSize, setPageSize] = useState(25)
  const [filterAnchor, setFilterAnchor] = useState<HTMLElement | null>(null)
  const [columnsAnchor, setColumnsAnchor] = useState<HTMLElement | null>(null)
  const [columnVisibility, setColumnVisibility] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(DEFAULT_COLUMN_IDS.map((key) => [key, true])),
  )
  const [logDialogRow, setLogDialogRow] = useState<DriftLogRow | null>(null)
  const [detailRow, setDetailRow] = useState<DriftLogRow | null>(null)
  const [commandTimelineError, setCommandTimelineError] = useState('')

  const executionRequestFilters = useMemo(() => {
    const filters: Record<string, string | boolean> = {}

    const searchValue = debouncedSearch.trim()
    if (searchValue) filters.search = searchValue
    if (logView === 'drift') filters.driftDetected = true

    DRIFT_FILTER_KEYS.forEach((key) => {
      const value = appliedFilters[key]?.trim()
      if (value) filters[key] = value
    })

    return filters
  }, [debouncedSearch, appliedFilters, logView])

  const { data: filterOptionsResponse } = useGetDriftLogFiltersQuery()
  const filterOptions = filterOptionsResponse?.data ?? {}

  const driftFilterFields = useMemo((): FilterFieldConfig[] =>
    DRIFT_FILTER_KEYS.map((key) => ({
      key,
      label: DRIFT_FILTER_LABELS[key],
      type: 'select',
      options: (filterOptions[key] ?? []).map((value: string) => ({
        value,
        label: value,
      })),
    })),
  [filterOptionsResponse])

  const { data: metricsData, isLoading: metricsLoading, isFetching: metricsFetching, refetch: refetchMetrics } = useGetDriftExecutionMetricsQuery({
    filters: executionRequestFilters,
  })

  const [
    fetchCommandLogs,
    { data: commandLogsData, isLoading: commandLogsLoading, reset: resetCommandLogs },
  ] = usePostCommandLogsMutation()

  const commandLogPayload = useMemo(
    () => (logDialogRow ? resolveCommandLogPayload(logDialogRow) : null),
    [logDialogRow],
  )

  const commandTimelineEntries = useMemo(() => {
    if (!commandLogPayload || !commandLogsData) return []
    return mapCommandLogsToTimeline(commandLogsData)
  }, [commandLogPayload, commandLogsData])

  const commandLogsLoadingState = Boolean(logDialogRow && commandLogsLoading)

  const handleOpenLogDialog = useCallback(async (row: DriftLogRow) => {
    setLogDialogRow(row)
    setCommandTimelineError('')

    const payload = resolveCommandLogPayload(row)
    if (!payload) {
      return
    }

    try {
      await fetchCommandLogs(payload).unwrap()
    } catch {
      const message = 'Failed to load command logs'
      setCommandTimelineError(message)
      toast.error(message)
    }
  }, [fetchCommandLogs])

  const handleCloseLogDialog = useCallback(() => {
    setLogDialogRow(null)
    setCommandTimelineError('')
    resetCommandLogs()
  }, [resetCommandLogs])

  const handleOpenRowDetails = useCallback((row: DriftLogRow) => {
    setDetailRow(row)
  }, [])

  const handleCloseRowDetails = useCallback(() => {
    setDetailRow(null)
  }, [])

  const { data, isLoading, isFetching, isError, refetch } = useGetDriftExecutionDataQuery({
    page: page + 1,
    limit: pageSize,
    filters: executionRequestFilters,
  })

  const handleRefresh = useCallback(() => {
    refetch()
    refetchMetrics()
  }, [refetch, refetchMetrics])

  const rows: DriftLogRow[] = data?.data ?? []
  const total: number = data?.total ?? 0
  const tableLoading = isLoading || isFetching
  const isRefreshing = tableLoading || metricsLoading || metricsFetching

  const allColumnKeys = useMemo(() => {
    const extraSet = new Set<string>()

    rows.forEach((row) => {
      Object.keys(row).forEach((key) => {
        if (DEFAULT_COLUMN_ALIAS_SET.has(key.toLowerCase())) return
        if (!DEFAULT_COLUMN_IDS.includes(key)) extraSet.add(key)
      })
    })

    const extras = Array.from(extraSet).sort((a, b) => getColumnLabel(a).localeCompare(getColumnLabel(b)))

    return [...DEFAULT_COLUMN_IDS, ...extras]
  }, [rows])

  useEffect(() => {
    setColumnVisibility((prev) => {
      const next = { ...prev }
      let changed = false

      allColumnKeys.forEach((key) => {
        if (!(key in next)) {
          next[key] = isDefaultVisibleColumn(key)
          changed = true
        }
      })

      return changed ? next : prev
    })
  }, [allColumnKeys.join('|')])

  useEffect(() => {
    setColumnVisibility((prev) => {
      const next: Record<string, boolean> = { ...prev }
      let changed = false

      allColumnKeys.forEach((key) => {
        const defaultVisible = isDefaultVisibleColumn(key)
        if (next[key] !== defaultVisible) {
          next[key] = defaultVisible
          changed = true
        }
      })

      return changed ? next : prev
    })
  }, [debouncedSearch, appliedFilters, logView])

  const isColumnVisible = (key: string): boolean =>
    columnVisibility[key] ?? isDefaultVisibleColumn(key)

  const visibleColumnKeys = useMemo(
    () => allColumnKeys.filter((key) => {
      // Drift tab uses the icon Action column; keep API action field out of the data columns.
      if (key === 'action') return false
      return isColumnVisible(key)
    }),
    [allColumnKeys, columnVisibility],
  )

  const toggleColumn = (key: string) => {
    setColumnVisibility((prev) => ({
      ...prev,
      [key]: !(prev[key] ?? isDefaultVisibleColumn(key)),
    }))
  }

  const openFilterPopover = (anchor: HTMLElement) => {
    setDraftFilters(appliedFilters)
    setFilterAnchor(anchor)
  }

  const applyFilters = () => {
    setAppliedFilters(draftFilters)
    setPage(0)
    setFilterAnchor(null)
  }

  const clearDraftFilters = () => {
    setDraftFilters(EMPTY_DRIFT_FILTERS)
  }

  const clearAllAppliedFilters = () => {
    setAppliedFilters(EMPTY_DRIFT_FILTERS)
    setDraftFilters(EMPTY_DRIFT_FILTERS)
    setPage(0)
  }

  const removeAppliedFilter = (key: string) => {
    setAppliedFilters((prev) => ({ ...prev, [key]: '' }))
    setDraftFilters((prev) => ({ ...prev, [key]: '' }))
    setPage(0)
  }

  const handleDraftFilterChange = (key: string, value: string) => {
    setDraftFilters((prev) => ({ ...prev, [key]: value }))
  }

  const hasActiveFilters = DRIFT_FILTER_KEYS.some((key) => Boolean(appliedFilters[key]?.trim()))

  const appliedFilterTags = useMemo(() => {
    const tags: { key: string; label: string }[] = []
    DRIFT_FILTER_KEYS.forEach((key) => {
      const value = appliedFilters[key]?.trim()
      if (value) {
        tags.push({ key, label: `${DRIFT_FILTER_LABELS[key]}: ${value}` })
      }
    })
    return tags
  }, [appliedFilters])

  const parsedMetrics = parseDriftLogMetrics(metricsData)
  const metricsLoadingState = metricsLoading || metricsFetching

  const formatMetricRate = (value: number) => `${Number(value).toFixed(2)}%`

  const totalExecutions = parsedMetrics?.totalExecutions ?? 0
  const successRate = parsedMetrics?.successRate ?? 0
  const failedRate = parsedMetrics?.failedRate ?? 0
  const realtimeRate = parsedMetrics?.realtimeRate ?? 0

  const logDialogDriftDetails = useMemo(
    () => (logDialogRow ? buildDriftDetailsFromRow(logDialogRow) : []),
    [logDialogRow],
  )

  const renderColumnCell = (columnId: string, row: DriftLogRow) => {
    const value = getColumnValue(row, columnId)
    const normalizedKey = columnId.toLowerCase()

    if (/^action$/i.test(normalizedKey)) {
      const display = formatCell(value)
      return display === '-' ? display : <ActionBadge action={display} />
    }

    if (/hostname|host|target/i.test(normalizedKey)) {
      const display = formatCell(value)
      return (
        <Typography variant="body2" color="#102459" noWrap title={display}>
          {display}
        </Typography>
      )
    }

    if (/executionstatus|status/i.test(normalizedKey)) {
      const display = formatCell(value)
      return display === '-' ? display : <StatusBadge status={display} />
    }

    if (/message|filepath|assignment|policy/i.test(normalizedKey)) {
      const display = formatCell(value)
      return (
        <Typography variant="body2" color="#102459" noWrap title={display}>
          {display}
        </Typography>
      )
    }

    if (/driftdetected/i.test(normalizedKey)) {
      if (value === null || value === undefined || value === '') {
        return <Typography variant="body2" color="#37383F">-</Typography>
      }
      const display = typeof value === 'boolean' ? (value ? 'Yes' : 'No') : formatCell(value)
      return (
        <Typography variant="body2" color="#37383F" noWrap title={display}>
          {display}
        </Typography>
      )
    }

    if (isTimestampKey(normalizedKey) || isTimestampKey(columnId)) {
      const formatted = formatTimestamp(value) ?? formatCell(value)
      return (
        <Tooltip title={formatted} arrow placement="top">
          <Typography variant="body2" color="#37383F" noWrap sx={{ cursor: 'default' }}>
            {formatted}
          </Typography>
        </Tooltip>
      )
    }

    const display = formatDriftCell(columnId, value)
    return (
      <Typography variant="body2" color="#37383F" noWrap title={display}>
        {display}
      </Typography>
    )
  }

  const columns: TableColumn[] = useMemo(() => {
    const dataColumns = visibleColumnKeys.map((columnId) => {
      const isTimestampCol = isTimestampKey(columnId) || /timestamp|time/i.test(columnId)
      return {
        key: columnId,
        header: getColumnLabel(columnId),
        width: isTimestampCol ? 230 : undefined,
        minWidth: /hostname/i.test(columnId) ? 220
          : isTimestampCol ? 230
          : /message|assignment|policy|filepath/i.test(columnId) ? 200
          : 140,
        render: (row: DriftLogRow) => renderColumnCell(columnId, row),
      }
    })

    if (logView !== 'drift') {
      return dataColumns
    }

    const logsActionColumn: TableColumn = {
      key: '_logs_action',
      header: 'Action',
      width: 72,
      minWidth: 72,
      align: 'center' as const,
      render: (row: DriftLogRow) => (
        <IconButton
          size="small"
          onClick={(e) => {
            e.stopPropagation()
            handleOpenLogDialog(row)
          }}
          sx={{ color: '#64748b', '&:hover': { color: '#2563eb', bgcolor: '#eff6ff' } }}
        >
          <List size={16} />
        </IconButton>
      ),
    }

    return [logsActionColumn, ...dataColumns]
  }, [visibleColumnKeys, logView, handleOpenLogDialog])

  // const handleExport = () => {
  //   if (!rows.length) return
  //
  //   const headers = visibleColumnKeys.map(toTitle)
  //   const csvRows = rows.map((row) => (
  //     visibleColumnKeys.map((key) => {
  //       const value = formatDriftCell(key, row[key])
  //       return `"${value.replace(/"/g, '""')}"`
  //     }).join(',')
  //   ))
  //
  //   const blob = new Blob([[headers.join(','), ...csvRows].join('\n')], { type: 'text/csv;charset=utf-8;' })
  //   const url = URL.createObjectURL(blob)
  //   const link = document.createElement('a')
  //   link.href = url
  //   link.download = logView === 'drift' ? 'drift-logs.csv' : 'execution-logs.csv'
  //   link.click()
  //   URL.revokeObjectURL(url)
  // }

  return (
    <Box
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        boxSizing: "border-box",
      }}
    >
      <Paper
        elevation={0}
        sx={{
          borderRadius: "12px",
          boxShadow: "0 2px 12px rgba(15,23,42,0.04)",
          backgroundColor: "transparent",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          flex: 1,
          minHeight: 0,
        }}
      >
        <Box sx={{ flexShrink: 0, px: 3, pt: 3, pb: 2.5 }}>
          <Box display="flex" justifyContent="space-between" alignItems="flex-start" flexWrap="wrap" gap={2} mb={1}>
            <Box>
              <Typography variant="h5" fontWeight={500} color="#0f172a" mb={0.5} fontFamily="JohnsonText">
                Logs & Activity
              </Typography>
              <Typography variant="body2" fontWeight={500} color="text.secondary" sx={{ maxWidth: 720 }}>
                Unified observability for executions, drift, compliance evaluations, governance actions, and platform
                events.
              </Typography>
            </Box>
            <Box display="flex" alignItems="center" gap={1.5} flexWrap="wrap">
              <Tooltip title="Refresh" arrow>
                <IconButton
                  size="small"
                  onClick={handleRefresh}
                  disabled={isRefreshing}
                  sx={{
                    bgcolor: "white",
                    border: "1px solid #e2e8f0",
                    borderRadius: "999px",
                    "&:hover": { bgcolor: "#f8fafc" },
                  }}
                >
                  <RefreshCw size={15} color="#64748b" />
                </IconButton>
              </Tooltip>
              <TextField
                size="small"
                placeholder="Search logs"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(0);
                }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Search size={15} color="#94a3b8" />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  width: 240,
                  "& .MuiOutlinedInput-root": { borderRadius: "999px", fontSize: "0.85rem", bgcolor: "white" },
                }}
              />
              <Button
                variant="outlined"
                size="small"
                startIcon={<SlidersHorizontal size={14} />}
                onClick={(e) => openFilterPopover(e.currentTarget)}
                sx={{
                  borderRadius: "999px",
                  borderColor: hasActiveFilters ? "#93c5fd" : "#e2e8f0",
                  color: hasActiveFilters ? "#2563eb" : "#64748b",
                  bgcolor: hasActiveFilters ? "#eff6ff" : "white",
                  fontSize: "0.85rem",
                  textTransform: "none",
                }}
              >
                Filter
              </Button>
              {/* <Button
                variant="outlined"
                size="small"
                startIcon={<Download size={14} />}
                onClick={handleExport}
                sx={{ borderRadius: '999px', borderColor: '#e2e8f0', color: '#64748b', fontSize: '0.85rem', textTransform: 'none' }}
              >
                Export
              </Button> */}
              <Button
                variant="outlined"
                size="small"
                startIcon={<Columns3 size={14} />}
                onClick={(e) => setColumnsAnchor(e.currentTarget)}
                sx={{
                  borderRadius: "999px",
                  borderColor: "#e2e8f0",
                  color: "#64748b",
                  fontSize: "0.85rem",
                  textTransform: "none",
                  bgcolor: "white",
                  "&:hover": { bgcolor: "#f8fafc" },
                }}
              >
                Columns
              </Button>
            </Box>
          </Box>

          <Box sx={{ ...LOG_TOGGLE_SX, mb: appliedFilterTags.length ? 1.5 : 3 }}>
            <Button
              disableElevation
              onClick={() => {
                setLogView("execution");
                setPage(0);
              }}
              sx={logToggleBtnSx(logView === "execution")}
            >
              Execution logs
            </Button>
            <Button
              disableElevation
              onClick={() => {
                setLogView("drift");
                setPage(0);
              }}
              sx={logToggleBtnSx(logView === "drift")}
            >
              Drift Logs
            </Button>
          </Box>

          {appliedFilterTags.length > 0 && (
            <Box display="flex" alignItems="center" gap={1} flexWrap="wrap" mb={3}>
              {appliedFilterTags.map((tag) => (
                <Chip
                  key={tag.key}
                  label={tag.label}
                  size="small"
                  onDelete={() => removeAppliedFilter(tag.key)}
                  sx={{
                    height: 28,
                    fontSize: "0.75rem",
                    fontWeight: 500,
                    bgcolor: "#eff6ff",
                    color: "#1d4ed8",
                    border: "1px solid #bfdbfe",
                    "& .MuiChip-deleteIcon": {
                      color: "#64748b",
                      fontSize: 16,
                      "&:hover": { color: "#1d4ed8" },
                    },
                  }}
                />
              ))}
              <Button
                size="small"
                onClick={clearAllAppliedFilters}
                sx={{
                  textTransform: "none",
                  fontWeight: 600,
                  fontSize: "0.75rem",
                  color: "#2563eb",
                  minWidth: "auto",
                  px: 1,
                }}
              >
                Clear all
              </Button>
            </Box>
          )}

          <Grid container spacing={2} mb={1}>
            <Grid item xs={12} sm={6} md={3}>
              <DriftStatCard
                label="Total Execution"
                value={metricsLoadingState ? "—" : totalExecutions}
                icon={<Activity size={18} />}
                iconColor="#0891b2"
                iconBg="#cffafe"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DriftStatCard
                label="Success Rate"
                value={metricsLoadingState ? "—" : formatMetricRate(successRate)}
                valueColor="#15803d"
                icon={<ShieldCheck size={18} />}
                iconColor="#059669"
                iconBg="#d1fae5"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DriftStatCard
                label="Failed Rate"
                value={metricsLoadingState ? "—" : formatMetricRate(failedRate)}
                valueColor="#dc2626"
                icon={<AlertTriangle size={18} />}
                iconColor="#dc2626"
                iconBg="#fee2e2"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DriftStatCard
                label="Realtime Rate"
                value={metricsLoadingState ? "—" : formatMetricRate(realtimeRate)}
                valueColor="#2563eb"
                icon={<Timer size={18} />}
                iconColor="#2563eb"
                iconBg="#dbeafe"
              />
            </Grid>
          </Grid>
        </Box>

        <Box
          sx={{
            flex: 1,
            minHeight: 0,
            overflowY: "auto",
            px: 3,
            pb: 3,
            pr: 2.5,
          }}
        >
          <PolicyTable
            key={logView}
            columns={columns}
            rows={rows}
            total={total}
            page={page}
            pageSize={pageSize}
            onPageChange={setPage}
            onPageSizeChange={(size) => {
              setPageSize(size);
              setPage(0);
            }}
            rowsPerPageOptions={[25, 50, 100, 200]}
            loading={tableLoading}
            error={isError}
            errorMessage="Failed to load logs"
            emptyMessage="No results"
            getRowId={getDriftRowId}
            onRowClick={handleOpenRowDetails}
            sx={{ borderRadius: "10px" }}
          />
        </Box>
      </Paper>

      <ListFilterPopover
        open={Boolean(filterAnchor)}
        anchorEl={filterAnchor}
        onClose={() => setFilterAnchor(null)}
        fields={driftFilterFields}
        draftValues={draftFilters}
        onDraftChange={handleDraftFilterChange}
        onApply={applyFilters}
        onClear={clearDraftFilters}
      />

      <Menu anchorEl={columnsAnchor} open={!!columnsAnchor} onClose={() => setColumnsAnchor(null)}>
        {allColumnKeys
          .filter((key) => key !== "action")
          .map((key) => (
            <MenuItem key={key} onClick={() => toggleColumn(key)}>
              <Checkbox size="small" checked={isColumnVisible(key)} />
              <Typography variant="body2">{getColumnLabel(key)}</Typography>
            </MenuItem>
          ))}
      </Menu>

      <DriftRowDetailsDialog open={Boolean(detailRow)} onClose={handleCloseRowDetails} row={detailRow} />

      <DriftLogDialog
        open={Boolean(logDialogRow)}
        onClose={handleCloseLogDialog}
        driftRow={logDialogRow}
        driftDetails={logDialogDriftDetails}
        timelineEntries={commandTimelineEntries}
        timelineLoading={commandLogsLoadingState}
        timelineError={commandTimelineError}
      />
    </Box>
  );
}

export default DriftPage
