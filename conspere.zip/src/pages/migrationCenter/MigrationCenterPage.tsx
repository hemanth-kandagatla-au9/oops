import React, { useState, useRef, useCallback } from 'react'
import {
  Box, Typography, Button, Grid, TextField,
  Table, TableHead, TableBody, TableRow, TableCell, LinearProgress,
} from '@mui/material'
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts'
import {
  Rocket, ChevronLeft, ChevronRight, Plus, Key, Plug, RefreshCw,
  CheckCircle2, Database, Globe, ShieldCheck, FileCode, AlertTriangle,
  XCircle, Check, Loader2, GitBranch, Send, Server, Clock, Edit2, Search,
} from 'lucide-react'
import { toast } from 'react-toastify'

type ConnState = 'awaiting' | 'scanning' | 'discovered'
type StepNum = 0 | 1 | 2 | 3 | 4 | 5
type ActionType = 'Refactor' | 'Map Resource' | 'Force Approve'

// ── Static data ───────────────────────────────────────────────────────────────

const DOMAIN_DATA = [
  { domain: 'Linux OS', rate: 98 },
  { domain: 'Database', rate: 88 },
  { domain: 'Security', rate: 91 },
  { domain: 'Middleware', rate: 85 },
  { domain: 'App Logic', rate: 78 },
]

const WAVE_DATA = [
  { wave: 'Wave 1', migrated: 1200 },
  { wave: 'Wave 2', migrated: 2800 },
  { wave: 'Wave 3', migrated: 5100 },
  { wave: 'Wave 4', migrated: 7800 },
  { wave: 'Wave 5', migrated: 9248 },
]

const COOKBOOKS = [
  { id: 'linux-nginx',  label: 'linux-nginx',  score: 92, scoreColor: '#10b981', scoreBg: '#ecfdf5', scoreBorder: '#a7f3d0' },
  { id: 'apache-web',   label: 'apache-web',   score: 90, scoreColor: '#10b981', scoreBg: '#ecfdf5', scoreBorder: '#a7f3d0' },
  { id: 'oracle-db',    label: 'oracle-db',    score: 75, scoreColor: '#d97706', scoreBg: '#fffbeb', scoreBorder: '#fde68a' },
  { id: 'sap-platform', label: 'sap-platform', score: 68, scoreColor: '#d97706', scoreBg: '#fffbeb', scoreBorder: '#fde68a' },
]

const BLUEPRINTS = [
  { file: 'linux-web-server-baseline.yml', Icon: Globe, desc: 'Enforces NGINX server, firewall states, SSL directories. Mapped from 17 recipes.', match: 92 },
  { file: 'oracle-db-tier-hardening.yml', Icon: Database, desc: 'Locks Oracle database system memory parameters, secure users, schema rules. Mapped from 23 recipes.', match: 88 },
  { file: 'cis-level1-os-hardening.yml', Icon: ShieldCheck, desc: 'Applies system file permissions, PAM configurations, SSH configurations per CIS L1 benchmarks. Mapped from 31 recipes.', match: 91 },
]

const VAL_ROWS: Array<{ source: string; scope: string; warning: string; severity: 'warning' | 'error'; confidence: number; action: ActionType }> = [
  { source: 'oracle-db',         scope: 'Cookbook', warning: 'Ruby loop pattern requires custom parsing',       severity: 'warning', confidence: 45, action: 'Refactor' },
  { source: 'sap-platform',      scope: 'Cookbook', warning: 'Unrecognized system resource call (LWRP)',         severity: 'error',   confidence: 38, action: 'Map Resource' },
  { source: 'legacy-monitoring', scope: 'Cookbook', warning: 'Ambiguous system state match (Review attributes)', severity: 'warning', confidence: 50, action: 'Force Approve' },
]

const STEP_LABELS = ['Source Integration', 'AI Transpilation', 'Blueprints', 'Review', 'SCM Export']

// ── Stepper Bar ───────────────────────────────────────────────────────────────

const StepperBar: React.FC<{ step: number; onAbort: () => void }> = ({ step, onAbort }) => (
  <Box sx={{ bgcolor: 'white', borderBottom: '1px solid #e2e8f0', px: 4, py: 1.5, display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0, boxShadow: '0 1px 4px rgba(0,0,0,0.05)' }}>
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
      <Rocket size={22} color="#1d4ed8" />
      <Box>
        <Typography sx={{ fontSize: '0.9rem', fontWeight: 700, color: '#111827', lineHeight: 1.2 }}>Migration Workspace</Typography>
        <Typography sx={{ fontSize: '0.72rem', color: '#6b7280', fontWeight: 500 }}>Chef Cookbook Migration Wave</Typography>
      </Box>
    </Box>

    <Box sx={{ flex: 1, maxWidth: 680, display: 'flex', alignItems: 'center', mx: 4, minWidth: 0 }}>
      {STEP_LABELS.map((label, i) => {
        const num = i + 1
        const done = step > num
        const active = step === num
        return (
          <React.Fragment key={label}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, flexShrink: 0 }}>
              <Box sx={{
                width: 30, height: 30, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 600, fontSize: '0.78rem', transition: 'all 0.2s', flexShrink: 0,
                ...(done   ? { bgcolor: '#10b981', color: 'white', border: '2px solid #10b981' }
                  : active ? { bgcolor: '#3b82f6', color: 'white', border: '2px solid #3b82f6', boxShadow: '0 0 0 4px rgba(59,130,246,0.15)' }
                           : { bgcolor: 'white', color: '#9ca3af', border: '2px solid #d1d5db' }),
              }}>
                {done ? <Check size={13} /> : num}
              </Box>
              <Typography sx={{ fontSize: '0.78rem', fontWeight: active ? 600 : 500, color: active ? '#111827' : '#6b7280', whiteSpace: 'nowrap' }}>
                {label}
              </Typography>
            </Box>
            {i < STEP_LABELS.length - 1 && (
              <Box sx={{ flex: 1, minWidth: 16, maxWidth: 48, height: 2, bgcolor: done ? '#10b981' : '#e2e8f0', mx: 1, transition: 'background-color 0.25s' }} />
            )}
          </React.Fragment>
        )
      })}
    </Box>

    <Button size="small" onClick={onAbort} startIcon={<XCircle size={14} />}
      sx={{ fontSize: '0.75rem', fontWeight: 600, color: '#dc2626', bgcolor: '#fef2f2', border: '1px solid #fecaca', borderRadius: '8px', textTransform: 'none', '&:hover': { bgcolor: '#fee2e2' } }}>
      Abort Wave
    </Button>
  </Box>
)

// ── Footer Navigation ─────────────────────────────────────────────────────────

const FooterNav: React.FC<{
  step: number
  onStep: (n: number) => void
  isConnected: boolean
  isPromoting: boolean
  onPromote: () => void
}> = ({ step, onStep, isConnected, isPromoting, onPromote }) => {
  const base = { borderRadius: '8px', fontWeight: 700, fontSize: '0.78rem', textTransform: 'none' as const, px: 2.5, py: 1.25 }
  const sec  = { ...base, border: '1px solid #d1d5db', color: '#374151', '&:hover': { bgcolor: '#f9fafb' } }
  const pri  = { ...base, bgcolor: '#1d4ed8', color: 'white', boxShadow: 'none', '&:hover': { bgcolor: '#1e40af', boxShadow: 'none' } }
  const suc  = { ...base, bgcolor: '#10b981', color: 'white', boxShadow: 'none', '&:hover': { bgcolor: '#059669', boxShadow: 'none' } }

  const backLabels: Record<number, string> = {
    1: 'Exit Workspace', 2: 'Connection Settings',
    3: 'Back to Code Editor', 4: 'Back to Blueprints', 5: 'Back to Validation',
  }
  const nextLabels: Record<number, string> = {
    2: 'Compile Blueprints',
    3: 'Validation & Governance',
    4: 'SCM Target Configuration',
  }

  return (
    <Box sx={{ bgcolor: 'white', borderTop: '1px solid #e2e8f0', px: 4, py: 1.5, display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0, boxShadow: '0 -2px 4px rgba(0,0,0,0.04)' }}>
      <Button variant="outlined" sx={sec} onClick={() => onStep(step - 1)} startIcon={<ChevronLeft size={14} />}>
        {backLabels[step]}
      </Button>

      <Box>
        {step === 1 && (isConnected
          ? <Button variant="contained" sx={pri} onClick={() => onStep(2)} endIcon={<ChevronRight size={14} />}>Proceed to Code Transpilation</Button>
          : <Button variant="contained" disabled sx={{ ...base, boxShadow: 'none' }}>Awaiting Connection</Button>
        )}
        {(step === 2 || step === 3 || step === 4) && (
          <Button variant="contained" sx={pri} onClick={() => onStep(step + 1)} endIcon={<ChevronRight size={14} />}>
            {nextLabels[step]}
          </Button>
        )}
        {step === 5 && (
          <Button variant="contained" sx={suc} onClick={onPromote} disabled={isPromoting}
            startIcon={isPromoting ? <Loader2 size={14} style={{ animation: 'spin 1s linear infinite' }} /> : <Send size={14} />}>
            {isPromoting ? 'Merging Branch...' : 'Execute SCM Promotion'}
          </Button>
        )}
      </Box>
    </Box>
  )
}

// ── Dashboard (Step 0) ────────────────────────────────────────────────────────

const DashboardView: React.FC<{ onStart: () => void }> = ({ onStart }) => (
  <Box sx={{ flex: 1, overflowY: 'auto', p: 2.5 }}>
    <Box>

      {/* Title row */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
        <Box>
          <Typography sx={{ fontSize: '1.75rem', fontWeight: 800, color: '#0f172a', letterSpacing: '-0.02em', lineHeight: 1.2 }}>Migration Center</Typography>
          <Typography sx={{ fontSize: '0.85rem', color: '#64748b', mt: 0.5 }}>Enterprise-grade AI-powered configuration modernization cockpit.</Typography>
        </Box>
        <Button variant="contained" onClick={onStart} startIcon={<Plus size={16} />}
          sx={{ bgcolor: '#1d4ed8', boxShadow: '0 4px 14px rgba(29,78,216,0.25)', textTransform: 'none', fontWeight: 700, borderRadius: '12px', px: 2.5, py: 1.25, '&:hover': { bgcolor: '#1e40af' } }}>
          Initialize Migration Wave
        </Button>
      </Box>

      {/* Dark banner */}
      <Box sx={{ bgcolor: '#0f172a', borderRadius: '16px', p: 3, mb: 3, position: 'relative', overflow: 'hidden', border: '1px solid #1e293b' }}>
        <Box sx={{ position: 'absolute', right: -64, bottom: -64, width: 256, height: 256, bgcolor: 'rgba(37,99,235,0.1)', borderRadius: '50%', filter: 'blur(48px)', pointerEvents: 'none' }} />
        <Box sx={{ position: 'relative', zIndex: 1, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 3, flexWrap: 'wrap' }}>
          <Box sx={{ maxWidth: 380 }}>
            <Box sx={{ display: 'inline-block', bgcolor: 'rgba(37,99,235,0.2)', border: '1px solid rgba(37,99,235,0.3)', color: '#60a5fa', fontSize: '0.65rem', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', px: 1.25, py: 0.5, borderRadius: '6px', mb: 1 }}>
              System Strategy
            </Box>
            <Typography sx={{ fontSize: '1.15rem', fontWeight: 700, color: 'white', mb: 0.75 }}>Migration Factory Pipeline</Typography>
            <Typography sx={{ fontSize: '0.78rem', color: '#94a3b8', lineHeight: 1.6 }}>
              Automate declarative state transformations while keeping SCM history intact. Turn imperative cookbooks into unified ConfigSphere rules.
            </Typography>
          </Box>
          <Grid container spacing={1.5} sx={{ flex: 1, maxWidth: 560 }}>
            {[
              { val: '9,248', label: 'Source Cookbooks', color: '#60a5fa' },
              { val: '87%',   label: 'Auto Converted',   color: '#34d399' },
              { val: '10%',   label: 'AI-Assisted Review', color: '#fbbf24' },
              { val: '3%',    label: 'Manual Action',    color: '#fb7185' },
            ].map(s => (
              <Grid item xs={6} sm={3} key={s.label}>
                <Box sx={{ bgcolor: 'rgba(255,255,255,0.05)', borderRadius: '12px', p: 1.75, border: '1px solid rgba(255,255,255,0.08)', textAlign: 'center' }}>
                  <Typography sx={{ fontSize: '1.5rem', fontWeight: 900, color: s.color }}>{s.val}</Typography>
                  <Typography sx={{ fontSize: '0.6rem', fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.06em', mt: 0.5 }}>{s.label}</Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Box>
      </Box>

      {/* KPI cards */}
      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        <Grid item xs={12} md={4}>
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5, boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5 }}>
              <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Migration Progress</Typography>
              <Box sx={{ bgcolor: '#f0fdf4', color: '#16a34a', fontSize: '0.7rem', fontWeight: 600, px: 1, py: 0.25, borderRadius: '4px' }}>Active</Box>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 1, mb: 1.5 }}>
              <Typography sx={{ fontSize: '1.75rem', fontWeight: 900, color: '#0f172a' }}>8,721</Typography>
              <Typography sx={{ fontSize: '0.78rem', color: '#64748b' }}>/ 9,248 Cookbooks</Typography>
            </Box>
            <Box sx={{ bgcolor: '#f1f5f9', borderRadius: '999px', height: 6, overflow: 'hidden' }}>
              <Box sx={{ bgcolor: '#10b981', height: '100%', width: '94.3%', borderRadius: '999px' }} />
            </Box>
          </Box>
        </Grid>
        <Grid item xs={12} md={4}>
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5, boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5 }}>
              <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Declarative Assets Built</Typography>
              <Database size={18} color="#1d4ed8" />
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 1 }}>
              <Typography sx={{ fontSize: '1.75rem', fontWeight: 900, color: '#0f172a' }}>4,192</Typography>
              <Typography sx={{ fontSize: '0.78rem', color: '#64748b' }}>State Blueprints</Typography>
            </Box>
            <Typography sx={{ fontSize: '0.72rem', color: '#64748b', mt: 1 }}>Mapped across 18 system tiers.</Typography>
          </Box>
        </Grid>
        <Grid item xs={12} md={4}>
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5, boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5 }}>
              <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Operational Efficiency</Typography>
              <Clock size={18} color="#10b981" />
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 1 }}>
              <Typography sx={{ fontSize: '1.75rem', fontWeight: 900, color: '#0f172a' }}>38.4k</Typography>
              <Typography sx={{ fontSize: '0.78rem', color: '#64748b' }}>Engineer Hours Saved</Typography>
            </Box>
            <Typography sx={{ fontSize: '0.72rem', color: '#64748b', mt: 1 }}>94.3% reduction in manual effort.</Typography>
          </Box>
        </Grid>
      </Grid>

      {/* Charts */}
      <Grid container spacing={3}>
        <Grid item xs={12} lg={6}>
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '16px', p: 3, boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography sx={{ fontSize: '0.75rem', fontWeight: 700, color: '#1e293b', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Transpilation Success Rate</Typography>
              <Typography sx={{ fontSize: '0.72rem', color: '#94a3b8' }}>By Target Domain</Typography>
            </Box>
            <ResponsiveContainer width="100%" height={230}>
              <BarChart data={DOMAIN_DATA} margin={{ top: 0, right: 0, bottom: 0, left: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="domain" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip formatter={(v: number) => [`${v}%`, 'Rate']} contentStyle={{ fontSize: '0.78rem', borderRadius: 8, border: '1px solid #e2e8f0' }} />
                <Bar dataKey="rate" fill="#1d4ed8" radius={[4, 4, 0, 0]} maxBarSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </Box>
        </Grid>
        <Grid item xs={12} lg={6}>
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '16px', p: 3, boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography sx={{ fontSize: '0.75rem', fontWeight: 700, color: '#1e293b', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Historical Migration Wave Runs</Typography>
              <Typography sx={{ fontSize: '0.72rem', color: '#94a3b8' }}>Quarterly Velocity</Typography>
            </Box>
            <ResponsiveContainer width="100%" height={230}>
              <LineChart data={WAVE_DATA} margin={{ top: 0, right: 0, bottom: 0, left: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="wave" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip formatter={(v: number) => [v.toLocaleString(), 'Cookbooks']} contentStyle={{ fontSize: '0.78rem', borderRadius: 8, border: '1px solid #e2e8f0' }} />
                <Line type="monotone" dataKey="migrated" stroke="#3b82f6" strokeWidth={3} dot={{ fill: '#3b82f6', r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </Box>
        </Grid>
      </Grid>

    </Box>
  </Box>
)

// ── Step 1: Source Integration ────────────────────────────────────────────────

const Step1View: React.FC<{ connState: ConnState; scanProgress: number; onConnect: () => void }> = ({ connState, scanProgress, onConnect }) => (
  <Box sx={{ flex: 1, overflowY: 'auto', p: 2.5 }}>
    <Box sx={{ maxWidth: 900, mx: 'auto' }}>
      <Box sx={{ mb: 3 }}>
        <Typography sx={{ fontSize: '1.4rem', fontWeight: 700, color: '#0f172a', mb: 0.5 }}>Establish Configuration Source Connection</Typography>
        <Typography sx={{ fontSize: '0.85rem', color: '#64748b' }}>Connect directly to your active configuration servers or repositories to discover cookbooks and run dependencies.</Typography>
      </Box>

      <Grid container spacing={3}>
        {/* Form */}
        <Grid item xs={12} md={8}>
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '16px', p: 3, boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
            <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.08em', mb: 2, pb: 1.5, borderBottom: '1px solid #f1f5f9' }}>
              Endpoint Parameters
            </Typography>
            <Grid container spacing={2} sx={{ mb: 2 }}>
              <Grid item xs={12} sm={6}>
                <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em', mb: 0.75 }}>Integration Platform</Typography>
                <Box sx={{ bgcolor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', p: 1.25, display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Server size={16} color="#1d4ed8" />
                  <Typography sx={{ fontSize: '0.875rem', fontWeight: 700, color: '#374151' }}>Chef Infra Server</Typography>
                </Box>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em', mb: 0.75 }}>Infra Server URL</Typography>
                <TextField size="small" fullWidth defaultValue="https://enterprise-chef.internal:443"
                  sx={{ '& .MuiOutlinedInput-root': { fontSize: '0.85rem', borderRadius: '8px' } }} />
              </Grid>
            </Grid>
            <Grid container spacing={2} sx={{ mb: 3 }}>
              <Grid item xs={12} sm={6}>
                <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em', mb: 0.75 }}>Client Username / ID</Typography>
                <TextField size="small" fullWidth defaultValue="configsphere-migration-agent"
                  sx={{ '& .MuiOutlinedInput-root': { fontSize: '0.85rem', borderRadius: '8px' } }} />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em', mb: 0.75 }}>Chef Organization Key</Typography>
                <TextField size="small" fullWidth type="password" defaultValue="placeholder"
                  sx={{ '& .MuiOutlinedInput-root': { fontSize: '0.85rem', borderRadius: '8px' } }} />
              </Grid>
            </Grid>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Button variant="contained" onClick={onConnect} disabled={connState === 'scanning'} startIcon={<Key size={14} />}
                sx={{ bgcolor: '#0f172a', textTransform: 'none', fontWeight: 700, borderRadius: '8px', boxShadow: 'none', '&:hover': { bgcolor: '#1e293b', boxShadow: 'none' } }}>
                Establish Connection & Scan
              </Button>
            </Box>
          </Box>
        </Grid>

        {/* Status card */}
        <Grid item xs={12} md={4}>
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '16px', p: 3, boxShadow: '0 1px 3px rgba(0,0,0,0.04)', height: '100%', display: 'flex', flexDirection: 'column' }}>
            <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.08em', mb: 2, pb: 1.5, borderBottom: '1px solid #f1f5f9' }}>
              Integration Status
            </Typography>

            {connState === 'awaiting' && (
              <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', gap: 2, py: 3 }}>
                <Box sx={{ width: 56, height: 56, bgcolor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Plug size={24} color="#9ca3af" />
                </Box>
                <Box>
                  <Typography sx={{ fontWeight: 700, color: '#1e293b', fontSize: '0.875rem' }}>Connection Awaiting Configuration</Typography>
                  <Typography sx={{ fontSize: '0.75rem', color: '#64748b', mt: 0.5 }}>Configure endpoint parameters and click "Establish Connection & Scan".</Typography>
                </Box>
              </Box>
            )}

            {connState === 'scanning' && (
              <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2.5, py: 3 }}>
                <Box sx={{ width: 56, height: 56, bgcolor: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <RefreshCw size={24} color="#1d4ed8" style={{ animation: 'spin 1s linear infinite' }} />
                </Box>
                <Box sx={{ textAlign: 'center' }}>
                  <Typography sx={{ fontWeight: 700, color: '#1e293b', fontSize: '0.875rem' }}>Establishing API Handshake</Typography>
                  <Typography sx={{ fontSize: '0.75rem', color: '#1d4ed8', fontWeight: 600, mt: 0.5 }}>Resolving endpoint dependency tree...</Typography>
                </Box>
                <LinearProgress variant="determinate" value={scanProgress} sx={{ width: '100%', height: 8, borderRadius: '999px', bgcolor: '#f1f5f9', '& .MuiLinearProgress-bar': { bgcolor: '#1d4ed8', borderRadius: '999px' } }} />
              </Box>
            )}

            {connState === 'discovered' && (
              <Box sx={{ flex: 1 }}>
                <Box sx={{ bgcolor: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: '8px', p: 1.5, display: 'flex', alignItems: 'flex-start', gap: 1.5, mb: 2 }}>
                  <CheckCircle2 size={18} color="#16a34a" style={{ flexShrink: 0 }} />
                  <Box>
                    <Typography sx={{ fontSize: '0.8rem', fontWeight: 700, color: '#15803d' }}>Integration Established</Typography>
                    <Typography sx={{ fontSize: '0.75rem', color: '#16a34a' }}>9,248 cookbooks identified safely.</Typography>
                  </Box>
                </Box>
                {[
                  { label: 'Infrastructure Cookbooks', val: '9,248' },
                  { label: 'Orchestrated Runrecipes',  val: '31,884' },
                  { label: 'Shared Roles Detected',    val: '412' },
                  { label: 'Target Environments Found',val: '18' },
                ].map(r => (
                  <Box key={r.label} sx={{ display: 'flex', justifyContent: 'space-between', py: 1, borderBottom: '1px solid #f1f5f9' }}>
                    <Typography sx={{ fontSize: '0.78rem', color: '#64748b' }}>{r.label}</Typography>
                    <Typography sx={{ fontSize: '0.875rem', fontWeight: 700, color: '#0f172a', fontFamily: 'monospace' }}>{r.val}</Typography>
                  </Box>
                ))}
              </Box>
            )}
          </Box>
        </Grid>
      </Grid>
    </Box>
  </Box>
)

// ── Step 2: AI Transpilation ──────────────────────────────────────────────────

const Step2View: React.FC<{ selectedCb: string; onSelectCb: (id: string) => void }> = ({ selectedCb, onSelectCb }) => {
  const cb = COOKBOOKS.find(c => c.id === selectedCb) ?? COOKBOOKS[0]
  return (
    <Box sx={{ flex: 1, overflow: 'hidden', p: 2, display: 'flex', gap: 2.5 }}>
      {/* Left: file tree */}
      <Box sx={{ width: 260, flexShrink: 0, bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '12px', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <Box sx={{ p: 2, borderBottom: '1px solid #e2e8f0', bgcolor: '#f8fafc', flexShrink: 0 }}>
          <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.08em', mb: 1.5 }}>Cookbook Source File Tree</Typography>
          <Box sx={{ position: 'relative' }}>
            <Box sx={{ position: 'absolute', left: 9, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', display: 'flex' }}>
              <Search size={13} color="#9ca3af" />
            </Box>
            <input placeholder="Filter recipes..." style={{ width: '100%', background: 'white', border: '1px solid #e2e8f0', borderRadius: 8, padding: '6px 12px 6px 30px', fontSize: '0.78rem', outline: 'none', boxSizing: 'border-box' }} />
          </Box>
        </Box>
        <Box sx={{ flex: 1, overflowY: 'auto', p: 1 }}>
          {COOKBOOKS.map(c => {
            const active = selectedCb === c.id
            return (
              <Box key={c.id} onClick={() => onSelectCb(c.id)} sx={{
                p: 1.5, borderRadius: '8px', cursor: 'pointer', mb: 0.5,
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                border: '1px solid', borderColor: active ? '#bfdbfe' : 'transparent',
                bgcolor: active ? '#eff6ff' : 'transparent',
                '&:hover': { bgcolor: active ? '#eff6ff' : '#f8fafc' },
              }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <FileCode size={14} color={active ? '#1d4ed8' : '#94a3b8'} />
                  <Typography sx={{ fontSize: '0.82rem', fontWeight: active ? 700 : 500, color: active ? '#1d4ed8' : '#374151' }}>{c.label}</Typography>
                </Box>
                <Box sx={{ bgcolor: c.scoreBg, color: c.scoreColor, border: `1px solid ${c.scoreBorder}`, fontSize: '0.65rem', fontWeight: 700, px: 0.75, py: 0.25, borderRadius: '4px' }}>
                  {c.score}%
                </Box>
              </Box>
            )
          })}
        </Box>
      </Box>

      {/* Right: split code view */}
      <Box sx={{ flex: 1, bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '12px', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Header */}
        <Box sx={{ p: 2, borderBottom: '1px solid #f1f5f9', bgcolor: 'rgba(248,250,252,0.5)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
          <Box>
            <Typography sx={{ fontSize: '0.62rem', color: '#9ca3af', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Selected Resource Target</Typography>
            <Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: '#0f172a' }}>{cb.label}</Typography>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Typography sx={{ fontSize: '0.78rem', color: '#64748b' }}>Transpilation Precision Score:</Typography>
            <Typography sx={{ fontSize: '1rem', fontWeight: 900, color: '#10b981' }}>{cb.score}%</Typography>
          </Box>
        </Box>

        {/* Code split */}
        <Box sx={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', overflow: 'hidden' }}>
          {/* Source */}
          <Box sx={{ borderRight: '1px solid #f1f5f9', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <Box sx={{ bgcolor: '#f8fafc', px: 2, py: 1, borderBottom: '1px solid #f1f5f9', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
              <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Legacy Chef DSL Code</Typography>
              <Typography sx={{ fontSize: '0.65rem', fontFamily: 'monospace', color: '#64748b' }}>recipes/default.rb</Typography>
            </Box>
            <Box sx={{ flex: 1, p: 2, overflowY: 'auto', bgcolor: '#0f172a' }}>
              <Box component="pre" sx={{ m: 0, fontFamily: 'monospace', fontSize: '0.78rem', color: '#cbd5e1', lineHeight: 1.9, whiteSpace: 'pre-wrap' }}>
                <span style={{ color: '#60a5fa' }}>package</span> <span style={{ color: '#4ade80' }}>'nginx'</span> <span style={{ color: '#60a5fa' }}>do</span>{'\n  action :install\n'}<span style={{ color: '#60a5fa' }}>end</span>
                {'\n\n'}<span style={{ color: '#60a5fa' }}>service</span> <span style={{ color: '#4ade80' }}>'nginx'</span> <span style={{ color: '#60a5fa' }}>do</span>{'\n  action [:enable, :start]\n'}<span style={{ color: '#60a5fa' }}>end</span>
                {'\n\n'}<span style={{ color: '#60a5fa' }}>template</span> <span style={{ color: '#4ade80' }}>'/etc/nginx/nginx.conf'</span> <span style={{ color: '#60a5fa' }}>do</span>
                {'\n  source '}<span style={{ color: '#4ade80' }}>'nginx.conf.erb'</span>
                {'\n  notifies :reload, '}<span style={{ color: '#4ade80' }}>'service[nginx]'</span>
                {'\n'}<span style={{ color: '#60a5fa' }}>end</span>
              </Box>
            </Box>
          </Box>

          {/* Target */}
          <Box sx={{ display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <Box sx={{ bgcolor: '#f8fafc', px: 2, py: 1, borderBottom: '1px solid #f1f5f9', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
              <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Declarative State Schema Target</Typography>
              <Typography sx={{ fontSize: '0.65rem', fontFamily: 'monospace', color: '#64748b' }}>policy.yaml</Typography>
            </Box>
            <Box sx={{ flex: 1, p: 2, overflowY: 'auto', bgcolor: '#030712' }}>
              <Box component="pre" sx={{ m: 0, fontFamily: 'monospace', fontSize: '0.78rem', color: '#cbd5e1', lineHeight: 1.9, whiteSpace: 'pre-wrap' }}>
                <span style={{ color: '#fbbf24' }}>name:</span> linux-web-server-baseline{'\n'}
                <span style={{ color: '#fbbf24' }}>rules:</span>{'\n'}
                {'  - '}<span style={{ color: '#fbbf24' }}>name:</span> Ensure NGINX Present{'\n'}
                {'    '}<span style={{ color: '#fbbf24' }}>package_install:</span>{'\n'}
                {'      '}<span style={{ color: '#fbbf24' }}>name:</span> nginx{'\n'}
                {'      '}<span style={{ color: '#fbbf24' }}>state:</span> present{'\n\n'}
                {'  - '}<span style={{ color: '#fbbf24' }}>name:</span> Enforce NGINX Service State{'\n'}
                {'    '}<span style={{ color: '#fbbf24' }}>service_validation:</span>{'\n'}
                {'      '}<span style={{ color: '#fbbf24' }}>name:</span> nginx{'\n'}
                {'      '}<span style={{ color: '#fbbf24' }}>state:</span> running{'\n'}
                {'      '}<span style={{ color: '#fbbf24' }}>enabled:</span> true{'\n\n'}
                {'  - '}<span style={{ color: '#fbbf24' }}>name:</span> Templated Site Configuration{'\n'}
                {'    '}<span style={{ color: '#fbbf24' }}>file_validation:</span>{'\n'}
                {'      '}<span style={{ color: '#fbbf24' }}>path:</span> /etc/nginx/nginx.conf{'\n'}
                {'      '}<span style={{ color: '#fbbf24' }}>source:</span> nginx.conf{'\n'}
                {'      '}<span style={{ color: '#fbbf24' }}>on_drift:</span> restart_nginx
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  )
}

// ── Step 3: Blueprints ────────────────────────────────────────────────────────

const Step3View: React.FC = () => (
  <Box sx={{ flex: 1, overflowY: 'auto', p: 2.5 }}>
    <Box sx={{ maxWidth: 1000, mx: 'auto' }}>
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '16px', p: 3, boxShadow: '0 1px 3px rgba(0,0,0,0.04)', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
            <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.08em', mb: 1.5 }}>Transpilation Engine Outcome</Typography>
            <Typography sx={{ fontSize: '3rem', fontWeight: 900, color: '#1d4ed8', lineHeight: 1 }}>128</Typography>
            <Typography sx={{ fontWeight: 700, color: '#1e293b', fontSize: '0.875rem', mt: 1 }}>Unified State Blueprints Compiled</Typography>
            <Grid container spacing={1} sx={{ mt: 3, pt: 2.5, borderTop: '1px solid #f1f5f9', width: '100%' }}>
              {[{ val: '2,145', label: 'Rules' }, { val: '356', label: 'Assign' }, { val: '54', label: 'Except' }].map(s => (
                <Grid item xs={4} key={s.label}>
                  <Box sx={{ bgcolor: '#f8fafc', borderRadius: '6px', p: 1.25 }}>
                    <Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a' }}>{s.val}</Typography>
                    <Typography sx={{ fontSize: '0.6rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', color: '#94a3b8', mt: 0.25 }}>{s.label}</Typography>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </Box>
        </Grid>
        <Grid item xs={12} md={8}>
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '16px', p: 3, boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
            <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.08em', mb: 2, pb: 1.5, borderBottom: '1px solid #f1f5f9' }}>Declarative Blueprints Core Manifest</Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
              {BLUEPRINTS.map(bp => (
                <Box key={bp.file} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 1.75, border: '1px solid #f1f5f9', borderRadius: '12px', cursor: 'pointer', '&:hover': { bgcolor: '#f8fafc' }, gap: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5 }}>
                    <Box sx={{ width: 40, height: 40, bgcolor: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <bp.Icon size={18} color="#1d4ed8" />
                    </Box>
                    <Box>
                      <Typography sx={{ fontSize: '0.8rem', fontWeight: 700, color: '#0f172a' }}>{bp.file}</Typography>
                      <Typography sx={{ fontSize: '0.72rem', color: '#64748b', mt: 0.25 }}>{bp.desc}</Typography>
                    </Box>
                  </Box>
                  <Box sx={{ bgcolor: '#f0fdf4', color: '#16a34a', border: '1px solid #bbf7d0', fontSize: '0.72rem', fontWeight: 700, px: 1.25, py: 0.5, borderRadius: '6px', flexShrink: 0 }}>
                    {bp.match}% Match
                  </Box>
                </Box>
              ))}
            </Box>
          </Box>
        </Grid>
      </Grid>
    </Box>
  </Box>
)

// ── Step 4: Governance Validation ─────────────────────────────────────────────

const Step4View: React.FC = () => (
  <Box sx={{ flex: 1, overflowY: 'auto', p: 2.5 }}>
    <Box sx={{ maxWidth: 1100, mx: 'auto' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography sx={{ fontSize: '1.3rem', fontWeight: 700, color: '#0f172a' }}>Automated Validation Queue</Typography>
          <Typography sx={{ fontSize: '0.8rem', color: '#64748b', mt: 0.25 }}>Review conversions flagged with warning indices before finalizing the SCM push.</Typography>
        </Box>
        <Button variant="contained" size="small" onClick={() => toast.success('Initiating bulk approvals...')}
          sx={{ bgcolor: '#0f172a', textTransform: 'none', fontWeight: 700, borderRadius: '8px', boxShadow: 'none', '&:hover': { bgcolor: '#1e293b', boxShadow: 'none' } }}>
          Bulk Approve Verified Items
        </Button>
      </Box>

      <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '16px', overflow: 'hidden', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
        <Table>
          <TableHead>
            <TableRow sx={{ bgcolor: '#f8fafc' }}>
              {['Recipe Source', 'Class Scope', 'Parsing / Translation Warning', 'AI Confidence', 'Action Resolution'].map((h, i) => (
                <TableCell key={h} align={i === 3 ? 'center' : i === 4 ? 'right' : 'left'}
                  sx={{ fontSize: '0.65rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.07em', py: 1.5, borderBottom: '1px solid #e2e8f0' }}>
                  {h}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {VAL_ROWS.map(row => (
              <TableRow key={row.source} sx={{ '&:hover': { bgcolor: '#f8fafc' } }}>
                <TableCell sx={{ fontSize: '0.8rem', fontWeight: 600, color: '#0f172a', borderColor: '#f1f5f9' }}>{row.source}</TableCell>
                <TableCell sx={{ borderColor: '#f1f5f9' }}>
                  <Box sx={{ display: 'inline-block', bgcolor: '#f1f5f9', color: '#64748b', border: '1px solid #e2e8f0', fontSize: '0.65rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.07em', px: 1.25, py: 0.5, borderRadius: '4px' }}>
                    {row.scope}
                  </Box>
                </TableCell>
                <TableCell sx={{ borderColor: '#f1f5f9' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, fontSize: '0.78rem', fontWeight: 600, color: row.severity === 'error' ? '#dc2626' : '#d97706' }}>
                    {row.severity === 'error' ? <XCircle size={15} /> : <AlertTriangle size={15} />}
                    {row.warning}
                  </Box>
                </TableCell>
                <TableCell align="center" sx={{ fontSize: '0.82rem', fontWeight: 700, color: '#1e293b', borderColor: '#f1f5f9' }}>{row.confidence}%</TableCell>
                <TableCell align="right" sx={{ borderColor: '#f1f5f9' }}>
                  {row.action === 'Force Approve' ? (
                    <Button size="small" onClick={() => toast.success(`${row.source} added to approval queue.`)}
                      sx={{ bgcolor: '#f0fdf4', color: '#16a34a', border: '1px solid #bbf7d0', textTransform: 'none', fontWeight: 700, fontSize: '0.72rem', borderRadius: '8px', gap: 0.5, '&:hover': { bgcolor: '#dcfce7' } }}>
                      Force Approve <Check size={12} />
                    </Button>
                  ) : (
                    <Button size="small" onClick={() => toast.info(`Opening ${row.action === 'Refactor' ? 'syntax block editor' : 'custom attribute mapper'}...`)}
                      sx={{ border: '1px solid #d1d5db', color: '#374151', textTransform: 'none', fontWeight: 500, fontSize: '0.72rem', borderRadius: '8px', gap: 0.5, '&:hover': { bgcolor: '#f9fafb', borderColor: '#9ca3af' } }}>
                      {row.action} <Edit2 size={11} />
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <Box sx={{ py: 1.25, px: 3, borderTop: '1px solid #e2e8f0', bgcolor: '#f8fafc', display: 'flex', justifyContent: 'space-between' }}>
          <Typography sx={{ fontSize: '0.65rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.07em' }}>Unresolved Artifact Validation Status</Typography>
          <Typography sx={{ fontSize: '0.65rem', fontWeight: 700, color: '#64748b' }}>Showing 3 of 527 issues</Typography>
        </Box>
      </Box>
    </Box>
  </Box>
)

// ── Step 5: SCM Export ────────────────────────────────────────────────────────

const Step5View: React.FC = () => (
  <Box sx={{ flex: 1, overflowY: 'auto', p: 2.5 }}>
    <Box sx={{ maxWidth: 1000, mx: 'auto' }}>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '16px', p: 3, boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
            <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.08em', mb: 2, pb: 1.5, borderBottom: '1px solid #f1f5f9' }}>Export Batch Configuration</Typography>
            {[
              { label: 'Compiled Desired State Blueprints', val: '128' },
              { label: 'Total Declarative Configuration Rules', val: '2,145' },
              { label: 'Target Node Targeting Assignments', val: '356' },
              { label: 'Risk Mitigation Governance Waivers', val: '54' },
            ].map((r, i, arr) => (
              <Box key={r.label} sx={{ display: 'flex', justifyContent: 'space-between', py: 1.75, ...(i < arr.length - 1 ? { borderBottom: '1px solid #f1f5f9' } : {}) }}>
                <Typography sx={{ fontSize: '0.8rem', fontWeight: 500, color: '#64748b' }}>{r.label}</Typography>
                <Typography sx={{ fontSize: '0.875rem', fontWeight: 700, color: '#0f172a', fontFamily: 'monospace' }}>{r.val}</Typography>
              </Box>
            ))}
            <Box sx={{ mt: 2.5, bgcolor: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: '10px', p: 1.75, display: 'flex', alignItems: 'center', gap: 1 }}>
              <CheckCircle2 size={16} color="#16a34a" style={{ flexShrink: 0 }} />
              <Typography sx={{ fontSize: '0.78rem', fontWeight: 600, color: '#15803d' }}>Pre-flight checks passed successfully. Branch ready for merge.</Typography>
            </Box>
          </Box>
        </Grid>

        <Grid item xs={12} md={6}>
          <Box sx={{ bgcolor: 'white', border: '1px solid #e2e8f0', borderRadius: '16px', p: 3, boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
            <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.08em', mb: 2, pb: 1.5, borderBottom: '1px solid #f1f5f9' }}>Target SCM Repository</Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, bgcolor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '12px', p: 2, mb: 2.5 }}>
              <GitBranch size={28} color="#0052cc" />
              <Box>
                <Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a' }}>Bitbucket Server</Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                  <CheckCircle2 size={13} color="#16a34a" />
                  <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: '#16a34a' }}>Connected & Writable</Typography>
                </Box>
              </Box>
            </Box>
            {[
              { label: 'Repository URL',  val: 'git@bitbucket.enterprise:configsphere-main-iac', blue: false },
              { label: 'Promotion Branch', val: 'migration-wave-1', blue: true },
              { label: 'Commit Header',    val: 'chore: transpile 9,248 cookbooks into state manifests', blue: false, small: true },
            ].map((r, i, arr) => (
              <Box key={r.label} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', py: 1.5, ...(i < arr.length - 1 ? { borderBottom: '1px solid #f1f5f9' } : {}), gap: 2 }}>
                <Typography sx={{ fontSize: '0.78rem', fontWeight: 500, color: '#64748b', flexShrink: 0 }}>{r.label}</Typography>
                <Typography sx={{ fontSize: r.small ? '0.72rem' : '0.8rem', fontWeight: 700, color: r.blue ? '#1d4ed8' : '#0f172a', fontFamily: 'monospace', textAlign: 'right', wordBreak: 'break-all' }}>
                  {r.val}
                </Typography>
              </Box>
            ))}
          </Box>
        </Grid>
      </Grid>
    </Box>
  </Box>
)

// ── Main ──────────────────────────────────────────────────────────────────────

const MigrationCenterPage: React.FC = () => {
  const [step, setStep] = useState<StepNum>(0)
  const [connState, setConnState] = useState<ConnState>('awaiting')
  const [scanProgress, setScanProgress] = useState(0)
  const [selectedCb, setSelectedCb] = useState('linux-nginx')
  const [isPromoting, setIsPromoting] = useState(false)
  const scanTimer = useRef<ReturnType<typeof setInterval> | null>(null)

  const goToStep = useCallback((n: number) => setStep(n as StepNum), [])

  const startConnection = useCallback(() => {
    if (scanTimer.current) clearInterval(scanTimer.current)
    setConnState('scanning')
    setScanProgress(0)
    toast.info('Initializing connection to Chef Infra Server...')
    let prog = 0
    scanTimer.current = setInterval(() => {
      prog += 20
      setScanProgress(prog)
      if (prog === 40) toast.info('Resolving cookbook dependency graphs...')
      if (prog === 80) toast.info('Parsing Ruby AST syntax trees...')
      if (prog >= 100) {
        clearInterval(scanTimer.current!)
        setConnState('discovered')
        toast.success('Discovery complete. 9,248 cookbooks successfully scanned!')
      }
    }, 800)
  }, [])

  const handlePromote = useCallback(() => {
    setIsPromoting(true)
    toast.info('Committing declarative manifests to target Bitbucket Repository...')
    setTimeout(() => {
      toast.success('PR compiled, checked for drift, and safely committed.')
      setTimeout(() => {
        toast.success('CI Pipeline triggered: Synchronizing baseline rules onto production servers.')
        setTimeout(() => { setIsPromoting(false); goToStep(0) }, 3000)
      }, 1500)
    }, 2000)
  }, [goToStep])

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', bgcolor: '#f8fafc', overflow: 'hidden' }}>
      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>

      {step > 0 && <StepperBar step={step} onAbort={() => goToStep(0)} />}

      <Box sx={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {step === 0 && <DashboardView onStart={() => goToStep(1)} />}
        {step === 1 && <Step1View connState={connState} scanProgress={scanProgress} onConnect={startConnection} />}
        {step === 2 && <Step2View selectedCb={selectedCb} onSelectCb={cb => { setSelectedCb(cb); toast.info(`Inspecting Ruby configuration logic for ${cb}...`) }} />}
        {step === 3 && <Step3View />}
        {step === 4 && <Step4View />}
        {step === 5 && <Step5View />}
      </Box>

      {step > 0 && (
        <FooterNav step={step} onStep={goToStep} isConnected={connState === 'discovered'} isPromoting={isPromoting} onPromote={handlePromote} />
      )}
    </Box>
  )
}

export default MigrationCenterPage
