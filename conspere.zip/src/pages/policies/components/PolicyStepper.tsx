/* eslint-disable no-undef */
import { Box, Stepper, Step, StepButton, StepConnector, Typography } from '@mui/material'
import { styled } from '@mui/material/styles'
import { stepConnectorClasses } from '@mui/material/StepConnector'
import blueStepper from '../../../assets/policyStepper/policy1ststepper.svg'
import completedStepper from '../../../assets/policyStepper/completedStepper.svg'
import defaultStepper from '../../../assets/policyStepper/defaultStepper.svg'

interface Props {
  activeStep: number
  onStepClick?: (step: number) => void
}

const POLICY_STEPS = ['Basic Info', 'Rule Selection', 'Review']

const PolicyStepConnector = styled(StepConnector)(() => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 20,
    left: 'calc(-50% + 20px)',
    right: 'calc(50% + 20px)',
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 2,
    border: 0,
    backgroundColor: '#e2e8f0',
    borderRadius: 1,
  },
  [`&.${stepConnectorClasses.active} .${stepConnectorClasses.line}`]: {
    backgroundColor: '#2563eb',
  },
  [`&.${stepConnectorClasses.completed} .${stepConnectorClasses.line}`]: {
    backgroundColor: '#22c55e',
  },
}))

const PolicyStepIcon = ({ active, completed }: { active: boolean; completed: boolean }) => {
  const src = completed ? completedStepper : active ? blueStepper : defaultStepper
  return <Box component="img" src={src} sx={{ width: 32, height: 32, objectFit: 'contain' }} />
}

const PolicyStepper = ({ activeStep, onStepClick }: Props) => {
  return (
    <Box sx={{ padding: '8px 24px 24px', width: '100%' }}>
    <Stepper
      nonLinear
      activeStep={activeStep}
      alternativeLabel
      connector={<PolicyStepConnector />}
      sx={{
        maxWidth: 820,
        mx: 'auto',
        pb: 1.5,
        '& .MuiStepLabel-label': { mt: 0.75, fontSize: '0.78rem' },
      }}
    >
      {POLICY_STEPS.map((label, i) => (
        <Step key={label}>
          <StepButton
            onClick={() => onStepClick?.(i)}
            icon={<PolicyStepIcon active={i === activeStep} completed={i < activeStep} />}
          >
            <Typography
              sx={{
                fontSize: 13,
                fontWeight: i === activeStep ? 600 : 500,
                color: i === activeStep ? '#0f172a' : '#475569',
              }}
            >
              {label}
            </Typography>
          </StepButton>
        </Step>
      ))}
    </Stepper>
    </Box>
  )
}

export default PolicyStepper
