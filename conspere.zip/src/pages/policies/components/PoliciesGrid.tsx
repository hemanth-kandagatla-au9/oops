import React from 'react'
import { Box, Skeleton } from '@mui/material'
import PolicyCard from './PolicyCard'
import { Policy } from '../../../utils/enums'
import '../policies.scss'


interface Props {
  policies: Policy[]
  onDeleteSuccess?: () => void
  loadingMoreCount?: number
}

const ShimmerCard: React.FC = () => (
  <Box
    className="ps-policy-card"
    sx={{
      p: 2,
      borderRadius: '12px',
      border: '1px solid #eef2f7',
      bgcolor: '#fff',
      minHeight: 200,
    }}
  >
    <Box display="flex" justifyContent="space-between" alignItems="center" mb={1.5}>
      <Skeleton variant="rounded" width={70} height={20} />
      <Skeleton variant="circular" width={20} height={20} />
    </Box>
    <Skeleton variant="text" width="70%" height={26} />
    <Box display="flex" justifyContent="space-between" mt={2} mb={1.5}>
      <Skeleton variant="text" width="30%" />
      <Skeleton variant="text" width="20%" />
    </Box>
    <Skeleton variant="rounded" width="100%" height={28} sx={{ mb: 2 }} />
    <Box display="flex" justifyContent="space-between" alignItems="center">
      <Skeleton variant="circular" width={28} height={28} />
      <Skeleton variant="text" width="30%" />
    </Box>
  </Box>
)

const PoliciesGrid: React.FC<Props> = ({ policies, onDeleteSuccess, loadingMoreCount = 0 }) => {

  if (!policies.length && !loadingMoreCount) {
    return (
      <div className="ps-empty">
        <p>No policies found</p>
      </div>
    )
  }

  return (
    <div className="ps-grid">
      {policies.map((p) => (
        <PolicyCard key={p._id} policy={p} onDeleteSuccess={onDeleteSuccess} />
      ))}
      {loadingMoreCount > 0
        && Array.from({ length: loadingMoreCount }).map((_, i) => (
          <ShimmerCard key={`policy-shimmer-${i}`} />
        ))}
    </div>
  )
}

export default PoliciesGrid
