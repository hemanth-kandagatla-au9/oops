import React, { useState } from 'react'
import { Box, Button, IconButton, InputAdornment, TextField, Tooltip, Typography } from '@mui/material'
import { Edit2, Eye, SlidersHorizontal, Plus, Search, Trash2, CheckCircle } from 'lucide-react'
import { useHistory } from 'react-router-dom'
import { toast } from 'react-toastify'
import {
  useGetPolicyGroupsQuery,
  useArchivePolicyGroupMutation,
  usePublishPolicyGroupMutation,
} from '../../redux/slices/policyGroupsSlice'
import { POLICYOPS_PATH } from '../../utils/constant'
import { formatDateTimeDisplay } from '../../utils/dateUtils'
import PolicyTable, { TableColumn } from '../../components/PolicyTable'
import LinkCell from '../../components/LinkCell'
import ConfirmDialog from '../../components/ConfirmDialog'
import { PolicyGroup } from '../../types'

// Shared user avatar (same pattern as PoliciesPage)
const UserAvatar: React.FC<{ name: string }> = ({ name }) => (
  <Box display="flex" alignItems="center" gap={1}>
    <Box sx={{
      width: 26, height: 26, borderRadius: '50%',
      bgcolor: '#dbeafe', display: 'flex', alignItems: 'center',
      justifyContent: 'center', flexShrink: 0,
    }}>
      <Typography sx={{ fontSize: '0.6rem', fontWeight: 700, color: '#2563eb' }}>
        {name.split(/[.\s@_-]/).filter(Boolean).map((p) => p[0]?.toUpperCase()).slice(0, 2).join('')}
      </Typography>
    </Box>
    <Typography variant="body2" noWrap>{name}</Typography>
  </Box>
)

// Pill-style tab button matching the design
const PillTab: React.FC<{ label: string; active: boolean; onClick: () => void }> = ({ label, active, onClick }) => (
  <Box
    onClick={onClick}
    sx={{
      px: 2.5, py: 0.6,
      borderRadius: '999px',
      border: '1.5px solid',
      borderColor: active ? '#2563eb' : 'transparent',
      color: active ? '#2563eb' : '#64748b',
      fontWeight: active ? 600 : 400,
      fontSize: '0.85rem',
      cursor: 'pointer',
      bgcolor: active ? '#eff6ff' : 'transparent',
      transition: 'all 0.15s',
      '&:hover': { borderColor: '#2563eb', color: '#2563eb' },
      userSelect: 'none',
    }}
  >
    {label}
  </Box>
)

const PolicyGroupsPage: React.FC = () => {
  const history = useHistory()
  const [tab, setTab] = useState<'all' | 'approved'>('all')
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(0)
  const [pageSize, setPageSize] = useState(25)
  const [confirmArchive, setConfirmArchive] = useState<PolicyGroup | null>(null)
  const [confirmPublish, setConfirmPublish] = useState<PolicyGroup | null>(null)

  const statusFilter = tab === 'approved' ? 'PUBLISHED' : undefined

  const { data, isLoading, isError } = useGetPolicyGroupsQuery({
    page: page + 1, limit: pageSize,
    search: search || undefined,
    status: statusFilter,
  })

  const [archiveGroup, { isLoading: archiving }] = useArchivePolicyGroupMutation()
  const [publishGroup, { isLoading: publishing }] = usePublishPolicyGroupMutation()

  const groups: PolicyGroup[] = data?.data ?? []
  const total: number = data?.total ?? 0

  // Backend may return camelCase (groupId) and UPPERCASE status.
  const asRecord = (g: PolicyGroup) => g as unknown as Record<string, string>
  const groupId = (g: PolicyGroup): string => g._id ?? g.group_id ?? asRecord(g).groupId ?? ''
  const groupStatus = (g: PolicyGroup): string => String(g.status ?? '').toLowerCase()
  const groupCreatedBy = (g: PolicyGroup): string => g.created_by ?? asRecord(g).createdBy ?? 'Unknown'
  const groupCreatedAt = (g: PolicyGroup): string => g.created_at ?? asRecord(g).createdAt ?? ''

  const handleArchive = async () => {
    if (!confirmArchive) return
    const g = confirmArchive
    setConfirmArchive(null)
    try { await archiveGroup(groupId(g)).unwrap(); toast.success(`"${g.name}" archived`) }
    catch { toast.error('Archive failed.') }
  }

  const handlePublish = async () => {
    if (!confirmPublish) return
    const g = confirmPublish
    setConfirmPublish(null)
    try { await publishGroup(groupId(g)).unwrap(); toast.success(`"${g.name}" published`) }
    catch { toast.error('Publish failed.') }
  }

  const columns: TableColumn[] = [
    {
      key: 'name', header: 'Policy Group Name', minWidth: 220,
      render: (row: PolicyGroup) => (
        <LinkCell
          label={row.name}
          secondary={row.description}
          onClick={() => history.push(`${POLICYOPS_PATH.POLICY_GROUPS}/${groupId(row)}`)}
        />
      ),
    },
    {
      key: 'policies', header: 'Rules', width: 80,
      render: (row: PolicyGroup) => (
        <Typography variant="body2" color="text.secondary">{(row.policies ?? []).length}</Typography>
      ),
    },
    {
      key: 'created_by', header: 'Created By', width: 200,
      render: (row: PolicyGroup) => <UserAvatar name={groupCreatedBy(row)} />,
    },
    {
      key: 'created_at', header: 'Created On', width: 200,
      render: (row: PolicyGroup) => (
        <Typography variant="body2" color="text.secondary">
          {formatDateTimeDisplay(groupCreatedAt(row))}
        </Typography>
      ),
    },
    {
      key: 'actions', header: 'Action', width: 150, align: 'right',
      render: (row: PolicyGroup) => (
        <Box display="flex" gap={0.25} justifyContent="flex-end">
          <Tooltip title="Edit">
            <span>
              <IconButton size="small"
                disabled={groupStatus(row) !== 'draft'}
                onClick={(e) => { e.stopPropagation(); history.push(`${POLICYOPS_PATH.POLICY_GROUPS}/${groupId(row)}/edit`) }}
                sx={{ color: groupStatus(row) === 'draft' ? '#64748b' : '#cbd5e1' }}>
                <Edit2 size={15} />
              </IconButton>
            </span>
          </Tooltip>
          <Tooltip title="View">
            <IconButton size="small" sx={{ color: '#64748b' }}
              onClick={(e) => { e.stopPropagation(); history.push(`${POLICYOPS_PATH.POLICY_GROUPS}/${groupId(row)}`) }}>
              <Eye size={15} />
            </IconButton>
          </Tooltip>
          {groupStatus(row) === 'draft' && (
            <Tooltip title="Publish">
              <IconButton size="small" sx={{ color: '#16a34a' }}
                onClick={(e) => { e.stopPropagation(); setConfirmPublish(row) }}>
                <CheckCircle size={15} />
              </IconButton>
            </Tooltip>
          )}
          <Tooltip title="Archive">
            <span>
              <IconButton size="small"
                disabled={groupStatus(row) === 'archived'}
                onClick={(e) => { e.stopPropagation(); setConfirmArchive(row) }}
                sx={{ color: groupStatus(row) !== 'archived' ? '#64748b' : '#cbd5e1' }}>
                <Trash2 size={15} />
              </IconButton>
            </span>
          </Tooltip>
        </Box>
      ),
    },
  ]

  return (
    <Box p={3}>
      {/* Pill tabs — above the header row */}
      <Box display="flex" gap={1} mb={2.5}>
        <PillTab label="All" active={tab === 'all'} onClick={() => { setTab('all'); setPage(0) }} />
        <PillTab label="Approved" active={tab === 'approved'} onClick={() => { setTab('approved'); setPage(0) }} />
      </Box>

      {/* Header row — title left, search + filter + CTA right */}
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={0.75}>
        <Box>
          <Box display="flex" alignItems="center" gap={1}>
            <Typography variant="h5" fontWeight={700}>Policy Group</Typography>
            <Box sx={{ px: 1, py: 0.15, bgcolor: '#eff6ff', borderRadius: '999px', border: '1px solid #dbeafe' }}>
              <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: '#2563eb' }}>{total}</Typography>
            </Box>
          </Box>
        </Box>
        <Box display="flex" alignItems="center" gap={1.5}>
          <TextField
            size="small"
            placeholder="Search"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(0) }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search size={15} color="#94a3b8" />
                </InputAdornment>
              ),
            }}
            sx={{ width: 200, '& .MuiOutlinedInput-root': { borderRadius: '16px', fontSize: '0.85rem' } }}
          />
          <Button
            variant="outlined" size="small"
            startIcon={<SlidersHorizontal size={14} />}
            sx={{ borderColor: '#e2e8f0', color: '#64748b', fontSize: '0.85rem' }}
          >
            Filter
          </Button>
          <Button
            variant="contained" size="small"
            startIcon={<Plus size={14} />}
            onClick={() => history.push(`${POLICYOPS_PATH.POLICY_GROUPS}/new`)}
            sx={{ bgcolor: '#2563eb', fontSize: '0.85rem', '&:hover': { bgcolor: '#1d4ed8' } }}
          >
            New Policy Group
          </Button>
        </Box>
      </Box>

      <Typography variant="body2" color="text.secondary" mb={2.5}>
        Deploy and manage policies across global, environment, region or Target Group scopes
      </Typography>

      <PolicyTable
        columns={columns} rows={groups} total={total}
        page={page} pageSize={pageSize}
        onPageChange={setPage} onPageSizeChange={(s) => { setPageSize(s); setPage(0) }}
        loading={isLoading} error={isError} errorMessage="Failed to load policy groups"
      />

      <ConfirmDialog
        open={!!confirmArchive}
        title="Archive Policy Group"
        message={`Archive "${confirmArchive?.name}"? It will be unavailable for new assignments.`}
        confirmLabel="Archive"
        confirmColor="warning"
        loading={archiving}
        onConfirm={handleArchive}
        onClose={() => setConfirmArchive(null)}
      />

      <ConfirmDialog
        open={!!confirmPublish}
        title="Publish Policy Group"
        message={`Publish "${confirmPublish?.name}"? It will become available for assignments.`}
        confirmLabel="Publish"
        confirmColor="success"
        loading={publishing}
        onConfirm={handlePublish}
        onClose={() => setConfirmPublish(null)}
      />
    </Box>
  )
}

export default PolicyGroupsPage
