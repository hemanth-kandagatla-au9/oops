import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  Box, Button, Checkbox, Chip, CircularProgress, Dialog, DialogActions, DialogContent,
  FormControl, FormHelperText, IconButton, InputLabel,
  ListItemText, MenuItem, OutlinedInput, Paper, Select, Stack, Step, StepButton,
  StepConnector, StepLabel, Stepper, TextField, Tooltip, Typography,
} from '@mui/material'
import { styled } from '@mui/material/styles'
import { stepConnectorClasses } from '@mui/material/StepConnector'
import { ChevronLeft, Pencil, Plus, Trash2, X } from 'lucide-react'
import { useHistory, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import { POLICYOPS_PATH } from '../../utils/constant'
import {
  ServerGroupRule,
  ServerGroupRuleLogic,
  useCreateServerGroupMutation,
  useGetServerGroupByIdQuery,
  usePreviewServerGroupServersMutation,
  useUpdateServerGroupMutation,
  toPreviewGroupRules,
  parsePreviewServersResponse,
  parseGroupRulesFromApi,
  resolveServerGroupRecord,
  toServerHostnameList,
  PreviewServer,
} from '../../redux/slices/serverGroupsSlice'
import { useGetTargetServersMetadataQuery } from '../../redux/slices/targetServersSlice'
import PolicyTable, { TableColumn } from '../../components/PolicyTable'
import blueStepper from '../../assets/policyStepper/policy1ststepper.svg'
import completedStepper from '../../assets/policyStepper/completedStepper.svg'
import defaultStepper from '../../assets/policyStepper/defaultStepper.svg'
import '../rules/RulesFormPage.scss'
import { showErrorToast, showSuccessToast } from '../../utils/toastHelper'

const SERVER_GROUPS_PATH = POLICYOPS_PATH.SERVER_GROUPS
const GROUP_STEPS = ['Basic Info', 'Define Rules', 'Review']

const OPERATOR_OPTIONS = [
  { value: 'is', label: 'Is' },
  { value: 'is_not', label: 'Is Not' },
  { value: 'contains', label: 'Contains' },
  { value: 'not_contains', label: 'Not Contains' },
  { value: 'in', label: 'In' },
  { value: 'not_in', label: 'Not In' },
] as const

const MULTI_VALUE_OPERATORS = new Set(['in', 'not_in'])
const TEXT_INPUT_OPERATORS = new Set(['contains', 'not_contains'])

const GROUP_TYPE_OPTIONS = [
  { value: 'DYNAMIC', label: 'Dynamic (Rule based)' },
  { value: 'STATIC', label: 'Static (Manual)' },
] as const

const TAG_CHIP_SX = {
  borderRadius: '999px',
  bgcolor: '#eef2ff',
  color: '#667085',
  fontSize: '0.75rem',
  fontWeight: 500,
  height: 22,
  cursor: "pointer",
  maxWidth: 220,

  '& .MuiChip-label': {
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    display: 'block',
  },

}

const PREVIEW_SERVER_COLUMNS: { key: keyof PreviewServer; label: string }[] = [
  { key: 'hostname', label: 'Hostname' },
  { key: 'region', label: 'Region' },
  { key: 'environment', label: 'Environment' },
  { key: 'service', label: 'Service' },
  { key: 'sid', label: 'SID' },
  { key: 'application', label: 'Application' },
  { key: 'businessService', label: 'Business Service' },
  { key: 'owner', label: 'Owner' },
  { key: 'serverType', label: 'Server Type' },
  { key: 'os', label: 'OS' },
  { key: 'status', label: 'Status' },
  { key: 'createdDate', label: 'Created Date' },
  { key: 'lastUpdated', label: 'Last Updated' },
]

const formatPreviewDate = (value?: string): string => {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleString()
}

const formatPreviewCell = (key: keyof PreviewServer, server: PreviewServer): string => {
  const value = server[key]
  if (value === undefined || value === null || value === '') return '—'
  if (key === 'createdDate' || key === 'lastUpdated') return formatPreviewDate(String(value))
  return String(value)
}

const TruncatedCell: React.FC<{ value: string }> = ({ value }) => (
  <Tooltip title={value} arrow placement="top" disableHoverListener={value === '—'}>
    <Typography
      variant="body2"
      color="text.secondary"
      noWrap
      sx={{ overflow: 'hidden', textOverflow: 'ellipsis', display: 'block', width: '100%' }}
    >
      {value}
    </Typography>
  </Tooltip>
)

const buildPreviewColumns = (): TableColumn[] =>
  PREVIEW_SERVER_COLUMNS.map((col) => ({
    key: col.key,
    header: col.label,
    width: col.key === 'hostname' ? 200 : undefined,
    minWidth: col.key === 'hostname' ? 200 : col.key === 'businessService' ? 160 : 120,
    render: (row: PreviewServer) => (
      <TruncatedCell value={formatPreviewCell(col.key, row)} />
    ),
  }))

const GroupStepConnector = styled(StepConnector)(() => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 20,
    left: 'calc(-50% + 20px)',
    right: 'calc(50% + 20px)',
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 2,
    border: 0,
    backgroundColor: '#e2e8f0',
    borderRadius: 1,
  },
  [`&.${stepConnectorClasses.active} .${stepConnectorClasses.line}`]: {
    backgroundColor: '#2563eb',
  },
  [`&.${stepConnectorClasses.completed} .${stepConnectorClasses.line}`]: {
    backgroundColor: '#22c55e',
  },
}))

const GroupStepIcon: React.FC<{ active: boolean; completed: boolean }> = ({ active, completed }) => {
  const src = completed ? completedStepper : active ? blueStepper : defaultStepper
  return <Box component="img" src={src} sx={{ width: 36, height: 36, objectFit: 'contain' }} />
}

type FieldErrors = Record<string, string>

type GroupFormSnapshot = {
  name: string
  description: string
  tags: string[]
  groupType: string
  ruleLogic: string
  groupRules: { field: string; operator: string; values: string[] }[]
}

const ReviewRow: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <Box display="flex" py={0.75} sx={{ '&:not(:last-child)': { borderBottom: '1px solid #f8fafc' } }}>
    <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', minWidth: 200, flexShrink: 0 }}>{label}</Typography>
    <Box flex={1}>
      {typeof value === 'string'
        ? <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#0f172a' }}>{value || '-'}</Typography>
        : value}
    </Box>
  </Box>
)

const toFieldLabel = (key: string): string =>
  key
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())

const normalizeOperator = (operator: string): string => {
  const normalized = operator.trim().toLowerCase().replace(/\s+/g, '_')
  if (normalized === 'is_not' || normalized === 'isnot') return 'is_not'
  if (normalized === 'not_contains') return 'not_contains'
  if (normalized === 'not_in' || normalized === 'notin') return 'not_in'
  if (OPERATOR_OPTIONS.some((op) => op.value === normalized)) return normalized
  if (normalized === 'is') return 'is'
  return normalized
}

const normalizeRuleLogic = (logic?: string): ServerGroupRuleLogic => {
  const upper = String(logic ?? 'AND').toUpperCase()
  if (upper === 'OR' || upper === 'ANY') return 'OR'
  return 'AND'
}

const buildMetadataMap = (raw: unknown): Record<string, string[]> => {
  const source = (raw as { data?: Record<string, unknown> })?.data ?? (raw as Record<string, unknown>) ?? {}
  const map: Record<string, string[]> = {}
  Object.entries(source).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      map[key] = value.map((item) => String(item)).filter(Boolean)
    }
  })
  return map
}

const ruleValuesFromApi = (rule: {
  values?: string[] | string
  value?: string | string[] | number
}): string[] => {
  if (typeof rule.values === 'string' && rule.values.trim()) {
    return [rule.values.trim()]
  }
  if (Array.isArray(rule.values) && rule.values.length) {
    return rule.values.map(String).filter((v) => v.trim())
  }
  if (Array.isArray(rule.value)) {
    return rule.value.map(String).filter((v) => v.trim())
  }
  if (rule.value !== undefined && rule.value !== null && String(rule.value).trim() !== '') {
    return [String(rule.value)]
  }
  return []
}

const extractGroupRulesRaw = (group: Record<string, unknown>) => {
  if (Array.isArray(group.groupRules)) return group.groupRules
  if (Array.isArray(group.group_rules)) return group.group_rules
  if (Array.isArray(group.rules)) return group.rules
  return null
}

const normalizeGroupType = (raw?: unknown): 'DYNAMIC' | 'STATIC' => {
  const upper = String(raw ?? 'DYNAMIC').toUpperCase()
  return upper === 'STATIC' ? 'STATIC' : 'DYNAMIC'
}

const normalizeGroupRules = (group: Record<string, unknown>, defaultField: string): ServerGroupRule[] => {
  const rules = extractGroupRulesRaw(group) as (ServerGroupRule & { value?: string | string[] | number; values?: string[] | string })[] | null
  if (Array.isArray(rules) && rules.length) {
    return rules.map((rule) => ({
      field: rule.field ?? defaultField,
      operator: normalizeOperator(String(rule.operator ?? 'is')),
      values: ruleValuesFromApi(rule),
    }))
  }

  const legacy = group.conditions as { field?: string; operator?: string; value?: string; values?: string[] | string }[] | undefined
  if (Array.isArray(legacy) && legacy.length) {
    return legacy.map((rule) => ({
      field: rule.field ?? defaultField,
      operator: normalizeOperator(String(rule.operator ?? 'is')),
      values: ruleValuesFromApi(rule),
    }))
  }

  return [{ field: defaultField, operator: 'is', values: [] }]
}

const ruleErrKey = (index: number, part: string) => `rule-${index}-${part}`

const selectFieldSx = {
  '& .MuiOutlinedInput-root': {
    height: 40,
    boxSizing: 'border-box',
    '& .MuiSelect-select': {
      display: 'flex',
      alignItems: 'center',
      minHeight: 'unset',
      py: 0,
      overflow: 'hidden',
    },
  },
}

const textFieldSx = {
  '& .MuiOutlinedInput-root': {
    height: 40,
    boxSizing: 'border-box',
  },
}

const validateStep0 = (name: string, groupType: string): FieldErrors => {
  const errs: FieldErrors = {}
  if (!name.trim()) errs.name = 'Group name is required'
  if (!groupType) errs.groupType = 'Group type is required'
  return errs
}

const validateStep1 = (groupRules: ServerGroupRule[]): FieldErrors => {
  const errs: FieldErrors = {}
  groupRules.forEach((rule, index) => {
    if (!rule.field) errs[ruleErrKey(index, 'field')] = 'Field is required'
    else if (groupRules.some((other, otherIndex) => otherIndex !== index && other.field === rule.field)) {
      errs[ruleErrKey(index, 'field')] = 'This field already has a condition'
    }
    if (!rule.operator) errs[ruleErrKey(index, 'operator')] = 'Operator is required'
    if (!rule.values.length || !rule.values.every((v) => v.trim())) {
      errs[ruleErrKey(index, 'values')] = MULTI_VALUE_OPERATORS.has(rule.operator)
        ? 'At least one value is required'
        : 'Value is required'
    }
  })
  return errs
}

const ServerGroupFormPage: React.FC = () => {
  const history = useHistory()
  const { id } = useParams<{ id: string }>()
  const isEdit = Boolean(id) && id !== 'new'

  const [step, setStep] = useState(0)
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [tags, setTags] = useState<string[]>([])
  const [tagInput, setTagInput] = useState('')
  const [groupType, setGroupType] = useState<'DYNAMIC' | 'STATIC'>('DYNAMIC')
  const [groupRules, setGroupRules] = useState<ServerGroupRule[]>([])
  const [ruleLogic, setRuleLogic] = useState<ServerGroupRuleLogic>('AND')
  const [previewServers, setPreviewServers] = useState<PreviewServer[]>([])
  const [previewTotal, setPreviewTotal] = useState(0)
  const [previewPage, setPreviewPage] = useState(0)
  const [previewPageSize, setPreviewPageSize] = useState(10)
  const [previewError, setPreviewError] = useState('')
  const [errors, setErrors] = useState<FieldErrors>({})
  const [ruleErrors, setRuleErrors] = useState<FieldErrors>({})
  const [confirmLeaveOpen, setConfirmLeaveOpen] = useState(false)
  const [snapshotVersion, setSnapshotVersion] = useState(0)

  const initialSnapshotRef = useRef<GroupFormSnapshot | null>(null)
  const pendingNavigationRef = useRef<(() => void) | null>(null)
  const unblockHistoryRef = useRef<(() => void) | null>(null)
  const allowNavigationRef = useRef(false)

  const { data: targetMetadataData, isLoading: loadingMetadata } = useGetTargetServersMetadataQuery()
  const { data: existing, isLoading: loadingGroup, isFetching: fetchingGroup } = useGetServerGroupByIdQuery(id!, { skip: !isEdit })
  const [previewServersApi, { isLoading: previewLoading }] = usePreviewServerGroupServersMutation()
  const [createGroup, { isLoading: creating }] = useCreateServerGroupMutation()
  const [updateGroup, { isLoading: updating }] = useUpdateServerGroupMutation()

  const metadataMap = useMemo(() => buildMetadataMap(targetMetadataData), [targetMetadataData])
  const fieldOptions = useMemo(() => Object.keys(metadataMap), [metadataMap])
  const defaultField = fieldOptions[0] ?? 'region'

  // Keep latest defaultField in a ref so hydrating an existing group does not
  // depend on it (metadata loads after the group and would otherwise re-run the
  // hydration effect, wiping edits and resetting the dirty snapshot).
  const defaultFieldRef = useRef(defaultField)
  useEffect(() => {
    defaultFieldRef.current = defaultField
  }, [defaultField])

  const usedFields = useMemo(() => new Set(groupRules.map((rule) => rule.field)), [groupRules])
  const canAddRule = fieldOptions.length > groupRules.length

  const getAvailableFieldsForRule = (index: number) => {
    const usedByOthers = new Set(
      groupRules.filter((_, i) => i !== index).map((rule) => rule.field),
    )
    return fieldOptions.filter((field) => !usedByOthers.has(field))
  }

  const emptyRule = (): ServerGroupRule => {
    const nextField = fieldOptions.find((field) => !usedFields.has(field)) ?? defaultField
    return {
      field: nextField,
      operator: 'is',
      values: [],
    }
  }

  const clearErr = (key: string) => {
    setErrors((prev) => {
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  const clearRuleErr = (key: string) => {
    setRuleErrors((prev) => {
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  const getCurrentFormSnapshot = useCallback((): GroupFormSnapshot => ({
    name: name.trim(),
    description: description.trim(),
    tags: [...tags].sort(),
    groupType,
    ruleLogic,
    groupRules: groupRules.map((r: ServerGroupRule) => ({
      field: r.field,
      operator: r.operator,
      values: [...r.values].sort(),
    })),
  }), [name, description, tags, groupType, ruleLogic, groupRules])

  const isDirty = useMemo(() => {
    if (!initialSnapshotRef.current) return false
    return JSON.stringify(getCurrentFormSnapshot()) !== JSON.stringify(initialSnapshotRef.current)
  }, [getCurrentFormSnapshot, snapshotVersion])

  const clearHistoryBlock = useCallback(() => {
    unblockHistoryRef.current?.()
    unblockHistoryRef.current = null
  }, [])

  const allowHistoryNavigation = useCallback(() => {
    allowNavigationRef.current = true
  }, [])

  const requestLeave = (navigate: () => void) => {
    if (isDirty) {
      pendingNavigationRef.current = navigate
      setConfirmLeaveOpen(true)
      return
    }
    navigate()
  }

  const goToServerGroups = () =>
    requestLeave(() => {
      allowHistoryNavigation()
      history.push(SERVER_GROUPS_PATH)
    })

  const handleConfirmLeave = () => {
    const navigate = pendingNavigationRef.current
    pendingNavigationRef.current = null
    setConfirmLeaveOpen(false)
    navigate?.()
  }

  const handleDismissLeaveConfirm = () => {
    pendingNavigationRef.current = null
    setConfirmLeaveOpen(false)
  }

  useEffect(() => {
    if (!existing || !isEdit) return
    const fallbackField = defaultFieldRef.current
    const group = resolveServerGroupRecord(existing)
    const loadedName = String(group.name ?? '')
    const loadedDescription = String(group.description ?? '')
    const loadedGroupType = normalizeGroupType(group.groupType ?? group.type ?? group.group_type)
    const loadedRuleLogic = normalizeRuleLogic(String(group.ruleLogic ?? group.rule_logic ?? ''))
    const loadedTags = Array.isArray(group.tags) ? group.tags.map(String) : []
    const parsedRules = parseGroupRulesFromApi(group, fallbackField)
    const loadedRules = parsedRules.length ? parsedRules : [{ field: fallbackField, operator: 'is', values: [] }]

    setName(loadedName)
    setDescription(loadedDescription)
    setGroupType(loadedGroupType)
    setRuleLogic(loadedRuleLogic)
    setTags(loadedTags)
    setGroupRules(loadedRules)

    initialSnapshotRef.current = {
      name: loadedName.trim(),
      description: loadedDescription.trim(),
      tags: [...loadedTags].sort(),
      groupType: loadedGroupType,
      ruleLogic: loadedRuleLogic,
      groupRules: loadedRules.map((r: ServerGroupRule) => ({ field: r.field, operator: r.operator, values: [...r.values].sort() })),
    }
    setSnapshotVersion((v: number) => v + 1)
    // defaultField intentionally omitted (read via ref) so metadata loading does not re-hydrate.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [existing, isEdit])

  useEffect(() => {
    if (isEdit) return
    if (groupRules.length === 0 && defaultField) {
      setGroupRules([emptyRule()])
    }
  }, [defaultField, groupRules.length, isEdit])

  useEffect(() => {
    if (isEdit) return
    if (!initialSnapshotRef.current && groupRules.length > 0) {
      initialSnapshotRef.current = getCurrentFormSnapshot()
      setSnapshotVersion((v: number) => v + 1)
    }
  }, [isEdit, groupRules.length, getCurrentFormSnapshot])

  useEffect(() => {
    if (!isDirty) {
      clearHistoryBlock()
      return
    }

    unblockHistoryRef.current = history.block((location: { pathname: string; search?: string; hash?: string }, action: string) => {
      if (allowNavigationRef.current) {
        allowNavigationRef.current = false
        return undefined
      }

      const targetPath = `${location.pathname}${location.search ?? ''}${location.hash ?? ''}`
      const currentPath = `${history.location.pathname}${history.location.search ?? ''}${history.location.hash ?? ''}`
      if (targetPath === currentPath) {
        return undefined
      }

      pendingNavigationRef.current = () => {
        allowHistoryNavigation()
        if (action === 'POP') history.goBack()
        else history.push(targetPath)
      }
      setConfirmLeaveOpen(true)
      return false
    })

    return clearHistoryBlock
  }, [history, isDirty, clearHistoryBlock, allowHistoryNavigation])

  useEffect(() => {
    if (!isDirty) return

    const handleBeforeUnload = (event: BeforeUnloadEvent) => {
      event.preventDefault()
      event.returnValue = ''
    }

    window.addEventListener('beforeunload', handleBeforeUnload)
    return () => window.removeEventListener('beforeunload', handleBeforeUnload)
  }, [isDirty])

  const updateRule = (index: number, patch: Partial<ServerGroupRule>) => {
    setGroupRules((prev) => prev.map((rule, i) => {
      if (i !== index) return rule
      const next = { ...rule, ...patch }
      if (patch.field && patch.field !== rule.field) {
        next.values = []
        clearRuleErr(ruleErrKey(index, 'field'))
        clearRuleErr(ruleErrKey(index, 'values'))
        prev.forEach((_, otherIndex) => {
          if (otherIndex !== index) clearRuleErr(ruleErrKey(otherIndex, 'field'))
        })
      }
      if (patch.operator && patch.operator !== rule.operator) {
        const wasMulti = MULTI_VALUE_OPERATORS.has(rule.operator)
        const isMulti = MULTI_VALUE_OPERATORS.has(patch.operator)
        if (wasMulti !== isMulti) next.values = []
        clearRuleErr(ruleErrKey(index, 'operator'))
        clearRuleErr(ruleErrKey(index, 'values'))
      }
      if (patch.values) clearRuleErr(ruleErrKey(index, 'values'))
      return next
    }))
  }

  const addRule = () => {
    if (!canAddRule) {
      toast.warn('Each field can only be used once per group.')
      return
    }
    setGroupRules((prev) => [...prev, emptyRule()])
  }

  const removeRule = (index: number) => {
    setGroupRules((prev) => (prev.length <= 1 ? prev : prev.filter((_, i) => i !== index)))
    setRuleErrors((prev) => {
      const next: FieldErrors = {}
      Object.entries(prev).forEach(([key, value]) => {
        const errValue = String(value)
        const match = key.match(/^rule-(\d+)-/)
        if (!match) {
          next[key] = errValue
          return
        }
        const rowIndex = Number(match[1])
        if (rowIndex === index) return
        if (rowIndex > index) {
          const part = key.split('-').slice(2).join('-')
          next[ruleErrKey(rowIndex - 1, part)] = errValue
          return
        }
        next[key] = errValue
      })
      return next
    })
  }

  const isRuleComplete = (rule: ServerGroupRule) =>
    Boolean(rule.field && rule.operator && rule.values.length > 0 && rule.values.every((v) => v.trim()))

  const previewColumns = useMemo(() => buildPreviewColumns(), [])

  const loadPreview = useCallback(async (page: number, pageSize: number) => {
    setPreviewError('')
    try {
      const result = await previewServersApi({
        groupRules: toPreviewGroupRules(groupRules),
        ruleLogic,
        page: page + 1,
        limit: pageSize,
      }).unwrap()
      const { servers, total } = parsePreviewServersResponse(result)
      setPreviewServers(servers)
      setPreviewTotal(total)
    } catch {
      setPreviewServers([])
      setPreviewTotal(0)
      setPreviewError('Failed to load matching servers. Please try again.')
      toast.error('Failed to load matching servers')
    }
  }, [groupRules, previewServersApi, ruleLogic])

  const fetchPreviewServersForSave = useCallback(async (): Promise<PreviewServer[]> => {
    const initial = await previewServersApi({
      groupRules: toPreviewGroupRules(groupRules),
      ruleLogic,
      page: 1,
      limit: Math.max(previewTotal, previewPageSize, 10),
    }).unwrap()
    const { servers, total } = parsePreviewServersResponse(initial)
    if (total === 0) return []
    if (servers.length >= total) return servers

    const full = await previewServersApi({
      groupRules: toPreviewGroupRules(groupRules),
      ruleLogic,
      page: 1,
      limit: total,
    }).unwrap()
    return parsePreviewServersResponse(full).servers
  }, [groupRules, previewPageSize, previewServersApi, previewTotal, ruleLogic])

  const serversFromExistingGroup = useCallback((): PreviewServer[] => {
    if (!existing) return []
    const group = resolveServerGroupRecord(existing)
    const raw = group.servers ?? group.matchingServers ?? group.servers_list
    if (!Array.isArray(raw)) return []
    return raw
      .map((server) => {
        if (typeof server === 'string') return { hostname: server }
        if (server && typeof server === 'object' && 'hostname' in server) {
          return { hostname: String((server as { hostname: string }).hostname) }
        }
        return null
      })
      .filter((server): server is PreviewServer => Boolean(server?.hostname))
  }, [existing])

  const resolveServersForSave = useCallback(async (): Promise<PreviewServer[]> => {
    const preview = await fetchPreviewServersForSave()
    if (preview.length > 0) return preview
    if (isEdit) return serversFromExistingGroup()
    return []
  }, [fetchPreviewServersForSave, isEdit, serversFromExistingGroup])

  const resetPreviewPagination = () => {
    setPreviewPage(0)
  }

  const handlePreviewPageChange = (page: number) => {
    setPreviewPage(page)
    loadPreview(page, previewPageSize)
  }

  const handlePreviewPageSizeChange = (size: number) => {
    setPreviewPageSize(size)
    setPreviewPage(0)
    loadPreview(0, size)
  }

  const goNext = async () => {
    if (step === 0) {
      const errs = validateStep0(name, groupType)
      if (Object.keys(errs).length) {
        setErrors(errs)
        return
      }
      setErrors({})
      setStep(1)
      return
    }
    if (step === 1) {
      const errs = validateStep1(groupRules)
      if (Object.keys(errs).length) {
        setRuleErrors(errs)
        return
      }
      setRuleErrors({})
      resetPreviewPagination()
      setStep(2)
      await loadPreview(0, previewPageSize)
      return
    }
  }

  const goPrev = () => {
    setStep((s) => Math.max(s - 1, 0))
  }

  const handleStepClick = async (targetStep: number) => {
    if (targetStep < step) {
      setStep(targetStep)
      return
    }
    if (targetStep === step) return

    if (step === 0 && targetStep > 0) {
      const errs = validateStep0(name, groupType)
      if (Object.keys(errs).length) {
        setErrors(errs)
        return
      }
      setErrors({})
    }

    if (step === 0 && targetStep > 1) {
      const errs = validateStep1(groupRules)
      if (Object.keys(errs).length) {
        setRuleErrors(errs)
        setStep(1)
        return
      }
      setRuleErrors({})
      resetPreviewPagination()
      setStep(2)
      await loadPreview(0, previewPageSize)
      return
    }

    if (step === 1 && targetStep > 1) {
      const errs = validateStep1(groupRules)
      if (Object.keys(errs).length) {
        setRuleErrors(errs)
        return
      }
      setRuleErrors({})
      resetPreviewPagination()
      setStep(2)
      await loadPreview(0, previewPageSize)
      return
    }

    setStep(targetStep)
  }

  const buildPayload = (serversForSave: PreviewServer[] = [], groupId?: string) => ({
    ...(groupId ? { id: groupId } : {}),
    name: name.trim(),
    description: description.trim() || undefined,
    groupType,
    ruleLogic,
    groupRules,
    tags: tags.length ? tags : undefined,
    metadata: {},
    servers: toServerHostnameList(serversForSave),
  })

  const handleSave = async () => {
    const step0Errs = validateStep0(name, groupType)
    if (Object.keys(step0Errs).length) {
      setErrors(step0Errs)
      setStep(0)
      return
    }
    const step1Errs = validateStep1(groupRules)
    if (Object.keys(step1Errs).length) {
      setRuleErrors(step1Errs)
      setStep(1)
      return
    }

    try {
      const serversForSave = await resolveServersForSave()
      const payload = buildPayload(serversForSave, isEdit ? id! : undefined)
      if (isEdit) {
        await updateGroup({ id: id!, data: payload }).unwrap()
        // toast.success(`"${name}" updated successfully`)
        showSuccessToast(`"${name}" updated successfully`)
      } else {
        await createGroup(payload).unwrap()
        // toast.success(`"${name}" created successfully`)
        showSuccessToast(`"${name}" created successfully`)
      }
      allowHistoryNavigation()
      history.push(SERVER_GROUPS_PATH)
    } catch (err: any) {
      // toast.error('Failed to save Target Group. Please try again.')
      showErrorToast({
        title: isEdit
          ? `Failed to update ${name}. Please try again.`
          : `Failed to create ${name}. Please try again.`,
        message: err?.data?.message,
      })
    }
  }

  const isFormComplete = !!name.trim() && !!groupType && groupRules.every(isRuleComplete)

  const groupTypeLabel = GROUP_TYPE_OPTIONS.find((o) => o.value === groupType)?.label ?? groupType

  const renderValueInput = (rule: ServerGroupRule, index: number) => {
    const options = metadataMap[rule.field] ?? []
    const isMulti = MULTI_VALUE_OPERATORS.has(rule.operator)
    const valueErr = ruleErrors[ruleErrKey(index, 'values')]
    const valueLabel = isMulti ? 'Values *' : 'Value *'

    if (options.length > 0 && !TEXT_INPUT_OPERATORS.has(rule.operator)) {
      return (
        <FormControl size="small" fullWidth className="rule-form-field" error={!!valueErr} sx={selectFieldSx}>
          <InputLabel id={`rule-value-label-${index}`}>{valueLabel}</InputLabel>
          <Select
            labelId={`rule-value-label-${index}`}
            label={valueLabel}
            multiple={isMulti}
            value={isMulti ? rule.values : (rule.values[0] ?? '')}
            onChange={(e) => {
              const value = e.target.value
              updateRule(index, {
                values: isMulti
                  ? (typeof value === 'string' ? value.split(',') : value as string[])
                  : [String(value)],
              })
            }}
            input={isMulti ? <OutlinedInput label={valueLabel} /> : undefined}
            renderValue={isMulti
              ? (selected) => (
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {(selected as string[]).map((v) => <Chip key={v} label={v} size="small" />)}
                </Box>
              )
              : undefined}
          >
            {options.map((option) => (
              <MenuItem key={option} value={option}>
                {isMulti && (
                  <Checkbox size="small" checked={rule.values.includes(option)} sx={{ p: 0.5, mr: 1 }} />
                )}
                <ListItemText primary={option} />
              </MenuItem>
            ))}
          </Select>
          {valueErr && <FormHelperText>{valueErr}</FormHelperText>}
        </FormControl>
      )
    }

    if (isMulti) {
      return (
        <TextField
          size="small"
          fullWidth
          label={valueLabel}
          placeholder="Comma-separated values"
          value={rule.values.join(', ')}
          className="rule-form-field"
          error={!!valueErr}
          helperText={valueErr}
          sx={textFieldSx}
          onChange={(e) => updateRule(index, {
            values: e.target.value.split(',').map((v) => v.trim()).filter(Boolean),
          })}
        />
      )
    }

    return (
      <TextField
        size="small"
        fullWidth
        label={valueLabel}
        value={rule.values[0] ?? ''}
        className="rule-form-field"
        error={!!valueErr}
        helperText={valueErr}
        sx={textFieldSx}
        onChange={(e) => updateRule(index, { values: [e.target.value] })}
      />
    )
  }

  if (isEdit && (loadingGroup || (fetchingGroup && !existing))) {
    return (
      <Box sx={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress />
      </Box>
    )
  }

  return (
    <div className="rule-form-page">
      <div className="rule-form-page__header">
        <Box display="flex" alignItems="center" gap={1}>
          <IconButton
            size="small"
            onClick={goToServerGroups}
            sx={{ color: '#64748b', border: '1px solid #e2e8f0', borderRadius: '8px', p: '4px', '&:hover': { bgcolor: '#f8fafc' } }}
          >
            <ChevronLeft size={16} />
          </IconButton>
          <Box>
            <Typography
              variant="caption"
              sx={{ color: '#2563eb', cursor: 'pointer', fontWeight: 500, display: 'block', lineHeight: 1.4, '&:hover': { textDecoration: 'underline' } }}
              onClick={goToServerGroups}
            >
              Target Groups
            </Typography>
            <Typography sx={{ fontSize: '1.05rem', fontWeight: 700, color: '#0f172a', lineHeight: 1.2 }}>
              {isEdit ? 'Modify Target Group' : 'Create Target Group'}
            </Typography>
          </Box>
        </Box>

        <Box display="flex" gap={1.5}>
          <Button variant="outlined" size="small" onClick={goToServerGroups} className="rule-btn rule-btn--cancel">
            Cancel
          </Button>
          <Button
            variant="contained"
            size="small"
            disabled={creating || updating || step !== GROUP_STEPS.length - 1 || !isFormComplete}
            onClick={handleSave}
            className="rule-btn rule-btn--publish"
          >
            {creating || updating ? 'Saving…' : isEdit ? 'Save Changes' : 'Save Group'}
          </Button>
        </Box>
      </div>

      <div className="rule-form-page__stepper-wrap">
        <Stepper
          nonLinear
          activeStep={step}
          alternativeLabel
          connector={<GroupStepConnector />}
          sx={{
            maxWidth: 820,
            mx: 'auto',
            '& .MuiStepLabel-label': { mt: 0.75, fontSize: '0.78rem' },
            '& .MuiStepLabel-labelContainer': { maxWidth: 'none' },
          }}
        >
          {GROUP_STEPS.map((label, index) => (
            <Step key={label} completed={index < step}>
              <StepButton disableRipple onClick={() => handleStepClick(index)}>
                <StepLabel
                  StepIconComponent={() => (
                    <GroupStepIcon active={index === step} completed={index < step} />
                  )}
                >
                  <Typography sx={{ fontSize: '0.78rem', fontWeight: index === step ? 700 : 400, color: index <= step ? '#1e293b' : '#94a3b8' }}>
                    {label}
                  </Typography>
                </StepLabel>
              </StepButton>
            </Step>
          ))}
        </Stepper>
      </div>

      <div className="rule-form-page__content" style={{ display: 'flex', flexDirection: 'column' }}>
        {step === 0 && (
          <Box display="flex" flexDirection="column" gap={2} sx={{ width: '100%', height: '100%' }}>
            <div className="rule-card" style={{ flex: 1, width: '100%' }}>
              <p className="rule-card__title">Group Information</p>
              <p className="rule-card__subtitle">Core identity and classification of this Target Group.</p>

              <Box display="grid" gridTemplateColumns="1fr 1fr" gap={2} mb={2}>
                <TextField
                  label="Group Name *"
                  value={name}
                  onChange={(e) => { setName(e.target.value); clearErr('name') }}
                  fullWidth
                  size="small"
                  className="rule-form-field"
                  error={!!errors.name}
                  helperText={errors.name}
                  placeholder="Policy Administration Servers"
                />
                <FormControl fullWidth size="small" className="rule-form-field" error={!!errors.groupType}>
                  <InputLabel>Group Type *</InputLabel>
                  <Select
                    value={groupType}
                    label="Group Type *"
                    onChange={(e) => {
                      setGroupType(e.target.value as 'DYNAMIC' | 'STATIC')
                      clearErr('groupType')
                    }}
                  >
                    {GROUP_TYPE_OPTIONS.map((option) => (
                      <MenuItem key={option.value} value={option.value}>{option.label}</MenuItem>
                    ))}
                  </Select>
                  {errors.groupType && <FormHelperText>{errors.groupType}</FormHelperText>}
                </FormControl>
              </Box>

              <TextField
                label="Description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                fullWidth
                size="small"
                multiline
                rows={2}
                className="rule-form-field"
                placeholder="All servers supporting Policy Administration business service"
                sx={{ mb: 2 }}
              />

              <TextField
                placeholder="Type a tag and press Enter"
                label="Tags"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && tagInput.trim()) {
                    e.preventDefault()
                    if (!tags.includes(tagInput.trim())) setTags((prev) => [...prev, tagInput.trim()])
                    setTagInput('')
                  }
                }}
                fullWidth
                size="small"
                className="rule-form-field"
              />
              {tags.length > 0 && (
                <Stack direction="row" spacing={1} flexWrap="wrap" mt={1.5}>
                  {tags.map((tag) => (
                    <Tooltip key={tag} title={tag} arrow>
                      <Chip
                        key={tag}
                        label={tag}
                        size="small"
                        onDelete={() => setTags((prev) => prev.filter((t) => t !== tag))}
                        sx={TAG_CHIP_SX}
                      />
                    </Tooltip>
                  ))}
                </Stack>
              )}
            </div>
          </Box>
        )}

        {step === 1 && (
          <Box display="flex" flexDirection="column" gap={2} sx={{ width: '100%', height: '100%' }}>
            <div className="rule-card" style={{ flex: 1, width: '100%' }}>
              <p className="rule-card__title">Define Group Rules</p>
              <p className="rule-card__subtitle">
                Include servers where the following conditions match.
              </p>

              {loadingMetadata ? (
                <Typography sx={{ fontSize: '0.875rem', color: '#94a3b8' }}>Loading field options…</Typography>
              ) : fieldOptions.length === 0 ? (
                <Typography sx={{ fontSize: '0.875rem', color: '#dc2626' }}>
                  No metadata fields available from target servers API.
                </Typography>
              ) : (
                <>
                  <div className="rule-dynamic-fields">
                    {groupRules.map((rule, index) => (
                      <div key={index} className="rule-dynamic-fields__item">
                        <Box
                          display="grid"
                          gridTemplateColumns="1fr 160px 1.2fr 40px"
                          gap={1.5}
                          alignItems="flex-start"
                        >
                          <FormControl size="small" fullWidth className="rule-form-field" error={!!ruleErrors[ruleErrKey(index, 'field')]} sx={selectFieldSx}>
                            <InputLabel>Field *</InputLabel>
                            <Select
                              label="Field *"
                              value={rule.field}
                              onChange={(e) => updateRule(index, { field: e.target.value })}
                            >
                              {getAvailableFieldsForRule(index).map((field) => (
                                <MenuItem key={field} value={field}>{toFieldLabel(field)}</MenuItem>
                              ))}
                            </Select>
                            {ruleErrors[ruleErrKey(index, 'field')] && (
                              <FormHelperText>{ruleErrors[ruleErrKey(index, 'field')]}</FormHelperText>
                            )}
                          </FormControl>

                          <FormControl size="small" fullWidth className="rule-form-field" error={!!ruleErrors[ruleErrKey(index, 'operator')]} sx={selectFieldSx}>
                            <InputLabel>Operator *</InputLabel>
                            <Select
                              label="Operator *"
                              value={rule.operator}
                              onChange={(e) => updateRule(index, { operator: e.target.value })}
                            >
                              {OPERATOR_OPTIONS.map((op) => (
                                <MenuItem key={op.value} value={op.value}>{op.label}</MenuItem>
                              ))}
                            </Select>
                            {ruleErrors[ruleErrKey(index, 'operator')] && (
                              <FormHelperText>{ruleErrors[ruleErrKey(index, 'operator')]}</FormHelperText>
                            )}
                          </FormControl>

                          {renderValueInput(rule, index)}

                          <IconButton
                            size="small"
                            onClick={() => removeRule(index)}
                            disabled={groupRules.length <= 1}
                            sx={{ mt: 0.75, color: '#94a3b8', '&:hover': { color: '#dc2626', bgcolor: '#fef2f2' } }}
                          >
                            <Trash2 size={16} />
                          </IconButton>
                        </Box>
                      </div>
                    ))}
                  </div>

                  <Button
                    size="small"
                    startIcon={<Plus size={14} />}
                    onClick={addRule}
                    disabled={!canAddRule}
                    sx={{ textTransform: 'none', color: '#2563eb', fontWeight: 500, mt: 1, mb: 2 }}
                  >
                    Add Condition
                  </Button>

                  <FormControl fullWidth size="small" className="rule-form-field" sx={selectFieldSx}>
                    <InputLabel>Rule Logic *</InputLabel>
                    <Select
                      value={ruleLogic}
                      label="Rule Logic *"
                      onChange={(e) => setRuleLogic(e.target.value as ServerGroupRuleLogic)}
                    >
                      <MenuItem value="AND">Match ALL Conditions (AND)</MenuItem>
                      <MenuItem value="OR">Match ANY Condition (OR)</MenuItem>
                    </Select>
                  </FormControl>
                </>
              )}
            </div>
          </Box>
        )}

        {step === 2 && (
          <Box sx={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5 }}>
              <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
                <Typography sx={{ fontSize: '0.9375rem', fontWeight: 700, color: '#102459' }}>Basic Information</Typography>
                <IconButton
                  size="small"
                  onClick={() => setStep(0)}
                  sx={{ color: '#94a3b8', '&:hover': { color: '#2563eb', bgcolor: '#eff6ff' } }}
                >
                  <Pencil size={15} />
                </IconButton>
              </Box>
              <ReviewRow label="Group Name" value={name} />
              <ReviewRow label="Group Type" value={groupTypeLabel} />
              <ReviewRow label="Description" value={description || '-'} />
              <ReviewRow label="Rule Logic" value={ruleLogic === 'OR' ? 'OR (Match ANY)' : 'AND (Match ALL)'} />
              {tags.length > 0 && (
                <ReviewRow
                  label="Tags"
                  value={(
                    <Stack direction="row" spacing={0.75} flexWrap="wrap">
                      {tags.map((t) => (
                        <Tooltip key={t} title={t} arrow>
                          <Chip
                            key={t}
                            label={t}
                            size="small"
                            sx={{
                              ...TAG_CHIP_SX,
                              fontSize: '0.75rem',
                              fontWeight: 500,
                              height: 22,
                            }}
                          />
                        </Tooltip>
                      ))}
                    </Stack>
                  )}
                />
              )}
            </Paper>

            <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5 }}>
              <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
                <Typography sx={{ fontSize: '0.9375rem', fontWeight: 700, color: '#102459' }}>Group Rules</Typography>
                <IconButton
                  size="small"
                  onClick={() => setStep(1)}
                  sx={{ color: '#94a3b8', '&:hover': { color: '#2563eb', bgcolor: '#eff6ff' } }}
                >
                  <Pencil size={15} />
                </IconButton>
              </Box>
              {groupRules.length > 0 ? (
                groupRules.map((rule, index) => (
                  <ReviewRow
                    key={index}
                    label={`Condition ${index + 1}`}
                    value={`${toFieldLabel(rule.field)} ${OPERATOR_OPTIONS.find((o) => o.value === rule.operator)?.label ?? rule.operator} ${rule.values.join(', ')}`}
                  />
                ))
              ) : (
                <Typography sx={{ fontSize: '0.8125rem', color: '#94a3b8', fontStyle: 'italic' }}>
                  No rules defined
                </Typography>
              )}
            </Paper>

            <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: '12px', p: 2.5 }}>
              <Typography sx={{ fontSize: '0.9375rem', fontWeight: 700, color: '#102459', mb: 0.5 }}>
                Matching Servers
              </Typography>
              <Typography sx={{ fontSize: '0.8125rem', color: '#64748b', mb: 2 }}>
                {previewLoading ? 'Loading preview…' : `${previewTotal} server(s) match your rules`}
              </Typography>

              <PolicyTable
                columns={previewColumns}
                rows={previewServers}
                total={previewTotal}
                page={previewPage}
                pageSize={previewPageSize}
                onPageChange={handlePreviewPageChange}
                onPageSizeChange={handlePreviewPageSizeChange}
                loading={previewLoading}
                error={!!previewError}
                errorMessage={previewError || 'Failed to load matching servers'}
                emptyMessage="No matching servers found."
                getRowId={(row: PreviewServer) => row.hostname}
                sx={{ border: 'none' }}
              />
            </Paper>
          </Box>
        )}
      </div>

      <div className="rule-form-page__footer">
        {step > 0 && (
          <Button variant="outlined" size="small" onClick={goPrev} className="rule-btn rule-btn--previous">
            Previous
          </Button>
        )}
        {step < GROUP_STEPS.length - 1 && (
          <Button variant="contained" size="small" onClick={goNext} className="rule-btn rule-btn--next">
            Next
          </Button>
        )}
      </div>

      <Dialog
        open={confirmLeaveOpen}
        onClose={handleDismissLeaveConfirm}
        maxWidth="xs"
        fullWidth
        PaperProps={{ sx: { borderRadius: 2 } }}
      >
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            px: 2.5,
            py: 2,
            borderBottom: '1px solid #e2e8f0',
          }}
        >
          <Typography variant="subtitle1" fontWeight={700} color="#0f172a">
            Unsaved Changes
          </Typography>
          <IconButton size="small" onClick={handleDismissLeaveConfirm} sx={{ color: '#94a3b8' }}>
            <X size={18} />
          </IconButton>
        </Box>
        <DialogContent sx={{ pt: 2.5 }}>
          <Typography sx={{ fontSize: '0.85rem', color: '#64748b' }}>
            You have unsaved changes. Are you sure you want to leave? Your changes will be lost.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 2.5, pb: 2.5, gap: 1 }}>
          <Button
            onClick={handleDismissLeaveConfirm}
            variant="outlined"
            size="small"
            sx={{ textTransform: 'none', borderRadius: 1.5 }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleConfirmLeave}
            variant="contained"
            size="small"
            sx={{
              textTransform: 'none',
              borderRadius: 1.5,
              bgcolor: '#2563eb',
              '&:hover': { bgcolor: '#1d4ed8' },
            }}
          >
            Yes, Leave
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  )
}

export default ServerGroupFormPage
