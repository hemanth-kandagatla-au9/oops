import React, { useState, useMemo } from 'react'
import {
  Box, Button, Chip, Dialog, DialogActions, DialogContent, IconButton,
  Tooltip, Typography,
} from '@mui/material'
import { Plus, Eye, Edit2, Trash2, RefreshCw } from 'lucide-react'
import { useHistory } from 'react-router-dom'
import { toast } from 'react-toastify'
import moment from 'moment'
import { POLICYOPS_PATH } from '../../utils/constant'
import PolicyTable, { TableColumn } from '../../components/PolicyTable'
import LinkCell from '../../components/LinkCell'
import SearchFilterBar from '../../components/SearchFilterBar'
import ListFilterPopover, { FilterFieldConfig } from '../../components/ListFilterPopover'
import AppliedFilterTags from '../../components/AppliedFilterTags'
import { useDebouncedValue } from '../../components/useDebouncedValue'
import { useDeleteServerGroupMutation, useGetServerGroupsQuery } from '../../redux/slices/serverGroupsSlice'

export interface ServerGroup {
  _id?: string
  id?: string
  name: string
  description?: string
  groupType?: string
  type?: string
  serverCount?: number
  servers?: number
  policyCount?: number
  ruleLogic?: 'AND' | 'OR' | 'ALL' | 'ANY'
  rule_logic?: 'AND' | 'OR' | 'ALL' | 'ANY'
  groupRules?: { field: string; operator: string; values: string[] }[]
  tags?: string[]
  updated_at?: string
  updatedAt?: string
}

interface ServerGroupFilters {
  groupType: string
  ruleLogic: string
  [key: string]: string
}

const EMPTY_FILTERS: ServerGroupFilters = { groupType: '', ruleLogic: '' }

const FILTER_FIELDS: FilterFieldConfig[] = [
  {
    key: 'groupType',
    label: 'Group Type',
    type: 'select',
    options: [
      { value: 'STATIC', label: 'Static' },
      { value: 'DYNAMIC', label: 'Dynamic' },
    ],
  },
  {
    key: 'ruleLogic',
    label: 'Rule Logic',
    type: 'select',
    options: [
      { value: 'AND', label: 'AND' },
      { value: 'OR', label: 'OR' },
    ],
  },
]

const SERVER_GROUPS_PATH = POLICYOPS_PATH.SERVER_GROUPS

const ServerGroupsPage: React.FC = () => {
  const history = useHistory()
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(0)
  const [pageSize, setPageSize] = useState(10)
  const [deleteTarget, setDeleteTarget] = useState<ServerGroup | null>(null)
  const [filterAnchor, setFilterAnchor] = useState<HTMLElement | null>(null)
  const [appliedFilters, setAppliedFilters] = useState<ServerGroupFilters>(EMPTY_FILTERS)
  const [draftFilters, setDraftFilters] = useState<ServerGroupFilters>(EMPTY_FILTERS)

  const debouncedSearch = useDebouncedValue(search, 400)

  const { data, isFetching, isError, refetch } = useGetServerGroupsQuery({
    page: page + 1,
    limit: pageSize,
    search: debouncedSearch.trim() || undefined,
    groupType: appliedFilters.groupType || undefined,
    ruleLogic: appliedFilters.ruleLogic || undefined,
  }, { refetchOnMountOrArgChange: true })

  const [deleteServerGroup, { isLoading: deleting }] = useDeleteServerGroupMutation()

  const groups: ServerGroup[] = data?.data ?? []
  const total: number = data?.total ?? groups.length

  const resetPage = () => setPage(0)
  const groupId = (row: ServerGroup) => row._id ?? row.id ?? ''

  const openFilterPopover = (anchor: HTMLElement) => {
    setDraftFilters(appliedFilters)
    setFilterAnchor(anchor)
  }
  const applyFilters = () => { setAppliedFilters(draftFilters); setFilterAnchor(null); resetPage() }
  const clearDraftFilters = () => { setDraftFilters(EMPTY_FILTERS); setAppliedFilters(EMPTY_FILTERS); setFilterAnchor(null); resetPage() }
  const clearAllAppliedFilters = () => { setAppliedFilters(EMPTY_FILTERS); setDraftFilters(EMPTY_FILTERS); resetPage() }
  const removeAppliedFilter = (key: string) => { setAppliedFilters((prev: ServerGroupFilters) => ({ ...prev, [key]: '' })); resetPage() }
  const handleDraftChange = (key: string, value: string) => setDraftFilters((prev: ServerGroupFilters) => ({ ...prev, [key]: value }))

  const hasActiveFilters = Boolean(appliedFilters.groupType || appliedFilters.ruleLogic)

  const appliedFilterTags = useMemo(() => {
    const tags: { key: string; label: string }[] = []
    if (appliedFilters.groupType) {
      const label = appliedFilters.groupType === 'STATIC' ? 'Static' : 'Dynamic'
      tags.push({ key: 'groupType', label: `Type: ${label}` })
    }
    if (appliedFilters.ruleLogic) {
      tags.push({ key: 'ruleLogic', label: `Rule Logic: ${appliedFilters.ruleLogic}` })
    }
    return tags
  }, [appliedFilters])

  const handleDelete = async () => {
    if (!deleteTarget) return
    const id = groupId(deleteTarget)
    const groupName = deleteTarget.name
    setDeleteTarget(null)
    try {
      await deleteServerGroup(id).unwrap()
      toast.success(`"${groupName}" deleted`)
    } catch {
      toast.error('Delete failed.')
    }
  }

  const formatType = (row: ServerGroup) => {
    const raw = row.groupType ?? row.type ?? ''
    if (!raw) return '—'
    const lower = raw.toLowerCase()
    if (lower === 'dynamic') return 'Dynamic'
    if (lower === 'static') return 'Static'
    return raw
  }

  const resolveRuleLogic = (row: ServerGroup) => {
    const logic = String(row.ruleLogic ?? row.rule_logic ?? 'AND').toUpperCase()
    return logic === 'OR' || logic === 'ANY' ? 'OR' : 'AND'
  }

  const columns: TableColumn[] = [
    {
      key: 'name',
      header: 'Group Name',
      width: '24%',
      render: (row: ServerGroup) => (
        <LinkCell
          label={row.name}
          secondary={row.description}
          onClick={() => history.push(`${SERVER_GROUPS_PATH}/${groupId(row)}`)}
        />
      ),
    },
    {
      key: 'groupType',
      header: 'Type',
      width: '12%',
      render: (row: ServerGroup) => (
        <Chip label={formatType(row)} size="small" variant="outlined" sx={{ fontSize: '0.72rem' }} />
      ),
    },
    {
      key: 'serverCount',
      header: 'Server Count',
      width: '12%',
      render: (row: ServerGroup) => (
        <Typography variant="body2" color="text.secondary" fontWeight={500}>
          {row.serverCount ?? row.servers ?? 0}
        </Typography>
      ),
    },
    {
      key: 'policyCount',
      header: 'Policy Count',
      width: '12%',
      render: (row: ServerGroup) => (
        <Typography variant="body2" color="text.secondary" fontWeight={500}>
          {row.policyCount ?? 0}
        </Typography>
      ),
    },
    {
      key: 'ruleLogic',
      header: 'Rule Logic',
      width: '12%',
      render: (row: ServerGroup) => (
        <Typography variant="body2" color="text.secondary" fontWeight={500}>
          {resolveRuleLogic(row)}
        </Typography>
      ),
    },
    {
      key: 'updated_at',
      header: 'Updated At',
      width: '16%',
      render: (row: ServerGroup) => {
        const ts = row.updated_at ?? row.updatedAt
        return (
          <Typography variant="body2" color="text.secondary">
            {ts ? moment(ts).local().format('MMM D, YYYY h:mm A') : '—'}
          </Typography>
        )
      },
    },
    {
      key: 'actions',
      header: 'Action',
      width: '14%',
      minWidth: 130,
      align: 'right',
      render: (row: ServerGroup) => (
        <Box display="flex" gap={0.25} justifyContent="flex-end">
          <Tooltip title="View">
            <IconButton
              size="small"
              sx={{ color: '#94a3b8', '&:hover': { color: '#2563eb', bgcolor: '#eff6ff' }, borderRadius: '6px' }}
              onClick={(e: React.MouseEvent<HTMLButtonElement>) => { e.stopPropagation(); history.push(`${SERVER_GROUPS_PATH}/${groupId(row)}`) }}
            >
              <Eye size={15} />
            </IconButton>
          </Tooltip>
          <Tooltip title="Edit">
            <IconButton
              size="small"
              sx={{ color: '#94a3b8', '&:hover': { color: '#2563eb', bgcolor: '#eff6ff' }, borderRadius: '6px' }}
              onClick={(e: React.MouseEvent<HTMLButtonElement>) => { e.stopPropagation(); history.push(`${SERVER_GROUPS_PATH}/${groupId(row)}/edit`) }}
            >
              <Edit2 size={15} />
            </IconButton>
          </Tooltip>
          <Tooltip title="Delete">
            <IconButton
              size="small"
              sx={{ color: '#94a3b8', '&:hover': { color: '#dc2626', bgcolor: '#fef2f2' }, borderRadius: '6px' }}
              onClick={(e: React.MouseEvent<HTMLButtonElement>) => { e.stopPropagation(); setDeleteTarget(row) }}
            >
              <Trash2 size={15} />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    },
  ]

  return (
    <Box p={3} sx={{ height: '100%', display: 'flex', flexDirection: 'column', boxSizing: 'border-box', overflow: 'hidden' }}>
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={0.75} sx={{ flexShrink: 0 }}>
        <Box>
          <Box display="flex" alignItems="center" gap={1}>
            <Typography variant="h5" fontWeight={700}>Target Groups</Typography>
            <Box sx={{ px: 1, py: 0.15, bgcolor: '#eff6ff', borderRadius: '999px', border: '1px solid #dbeafe' }}>
              <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: '#2563eb' }}>{total}</Typography>
            </Box>
          </Box>
        </Box>
        <Box display="flex" alignItems="center" gap={1.5}>
          <Tooltip title="Refresh">
            <IconButton
              size="small"
              onClick={() => { resetPage(); refetch() }}
              sx={{
                border: '1px solid #e2e8f0',
                borderRadius: '999px',
                width: 36,
                height: 36,
                color: '#64748b',
                '&:hover': { bgcolor: '#f8fafc', borderColor: '#cbd5e1' },
              }}
            >
              <RefreshCw size={15} />
            </IconButton>
          </Tooltip>
          <SearchFilterBar
            search={search}
            onSearchChange={(v: string) => { setSearch(v); resetPage() }}
            searchPlaceholder="Search Target Groups..."
            onFilterClick={(e: React.MouseEvent<HTMLElement>) => openFilterPopover(e.currentTarget)}
            hasActiveFilters={hasActiveFilters}
          />
          <Button
            variant="contained"
            size="small"
            startIcon={<Plus size={14} />}
            onClick={() => history.push(`${SERVER_GROUPS_PATH}/new`)}
            sx={{ bgcolor: '#2563eb', fontSize: '0.85rem', '&:hover': { bgcolor: '#1d4ed8' } }}
          >
            Create Group
          </Button>
        </Box>
      </Box>

      <Typography variant="body2" color="text.secondary" mb={1} sx={{ flexShrink: 0 }}>
        Organize servers into dynamic or static groups for assignments and targeting
      </Typography>

      <AppliedFilterTags
        tags={appliedFilterTags}
        onRemove={removeAppliedFilter}
        onClearAll={clearAllAppliedFilters}
      />

      <ListFilterPopover
        open={Boolean(filterAnchor)}
        anchorEl={filterAnchor}
        onClose={() => setFilterAnchor(null)}
        fields={FILTER_FIELDS}
        draftValues={draftFilters}
        onDraftChange={handleDraftChange}
        onApply={applyFilters}
        onClear={clearDraftFilters}
      />

      <Box sx={{ flex: 1, minHeight: 0 }}>
        <PolicyTable
          columns={columns}
          rows={groups}
          total={total}
          page={page}
          pageSize={pageSize}
          onPageChange={setPage}
          onPageSizeChange={(s) => { setPageSize(s); setPage(0) }}
          loading={isFetching}
          error={isError}
          errorMessage="Failed to load Target Groups"
          sx={{ height: '100%' }}
        />
      </Box>

      <Dialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        maxWidth="xs"
        fullWidth
        PaperProps={{ sx: { borderRadius: '16px', p: 1 } }}
      >
        <DialogContent sx={{ pt: 3.5, pb: 1, px: 3.5, textAlign: 'center' }}>
          <Box sx={{ width: 52, height: 52, borderRadius: '50%', bgcolor: '#fef2f2', border: '1px solid #fecaca', display: 'flex', alignItems: 'center', justifyContent: 'center', mx: 'auto', mb: 2 }}>
            <Trash2 size={22} color="#dc2626" />
          </Box>
          <Typography sx={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a', mb: 1 }}>Delete Target Group</Typography>
          <Typography sx={{ fontSize: '0.8375rem', color: '#64748b', lineHeight: 1.6 }}>
            Are you sure you want to delete{' '}
            <Box component="span" sx={{ fontWeight: 600, color: '#0f172a' }}>"{deleteTarget?.name}"</Box>?
            <br />
            This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3, pt: 2, gap: 1.5, justifyContent: 'center' }}>
          <Button
            variant="outlined"
            onClick={() => setDeleteTarget(null)}
            sx={{ borderColor: '#e2e8f0', color: '#475569', px: 3, borderRadius: '8px', textTransform: 'none', fontWeight: 500, '&:hover': { bgcolor: '#f8fafc' } }}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={handleDelete}
            disabled={deleting}
            sx={{ bgcolor: '#dc2626', px: 3, borderRadius: '8px', textTransform: 'none', fontWeight: 500, boxShadow: 'none', '&:hover': { bgcolor: '#b91c1c', boxShadow: 'none' } }}
          >
            {deleting ? 'Deleting…' : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default ServerGroupsPage
