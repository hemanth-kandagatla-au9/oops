import { Typography } from '@mui/material'
import { toast } from 'react-toastify'
import React from 'react'

interface ErrorToastProps {
  title: string
  message?: string
}

export const showErrorToast = ({
  title,
  message,
}: ErrorToastProps) => {
  toast.error(
    <div>
      <Typography
        sx={{
          fontSize: '0.85rem',
          fontWeight: 600,
          color: '#0f172a',
          mb: 0.25,
        }}
      >
        {title}
      </Typography>

      {message && (
        <Typography
          sx={{
            fontSize: '0.8rem',
            color: '#64748b',
          }}
        >
          {message}
        </Typography>
      )}
    </div>
  )
}

export const showSuccessToast = (message: string) => {
  toast.success(message)
}