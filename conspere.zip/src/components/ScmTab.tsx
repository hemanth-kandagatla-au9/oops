import React, { useState } from 'react'
import { Box, Typography, Button, IconButton, Tooltip } from '@mui/material'
import Editor from '@monaco-editor/react'
import { GitBranch, FolderOpen, Copy, Check, ExternalLink, RefreshCw, Code2, CheckCircle2 } from 'lucide-react'

interface ScmTabProps {
  name: string
  type: 'rule' | 'policy' | 'assignment'
}

const toSlug = (name: string) =>
  (name || '').toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')

const generateJson = (name: string, type: string, slug: string): string => {
  if (type === 'policy') {
    return JSON.stringify({
      policy: {
        id: slug,
        name,
        description: `Policy configuration for ${name}.`,
        severity: 'critical',
        enabled: true,
      },
      rules: [
        {
          id: 'no-root-ssh-login',
          type: 'command',
          description: "Ensure PermitRootLogin is set to 'no' in sshd config",
          command: "grep -i '^PermitRootLogin' /etc/ssh/sshd_config",
          expected_output: 'PermitRootLogin no',
        },
      ],
      remediation: {
        description: 'Set PermitRootLogin to no',
        script: `set_${slug}.sh`,
      },
    }, null, 2)
  }
  if (type === 'rule') {
    return JSON.stringify({
      rule: {
        id: slug,
        name,
        type: 'configuration',
        severity: 'high',
        enabled: true,
      },
      checks: [
        {
          type: 'file_validation',
          description: 'Validates configuration state',
          command: 'validate_config.sh',
          expected_output: 'compliant',
        },
      ],
      remediation: {
        description: 'Auto-remediate on drift detection',
        script: `remediate_${slug}.sh`,
      },
    }, null, 2)
  }
  return JSON.stringify({
    assignment: {
      id: slug,
      name,
      mode: 'enforce',
      enabled: true,
    },
    target: {
      type: 'metadata',
      value: { environment: 'production' },
    },
    schedule: {
      frequency: 60,
      timezone: 'UTC',
    },
  }, null, 2)
}

/* ── Bitbucket SVG as background-image (no JSX SVG elements needed) ──── */
const BB_BLUE  = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill='%230052CC' d='M.778 0C.35 0 0 .35 0 .778v14.444C0 15.65.35 16 .778 16h14.444c.428 0 .778-.35.778-.778V.778C16 .35 15.65 0 15.222 0H.778zm8.756 11.263H6.47l-.787-4.14h5.64l-.789 4.14z'/%3E%3C/svg%3E")`
const BB_WHITE = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill='%23ffffff' d='M.778 0C.35 0 0 .35 0 .778v14.444C0 15.65.35 16 .778 16h14.444c.428 0 .778-.35.778-.778V.778C16 .35 15.65 0 15.222 0H.778zm8.756 11.263H6.47l-.787-4.14h5.64l-.789 4.14z'/%3E%3C/svg%3E")`

const BBIcon = ({ white = false, size = 14 }: { white?: boolean; size?: number }) => (
  <Box sx={{
    width: size, height: size, flexShrink: 0,
    backgroundImage: white ? BB_WHITE : BB_BLUE,
    backgroundSize: 'contain',
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'center',
  }} />
)

/* ── Table-style row ─────────────────────────────────────────────────── */
const Row = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <Box display="flex" alignItems="flex-start"
    sx={{ borderBottom: '1px solid #f0f4f8', py: 1.1, px: 2.5 }}>
    <Typography sx={{
      fontSize: '0.8rem', color: '#9aa4b2', fontWeight: 400,
      width: 148, flexShrink: 0, lineHeight: 1.6, pt: 0.1,
    }}>
      {label}
    </Typography>
    <Box flex={1} display="flex" alignItems="center" flexWrap="wrap" minWidth={0}>
      {children}
    </Box>
  </Box>
)

const Val = ({ children }: { children: React.ReactNode }) => (
  <Typography sx={{ fontSize: '0.8125rem', fontWeight: 500, color: '#1a2232', lineHeight: 1.5 }}>
    {children}
  </Typography>
)

/* ─────────────────────────────────────────────────────────────────────── */

const BITBUCKET_URL = 'https://sourcecode.jnj.com/projects/JESY/repos/config-management/browse'

const ScmTab: React.FC<ScmTabProps> = ({ name, type }) => {
  const [commitCopied, setCommitCopied] = useState(false)
  const [yamlCopied,   setYamlCopied]   = useState(false)

  const slug        = toSlug(name)
  const filePath    = `/${type}s/${slug}.json`
  const jsonContent = generateJson(name, type, slug)

  const copyCommit = () => {
    navigator.clipboard.writeText('a7b91c2')
    setCommitCopied(true)
    setTimeout(() => setCommitCopied(false), 1500)
  }

  const copyJson = () => {
    navigator.clipboard.writeText(jsonContent)
    setYamlCopied(true)
    setTimeout(() => setYamlCopied(false), 1500)
  }

  const openBitbucket = () => window.open(`${BITBUCKET_URL}${filePath}`, '_blank')

  return (
    <Box display="flex" gap={2.5} sx={{ alignItems: 'flex-start' }}>

      {/* ══ LEFT: SCM Details — 430 px, own card ═══════════════════════ */}
      <Box sx={{
        width: 430,
        flexShrink: 0,
        border: '1px solid #e2e8f0',
        borderRadius: '12px',
        bgcolor: 'white',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
      }}>
        {/* Section title */}
        <Box sx={{ px: 2.5, pt: 2.25, pb: 1.5 }}>
          <Typography sx={{ fontSize: '0.9rem', fontWeight: 700, color: '#0f1f3d' }}>
            SCM Details
          </Typography>
        </Box>

        {/* Rows */}
        <Box sx={{ flex: 1 }}>

          <Row label="Source">
            <Box sx={{
              display: 'inline-flex', alignItems: 'center', gap: 0.75,
              bgcolor: '#eef2fc', border: '1px solid #c9d5f6',
              borderRadius: '6px', px: 0.9, py: 0.3,
            }}>
              <BBIcon size={14} />
              <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#0052CC' }}>Bitbucket</Typography>
            </Box>
          </Row>

          <Row label="Repository">
            <Typography sx={{
              fontSize: '0.8125rem', fontWeight: 500, color: '#2563eb',
              cursor: 'pointer', '&:hover': { textDecoration: 'underline' },
            }}
              onClick={() => window.open('https://sourcecode.jnj.com/projects/JESY/repos/config-management', '_blank')}>
              config-management
            </Typography>
          </Row>

          <Row label="Branch">
            <Box display="flex" alignItems="center" gap={0.75}>
              <GitBranch size={13} color="#64748b" />
              <Val>main</Val>
            </Box>
          </Row>

          <Row label="File Path">
            <Box display="flex" alignItems="flex-start" gap={0.5} sx={{ minWidth: 0 }}>
              <FolderOpen size={13} color="#2563eb" style={{ marginTop: 3, flexShrink: 0 }} />
              <Typography sx={{
                fontSize: '0.8rem', fontWeight: 500, color: '#2563eb',
                wordBreak: 'break-all', lineHeight: 1.5,
                cursor: 'pointer', '&:hover': { textDecoration: 'underline' },
              }}
                onClick={openBitbucket}>
                {filePath}
              </Typography>
            </Box>
          </Row>

          <Row label="Status">
            <Box display="flex" alignItems="center" gap={0.6}>
              <CheckCircle2 size={15} color="#16a34a" />
              <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#16a34a' }}>In Sync</Typography>
            </Box>
          </Row>

          <Row label="Last Sync">
            <Box display="flex" alignItems="center" gap={0.5}>
              <Val>5 mins ago</Val>
              <RefreshCw size={12} color="#9aa4b2" style={{ marginLeft: 4 }} />
            </Box>
          </Row>

          <Row label="Last Commit ID">
            <Box display="flex" alignItems="center">
              <Typography sx={{ fontSize: '0.8125rem', fontWeight: 600, color: '#1a2232', fontFamily: 'monospace' }}>
                a7b91c2
              </Typography>
              <Tooltip title={commitCopied ? 'Copied!' : 'Copy commit ID'}>
                <IconButton size="small" onClick={copyCommit}
                  sx={{ p: '3px', ml: 0.5, color: commitCopied ? '#16a34a' : '#9aa4b2', '&:hover': { color: '#2563eb' } }}>
                  {commitCopied ? <Check size={12} /> : <Copy size={12} />}
                </IconButton>
              </Tooltip>
            </Box>
          </Row>

          <Row label="Commit Message">
            <Typography sx={{ fontSize: '0.8125rem', color: '#1a2232', lineHeight: 1.5 }}>
              Update configuration settings
            </Typography>
          </Row>

          <Row label="Committed By"><Val>jdoe</Val></Row>

          <Row label="Committed On">
            <Typography sx={{ fontSize: '0.8125rem', color: '#1a2232' }}>15 Jun 2026 10:24 AM</Typography>
          </Row>

        </Box>

        {/* Buttons pinned at bottom */}
        <Box sx={{ px: 2.5, py: 2, borderTop: '1px solid #f0f4f8', display: 'flex', gap: 1.25 }}>
          <Button size="small" variant="outlined"
            startIcon={<Code2 size={14} />}
            sx={{
              flex: 1, fontSize: '0.8rem', textTransform: 'none', fontWeight: 500,
              borderColor: '#d1d5db', color: '#374151', borderRadius: '8px',
              '&:hover': { borderColor: '#9ca3af', bgcolor: '#f9fafb' },
            }}>
            View JSON
          </Button>

          <Button size="small" variant="outlined"
            onClick={openBitbucket}
            startIcon={<BBIcon size={15} />}
            endIcon={<ExternalLink size={13} />}
            sx={{
              flex: 1, fontSize: '0.8rem', textTransform: 'none', fontWeight: 500,
              borderColor: '#0052CC', color: '#0052CC', borderRadius: '8px',
              '&:hover': { bgcolor: '#eef2fc', borderColor: '#0043a8' },
            }}>
            Open in Bitbucket
          </Button>
        </Box>
      </Box>

      {/* ══ RIGHT: File Preview — own card, slightly off-white bg ══════ */}
      <Box sx={{
        flex: 1,
        minWidth: 0,
        border: '1px solid #e2e8f0',
        borderRadius: '12px',
        bgcolor: '#f8fafc',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
      }}>
        {/* Header strip */}
        <Box display="flex" justifyContent="space-between" alignItems="center"
          sx={{ px: 2.5, py: 1.5, bgcolor: 'white', borderBottom: '1px solid #e8edf4', flexShrink: 0 }}>
          <Box display="flex" alignItems="baseline" gap={0.75} sx={{ minWidth: 0, mr: 1 }}>
            <Typography sx={{ fontSize: '0.9rem', fontWeight: 700, color: '#0f1f3d', whiteSpace: 'nowrap' }}>
              File Preview
            </Typography>
            <Typography sx={{
              fontSize: '0.8rem', color: '#64748b', fontFamily: 'monospace',
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            }}>
              ({slug}.json)
            </Typography>
          </Box>
          <Button size="small" variant="outlined"
            startIcon={yamlCopied ? <Check size={13} /> : <Copy size={13} />}
            onClick={copyJson}
            sx={{
              fontSize: '0.775rem', textTransform: 'none', borderRadius: '8px', flexShrink: 0,
              borderColor: yamlCopied ? '#bbf7d0' : '#d1d5db',
              color: yamlCopied ? '#16a34a' : '#374151',
              bgcolor: yamlCopied ? '#f0fdf4' : 'transparent',
              '&:hover': { borderColor: '#9ca3af', bgcolor: '#f9fafb' },
            }}>
            {yamlCopied ? 'Copied!' : 'Copy'}
          </Button>
        </Box>

        {/* Monaco editor */}
        <Box sx={{ flex: 1, pt: 0.5 }}>
          <Editor
            language="json"
            value={jsonContent}
            theme="vs"
            height="475px"
            options={{
              readOnly: true,
              minimap: { enabled: false },
              scrollBeyondLastLine: false,
              fontSize: 13,
              lineNumbers: 'on' as const,
              renderLineHighlight: 'none' as const,
              overviewRulerLanes: 0,
              hideCursorInOverviewRuler: true,
              scrollbar: { vertical: 'auto', horizontal: 'hidden' },
              folding: false,
              glyphMargin: false,
              contextmenu: false,
              padding: { top: 12, bottom: 16 },
              wordWrap: 'off' as const,
            }}
          />
        </Box>
      </Box>

    </Box>
  )
}

export default ScmTab
