import React from 'react'
import {
  Box,
  CircularProgress,
  Dialog,
  Grid,
  IconButton,
  Tooltip,
  Typography,
} from '@mui/material'
import moment from 'moment'
import { FileText, LogIn, Settings, Terminal, X } from 'lucide-react'

const pickRowValue = (row: Record<string, unknown>, ...keys: string[]): unknown => {
  for (const key of keys) {
    const value = row[key]
    if (value !== undefined && value !== null && value !== '') return value
  }
  return null
}

export interface DriftLogMetricsData {
  totalExecutions: number
  successRate: number
  failedRate: number
  realtimeRate: number
}

export const parseDriftLogMetrics = (response: unknown): DriftLogMetricsData | null => {
  const payload = (response as { data?: DriftLogMetricsData })?.data
    ?? (response as DriftLogMetricsData | null)

  if (!payload || typeof payload !== 'object') return null

  return {
    totalExecutions: Number(payload.totalExecutions ?? 0),
    successRate: Number(payload.successRate ?? 0),
    failedRate: Number(payload.failedRate ?? 0),
    realtimeRate: Number(payload.realtimeRate ?? 0),
  }
}

export interface DriftTimelineTag {
  label: string
  value: string
  variant?: 'default' | 'currentUser'
}

export interface DriftTimelineEntry {
  id: string
  date?: string
  time: string
  timeTooltip?: string
  userTags: DriftTimelineTag[]
  metaTags: DriftTimelineTag[]
  command?: string
  iconType?: 'terminal' | 'settings' | 'login'
}

export interface CommandLogRequest {
  hostname: string
  command: string
  timestamp?: string
}

const extractFileName = (filepath: string): string => {
  const trimmed = filepath.trim()
  if (!trimmed) return ''
  const segments = trimmed.replace(/\\/g, '/').split('/').filter(Boolean)
  return segments.length ? segments[segments.length - 1] : trimmed
}

export const resolveCommandLogPayload = (row: Record<string, unknown>): CommandLogRequest | null => {
  const hostname = String(pickRowValue(row, 'hostname', 'host', 'target') ?? '').trim()
  const ruleType = String(pickRowValue(row, 'ruleType', 'ruletype', 'rule_type') ?? '').toLowerCase()

  let command = ''
  const filepath = String(pickRowValue(row, 'filepath', 'filePath', 'file_path', 'path') ?? '').trim()
  if (ruleType === 'file') {
    command = extractFileName(filepath)
  } else if (ruleType === 'package') {
    command = String(pickRowValue(row, 'artifactName', 'artifact_name', 'artifact') ?? '').trim()
  } else if (ruleType === 'service') {
    command = String(pickRowValue(row, 'serviceName', 'service_name', 'service') ?? '').trim()
  } else if (ruleType === 'user') {
    command = String(pickRowValue(row, 'username', 'user_name', 'userName', 'user') ?? '').trim()
  } else if (ruleType === 'script') {
    command = extractFileName(filepath)
  }

  if (!hostname || !command) return null

  const timestampRaw = pickRowValue(
    row,
    'timestampRealtime',
    'timestamp_realtime',
    'timestamprealtime',
    'timestamp',
    'time',
    'eventTime',
    'event_time',
    'createdAt',
    'created_at',
  )
  const timestamp = timestampRaw != null && String(timestampRaw).trim()
    ? String(timestampRaw).trim()
    : undefined

  return { hostname, command, ...(timestamp ? { timestamp } : {}) }
}

export interface DriftDetailItem {
  label: string
  value: string
  fieldKey?: string
}

const formatDetailValue = (value: unknown): string => {
  if (value === null || value === undefined || value === '') return ''
  if (typeof value === 'boolean') return value ? 'Yes' : 'No'
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}

export const buildDriftDetailsFromRow = (row: Record<string, unknown>): DriftDetailItem[] => {
  const ruleType = String(pickRowValue(row, 'ruleType', 'ruletype', 'rule_type') ?? '').trim().toLowerCase()
  const items: DriftDetailItem[] = [
    {
      label: 'Hostname',
      value: String(pickRowValue(row, 'hostname', 'host', 'target') ?? '').trim(),
      fieldKey: 'hostname',
    },
    {
      label: 'Rule Type',
      value: String(pickRowValue(row, 'ruleType', 'ruletype', 'rule_type') ?? '').trim(),
      fieldKey: 'ruleType',
    },
  ]

  if (ruleType === 'file') {
    items.push({
      label: 'Filepath',
      value: String(pickRowValue(row, 'filepath', 'filePath', 'file_path', 'path') ?? '').trim(),
      fieldKey: 'filepath',
    })
  } else if (ruleType === 'package') {
    items.push({
      label: 'Artifact Name',
      value: String(pickRowValue(row, 'artifactName', 'artifact_name', 'artifact') ?? '').trim(),
      fieldKey: 'artifact',
    })
  } else if (ruleType === 'service') {
    items.push({
      label: 'Service Name',
      value: String(pickRowValue(row, 'serviceName', 'service_name', 'service') ?? '').trim(),
      fieldKey: 'serviceName',
    })
  } else if (ruleType === 'user') {
    items.push({
      label: 'Username',
      value: String(pickRowValue(row, 'username', 'user_name', 'userName', 'user') ?? '').trim(),
      fieldKey: 'username',
    })
  } else if (ruleType === 'script') {
    items.push({
      label: 'Filepath',
      value: String(pickRowValue(row, 'filepath', 'filePath', 'file_path', 'path') ?? '').trim(),
      fieldKey: 'filepath',
    })
  }

  const realtimeValue = pickRowValue(row, 'realtime', 'isRealtime', 'is_realtime')
  items.push(
    {
      label: 'Status',
      value: String(pickRowValue(row, 'status', 'executionStatus', 'execution_status') ?? '').trim(),
      fieldKey: 'executionStatus',
    },
    {
      label: 'Action Taken',
      value: String(pickRowValue(row, 'actionTaken', 'action_taken', 'action') ?? '').trim(),
      fieldKey: 'actionTaken',
    },
    {
      label: 'Realtime',
      value: formatDetailValue(realtimeValue),
      fieldKey: 'realtime',
    },
  )

  return items
    .map((item) => ({ ...item, value: item.value || '—' }))
    .filter((item) => item.value !== '—')
}

export const resolveDriftTimestampValue = (row: Record<string, unknown>): unknown =>
  pickRowValue(
    row,
    'timestampRealtime',
    'timestamp_realtime',
    'timestamprealtime',
    'timestamp',
    'time',
    'eventTime',
    'event_time',
    'createdAt',
    'created_at',
  )

const toDetailLabel = (key: string): string =>
  key
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())

const isTimestampLikeKey = (key: string): boolean => {
  const normalized = key.toLowerCase().replace(/_/g, '')
  return (
    normalized === 'timestamp'
    || normalized === 'time'
    || normalized.endsWith('timestamp')
    || normalized === 'createdat'
    || normalized === 'updatedat'
    || normalized === 'eventtime'
    || normalized === 'timestamprealtime'
  )
}

const formatDetailFieldValue = (key: string, rawValue: unknown): string => {
  if (rawValue === null || rawValue === undefined || rawValue === '') return '—'
  if (typeof rawValue === 'boolean') return rawValue ? 'Yes' : 'No'
  if (typeof rawValue === 'object') return JSON.stringify(rawValue)
  if (isTimestampLikeKey(key)) {
    return formatCommandLogTimestamp(rawValue).tooltip ?? String(rawValue)
  }
  return String(rawValue)
}

export const buildAllDriftDetailsFromRow = (row: Record<string, unknown>): DriftDetailItem[] =>
  Object.keys(row).map((key) => ({
    label: toDetailLabel(key),
    value: formatDetailFieldValue(key, row[key]),
    fieldKey: key,
  }))

export const getCommandLogErrorMessage = (row: Record<string, unknown>): string => {
  const hostname = String(pickRowValue(row, 'hostname', 'host', 'target') ?? '').trim()
  const ruleType = String(pickRowValue(row, 'ruleType', 'ruletype', 'rule_type') ?? '').trim()

  if (!hostname) return 'Hostname is required to load command logs'
  if (!ruleType) return 'Rule type is required to resolve command'

  const normalizedRuleType = ruleType.toLowerCase()
  if (normalizedRuleType === 'file') return 'File path is required to load command logs'
  if (normalizedRuleType === 'package') return 'Artifact name is required to load command logs'
  if (normalizedRuleType === 'service') return 'Service name is required to load command logs'
  if (normalizedRuleType === 'user') return 'Username is required to load command logs'
  if (normalizedRuleType === 'script') return 'File path with filename is required to load command logs'

  return `Command could not be resolved for rule type "${ruleType}"`
}

const formatCommandLogTimestamp = (value: unknown): { date: string; time: string; tooltip?: string } => {
  if (value === null || value === undefined || value === '') {
    return { date: '—', time: '—' }
  }
  const m = moment(value as string | number | Date)
  if (!m.isValid()) {
    return { date: String(value), time: '' }
  }
  const formatted = m.local()
  return {
    date: formatted.format('DD MMM, YYYY'),
    time: formatted.format('hh:mm A'),
    tooltip: formatted.format('DD MMM, YYYY | hh:mm A'),
  }
}

const formatUserLabel = (value: string): string => {
  if (!value) return value
  return value.toLowerCase()
}

const buildCommandLogTags = (row: Record<string, unknown>): {
  userTags: DriftTimelineTag[]
  metaTags: DriftTimelineTag[]
  command?: string
} => {
  const userTags: DriftTimelineTag[] = []
  const metaTags: DriftTimelineTag[] = []

  const loggedInUser = String(pickRowValue(row, 'logged_in_user', 'loggedInUser') ?? '').trim()
  const currentUser = String(pickRowValue(row, 'current_user', 'currentUser') ?? '').trim()
  const command = String(
    pickRowValue(row, 'command', 'cmd', 'commandLine', 'command_line', 'commandText', 'command_text') ?? '',
  ).trim()
  const ipAddress = pickRowValue(row, 'ipAddress', 'ip_address', 'ip')
  const peer = pickRowValue(row, 'peer', 'peerAddress', 'peer_address')

  if (loggedInUser) userTags.push({ label: 'Logged in User', value: formatUserLabel(loggedInUser) })
  if (currentUser) userTags.push({ label: 'Current User', value: formatUserLabel(currentUser), variant: 'currentUser' })
  if (ipAddress) metaTags.push({ label: 'IP Address', value: String(ipAddress) })
  if (peer) metaTags.push({ label: 'Peer', value: String(peer) })

  return {
    userTags,
    metaTags,
    command: command || undefined,
  }
}

export const mapCommandLogsToTimeline = (response: unknown): DriftTimelineEntry[] => {
  const payload = (response as { data?: unknown })?.data ?? response
  const items = Array.isArray(payload) ? payload : []

  return items.map((item, index) => {
    const row = item as Record<string, unknown>
    const loggedInUser = String(pickRowValue(row, 'logged_in_user', 'loggedInUser') ?? '').trim()

    const timestampValue = pickRowValue(row, 'timestamp', 'time', 'createdAt', 'created_at')
    const { date, time, tooltip: timeTooltip } = formatCommandLogTimestamp(timestampValue)

    const { userTags, metaTags, command } = buildCommandLogTags(row)

    return {
      id: String(pickRowValue(row, 'id', '_id', 'logId') ?? `${timestampValue ?? 'log'}-${index}`),
      date,
      time,
      timeTooltip,
      userTags,
      metaTags,
      command,
      iconType: loggedInUser ? 'login' : 'terminal',
    }
  })
}

export interface DriftLogDialogProps {
  open: boolean
  onClose: () => void
  driftRow?: Record<string, unknown> | null
  driftDetails?: DriftDetailItem[]
  timelineEntries?: DriftTimelineEntry[]
  timelineLoading?: boolean
  timelineError?: string
}

const TIMELINE_ICON_STYLES = {
  terminal: { bg: '#dbeafe', color: '#2563eb', icon: <Terminal size={14} /> },
  settings: { bg: '#fef3c7', color: '#d97706', icon: <Settings size={14} /> },
  login: { bg: '#ccfbf1', color: '#0d9488', icon: <LogIn size={14} /> },
} as const

const TRUNCATABLE_VALUE_MIN_LENGTH = 28

const isDriftTimestampKey = (key?: string): boolean => {
  if (!key) return false
  const normalized = key.toLowerCase().replace(/_/g, '')
  return (
    normalized === 'timestamprealtime'
    || normalized === 'timestamp'
    || normalized === 'time'
    || normalized === 'eventtime'
  )
}

const TRUNCATABLE_DRIFT_LABELS = new Set(['Filepath', 'Artifact Name', 'Service Name', 'Username'])

const MetricItem: React.FC<{ label: string; value: string | number; truncate?: boolean }> = ({
  label,
  value,
  truncate = false,
}) => {
  const text = String(value)

  const valueTypography = (
    <Typography
      variant="body2"
      fontWeight={700}
      color="#0f172a"
      noWrap={truncate}
      sx={truncate ? { overflow: 'hidden', textOverflow: 'ellipsis' } : undefined}
    >
      {text}
    </Typography>
  )

  return (
    <Box sx={{ minWidth: 0, maxWidth: '100%' }}>
      <Typography variant="caption" color="text.secondary" display="block" mb={0.25}>
        {label}
      </Typography>
      {truncate ? (
        <Tooltip title={text} arrow placement="top">
          <Box component="span" sx={{ display: 'block', minWidth: 0, maxWidth: '100%', cursor: 'default' }}>
            {valueTypography}
          </Box>
        </Tooltip>
      ) : (
        valueTypography
      )}
    </Box>
  )
}

const TAG_VARIANT_STYLES = {
  default: {
    bgcolor: '#eff6ff',
    color: '#1d4ed8',
    border: '1px solid #bfdbfe',
  },
  currentUser: {
    bgcolor: '#ecfdf5',
    color: '#047857',
    border: '1px solid #a7f3d0',
  },
} as const

const ValueTag: React.FC<{ label: string; value: string; variant?: DriftTimelineTag['variant'] }> = ({
  label,
  value,
  variant = 'default',
}) => {
  const text = String(value)
  const truncate = text.length > TRUNCATABLE_VALUE_MIN_LENGTH
  const styles = TAG_VARIANT_STYLES[variant]

  const chip = (
    <Box
      sx={{
        display: 'inline-flex',
        alignItems: 'center',
        maxWidth: truncate ? 220 : 'none',
        px: 1.25,
        py: 0.45,
        borderRadius: '999px',
        bgcolor: styles.bgcolor,
        color: styles.color,
        border: styles.border,
        cursor: 'default',
      }}
    >
      <Typography
        variant="caption"
        fontWeight={600}
        noWrap={truncate}
        sx={truncate ? { overflow: 'hidden', textOverflow: 'ellipsis' } : undefined}
      >
        {text}
      </Typography>
    </Box>
  )

  return (
    <Tooltip title={label} arrow placement="top">
      {truncate ? <Box component="span">{chip}</Box> : chip}
    </Tooltip>
  )
}

const TimelineDateColumn: React.FC<{ date?: string; time?: string; timeTooltip?: string }> = ({
  date,
  time,
  timeTooltip,
}) => (
  <Box sx={{ width: 96, flexShrink: 0, pt: 0.25, textAlign: 'right' }}>
    <Tooltip title={timeTooltip ?? `${date ?? ''} ${time ?? ''}`.trim()} arrow placement="top">
      <Box sx={{ cursor: 'default' }}>
        {date && (
          <Typography variant="caption" color="text.secondary" fontWeight={500} display="block" lineHeight={1.4}>
            {date}
          </Typography>
        )}
        <Typography variant="caption" color="text.secondary" fontWeight={500} display="block" lineHeight={1.4}>
          {time}
        </Typography>
      </Box>
    </Tooltip>
  </Box>
)

const TimelineMarker: React.FC<{ iconType?: DriftTimelineEntry['iconType'] }> = ({ iconType = 'terminal' }) => {
  const style = TIMELINE_ICON_STYLES[iconType]
  return (
    <Box
      sx={{
        width: 28,
        height: 28,
        borderRadius: '50%',
        bgcolor: style.bg,
        color: style.color,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
        border: '2px solid #fff',
        boxShadow: '0 0 0 1px #e2e8f0',
        zIndex: 1,
      }}
    >
      {style.icon}
    </Box>
  )
}

const UserBadge: React.FC<{ label: string }> = ({ label }) => (
  <Box
    sx={{
      display: 'inline-flex',
      px: 1,
      py: 0.2,
      borderRadius: '6px',
      bgcolor: '#f1f5f9',
      border: '1px solid #e2e8f0',
    }}
  >
    <Typography variant="caption" color="#475569" fontWeight={500}>
      {label}
    </Typography>
  </Box>
)

const TimelineEntry: React.FC<{ entry: DriftTimelineEntry; isLast?: boolean }> = ({ entry, isLast }) => (
  <Box sx={{ display: 'flex', gap: 2, position: 'relative', pb: isLast ? 0 : 2.5 }}>
    <TimelineDateColumn date={entry.date} time={entry.time} timeTooltip={entry.timeTooltip} />

    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: 28, flexShrink: 0 }}>
      <TimelineMarker iconType={entry.iconType} />
      {!isLast && (
        <Box
          sx={{
            flex: 1,
            width: 0,
            borderLeft: '2px dotted #cbd5e1',
            mt: 0.5,
            minHeight: 24,
          }}
        />
      )}
    </Box>

    <Box sx={{ flex: 1, minWidth: 0, pt: 0.1 }}>
      {entry.userTags.length > 0 && (
        <Box display="flex" flexWrap="wrap" gap={0.75} mb={entry.command || entry.metaTags.length ? 0.75 : 0}>
          {entry.userTags.map((tag) => (
            <ValueTag
              key={`${entry.id}-${tag.label}`}
              label={tag.label}
              value={tag.value}
              variant={tag.variant}
            />
          ))}
        </Box>
      )}
      {entry.command && (
        <Box mb={entry.metaTags.length ? 0.75 : 0} sx={{ wordBreak: 'break-all', whiteSpace: 'pre-wrap' }}>
          <MetricItem label="Command" value={entry.command} />
        </Box>
      )}
      {entry.metaTags.length > 0 && (
        <Box display="flex" flexWrap="wrap" gap={0.75}>
          {entry.metaTags.map((tag) => (
            <ValueTag
              key={`${entry.id}-${tag.label}`}
              label={tag.label}
              value={tag.value}
              variant={tag.variant}
            />
          ))}
        </Box>
      )}
    </Box>
  </Box>
)

const DriftLogDialog: React.FC<DriftLogDialogProps> = ({
  open,
  onClose,
  driftRow = null,
  driftDetails = [],
  timelineEntries = [],
  timelineLoading = false,
  timelineError,
}) => {
  const rawTimestamp = driftRow
    ? resolveDriftTimestampValue(driftRow)
    : driftDetails.find((item) => isDriftTimestampKey(item.fieldKey))?.value

  const timestampParts = formatCommandLogTimestamp(rawTimestamp)

  const driftDetailsForDisplay = driftDetails.filter(
    (item) => !isDriftTimestampKey(item.fieldKey),
  )

  const hasTimelineContent = timelineEntries.length > 0 || timelineLoading

  return (
  <Dialog
    open={open}
    onClose={onClose}
    maxWidth="md"
    fullWidth
    PaperProps={{
      sx: {
        borderRadius: '12px',
        overflow: 'hidden',
        maxHeight: '85vh',
      },
    }}
  >
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        px: 2.5,
        py: 2,
        borderBottom: '1px solid #e2e8f0',
      }}
    >
      <Box display="flex" alignItems="center" gap={1}>
        <FileText size={18} color="#2563eb" />
        <Typography variant="subtitle1" fontWeight={700} color="#0f172a">
          Action History
        </Typography>
      </Box>
      <IconButton size="small" onClick={onClose} sx={{ color: '#94a3b8' }}>
        <X size={18} />
      </IconButton>
    </Box>

    <Box sx={{ px: 2.5, py: 2.5, overflowY: 'auto', maxHeight: 'calc(85vh - 64px)' }}>
      <Box sx={{ display: 'flex', gap: 2, position: 'relative', pb: hasTimelineContent ? 2.5 : 0 }}>
        <TimelineDateColumn
          date={timestampParts.date}
          time={timestampParts.time}
          timeTooltip={timestampParts.tooltip}
        />

        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: 28, flexShrink: 0 }}>
          <TimelineMarker iconType="terminal" />
          {hasTimelineContent && (
            <Box
              sx={{
                flex: 1,
                width: 0,
                borderLeft: '2px dotted #cbd5e1',
                mt: 0.5,
                minHeight: 24,
              }}
            />
          )}
        </Box>

        <Box sx={{ flex: 1, minWidth: 0, pt: 0.1 }}>
          <UserBadge label="CSP Agent" />

          <Typography
            variant="caption"
            color="text.secondary"
            fontWeight={600}
            display="block"
            sx={{ mt: 0.75, mb: 1, textTransform: 'uppercase', letterSpacing: '0.04em' }}
          >
            Drift Action Details
          </Typography>

          {driftDetailsForDisplay.length ? (
            <Grid container spacing={2}>
              {driftDetailsForDisplay.map((item) => (
                <Grid item xs={6} key={item.fieldKey ?? item.label} sx={{ minWidth: 0 }}>
                  <MetricItem
                    label={item.label}
                    value={item.value}
                    truncate={TRUNCATABLE_DRIFT_LABELS.has(item.label)}
                  />
                </Grid>
              ))}
            </Grid>
          ) : (
            <Typography variant="body2" color="text.secondary">
              No drift details available
            </Typography>
          )}
        </Box>
      </Box>

      {timelineLoading && (
        <Box display="flex" justifyContent="center" py={2}>
          <CircularProgress size={22} />
        </Box>
      )}

      {!timelineLoading && timelineError && (
        <Typography variant="body2" color="error" textAlign="center" py={2}>
          {timelineError}
        </Typography>
      )}

      {!timelineLoading && !timelineError && timelineEntries.length === 0 && (
        <Typography variant="body2" color="text.secondary" textAlign="center" py={2}>
          No command logs found
        </Typography>
      )}

      {!timelineLoading && timelineEntries.map((entry, index) => (
        <TimelineEntry
          key={entry.id}
          entry={entry}
          isLast={index === timelineEntries.length - 1}
        />
      ))}
    </Box>
  </Dialog>
  )
}

export interface DriftRowDetailsDialogProps {
  open: boolean
  onClose: () => void
  row: Record<string, unknown> | null
}

export const DriftRowDetailsDialog: React.FC<DriftRowDetailsDialogProps> = ({
  open,
  onClose,
  row,
}) => {
  const details = row ? buildAllDriftDetailsFromRow(row) : []

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: '12px',
          overflow: 'hidden',
          maxHeight: '85vh',
        },
      }}
    >
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          px: 2.5,
          py: 2,
          borderBottom: '1px solid #e2e8f0',
        }}
      >
        <Box display="flex" alignItems="center" gap={1}>
          <FileText size={18} color="#2563eb" />
          <Typography variant="subtitle1" fontWeight={700} color="#0f172a">
            Log Details
          </Typography>
        </Box>
        <IconButton size="small" onClick={onClose} sx={{ color: '#94a3b8' }}>
          <X size={18} />
        </IconButton>
      </Box>

      <Box sx={{ px: 2.5, py: 2.5, overflowY: 'auto', maxHeight: 'calc(85vh - 64px)' }}>
        {details.length ? (
          <Grid container spacing={2}>
            {details.map((item) => (
              <Grid item xs={12} sm={6} key={item.fieldKey ?? item.label} sx={{ minWidth: 0 }}>
                <MetricItem
                  label={item.label}
                  value={item.value}
                  truncate={TRUNCATABLE_DRIFT_LABELS.has(item.label) || item.value.length > 28}
                />
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography variant="body2" color="text.secondary">
            No details available
          </Typography>
        )}
      </Box>
    </Dialog>
  )
}

export default DriftLogDialog
