import { configureStore, combineReducers } from "@reduxjs/toolkit";
import {
  persistStore,
  persistReducer,
  FLUSH,
  REHYDRATE,
  PAUSE,
  PERSIST,
  PURGE,
  REGISTER,
} from "redux-persist";
import storage from "redux-persist/lib/storage";
import { rulesSlice } from "./slices/rulesSlice";
import { policiesSlice } from "./slices/policiesSlice";
import { policyGroupsSlice } from "./slices/policyGroupsSlice";
import { assignmentsSlice } from "./slices/assignmentsSlice";
import { targetServersSlice } from "./slices/targetServersSlice";
import { artifactsSlice } from "./slices/artifactsSlice";
import { complianceSlice } from "./slices/complianceSlice";
import { auditSlice } from "./slices/auditSlice";
import { agentsSlice } from "./slices/agentsSlice";
import { serverGroupsSlice } from "./slices/serverGroupsSlice";
import permissionReducer from "./slices/permissionSlice";

const permissionsPersistConfig = {
  key: "permissions",
  storage,
  blacklist: ["isLoading", "isError", "isSessionExpired"],
};

const persistConfig = {
  key: "root",
  storage,
  whitelist: [],
};

const rootReducer = combineReducers({
  [rulesSlice.reducerPath]: rulesSlice.reducer,
  [policiesSlice.reducerPath]: policiesSlice.reducer,
  [policyGroupsSlice.reducerPath]: policyGroupsSlice.reducer,
  [assignmentsSlice.reducerPath]: assignmentsSlice.reducer,
  [targetServersSlice.reducerPath]: targetServersSlice.reducer,
  [artifactsSlice.reducerPath]: artifactsSlice.reducer,
  [complianceSlice.reducerPath]: complianceSlice.reducer,
  [auditSlice.reducerPath]: auditSlice.reducer,
  [agentsSlice.reducerPath]: agentsSlice.reducer,
  [serverGroupsSlice.reducerPath]: serverGroupsSlice.reducer,
  permissions: persistReducer(permissionsPersistConfig, permissionReducer),
});

const persistedReducer = persistReducer(persistConfig, rootReducer);

export const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    })
      .concat(rulesSlice.middleware)
      .concat(policiesSlice.middleware)
      .concat(policyGroupsSlice.middleware)
      .concat(assignmentsSlice.middleware)
      .concat(targetServersSlice.middleware)
      .concat(artifactsSlice.middleware)
      .concat(complianceSlice.middleware)
      .concat(auditSlice.middleware)
      .concat(agentsSlice.middleware)
      .concat(serverGroupsSlice.middleware),
});

export const persistor = persistStore(store);
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
