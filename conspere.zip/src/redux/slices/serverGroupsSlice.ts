import { createApi } from '@reduxjs/toolkit/query/react'
import { baseQuery } from '../../services/baseQuery'

export type ServerGroupRuleLogic = 'AND' | 'OR'

export const MULTI_VALUE_OPERATORS = new Set(['in', 'not_in'])

export interface ServerGroupRule {
  field: string
  operator: string
  values: string[]
}

export interface ServerGroupPreviewRule {
  field: string
  operator: string
  value: string | string[]
}

export const toPreviewGroupRules = (rules: ServerGroupRule[]): ServerGroupPreviewRule[] =>
  rules.map((rule) => {
    const operator = rule.operator.trim().toLowerCase()
    if (MULTI_VALUE_OPERATORS.has(operator)) {
      return { field: rule.field, operator, value: rule.values }
    }
    return { field: rule.field, operator, value: rule.values[0] ?? '' }
  })

const normalizeOperator = (operator: string): string => {
  const normalized = operator.trim().toLowerCase().replace(/\s+/g, '_')
  if (normalized === 'is_not' || normalized === 'isnot') return 'is_not'
  if (normalized === 'not_contains') return 'not_contains'
  if (normalized === 'not_in' || normalized === 'notin') return 'not_in'
  if (normalized === 'is') return 'is'
  return normalized
}

type ApiGroupRule = {
  field?: string
  operator?: string
  values?: string[] | string
  value?: string | string[] | number
}

export const ruleValuesFromApi = (rule: ApiGroupRule): string[] => {
  if (typeof rule.values === 'string' && rule.values.trim()) {
    return [rule.values.trim()]
  }
  if (Array.isArray(rule.values) && rule.values.length) {
    return rule.values.map(String).filter((v) => v.trim())
  }
  if (Array.isArray(rule.value)) {
    return rule.value.map(String).filter((v) => v.trim())
  }
  if (rule.value !== undefined && rule.value !== null && String(rule.value).trim() !== '') {
    return [String(rule.value)]
  }
  return []
}

const firstRulesArray = (record: Record<string, unknown>): ApiGroupRule[] | null => {
  const metadata = record.metadata as Record<string, unknown> | undefined
  const sources = [
    record.groupRules,
    record.group_rules,
    record.rules,
    record.conditions,
    metadata?.groupRules,
    metadata?.group_rules,
  ]
  for (const source of sources) {
    if (Array.isArray(source) && source.length > 0) {
      return source as ApiGroupRule[]
    }
  }
  return null
}

export const extractGroupRulesRaw = (group: Record<string, unknown>): ApiGroupRule[] | null =>
  firstRulesArray(group)

export const parseGroupRulesFromApi = (
  group: Record<string, unknown>,
  defaultField = '',
): ServerGroupRule[] => {
  const rules = extractGroupRulesRaw(group)
  if (!rules) return []

  return rules.map((rule) => ({
    field: String(rule.field ?? defaultField),
    operator: normalizeOperator(String(rule.operator ?? 'is')),
    values: ruleValuesFromApi(rule),
  }))
}

export const resolveServerGroupRecord = (response: unknown): Record<string, unknown> => {
  if (!response || typeof response !== 'object') return {}

  const root = response as Record<string, unknown>
  const level1 = (root.data ?? root) as Record<string, unknown>
  if (!level1 || typeof level1 !== 'object' || Array.isArray(level1)) return {}

  const nested = level1.data ?? level1.serverGroup ?? level1.server_group ?? level1.record
  let record = level1
  if (nested && typeof nested === 'object' && !Array.isArray(nested)) {
    record = { ...level1, ...(nested as Record<string, unknown>) }
  }

  if (!extractGroupRulesRaw(record) && root !== level1) {
    const outerRules = firstRulesArray(root)
    if (outerRules) {
      record = { ...record, groupRules: outerRules }
    }
  }

  return record
}

export const resolveRuleLogic = (group: Record<string, unknown>): ServerGroupRuleLogic => {
  const upper = String(group.ruleLogic ?? group.rule_logic ?? 'AND').toUpperCase()
  return upper === 'OR' || upper === 'ANY' ? 'OR' : 'AND'
}

export interface ServerGroupPayload {
  id?: string
  name: string
  description?: string
  groupType: 'DYNAMIC' | 'STATIC'
  ruleLogic?: ServerGroupRuleLogic
  groupRules?: ServerGroupRule[]
  servers?: { hostname: string }[]
  tags?: string[]
  metadata?: Record<string, unknown>
}

export interface PreviewServerGroupPayload {
  groupRules: ServerGroupPreviewRule[]
  ruleLogic: ServerGroupRuleLogic
  page?: number
  limit?: number
}

export const serverGroupsSlice = createApi({
  reducerPath: 'serverGroupsApi',
  baseQuery,
  tagTypes: ['ServerGroup'],
  endpoints: (builder) => ({
    getServerGroups: builder.query<any, { page?: number; limit?: number; search?: string; groupType?: string; ruleLogic?: string }>({
      query: ({ page = 1, limit = 20, search, groupType, ruleLogic }: { page?: number; limit?: number; search?: string; groupType?: string; ruleLogic?: string }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) })
        if (search) params.append('search', search)
        if (groupType) params.append('groupType', groupType)
        if (ruleLogic) params.append('ruleLogic', ruleLogic)
        return `/server-groups?${params.toString()}`
      },
      providesTags: ['ServerGroup'],
    }),
    getServerGroupById: builder.query<any, string>({
      query: (id) => `/server-groups/${id}`,
      providesTags: (_r, _e, id) => [{ type: 'ServerGroup', id }],
    }),
    previewServerGroupServers: builder.mutation<any, PreviewServerGroupPayload>({
      query: (body) => ({
        url: '/server-groups/records/query',
        method: 'POST',
        body,
      }),
    }),
    createServerGroup: builder.mutation<any, ServerGroupPayload>({
      query: (body) => ({ url: '/server-groups/create', method: 'POST', body }),
      invalidatesTags: ['ServerGroup'],
    }),
    updateServerGroup: builder.mutation<any, { id: string; data: ServerGroupPayload }>({
      query: ({ id, data }) => ({ url: `/server-groups/${id}`, method: 'PUT', body: data }),
      invalidatesTags: (_r, _e, { id }) => [{ type: 'ServerGroup', id }, 'ServerGroup'],
    }),
    deleteServerGroup: builder.mutation<any, string>({
      query: (id) => ({ url: `/server-groups/${id}`, method: 'DELETE' }),
      invalidatesTags: ['ServerGroup'],
    }),
  }),
})

export interface PreviewServer {
  hostname: string
  region?: string
  environment?: string
  service?: string
  sid?: string
  application?: string
  businessService?: string
  owner?: string
  serverType?: string
  os?: string
  status?: string
  createdDate?: string
  lastUpdated?: string
  env?: string
}

export const toServerHostnameEntry = (server: PreviewServer | { hostname?: string } | string) => {
  const hostname = typeof server === 'string' ? server : server.hostname
  return hostname ? { hostname } : null
}

export const toServerHostnameList = (
  servers: Array<PreviewServer | { hostname?: string } | string>,
): { hostname: string }[] =>
  servers
    .map(toServerHostnameEntry)
    .filter((entry): entry is { hostname: string } => entry !== null)

export const parsePreviewServersResponse = (
  response: unknown,
): { servers: PreviewServer[]; total: number } => {
  const payload = (response as { data?: unknown })?.data ?? response

  if (Array.isArray(payload)) {
    return { servers: payload as PreviewServer[], total: payload.length }
  }

  if (payload && typeof payload === 'object') {
    const record = payload as Record<string, unknown>
    const serversRaw = record.records
      ?? record.servers
      ?? record.data
      ?? record.matchingServers
      ?? record.matching_servers
      ?? []
    const servers = Array.isArray(serversRaw) ? (serversRaw as PreviewServer[]) : []
    const total = Number(record.total ?? record.count ?? servers.length)
    return { servers, total: Number.isFinite(total) ? total : servers.length }
  }

  return { servers: [], total: 0 }
}

export const {
  useGetServerGroupsQuery,
  useGetServerGroupByIdQuery,
  usePreviewServerGroupServersMutation,
  useCreateServerGroupMutation,
  useUpdateServerGroupMutation,
  useDeleteServerGroupMutation,
} = serverGroupsSlice
