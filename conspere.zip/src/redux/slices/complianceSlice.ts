import { createApi } from "@reduxjs/toolkit/query/react";
import { baseQuery } from "../../services/baseQuery";

export type DriftLogFilters = {
  search?: string;
  driftDetected?: boolean;
  status?: string;
  severity?: string;
  hostname?: string;
  region?: string;
  os?: string;
  sid?: string;
  owner?: string;
  application?: string;
  environment?: string;
  ruleId?: string;
  ruleName?: string;
  ruleType?: string;
  policyId?: string;
  policyName?: string;
  executionStatus?: string;
  businessUnit?: string;
  assignmentName?: string;
  assignmentId?: string;
  filePath?: string;
  serviceName?: string;
  actionTaken?: string;
};

export type DriftLogExecutionDataRequest = {
  page?: number;
  limit?: number;
  filters?: DriftLogFilters;
};

export type DriftLogExecutionMetricsRequest = {
  filters?: DriftLogFilters;
};

const sanitizeDriftLogFilters = (filters: DriftLogFilters = {}): DriftLogFilters => {
  const result: DriftLogFilters = {};

  Object.entries(filters).forEach(([key, value]) => {
    if (value === undefined || value === null || value === "") return;
    if (typeof value === "string" && !value.trim()) return;
    (result as Record<string, string | boolean>)[key] =
      typeof value === "string" ? value.trim() : value;
  });

  return result;
};

export const complianceSlice = createApi({
  reducerPath: "complianceApi",
  baseQuery,
  tagTypes: ["Compliance"],
  endpoints: (builder) => ({
    getComplianceRecords: builder.query<any, { page?: number; limit?: number; status?: string }>({
      query: ({ page = 1, limit = 10, status }) => {
        const params = new URLSearchParams({ page: String(page), limit: String(limit) });
        if (status) params.append("status", status);
        return `/compliance?${params.toString()}`;
      },
      providesTags: ["Compliance"],
    }),
    getComplianceSummary: builder.query<any, void>({
      query: () => "/compliance/summary",
    }),
    getComplianceById: builder.query<any, string>({
      query: (id) => `/compliance/${id}`,
    }),
    createComplianceRecord: builder.mutation<any, Partial<any>>({
      query: (body) => ({ url: "/compliance", method: "POST", body }),
      invalidatesTags: ["Compliance"],
    }),
    getDashboardSummary: builder.query<any, void>({
      query: () => "/dashboard/summary",
    }),
    getComplianceTrend: builder.query<any, void>({
      query: () => "/compliance/trend",
    }),
    getDriftExecutionData: builder.query<any, DriftLogExecutionDataRequest>({
      query: ({ page = 1, limit = 10, filters = {} }) => ({
        url: "/drift-logs/execution-data",
        method: "POST",
        body: {
          page,
          limit,
          filters: sanitizeDriftLogFilters(filters),
        },
      }),
    }),
    getDriftExecutionMetrics: builder.query<any, DriftLogExecutionMetricsRequest>({
      query: ({ filters = {} }) => ({
        url: "/drift-logs/execution-metrics",
        method: "POST",
        body: {
          filters: sanitizeDriftLogFilters(filters),
        },
      }),
    }),
    getDriftLogFilters: builder.query<any, void>({
      query: () => "/drift-logs/filters-data",
    }),
    postCommandLogs: builder.mutation<
      any,
      { hostname: string; command: string; timestamp?: string }
    >({
      query: ({ hostname, command, timestamp }) => ({
        url: "/drift-logs/command-logs",
        method: "POST",
        body: {
          hostname,
          command,
          ...(timestamp ? { timestamp } : {}),
        },
      }),
    }),
    getRemediationEvents: builder.query<any, { page?: number; limit?: number }>({
      query: ({ page = 1, limit = 10 }) =>
        `/remediation-events?page=${page}&limit=${limit}`,
    }),
  }),
});

export const {
  useGetComplianceRecordsQuery,
  useGetComplianceSummaryQuery,
  useGetComplianceByIdQuery,
  useCreateComplianceRecordMutation,
  useGetDashboardSummaryQuery,
  useGetComplianceTrendQuery,
  useGetDriftExecutionDataQuery,
  useGetDriftExecutionMetricsQuery,
  useGetDriftLogFiltersQuery,
  usePostCommandLogsMutation,
  useGetRemediationEventsQuery,
} = complianceSlice;
