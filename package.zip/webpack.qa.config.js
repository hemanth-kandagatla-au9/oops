const { merge } = require("webpack-merge");

const webpack = require("webpack");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const commonConfig = require("./webpack.common.js");
const deps = require("./package.json").dependencies;

const devConfig = merge(commonConfig, {
  mode: "development",
  output: {
    // publicPath: 'https://qa.iasp.apps.jnj.com/',
    publicPath: 'auto',
  },
   devServer: {
    headers: {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  },
    client: {
      overlay: false,
    },
  },
  plugins: [
    new ModuleFederationPlugin({
      name: "star",
      filename: "remoteEntry.js",
      remotes: {
        workflow: `workflow@https://qa.workflow.ias.apps.jnj.com/remoteEntry.js?v=${Date.now()}`,
        Insights: `Insights@https://qa.insights.ias.apps.jnj.com/remoteEntry.js?v=${Date.now()}`,
        risebot: `risebot@https://qa.agent.ias.apps.jnj.com/remoteEntry.js?v=${Date.now()}`,
        InsightsAuth: `InsightsAuth@https://qa.insightsauth.ias.apps.jnj.com/remoteEntry.js?v=${Date.now()}`,
        WorkflowAuth : `WorkflowAuth@https://qa.workflow-auth.ias.apps.jnj.com/remoteEntry.js?v=${Date.now()}`,
        ApiGateway: `ApiGateway@https://qa.gateway.ias.apps.jnj.com/remoteEntry.js?v=${Date.now()}`
      },
      shared: {
        ...deps,
        react: {
          singleton: true,
          requiredVersion: deps.react,
        },
        "react-redux": {
          singleton: true,
          requiredVersion: deps["react-redux"],
        },
        "@mui/x-data-grid": {
          singleton: true,
          requiredVersion: deps["@mui/x-data-grid"],
        },
        "react-typed": {
          singleton: true,
          requiredVersion: deps["react-typed"],
        },
      },
    }),
    new webpack.DefinePlugin({
      "process.env": JSON.stringify({
        GENERATE_SOURCEMAP: false,
        SKIP_PREFLIGHT_CHECK: true,
        REACT_APP_CLIENTID: "407b5b20-2700-4aa2-86a0-d1abfea64386",
        REACT_APP_AUTHORITY_URL: "https://login.microsoftonline.com/3ac94b33-9135-4821-9502-eafda6592a35/",
        REACT_APP_REDIRECTURI: "https://qa.ias.apps.jnj.com/",
        REACT_APP_POSTLOGOUTREDIRECTURI: "https://qa.ias.apps.jnj.com/logout",
        AUTH_API_URL:`https://qa.insightsauth.ias.apps.jnj.com/api/insightsauth`,
         REACT_APP_BACKEND_URL:
          "https://qa.insights.ias.apps.jnj.com/api/insights/",
        IACRYPT_URL : `https://qa.iacrypt.ias.apps.jnj.com/`,
         }),
    }),
  ],
});

module.exports = devConfig;
