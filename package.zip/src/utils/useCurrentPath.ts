/* eslint-disable no-empty */
import { useEffect, useRef, useState } from 'react';

try {
  const _push = window.history.pushState.bind(window.history);
  const _replace = window.history.replaceState.bind(window.history);

  Object.defineProperty(window.history, 'pushState', {
    configurable: true,
    value: function (...args: Parameters<typeof _push>) {
      _push(...args);
      window.dispatchEvent(new Event('__pathchange__'));
    },
  });

  Object.defineProperty(window.history, 'replaceState', {
    configurable: true,
    value: function (...args: Parameters<typeof _replace>) {
      _replace(...args);
      window.dispatchEvent(new Event('__pathchange__'));
    },
  });
} catch (_) {}

export const useCurrentPath = () => {
  const [currentPath, setCurrentPath] = useState(window.location.pathname);
  const ref = useRef(currentPath);

  useEffect(() => {
    const sync = () => {
      const next = window.location.pathname;
      if (next !== ref.current) {
        ref.current = next;
        setCurrentPath(next);
      }
    };

    window.addEventListener('__pathchange__', sync);
    window.addEventListener('popstate', sync);
    const id = setInterval(sync, 200);

    return () => {
      window.removeEventListener('__pathchange__', sync);
      window.removeEventListener('popstate', sync);
      clearInterval(id);
    };
  }, []);

  return currentPath;
};
