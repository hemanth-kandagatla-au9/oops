export const shouldHideHeader = (pathname: string): boolean => {
  const cleanPath = pathname.length > 1 ? pathname.replace(/\/+$/, '') : pathname;

  return (
    // workflow routes
    cleanPath === '/app/workflow/myspace-add' ||
    cleanPath === '/app/workflow/helpcontent' ||
    /^\/app\/workflow\/capability\/[^/]+$/.test(cleanPath) ||
    // service account routes
    /^\/app\/workflow\/service-account\/serviceAccountId\/[^/]+$/.test(cleanPath) ||
    // approval request detail
    /^\/app\/cm-approvalrequest\/[^/]+$/.test(cleanPath) ||
    // request status detail
    /^\/app\/cm-requeststatus\/[^/]+$/.test(cleanPath) ||
    // pipeline create
    cleanPath === '/app/pipeline-configuration/create' ||
    // pipeline edit
    /^\/app\/pipeline-configuration\/[^/]+$/.test(cleanPath) ||
    // pipeline view
    /^\/app\/pipeline-configuration\/view\/[^/]+$/.test(cleanPath) ||
    // rise agent bulk action logs
    cleanPath.startsWith('/app/riseagent/bulkActionLogs')
  );
};
