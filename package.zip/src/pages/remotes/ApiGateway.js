import safeLazy from '../../utils/safeLazy';

export const ApiGatewayApp = safeLazy(() => import('ApiGateway/App'));
