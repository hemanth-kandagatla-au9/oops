# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html)

## [Unreleased]

## [2.0.1] - 2026-06-04

## [1.0.15] - 2026-06-03

## [1.0.14] - 2026-05-19

## [1.0.12] - 2026-04-29

## [1.0.11] - 2026-04-29

## [1.0.9] - 2026-03-25

## [1.0.8] - 2026-03-25

## [1.0.7] - 2026-03-24

## [1.0.2] - 2026-03-07

## [1.0.1] - 2026-02-26


[Unreleased]: https://sourcecode.jnj.com/projects/ASX-JJCW/repos/iasphere-platform-mf/compare/diff?targetBranch=refs%2Ftags%2F2.0.1&sourceBranch=refs%2Fheads%2Fdevelop
[2.0.1]: https://sourcecode.jnj.com/projects/ASX-JJCW/repos/iasphere-platform-mf/compare/diff?targetBranch=refs%2Ftags%2F2.0.1-rc&sourceBranch=refs%2Ftags%2F2.0.1
[1.0.15]: https://sourcecode.jnj.com/projects/ASX-JJCW/repos/iasphere-platform-mf/compare/diff?targetBranch=refs%2Ftags%2F1.0.15-rc&sourceBranch=refs%2Ftags%2F1.0.15
[1.0.14]: https://sourcecode.jnj.com/projects/ASX-JJCW/repos/iasphere-platform-mf/compare/diff?targetBranch=refs%2Ftags%2F1.0.14-rc&sourceBranch=refs%2Ftags%2F1.0.14
[1.0.12]: https://sourcecode.jnj.com/projects/ASX-JJCW/repos/iasphere-platform-mf/compare/diff?targetBranch=refs%2Ftags%2F1.0.12-rc&sourceBranch=refs%2Ftags%2F1.0.12
[1.0.11]: https://sourcecode.jnj.com/projects/ASX-JJCW/repos/iasphere-platform-mf/compare/diff?targetBranch=refs%2Ftags%2F1.0.11-rc&sourceBranch=refs%2Ftags%2F1.0.11
[1.0.9]: https://sourcecode.jnj.com/projects/ASX-JJCW/repos/iasphere-platform-mf/compare/diff?targetBranch=refs%2Ftags%2F1.0.8&sourceBranch=refs%2Ftags%2F1.0.9
[1.0.8]: https://sourcecode.jnj.com/projects/ASX-JJCW/repos/iasphere-platform-mf/compare/diff?targetBranch=refs%2Ftags%2F1.0.8-rc&sourceBranch=refs%2Ftags%2F1.0.8
[1.0.7]: https://sourcecode.jnj.com/projects/ASX-JJCW/repos/iasphere-platform-mf/compare/diff?targetBranch=refs%2Ftags%2F1.0.7-rc&sourceBranch=refs%2Ftags%2F1.0.7
[1.0.2]: https://sourcecode.jnj.com/projects/ASX-JJCW/repos/iasphere-platform-mf/compare/diff?targetBranch=refs%2Ftags%2F1.0.2-rc&sourceBranch=refs%2Ftags%2F1.0.2
[1.0.1]: https://sourcecode.jnj.com/projects/ASX-JJCW/repos/iasphere-platform-mf/compare/diff?targetBranch=refs%2Ftags%2F1.0.1-rc&sourceBranch=refs%2Ftags%2F1.0.1

