const { merge } = require("webpack-merge");

const webpack = require("webpack");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const commonConfig = require("./webpack.common.js");
const deps = require("./package.json").dependencies;

const devConfig = merge(commonConfig, {
  mode: "production",
  output: {
    // publicPath: 'https://ias.jnj.com/',
    publicPath: 'auto',
  },
   devServer: {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, PATCH, OPTIONS",
      "Access-Control-Allow-Headers":
        "X-Requested-With, content-type, Authorization",
    }
  },
  plugins: [
    new ModuleFederationPlugin({
      name: "star",
      filename: "remoteEntry.js",
      remotes: {
        workflow: `workflow@https://workflow.ias.jnj.com/remoteEntry.js?v=${Date.now()}`,
        Insights: `Insights@https://insights.ias.jnj.com/remoteEntry.js?v=${Date.now()}`,
        risebot:`risebot@https://agent.ias.jnj.com/remoteEntry.js?v=${Date.now()}`,
        InsightsAuth: `InsightsAuth@https://insightsauth.ias.jnj.com/remoteEntry.js?v=${Date.now()}`,
        WorkflowAuth : `WorkflowAuth@https://workflow-auth.ias.jnj.com/remoteEntry.js?v=${Date.now()}`,
        ApiGateway: `ApiGateway@https://gateway.ias.jnj.com/remoteEntry.js?v=${Date.now()}`
      },
      shared: {
        ...deps,
        react: {
          singleton: true,
          requiredVersion: deps.react,
        },
        "react-redux": {
          singleton: true,
          requiredVersion: deps["react-redux"],
        },
        "@mui/x-data-grid": {
          singleton: true,
          requiredVersion: deps["@mui/x-data-grid"],
        },
        "react-typed": {
          singleton: true,
          requiredVersion: deps["react-typed"],
        },
      },
    }),
    new webpack.DefinePlugin({
      "process.env": JSON.stringify({
        GENERATE_SOURCEMAP: false,
        SKIP_PREFLIGHT_CHECK: true,
        REACT_APP_CLIENTID: "ccf0c2f3-740b-448b-998c-91a9667af567",
        REACT_APP_AUTHORITY_URL: "https://login.microsoftonline.com/3ac94b33-9135-4821-9502-eafda6592a35/",
        REACT_APP_REDIRECTURI: "https://ias.jnj.com/",
        REACT_APP_POSTLOGOUTREDIRECTURI: "https://ias.jnj.com/logout",
        AUTH_API_URL:`https://insightsauth.ias.jnj.com/api/insightsauth`,
          REACT_APP_BACKEND_URL:
          "https://insights.ias.jnj.com/api/insights/",
        IACRYPT_URL :`https://iacrypt.ias.jnj.com/`,
         }),
    }),
  ],
});

module.exports = devConfig;
