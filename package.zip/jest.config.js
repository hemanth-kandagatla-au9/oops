module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  // Stabilize URL normalization for jsdom (prevents href surprises)
  testEnvironmentOptions: { url: 'http://localhost/' },

  roots: ['<rootDir>/src'],
  testMatch: [
    '**/__tests__/**/*.+(ts|tsx|js)',
    '**/?(*.)+(spec|test).+(ts|tsx|js)',
  ],

  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node'],
  moduleNameMapper: {
    '^.+\\.module\\.(css|sass|scss)$': 'identity-obj-proxy',
    '^.+\\.(css|sass|scss)$': '<rootDir>/src/__mocks__/styleMock.js',
    '\\.(jpg|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$':
      '<rootDir>/src/__mocks__/fileMock.js',
  },

  setupFilesAfterEnv: ['<rootDir>/src/setupTests.ts'],

  collectCoverageFrom: [
    'src/**/*.{js,jsx,ts,tsx}',
    '!src/**/*.d.ts',
    '!src/index.ts',
    '!src/bootstrap.tsx',
    '!src/**/*.stories.{js,jsx,ts,tsx}',
    '!src/__mocks__/**',
    '!src/**/__tests__/**',
  ],

  coverageThreshold: {
    global: {
      branches: 50,
      functions: 50,
      lines: 50,
      statements: 50,
    },
  },

  testPathIgnorePatterns: ['/node_modules/', '/dist/', '/build/'],

  // Let these ESM libs be transformed by Jest
  transformIgnorePatterns: ['node_modules/(?!(react-redux|@reduxjs|@azure)/)'],

  // Rely on preset ts-jest for TS; keep babel-jest only for JS/JSX
  transform: {
    '^.+\\.(js|jsx)$': 'babel-jest',
  },

  // Keep test state isolated
  clearMocks: true,
  resetMocks: true,
  restoreMocks: true,
};
