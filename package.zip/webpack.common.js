const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const { ModuleFederationPlugin } = require('webpack').container;
const Dotenv = require('dotenv-webpack');
process.env.NODE_ENV = "development";
process.env.BABEL_ENV = "development";
module.exports = {
    entry: './src/index.ts',
    output: {
        path: path.resolve(__dirname, 'dist'),
        publicPath: 'auto',
        filename: '[name].[contenthash].js',
        uniqueName: "start",
        clean: true,
    },
    devServer: {
  headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, PATCH, OPTIONS",
    "Access-Control-Allow-Headers": "X-Requested-With, content-type, Authorization"
  },
   
        open: ["/"],
        static: {
            directory: path.join(__dirname, "public"),
        },
        client: {
            overlay: false,
        },
        port: 3006,
        hot: false,
        compress: true,
        historyApiFallback: true,
        allowedHosts: "all",

    },
    resolve: {
          extensions: ['.tsx', '.ts', '.js', '.scss', '.css', '.jsx'],
          fullySpecified: false,
        
        fallback: {
            process: require.resolve("process/browser"),
            buffer: require.resolve("buffer/"),
            stream: require.resolve("stream-browserify"),
            zlib: require.resolve("browserify-zlib"),
            crypto: require.resolve("crypto-browserify"),
            http: require.resolve("stream-http"),
            https: require.resolve("https-browserify"),
            os: require.resolve("os-browserify/browser"),
            url: require.resolve("url/"),
            vm:false
  }
    },


    module: {
        rules: [
            {
                test: /\.(png|jpg|jpeg|gif|ico|ttf|woff2|eot|woff)$/,
                use: ["file-loader?name=[name].[ext]"],
            },
            {
                test: /\.(js|jsx|mjs)$/,
                exclude: /node_modules/,
                use: {
                    loader: "babel-loader",
                },
            },
            {
                test: /\.svg$/,
                use: [
                    {
                        loader: 'file-loader',
                        options: {
                            name: '[name].[hash].[ext]',
                            outputPath: 'images'
                        }
                    }
                ]
            },
            {
                test: /\.(ts|tsx)$/,
                loader: 'ts-loader',
                exclude: /node_modules/,
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader'],
            },
            {
                test: /\.module\.css$/,
                use: ['style-loader', { loader: 'css-loader', options: { modules: true } }],
            },
            {
                test: /\.scss$/,
                use: [
                    "style-loader",
                    "css-loader",
                    {
                        loader: "sass-loader",
                        options: {
                            implementation: require("sass"),
                        },
                    },
                ],
            },
        ],
    },

    plugins: [
        new HtmlWebpackPlugin({
            template: path.join(__dirname, "public", "index.html"),
            publicPath: "/",
        }),
        new webpack.ProvidePlugin({
            Buffer: ["buffer", "Buffer"],
            process: "process",
            // assert: "assert",    
        }),
    ],
}