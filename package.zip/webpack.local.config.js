const { merge } = require("webpack-merge");
const webpack = require("webpack");
const { ModuleFederationPlugin } = require("webpack").container;
const commonConfig = require("./webpack.common.js");
const deps = require("./package.json").dependencies;
const path = require("path");
const today = new Date();
today.setHours(0, 0, 0, 0);
const timestamp = today.getTime();

const devConfig = merge(commonConfig, {
  mode: "development",
  devtool: "source-map",
  output: {
    publicPath:"http://localhost:3006/"
    // publicPath: "auto",
  },
  devServer: {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, PATCH, OPTIONS",
      "Access-Control-Allow-Headers":
        "X-Requested-With, content-type, Authorization",
    },
    client: {
      overlay: false,
    },
  },
  plugins: [
    new ModuleFederationPlugin({
      name: "star",
      filename: "remoteEntry.js",
      remotes: {
        workflow: `workflow@http://localhost:3002/remoteEntry.js`,
        Insights: `Insights@http://localhost:3000/remoteEntry.js`,
        risebot: `risebot@http://localhost:3005/remoteEntry.js`,
        InsightsAuth: `InsightsAuth@http://localhost:3001/remoteEntry.js`,
        WorkflowAuth : `WorkflowAuth@http://localhost:3004/remoteEntry.js`,
        ApiGateway: `ApiGateway@http://localhost:3007/remoteEntry.js`,

        // workflow: `workflow@https://predev.workflow.ias.apps.jnj.com/remoteEntry.js?v=${Date.now()}`,
        // ApiGateway: `ApiGateway@https://predev.gateway.ias.apps.jnj.com/remoteEntry.js?v=${Date.now()}`,

        // Insights: `Insights@https://predev.insights.ias.apps.jnj.com/remoteEntry.js?v=${Date.now()}`,
        // risebot:`risebot@https://predev.agent.ias.apps.jnj.com/remoteEntry.js?v=${Date.now()}`,
        // InsightsAuth: `InsightsAuth@https://predev.insightsauth.ias.apps.jnj.com/remoteEntry.js?v=${Date.now()}`,
        // WorkflowAuth : `WorkflowAuth@https://predev.workflow-auth.ias.apps.jnj.com/remoteEntry.js?v=${Date.now()}`
      },

      shared: {
        react: {
          singleton: true,
          requiredVersion: deps.react,
        },
        "react-dom": {
          singleton: true,
          requiredVersion: deps["react-dom"],
        },
        "react-router-dom": {
          singleton: true,
          requiredVersion: deps["react-router-dom"],
        },
        "react/jsx-runtime": { singleton: true, requiredVersion: deps.react },
        "react/jsx-dev-runtime": {
          singleton: true,
          requiredVersion: deps.react,
        },
         "react-bootstrap": {
          singleton: true,
          requiredVersion: deps["react-bootstrap"],
        },
        redux: { singleton: true, requiredVersion: deps.redux },
  "@reduxjs/toolkit": { singleton: true, requiredVersion: deps["@reduxjs/toolkit"] },
  "react-redux": { singleton: true, requiredVersion: deps["react-redux"] },


        // "react-typed": { singleton: true, requiredVersion: deps["react-typed"] },
      },
    }),
    new webpack.DefinePlugin({
      "process.env": JSON.stringify({
        GENERATE_SOURCEMAP: false,
        SKIP_PREFLIGHT_CHECK: true,
        REACT_APP_CLIENTID: "407b5b20-2700-4aa2-86a0-d1abfea64386",
        REACT_APP_AUTHORITY_URL:"https://login.microsoftonline.com/3ac94b33-9135-4821-9502-eafda6592a35/",
        REACT_APP_REDIRECTURI: "http://localhost:3006/",
        REACT_APP_POSTLOGOUTREDIRECTURI: "http://localhost:3006/logout",
        REACT_APP_BACKEND_URL:"https://predev.insights.ias.apps.jnj.com/api/insights/",
        AUTH_API_URL:`https://predev.insightsauth.ias.apps.jnj.com/api/insightsauth`,
        IACRYPT_URL : `https://predev.iacrypt.ias.apps.jnj.com/`,
        }),
    }),
  ],
});
module.exports = devConfig;
